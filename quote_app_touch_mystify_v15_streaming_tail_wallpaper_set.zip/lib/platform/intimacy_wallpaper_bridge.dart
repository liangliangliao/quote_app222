import 'dart:io' show Platform;

import 'package:flutter/services.dart';

class IntimacyWallpaperBridge {
  static const MethodChannel _channel = MethodChannel('com.example.quote_app/intimacy_wallpaper');

  static bool get isAndroid => Platform.isAndroid;

  static Future<bool> saveConfig({
    required int style,
    required double intimacy,
    required double randomness,
    required double ribbonWidth,
    required double trail,
    required double fullScreenCoverage,
    required double strokeDensity,
    required bool previewAccelerated,
    required double previewCycleMinutes,
    required bool bubbles,
    required bool powerSave,
    required bool randomCycle,
    required double cycleMinDays,
    required double cycleMaxDays,
    required double fixedCycleDays,
    required double ratioSeparation,
    required double ratioAttraction,
    required double ratioSync,
    required double ratioCritical,
    required double ratioRelease,
    required double ratioAfterglow,
    required double criticalMinSec,
    required double criticalMaxSec,
    required double releaseMinSec,
    required double releaseMaxSec,
    required double afterglowMinSec,
    required double afterglowMaxSec,
  }) async {
    if (!isAndroid) return false;
    final ok = await _channel.invokeMethod<bool>('saveConfig', <String, dynamic>{
      'style': style,
      'intimacy': intimacy,
      'randomness': randomness,
      'ribbonWidth': ribbonWidth,
      'trail': trail,
      'fullScreenCoverage': fullScreenCoverage,
      'strokeDensity': strokeDensity,
      'previewAccelerated': previewAccelerated,
      'previewCycleMinutes': previewCycleMinutes,
      'bubbles': bubbles,
      'powerSave': powerSave,
      'randomCycle': randomCycle,
      'cycleMinDays': cycleMinDays,
      'cycleMaxDays': cycleMaxDays,
      'fixedCycleDays': fixedCycleDays,
      'ratioSeparation': ratioSeparation,
      'ratioAttraction': ratioAttraction,
      'ratioSync': ratioSync,
      'ratioCritical': ratioCritical,
      'ratioRelease': ratioRelease,
      'ratioAfterglow': ratioAfterglow,
      'criticalMinSec': criticalMinSec,
      'criticalMaxSec': criticalMaxSec,
      'releaseMinSec': releaseMinSec,
      'releaseMaxSec': releaseMaxSec,
      'afterglowMinSec': afterglowMinSec,
      'afterglowMaxSec': afterglowMaxSec,
    });
    return ok == true;
  }

  static Future<bool> setLiveWallpaperDirect() async {
    if (!isAndroid) return false;
    try {
      final ok = await _channel.invokeMethod<bool>('setLiveWallpaperDirect');
      return ok == true;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> openLiveWallpaper() async {
    if (!isAndroid) return false;
    final ok = await _channel.invokeMethod<bool>('openLiveWallpaper');
    return ok == true;
  }

  static Future<bool> isSupported() async {
    if (!isAndroid) return false;
    final ok = await _channel.invokeMethod<bool>('isSupported');
    return ok == true;
  }
}
