package com.example.quote_app

import android.app.Activity
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.InputType
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

/**
 * V30：预设行为系统闹钟全屏确认表单。
 *
 * 由 AlarmManager 到点触发，通知 fullScreenIntent 直接拉起这个原生 Activity。
 * 用户无需进入 Flutter 首页，可直接填写“完成 / 未完成 / 跳过”。
 */
class BehaviorPresetAlarmFormActivity : Activity() {
  private var payload = JSONObject()
  private lateinit var actualValue: EditText
  private lateinit var actualDuration: EditText
  private lateinit var note: EditText
  private var mediaPlayer: MediaPlayer? = null
  private var vibrator: Vibrator? = null

  override fun onCreate(savedInstanceState: Bundle?) {
    requestWindowFeature(Window.FEATURE_NO_TITLE)
    super.onCreate(savedInstanceState)
    if (Build.VERSION.SDK_INT >= 27) {
      setShowWhenLocked(true)
      setTurnScreenOn(true)
    } else {
      @Suppress("DEPRECATION")
      window.addFlags(
        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
          WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
          WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
      )
    }
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    try { payload = JSONObject(intent?.getStringExtra("payload") ?: "{}") } catch (_: Throwable) {}
    startAlarmSignal()
    buildUi()
  }

  override fun onDestroy() {
    stopAlarmSignal()
    super.onDestroy()
  }

  private fun startAlarmSignal() {
    try {
      val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
      if (alarmUri != null) {
        mediaPlayer = MediaPlayer().apply {
          setDataSource(this@BehaviorPresetAlarmFormActivity, alarmUri)
          if (Build.VERSION.SDK_INT >= 21) {
            setAudioAttributes(
              AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            )
          } else {
            @Suppress("DEPRECATION")
            setAudioStreamType(AudioManager.STREAM_ALARM)
          }
          isLooping = true
          prepare()
          start()
        }
      }
    } catch (t: Throwable) {
      try { com.example.quote_app.data.DbRepo.log(this, null, "[BehaviorPresetAlarm] play alarm sound failed: ${t.javaClass.simpleName} ${t.message}") } catch (_: Throwable) {}
    }

    if (!payload.optBoolean("alarmVibrate", true)) return
    try {
      vibrator = if (Build.VERSION.SDK_INT >= 31) {
        (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
      } else {
        @Suppress("DEPRECATION")
        getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
      }
      val pattern = longArrayOf(0L, 800L, 450L, 800L, 450L)
      if (Build.VERSION.SDK_INT >= 26) {
        vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
      } else {
        @Suppress("DEPRECATION")
        vibrator?.vibrate(pattern, 0)
      }
    } catch (t: Throwable) {
      try { com.example.quote_app.data.DbRepo.log(this, null, "[BehaviorPresetAlarm] vibrate failed: ${t.javaClass.simpleName} ${t.message}") } catch (_: Throwable) {}
    }
  }

  private fun stopAlarmSignal() {
    try {
      mediaPlayer?.let { player ->
        try { if (player.isPlaying) player.stop() } catch (_: Throwable) {}
        try { player.release() } catch (_: Throwable) {}
      }
    } catch (_: Throwable) {}
    mediaPlayer = null
    try { vibrator?.cancel() } catch (_: Throwable) {}
    vibrator = null
  }

  private fun buildUi() {
    val presetName = payload.optString("presetName", "预设行为")
    val category = payload.optString("category", "未分类")
    val unit = payload.optString("unit", "次")
    val target = payload.opt("targetValue")?.toString()?.takeIf { it != "null" }.orEmpty()
    val duration = payload.optInt("defaultDurationMin", 0).takeIf { it > 0 }?.toString().orEmpty()

    val root = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(20), dp(26), dp(20), dp(20))
      setBackgroundColor(0xFFFFFFFF.toInt())
    }

    root.addView(TextView(this).apply {
      text = "预设行为闹钟"
      textSize = 28f
      setTextColor(0xFF0F172A.toInt())
      typeface = android.graphics.Typeface.DEFAULT_BOLD
    })
    root.addView(TextView(this).apply {
      text = "已按系统闹钟铃声响铃。确认后会停止响铃和震动，不会再发送通知提醒。"
      textSize = 15f
      setTextColor(0xFF64748B.toInt())
      setPadding(0, dp(8), 0, dp(16))
    })

    root.addView(card("行为", presetName))
    root.addView(card("类别", category))
    val goalText = listOf(
      if (target.isNotBlank()) "$target$unit" else "无固定量",
      if (duration.isNotBlank()) "默认 ${duration}分钟" else null
    ).filterNotNull().joinToString(" · ")
    root.addView(card("计划", goalText))

    actualValue = edit("实际完成量", if (target.isNotBlank()) target else "", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
    root.addView(actualValue)
    actualDuration = edit("实际时长（分钟）", duration, InputType.TYPE_CLASS_NUMBER)
    root.addView(actualDuration)
    note = edit("备注（可选）", "例如：分两次完成 / 身体不舒服 / 改到晚上", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE, 3)
    root.addView(note)

    val primary = Button(this).apply {
      text = "完成并保存记录"
      textSize = 16f
      setTextColor(0xFFFFFFFF.toInt())
      setBackgroundColor(0xFF4F5FA3.toInt())
      setOnClickListener { submit("done") }
    }
    root.addView(primary, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(16) })

    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
    row.addView(Button(this).apply { text = "未完成"; setOnClickListener { submit("missed") } }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(8) })
    row.addView(Button(this).apply { text = "跳过"; setOnClickListener { submit("skipped") } }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
    root.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(8) })

    val cancel = TextView(this).apply {
      text = "停止响铃，稍后再说"
      gravity = Gravity.CENTER
      textSize = 15f
      setTextColor(0xFF64748B.toInt())
      setPadding(0, dp(14), 0, 0)
      setOnClickListener { finish() }
    }
    root.addView(cancel)

    setContentView(ScrollView(this).apply { addView(root) })
  }

  private fun submit(status: String) {
    val saved = BehaviorObservationNativeRecorder.savePresetAlarmCheckIn(
      this,
      payload,
      status,
      actualValue.text?.toString()?.trim(),
      actualDuration.text?.toString()?.trim(),
      note.text?.toString()?.trim()
    )
    if (saved > 0L) {
      Toast.makeText(this, when (status) {
        "done" -> "已保存完成记录"
        "missed" -> "已记录未完成"
        else -> "已记录跳过"
      }, Toast.LENGTH_SHORT).show()
      finish()
    } else {
      Toast.makeText(this, "保存失败，请先打开一次 App 初始化数据库", Toast.LENGTH_LONG).show()
    }
  }

  private fun card(label: String, value: String): TextView = TextView(this).apply {
    text = "$label：$value"
    textSize = 16f
    setTextColor(0xFF0F172A.toInt())
    setPadding(dp(14), dp(12), dp(14), dp(12))
    setBackgroundColor(0xFFF8FAFC.toInt())
  }

  private fun edit(label: String, hintText: String, input: Int, lines: Int = 1): EditText = EditText(this).apply {
    hint = label + if (hintText.isNotBlank()) "，例如 $hintText" else ""
    textSize = 16f
    inputType = input
    minLines = lines
    maxLines = if (lines > 1) 4 else 1
    setSingleLine(lines == 1)
  }

  private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
}
