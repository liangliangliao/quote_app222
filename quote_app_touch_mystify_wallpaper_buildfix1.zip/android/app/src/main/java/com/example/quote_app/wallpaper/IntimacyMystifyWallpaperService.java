package com.example.quote_app.wallpaper;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.util.Random;

/**
 * 发现之旅/触摸：Mystify 风格动态艺术壁纸。
 *
 * 设计目标：
 * - 用 Windows Mystify 式的“少量主光带 + 黑底 + 随机变形 + 残影”表达亲密过程。
 * - 不绘制任何具象身体或露骨动作，只表达两股生命力的吸引、靠近、同步、升高、临界、释放、余韵。
 * - 作为 Live Wallpaper 时遵循可见性生命周期，不可见时停止渲染以降低电量消耗。
 */
public class IntimacyMystifyWallpaperService extends WallpaperService {
    static final String PREFS = "intimacy_mystify_wallpaper";

    @Override
    public Engine onCreateEngine() {
        return new MystifyEngine();
    }

    final class MystifyEngine extends Engine {
        private RenderThread renderThread;
        private boolean visible = false;

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            ensureThread(holder);
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            if (renderThread != null) renderThread.resize(width, height);
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            if (renderThread != null) renderThread.setVisible(visible);
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
        }

        @Override
        public void onDestroy() {
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
            super.onDestroy();
        }

        private void ensureThread(SurfaceHolder holder) {
            if (renderThread == null) {
                renderThread = new RenderThread(getApplicationContext(), holder);
                renderThread.setVisible(visible);
                renderThread.start();
            }
        }
    }

    static final class RenderThread extends Thread {
        private final Context context;
        private final SurfaceHolder holder;
        private final SharedPreferences prefs;
        private final Random random = new Random();

        private volatile boolean running = true;
        private volatile boolean visible = false;
        private int width = 1;
        private int height = 1;
        private Bitmap buffer;
        private Canvas bufferCanvas;

        private final Paint fadePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint corePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint thinPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bubblePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint clearPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bloomPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private Config cfg = new Config();
        private long lastConfigRead = 0L;
        private long startMs = SystemClock.elapsedRealtime();
        private float nextMorphAtSec = 20f;

        private Ribbon left;
        private Ribbon right;
        private float seedPhase = 0f;

        RenderThread(Context context, SurfaceHolder holder) {
            super("IntimacyMystifyWallpaperRenderer");
            this.context = context.getApplicationContext();
            this.holder = holder;
            this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            clearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            fadePaint.setStyle(Paint.Style.FILL);
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeCap(Paint.Cap.ROUND);
            glowPaint.setStrokeJoin(Paint.Join.ROUND);
            corePaint.setStyle(Paint.Style.STROKE);
            corePaint.setStrokeCap(Paint.Cap.ROUND);
            corePaint.setStrokeJoin(Paint.Join.ROUND);
            thinPaint.setStyle(Paint.Style.STROKE);
            thinPaint.setStrokeCap(Paint.Cap.ROUND);
            thinPaint.setStrokeJoin(Paint.Join.ROUND);
            bubblePaint.setStyle(Paint.Style.STROKE);
            bloomPaint.setStyle(Paint.Style.FILL);
            readConfig(true);
            randomizeRibbons();
        }

        void setVisible(boolean visible) { this.visible = visible; }
        void requestStop() { running = false; interrupt(); }

        synchronized void resize(int w, int h) {
            if (w <= 0 || h <= 0) return;
            width = w;
            height = h;
            if (buffer != null) buffer.recycle();
            buffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bufferCanvas = new Canvas(buffer);
            bufferCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
            randomizeRibbons();
        }

        @Override
        public void run() {
            long lastFrame = SystemClock.elapsedRealtime();
            while (running) {
                if (!visible) {
                    sleepQuiet(120);
                    lastFrame = SystemClock.elapsedRealtime();
                    continue;
                }
                long now = SystemClock.elapsedRealtime();
                float dt = Math.min(0.05f, (now - lastFrame) / 1000f);
                lastFrame = now;

                if (now - lastConfigRead > 900L) readConfig(false);
                drawFrame(now, dt);
                sleepQuiet(cfg.powerSave ? 42 : 28);
            }
        }

        private void drawFrame(long nowMs, float dt) {
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;
                if (width <= 2 || height <= 2) resize(canvas.getWidth(), canvas.getHeight());
                if (buffer == null || bufferCanvas == null) resize(canvas.getWidth(), canvas.getHeight());

                float sec = (nowMs - startMs) / 1000f;
                float cycle = 78f;
                float u = (sec % cycle) / cycle;
                Phase phase = Phase.of(u);
                float local = smooth((u - phase.start) / Math.max(0.001f, phase.end - phase.start));
                float intensity = clamp(phase.intensity * (0.72f + 0.56f * cfg.intimacy), 0f, 1.25f);
                float closeness = clamp(phase.closeness + (float)Math.sin(local * Math.PI) * 0.07f, 0f, 1f);
                float tension = clamp(phase.tension * (0.70f + 0.70f * cfg.intimacy), 0f, 1.25f);
                float release = phase.name.equals("释放") ? (float)Math.sin(local * Math.PI) : 0f;
                float after = phase.name.equals("余韵") ? local : 0f;

                if (sec > nextMorphAtSec) {
                    nextMorphAtSec = sec + 18f + random.nextFloat() * 22f;
                    randomizeRibbons();
                }

                int[] colors = palette(cfg.style);
                int bg = colors[4];
                // 每帧先对离屏残影层做半透明暗化，保留 Mystify 式拖尾。
                int fadeAlpha = (int)lerp(18f, 58f, 1f - cfg.trail);
                fadeAlpha += cfg.powerSave ? 9 : 0;
                fadePaint.setColor(withAlpha(bg, fadeAlpha));
                bufferCanvas.drawRect(0, 0, width, height, fadePaint);

                float cx = width * 0.5f + (float)Math.sin(sec * 0.045f + seedPhase) * width * 0.035f;
                float cy = height * 0.52f + (float)Math.cos(sec * 0.039f + seedPhase * 0.7f) * height * 0.035f;
                float dist = lerp(Math.min(width, height) * 0.34f, Math.min(width, height) * 0.045f, closeness);
                float orbit = sec * (0.20f + intensity * 0.22f) + seedPhase;
                float ax = cx - (float)Math.cos(orbit) * dist;
                float ay = cy - (float)Math.sin(orbit * 1.17f) * dist * 0.66f;
                float bx = cx + (float)Math.cos(orbit) * dist;
                float by = cy + (float)Math.sin(orbit * 1.17f) * dist * 0.66f;
                if (release > 0f) {
                    ax = lerp(ax, cx, release * 0.94f); ay = lerp(ay, cy, release * 0.94f);
                    bx = lerp(bx, cx, release * 0.94f); by = lerp(by, cy, release * 0.94f);
                }

                updateRibbon(left, ax, ay, width, height, dt, intensity, tension, cfg.randomness);
                updateRibbon(right, bx, by, width, height, dt, intensity, tension, cfg.randomness);

                drawBackgroundBreath(bufferCanvas, colors, cx, cy, intensity, release, after);
                drawRings(bufferCanvas, colors, cx, cy, sec, intensity, release, after);
                drawRibbon(bufferCanvas, left, colors[0], colors[1], intensity, tension, release, true);
                drawRibbon(bufferCanvas, right, colors[2], colors[3], intensity, tension, release, false);
                drawCenterPulse(bufferCanvas, colors, cx, cy, release, after, sec);
                if (cfg.bubbles) drawAfterglow(bufferCanvas, colors, cx, cy, sec, after, intensity);

                // 输出离屏层到壁纸 Surface。
                canvas.drawColor(bg);
                canvas.drawBitmap(buffer, 0, 0, null);
            } catch (Throwable ignored) {
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas); } catch (Throwable ignored) {}
                }
            }
        }

        private void drawBackgroundBreath(Canvas c, int[] colors, float cx, float cy, float intensity, float release, float after) {
            float r = Math.min(width, height) * (0.34f + intensity * 0.18f + release * 0.36f);
            bloomPaint.setShader(new RadialGradient(cx, cy, r, new int[]{withAlpha(colors[1], 38), withAlpha(colors[2], 18), Color.TRANSPARENT}, null, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, bloomPaint);
            bloomPaint.setShader(null);
        }

        private void drawRings(Canvas c, int[] colors, float cx, float cy, float sec, float intensity, float release, float after) {
            thinPaint.setShader(null);
            thinPaint.setStyle(Paint.Style.STROKE);
            for (int i = 0; i < 5; i++) {
                float rp = ((sec * (0.012f + intensity * 0.012f)) + i / 5f) % 1f;
                float rx = Math.min(width, height) * (0.08f + rp * 0.46f * (1f + release * 0.35f));
                float ry = rx * (0.42f + intensity * 0.06f);
                int a = (int)((1f - rp) * (22f + intensity * 44f + release * 90f) * (1f - after * 0.7f));
                thinPaint.setColor(withAlpha(Color.WHITE, a));
                thinPaint.setStrokeWidth(1.0f + intensity * 1.8f + release * 3f);
                c.save();
                c.rotate((sec * 2.1f + i * 11f) % 360f, cx, cy);
                c.drawOval(new RectF(cx - rx, cy - ry, cx + rx, cy + ry), thinPaint);
                c.restore();
            }
        }

        private void drawRibbon(Canvas c, Ribbon r, int colorA, int colorB, float intensity, float tension, float release, boolean cool) {
            Path path = r.path();
            float baseWidth = lerp(3.0f, 11.5f, cfg.ribbonWidth) * (0.78f + intensity * 0.80f + release * 0.45f);
            Shader shader = new LinearGradient(0, 0, width, height, withAlpha(colorA, 235), withAlpha(colorB, 235), Shader.TileMode.CLAMP);

            glowPaint.setShader(shader);
            glowPaint.setStrokeWidth(baseWidth * 5.8f);
            glowPaint.setAlpha((int)(42 + intensity * 66 + release * 60));
            glowPaint.setMaskFilter(new BlurMaskFilter(baseWidth * 1.9f, BlurMaskFilter.Blur.NORMAL));
            c.drawPath(path, glowPaint);

            glowPaint.setMaskFilter(null);
            glowPaint.setStrokeWidth(baseWidth * 2.2f);
            glowPaint.setAlpha((int)(70 + intensity * 70 + release * 58));
            c.drawPath(path, glowPaint);

            corePaint.setShader(shader);
            corePaint.setStrokeWidth(Math.max(1.4f, baseWidth * 0.62f));
            corePaint.setAlpha((int)(156 + intensity * 80));
            c.drawPath(path, corePaint);

            // 中央细线强化 Mystify 的银白高光。
            thinPaint.setShader(null);
            thinPaint.setColor(withAlpha(Color.WHITE, (int)(120 + intensity * 88)));
            thinPaint.setStrokeWidth(Math.max(1.0f, baseWidth * 0.18f));
            c.drawPath(path, thinPaint);
        }

        private void drawCenterPulse(Canvas c, int[] colors, float cx, float cy, float release, float after, float sec) {
            if (release <= 0.001f && after <= 0.001f) return;
            float radius = Math.min(width, height) * (0.05f + release * 0.72f + after * 0.12f);
            int alpha = (int)(release * 200 + after * 34);
            bloomPaint.setShader(new RadialGradient(cx, cy, radius, new int[]{withAlpha(Color.WHITE, alpha), withAlpha(colors[3], alpha / 3), Color.TRANSPARENT}, null, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, radius, bloomPaint);
            bloomPaint.setShader(null);
            if (release > 0f) {
                thinPaint.setStyle(Paint.Style.STROKE);
                thinPaint.setColor(withAlpha(colors[3], (int)(release * 160)));
                thinPaint.setStrokeWidth(2f + release * 5f);
                c.drawCircle(cx, cy, Math.min(width, height) * (0.08f + release * 0.42f), thinPaint);
            }
        }

        private void drawAfterglow(Canvas c, int[] colors, float cx, float cy, float sec, float after, float intensity) {
            if (after <= 0.02f) return;
            bubblePaint.setStyle(Paint.Style.STROKE);
            for (int i = 0; i < 10; i++) {
                float a = (float)(i * Math.PI * 2 / 10f + sec * (0.08f + i * 0.006f) + seedPhase);
                float rr = Math.min(width, height) * (0.11f + i * 0.022f + after * 0.15f);
                float x = cx + (float)Math.cos(a) * rr;
                float y = cy + (float)Math.sin(a * 1.23f) * rr * 0.66f;
                float r = Math.min(width, height) * (0.018f + i * 0.003f);
                int alpha = (int)((1f - Math.abs(0.5f - after)) * 34f * (1f - i * 0.055f));
                bubblePaint.setColor(withAlpha(i % 2 == 0 ? colors[1] : colors[2], alpha));
                bubblePaint.setStrokeWidth(1.0f + i * 0.05f);
                c.drawCircle(x, y, r, bubblePaint);
            }
        }

        private void updateRibbon(Ribbon r, float targetX, float targetY, int w, int h, float dt, float intensity, float tension, float randomness) {
            float anchorStrength = 0.020f + intensity * 0.035f;
            float jitter = (0.18f + randomness * 0.95f) * (0.7f + tension);
            for (int i = 0; i < r.count; i++) {
                float rel = (i - (r.count - 1) * 0.5f) / Math.max(1f, (r.count - 1) * 0.5f);
                float desiredX = targetX + rel * w * (0.10f + 0.07f * randomness) + (float)Math.sin(seedPhase + i * 1.7f) * w * 0.025f * tension;
                float desiredY = targetY + (float)Math.sin(i * 0.92f + seedPhase) * h * (0.055f + 0.018f * randomness) * (0.6f + tension);
                r.vx[i] += (desiredX - r.x[i]) * anchorStrength * dt * 60f;
                r.vy[i] += (desiredY - r.y[i]) * anchorStrength * dt * 60f;
                r.vx[i] += (random.nextFloat() - 0.5f) * jitter * 18f;
                r.vy[i] += (random.nextFloat() - 0.5f) * jitter * 18f;
                r.x[i] += r.vx[i] * dt * 60f;
                r.y[i] += r.vy[i] * dt * 60f;
                r.vx[i] *= 0.955f;
                r.vy[i] *= 0.955f;
                float pad = 32f;
                if (r.x[i] < pad || r.x[i] > w - pad) r.vx[i] *= -0.82f;
                if (r.y[i] < pad || r.y[i] > h - pad) r.vy[i] *= -0.82f;
                r.x[i] = clamp(r.x[i], pad, w - pad);
                r.y[i] = clamp(r.y[i], pad, h - pad);
            }
        }

        private void randomizeRibbons() {
            seedPhase = random.nextFloat() * (float)Math.PI * 2f;
            left = new Ribbon(7);
            right = new Ribbon(7);
            float w = Math.max(360f, width);
            float h = Math.max(640f, height);
            initRibbon(left, w * 0.25f, h * 0.52f, -1f);
            initRibbon(right, w * 0.75f, h * 0.52f, 1f);
        }

        private void initRibbon(Ribbon r, float cx, float cy, float dir) {
            for (int i = 0; i < r.count; i++) {
                float rel = (i - (r.count - 1) * 0.5f) / Math.max(1f, (r.count - 1) * 0.5f);
                r.x[i] = cx + rel * width * 0.11f;
                r.y[i] = cy + (float)Math.sin(i * 1.1f + seedPhase) * height * 0.05f;
                r.vx[i] = (random.nextFloat() - 0.5f) * 8f + dir * 1.5f;
                r.vy[i] = (random.nextFloat() - 0.5f) * 8f;
            }
        }

        private void readConfig(boolean force) {
            long now = SystemClock.elapsedRealtime();
            if (!force && now - lastConfigRead < 500L) return;
            lastConfigRead = now;
            cfg.style = prefs.getInt("style", 0);
            cfg.intimacy = prefs.getFloat("intimacy", 0.72f);
            cfg.randomness = prefs.getFloat("randomness", 0.48f);
            cfg.ribbonWidth = prefs.getFloat("ribbonWidth", 0.55f);
            cfg.trail = prefs.getFloat("trail", 0.62f);
            cfg.bubbles = prefs.getBoolean("bubbles", true);
            cfg.powerSave = prefs.getBoolean("powerSave", false);
            long savedSeed = prefs.getLong("seed", 0L);
            if (savedSeed != 0L && random.nextInt(600) == 3) random.setSeed(savedSeed ^ now);
        }

        private int[] palette(int style) {
            switch (Math.floorMod(style, 5)) {
                case 1: return new int[]{0xFF67E8F9, 0xFF93C5FD, 0xFFC4B5FD, 0xFFFDE68A, 0xFF020617};
                case 2: return new int[]{0xFFA78BFA, 0xFFD8B4FE, 0xFFF9A8D4, 0xFFFFF7ED, 0xFF050316};
                case 3: return new int[]{0xFFE5E7EB, 0xFFFFFFFF, 0xFF93C5FD, 0xFFD1D5DB, 0xFF000000};
                case 4: return new int[]{0xFFFDE68A, 0xFFFFF7ED, 0xFFFB7185, 0xFFFACC15, 0xFF06030A};
                default: return new int[]{0xFF7DD3FC, 0xFFC4B5FD, 0xFFF472B6, 0xFFFDE68A, 0xFF030712};
            }
        }

        private static int withAlpha(int color, int alpha) {
            return (clampInt(alpha, 0, 255) << 24) | (color & 0x00FFFFFF);
        }
        private static int clampInt(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }
        private static float clamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }
        private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
        private static float smooth(float x) { x = clamp(x, 0f, 1f); return x * x * (3f - 2f * x); }
        private static void sleepQuiet(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }
    }

    static final class Ribbon {
        final int count;
        final float[] x;
        final float[] y;
        final float[] vx;
        final float[] vy;
        Ribbon(int count) {
            this.count = count;
            x = new float[count]; y = new float[count]; vx = new float[count]; vy = new float[count];
        }
        Path path() {
            Path p = new Path();
            if (count <= 0) return p;
            p.moveTo(x[0], y[0]);
            for (int i = 1; i < count - 1; i++) {
                float mx = (x[i] + x[i + 1]) * 0.5f;
                float my = (y[i] + y[i + 1]) * 0.5f;
                p.quadTo(x[i], y[i], mx, my);
            }
            p.lineTo(x[count - 1], y[count - 1]);
            return p;
        }
    }

    static final class Config {
        int style = 0;
        float intimacy = 0.72f;
        float randomness = 0.48f;
        float ribbonWidth = 0.55f;
        float trail = 0.62f;
        boolean bubbles = true;
        boolean powerSave = false;
    }

    static final class Phase {
        final String name; final float start; final float end; final float intensity; final float closeness; final float tension;
        Phase(String name, float start, float end, float intensity, float closeness, float tension) {
            this.name = name; this.start = start; this.end = end; this.intensity = intensity; this.closeness = closeness; this.tension = tension;
        }
        static final Phase[] ALL = new Phase[]{
                new Phase("吸引", 0.00f, 0.16f, 0.18f, 0.14f, 0.10f),
                new Phase("靠近", 0.16f, 0.32f, 0.35f, 0.34f, 0.26f),
                new Phase("同步", 0.32f, 0.50f, 0.56f, 0.60f, 0.48f),
                new Phase("升高", 0.50f, 0.70f, 0.78f, 0.80f, 0.76f),
                new Phase("临界", 0.70f, 0.82f, 0.95f, 0.90f, 1.00f),
                new Phase("释放", 0.82f, 0.90f, 1.00f, 1.00f, 0.44f),
                new Phase("余韵", 0.90f, 1.00f, 0.26f, 0.56f, 0.08f),
        };
        static Phase of(float u) {
            for (Phase p : ALL) if (u >= p.start && u < p.end) return p;
            return ALL[ALL.length - 1];
        }
    }
}
