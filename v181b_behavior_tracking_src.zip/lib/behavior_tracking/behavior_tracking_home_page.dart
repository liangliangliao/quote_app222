// ============================================================
// behavior_tracking_home_page.dart
// ============================================================

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'behavior_tracking_models.dart';
import 'behavior_tracking_dao.dart';
import 'behavior_record_form_page.dart';
import 'daily_review_page.dart';

class BehaviorTrackingHomePage extends StatefulWidget {
  const BehaviorTrackingHomePage({super.key});

  @override
  State<BehaviorTrackingHomePage> createState() =>
      _BehaviorTrackingHomePageState();
}

class _BehaviorTrackingHomePageState extends State<BehaviorTrackingHomePage>
    with SingleTickerProviderStateMixin {
  late final TabController _tab;
  final _dao = BehaviorTrackingDao();

  List<BehaviorRecord> _todayRecords = [];
  List<BehaviorRecord> _historyRecords = [];
  List<DailyReview> _reviews = [];
  Map<String, int> _layerCounts = {};
  bool _loading = true;

  // History filters
  BehaviorLayer? _filterLayer;
  static const int _historyLimit = 60;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
    _tab.addListener(() => setState(() {}));
    _load();
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final today = await _dao.fetchTodayRecords();
      final history = await _dao.fetchRecords(
          layer: _filterLayer, limit: _historyLimit);
      final reviews = await _dao.fetchRecentReviews(limit: 30);
      final counts = await _dao.fetchLayerCounts(days: 7);
      if (!mounted) return;
      setState(() {
        _todayRecords = today;
        _historyRecords = history;
        _reviews = reviews;
        _layerCounts = counts;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  Future<void> _goAddRecord(BehaviorLayer layer) async {
    await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => BehaviorRecordFormPage(initialLayer: layer),
        fullscreenDialog: true,
      ),
    );
    _load();
  }

  Future<void> _goReview({DateTime? date}) async {
    await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => DailyReviewPage(date: date ?? DateTime.now()),
        fullscreenDialog: true,
      ),
    );
    _load();
  }

  Future<void> _deleteRecord(BehaviorRecord rec) async {
    if (rec.id == null) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除记录'),
        content: const Text('确认删除这条行为记录？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('删除', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
    if (ok == true) {
      await _dao.deleteRecord(rec.id!);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F4EF),
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C2C2E),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('行为追踪',
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18)),
        centerTitle: true,
        bottom: TabBar(
          controller: _tab,
          indicatorColor: const Color(0xFFE8A87C),
          labelColor: const Color(0xFFE8A87C),
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(text: '今日记录'),
            Tab(text: '历史轨迹'),
            Tab(text: '定期复盘'),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tab,
              children: [
                _buildTodayTab(),
                _buildHistoryTab(),
                _buildReviewTab(),
              ],
            ),
      floatingActionButton: _buildFab(),
    );
  }

  Widget? _buildFab() {
    if (_tab.index == 2) {
      return FloatingActionButton.extended(
        backgroundColor: const Color(0xFF2C2C2E),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.edit_note),
        label: const Text('今日复盘'),
        onPressed: _goReview,
      );
    }
    return FloatingActionButton.extended(
      backgroundColor: const Color(0xFFE8A87C),
      foregroundColor: Colors.white,
      icon: const Icon(Icons.add),
      label: const Text('添加记录'),
      onPressed: () => _showLayerPicker(),
    );
  }

  // ---- Today Tab ----

  Widget _buildTodayTab() {
    return RefreshIndicator(
      onRefresh: _load,
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: _buildStatsBar()),
          SliverToBoxAdapter(child: _buildQuickAdd()),
          if (_todayRecords.isEmpty)
            const SliverFillRemaining(
              child: _EmptyState(
                icon: Icons.track_changes_outlined,
                message: '今天还没有记录\n从下面快捷入口开始追踪吧',
              ),
            )
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) => _RecordCard(
                  record: _todayRecords[i],
                  onDelete: () => _deleteRecord(_todayRecords[i]),
                ),
                childCount: _todayRecords.length,
              ),
            ),
          const SliverPadding(padding: EdgeInsets.only(bottom: 80)),
        ],
      ),
    );
  }

  Widget _buildStatsBar() {
    final total = _todayRecords.length;
    final layerSet = _todayRecords.map((r) => r.layer).toSet().length;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Row(
        children: [
          _StatChip(label: '今日记录', value: '$total 条'),
          const SizedBox(width: 8),
          _StatChip(label: '覆盖层面', value: '$layerSet 个'),
          const SizedBox(width: 8),
          _StatChip(label: '本周总计', value: '${_layerCounts.values.fold(0, (a, b) => a + b)} 条'),
        ],
      ),
    );
  }

  Widget _buildQuickAdd() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('快速记录',
              style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                  color: Colors.grey[600])),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: BehaviorLayer.values.map((layer) {
              return ActionChip(
                avatar: Text(layer.icon, style: const TextStyle(fontSize: 14)),
                label: Text(layer.label),
                backgroundColor: Colors.white,
                elevation: 2,
                onPressed: () => _goAddRecord(layer),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  // ---- History Tab ----

  Widget _buildHistoryTab() {
    return Column(
      children: [
        _buildHistoryFilterBar(),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _load,
            child: _historyRecords.isEmpty
                ? const _EmptyState(
                    icon: Icons.history,
                    message: '暂无历史记录')
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 80),
                    itemCount: _historyRecords.length,
                    itemBuilder: (ctx, i) => _RecordCard(
                      record: _historyRecords[i],
                      showDate: true,
                      onDelete: () => _deleteRecord(_historyRecords[i]),
                    ),
                  ),
          ),
        ),
      ],
    );
  }

  Widget _buildHistoryFilterBar() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
      child: Row(
        children: [
          FilterChip(
            label: const Text('全部'),
            selected: _filterLayer == null,
            onSelected: (_) {
              setState(() => _filterLayer = null);
              _load();
            },
          ),
          const SizedBox(width: 6),
          ...BehaviorLayer.values.map((l) => Padding(
            padding: const EdgeInsets.only(right: 6),
            child: FilterChip(
              avatar: Text(l.icon, style: const TextStyle(fontSize: 12)),
              label: Text(l.label),
              selected: _filterLayer == l,
              onSelected: (_) {
                setState(() => _filterLayer = _filterLayer == l ? null : l);
                _load();
              },
            ),
          )),
        ],
      ),
    );
  }

  // ---- Review Tab ----

  Widget _buildReviewTab() {
    return RefreshIndicator(
      onRefresh: _load,
      child: _reviews.isEmpty
          ? const _EmptyState(
              icon: Icons.auto_stories_outlined,
              message: '还没有复盘记录\n点击右下角开始今日复盘')
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 80),
              itemCount: _reviews.length,
              itemBuilder: (ctx, i) => _ReviewCard(
                review: _reviews[i],
                onTap: () => _goReview(date: _reviews[i].date),
              ),
            ),
    );
  }

  // ---- Layer picker ----

  void _showLayerPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('选择追踪层面',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 16),
            ...BehaviorLayer.values.map((l) => ListTile(
              leading: CircleAvatar(
                backgroundColor: const Color(0xFFF0EBE3),
                child: Text(l.icon, style: const TextStyle(fontSize: 18)),
              ),
              title: Text(l.label,
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(l.description,
                  style: const TextStyle(fontSize: 12)),
              onTap: () {
                Navigator.pop(ctx);
                _goAddRecord(l);
              },
            )),
          ],
        ),
      ),
    );
  }
}

// ---- Sub-widgets ----

class _StatChip extends StatelessWidget {
  final String label;
  final String value;

  const _StatChip({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)],
        ),
        child: Column(
          children: [
            Text(value,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 2),
            Text(label,
                style: TextStyle(fontSize: 11, color: Colors.grey[600])),
          ],
        ),
      ),
    );
  }
}

class _RecordCard extends StatelessWidget {
  final BehaviorRecord record;
  final VoidCallback? onDelete;
  final bool showDate;

  const _RecordCard({required this.record, this.onDelete, this.showDate = false});

  @override
  Widget build(BuildContext context) {
    final fmt = showDate
        ? DateFormat('MM/dd HH:mm')
        : DateFormat('HH:mm');
    final timeStr = fmt.format(record.createdAt);

    return Dismissible(
      key: Key('rec_${record.id}'),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        color: Colors.red[100],
        child: const Icon(Icons.delete_outline, color: Colors.red),
      ),
      confirmDismiss: (_) async {
        onDelete?.call();
        return false; // we handle deletion manually
      },
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 6, 16, 6),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 6, offset: const Offset(0, 2))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF0EBE3),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(record.layer.icon, style: const TextStyle(fontSize: 12)),
                      const SizedBox(width: 4),
                      Text(record.layer.label,
                          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500)),
                    ],
                  ),
                ),
                const Spacer(),
                Text(timeStr,
                    style: TextStyle(fontSize: 11, color: Colors.grey[500])),
              ],
            ),
            const SizedBox(height: 8),
            Text(record.what,
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                maxLines: 2,
                overflow: TextOverflow.ellipsis),
            if (record.why.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text('原因：${record.why}',
                  style: TextStyle(fontSize: 13, color: Colors.grey[600]),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ],
            if (record.result.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text('结果：${record.result}',
                  style: TextStyle(fontSize: 13, color: Colors.grey[600]),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ],
            if (record.emotion != null) ...[
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  '${record.emotion}${record.emotionIntensity != null ? '  ${record.emotionIntensity}/10' : ''}',
                  style: TextStyle(fontSize: 12, color: Colors.blue[700]),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ReviewCard extends StatelessWidget {
  final DailyReview review;
  final VoidCallback? onTap;

  const _ReviewCard({required this.review, this.onTap});

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat('yyyy年MM月dd日');
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 6, offset: const Offset(0, 2))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.auto_stories_outlined, size: 16, color: Color(0xFFE8A87C)),
                const SizedBox(width: 6),
                Text(fmt.format(review.date),
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                const Spacer(),
                const Icon(Icons.chevron_right, size: 18, color: Colors.grey),
              ],
            ),
            if (review.importantActions.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('✅ ${review.importantActions}',
                  style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis),
            ],
            if (review.mainEmotion.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text('💭 ${review.mainEmotion}',
                  style: TextStyle(fontSize: 13, color: Colors.grey[700]),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ],
            if (review.tomorrowAdjust.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text('🎯 ${review.tomorrowAdjust}',
                  style: TextStyle(fontSize: 13, color: Colors.blue[700]),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ],
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String message;

  const _EmptyState({required this.icon, required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 64, color: Colors.grey[300]),
            const SizedBox(height: 16),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, color: Colors.grey[500], height: 1.6),
            ),
          ],
        ),
      ),
    );
  }
}
