// ============================================================
// behavior_record_form_page.dart
// ============================================================

import 'package:flutter/material.dart';
import 'behavior_tracking_models.dart';
import 'behavior_tracking_dao.dart';

class BehaviorRecordFormPage extends StatefulWidget {
  final BehaviorLayer initialLayer;

  const BehaviorRecordFormPage({super.key, required this.initialLayer});

  @override
  State<BehaviorRecordFormPage> createState() => _BehaviorRecordFormPageState();
}

class _BehaviorRecordFormPageState extends State<BehaviorRecordFormPage> {
  late BehaviorLayer _layer;
  final _dao = BehaviorTrackingDao();
  bool _saving = false;

  // Common fields
  final _whatCtrl = TextEditingController();
  final _whyCtrl = TextEditingController();
  final _resultCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();

  // Emotion
  String? _emotion;
  int _emotionIntensity = 5;
  final _emotionReactionCtrl = TextEditingController();

  // Cognition
  final _situationCtrl = TextEditingController();
  final _autoThoughtCtrl = TextEditingController();
  final _followBehaviorCtrl = TextEditingController();

  // Result
  final _shortTermCtrl = TextEditingController();
  final _longTermCtrl = TextEditingController();

  // Body
  final _sleepTimeCtrl = TextEditingController();
  final _wakeTimeCtrl = TextEditingController();
  int _energyLevel = 3;

  // Time block
  final _timeStartCtrl = TextEditingController();
  final _timeEndCtrl = TextEditingController();
  String? _timeCategory;

  static const _emotionOptions = [
    '平静', '满足', '愉悦', '兴奋', '感恩',
    '焦虑', '烦躁', '委屈', '愤怒', '悲伤',
    '迷茫', '孤独', '疲惫', '空虚', '逃避',
  ];

  static const _timeCategoryOptions = [
    '工作/学习', '娱乐', '生活事务', '休息', '人际',
  ];

  @override
  void initState() {
    super.initState();
    _layer = widget.initialLayer;
  }

  @override
  void dispose() {
    for (final c in [
      _whatCtrl, _whyCtrl, _resultCtrl, _noteCtrl,
      _emotionReactionCtrl, _situationCtrl, _autoThoughtCtrl,
      _followBehaviorCtrl, _shortTermCtrl, _longTermCtrl,
      _sleepTimeCtrl, _wakeTimeCtrl, _timeStartCtrl, _timeEndCtrl,
    ]) { c.dispose(); }
    super.dispose();
  }

  Future<void> _save() async {
    if (_whatCtrl.text.trim().isEmpty) {
      _toast('请填写主要内容');
      return;
    }
    setState(() => _saving = true);
    try {
      final record = BehaviorRecord(
        createdAt: DateTime.now(),
        layer: _layer,
        what: _whatCtrl.text.trim(),
        why: _whyCtrl.text.trim(),
        result: _resultCtrl.text.trim(),
        note: _noteCtrl.text.trim(),
        emotion: _emotion,
        emotionIntensity: _layer == BehaviorLayer.emotion ? _emotionIntensity : null,
        emotionReaction: _emotionReactionCtrl.text.trim().isEmpty ? null : _emotionReactionCtrl.text.trim(),
        situation: _situationCtrl.text.trim().isEmpty ? null : _situationCtrl.text.trim(),
        autoThought: _autoThoughtCtrl.text.trim().isEmpty ? null : _autoThoughtCtrl.text.trim(),
        followBehavior: _followBehaviorCtrl.text.trim().isEmpty ? null : _followBehaviorCtrl.text.trim(),
        shortTermResult: _shortTermCtrl.text.trim().isEmpty ? null : _shortTermCtrl.text.trim(),
        longTermImpact: _longTermCtrl.text.trim().isEmpty ? null : _longTermCtrl.text.trim(),
        sleepTime: _sleepTimeCtrl.text.trim().isEmpty ? null : _sleepTimeCtrl.text.trim(),
        wakeTime: _wakeTimeCtrl.text.trim().isEmpty ? null : _wakeTimeCtrl.text.trim(),
        energyLevel: _layer == BehaviorLayer.body ? _energyLevel : null,
        timeStart: _timeStartCtrl.text.trim().isEmpty ? null : _timeStartCtrl.text.trim(),
        timeEnd: _timeEndCtrl.text.trim().isEmpty ? null : _timeEndCtrl.text.trim(),
        timeCategory: _timeCategory,
      );
      await _dao.insertRecord(record);
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      _toast('保存失败：$e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F4EF),
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C2C2E),
        foregroundColor: Colors.white,
        title: const Text('添加行为记录'),
        actions: [
          TextButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('保存', style: TextStyle(color: Color(0xFFE8A87C), fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 60),
        children: [
          _buildLayerSelector(),
          const SizedBox(height: 16),
          _buildLayerHint(),
          const SizedBox(height: 16),
          _buildCommonFields(),
          const SizedBox(height: 12),
          _buildLayerSpecificFields(),
        ],
      ),
    );
  }

  Widget _buildLayerSelector() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('追踪层面', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.grey)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: BehaviorLayer.values.map((l) {
              final selected = _layer == l;
              return GestureDetector(
                onTap: () => setState(() => _layer = l),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(
                    color: selected ? const Color(0xFF2C2C2E) : const Color(0xFFF0EBE3),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(l.icon, style: const TextStyle(fontSize: 14)),
                      const SizedBox(width: 4),
                      Text(l.label,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: selected ? Colors.white : Colors.black87,
                          )),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildLayerHint() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFE8A87C).withOpacity(0.12),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFE8A87C).withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Text(_layer.icon, style: const TextStyle(fontSize: 20)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(_layer.description,
                style: TextStyle(fontSize: 13, color: Colors.brown[700])),
          ),
        ],
      ),
    );
  }

  Widget _buildCommonFields() {
    return _FormCard(
      title: '基础信息',
      children: [
        _buildField(
          controller: _whatCtrl,
          label: _whatLabel,
          hint: _whatHint,
          required: true,
          maxLines: 3,
        ),
        const SizedBox(height: 12),
        _buildField(
          controller: _whyCtrl,
          label: '为什么？（触发原因）',
          hint: '什么触发了这个行为或状态？',
          maxLines: 2,
        ),
        const SizedBox(height: 12),
        _buildField(
          controller: _resultCtrl,
          label: '产生了什么结果？',
          hint: '行为之后发生了什么？',
          maxLines: 2,
        ),
        const SizedBox(height: 12),
        _buildField(
          controller: _noteCtrl,
          label: '补充备注',
          hint: '可选，其他想记录的内容',
          maxLines: 2,
        ),
      ],
    );
  }

  String get _whatLabel {
    switch (_layer) {
      case BehaviorLayer.time:        return '这段时间做了什么？ *';
      case BehaviorLayer.behavior:    return '做了什么具体行为？ *';
      case BehaviorLayer.emotion:     return '发生了什么事件？ *';
      case BehaviorLayer.cognition:   return '当时的情境是什么？ *';
      case BehaviorLayer.result:      return '是什么行为？ *';
      case BehaviorLayer.environment: return '当时的环境如何？ *';
      case BehaviorLayer.body:        return '身体状态描述 *';
    }
  }

  String get _whatHint {
    switch (_layer) {
      case BehaviorLayer.time:        return '例：22:00–01:00 刷短视频 3 小时';
      case BehaviorLayer.behavior:    return '例：今天运动 30 分钟，完成了 3 道题';
      case BehaviorLayer.emotion:     return '例：被上司批评了一件事';
      case BehaviorLayer.cognition:   return '例：看到任务列表很长';
      case BehaviorLayer.result:      return '例：熬夜刷视频 2 小时';
      case BehaviorLayer.environment: return '例：手机放在手边，房间比较杂乱';
      case BehaviorLayer.body:        return '例：睡眠不足，下午一直犯困';
    }
  }

  Widget _buildLayerSpecificFields() {
    switch (_layer) {
      case BehaviorLayer.time:
        return _buildTimeFields();
      case BehaviorLayer.behavior:
        return const SizedBox.shrink();
      case BehaviorLayer.emotion:
        return _buildEmotionFields();
      case BehaviorLayer.cognition:
        return _buildCognitionFields();
      case BehaviorLayer.result:
        return _buildResultFields();
      case BehaviorLayer.environment:
        return const SizedBox.shrink();
      case BehaviorLayer.body:
        return _buildBodyFields();
    }
  }

  Widget _buildTimeFields() {
    return _FormCard(
      title: '时间块信息',
      children: [
        Row(
          children: [
            Expanded(child: _buildField(controller: _timeStartCtrl, label: '开始时间', hint: '如 09:00')),
            const SizedBox(width: 10),
            Expanded(child: _buildField(controller: _timeEndCtrl, label: '结束时间', hint: '如 10:30')),
          ],
        ),
        const SizedBox(height: 12),
        const Text('时间类别', style: TextStyle(fontSize: 13, color: Colors.grey)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: _timeCategoryOptions.map((cat) {
            final selected = _timeCategory == cat;
            return ChoiceChip(
              label: Text(cat),
              selected: selected,
              onSelected: (_) => setState(() => _timeCategory = selected ? null : cat),
              selectedColor: const Color(0xFF2C2C2E),
              labelStyle: TextStyle(color: selected ? Colors.white : Colors.black87),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildEmotionFields() {
    return _FormCard(
      title: '情绪详情',
      children: [
        const Text('情绪标签', style: TextStyle(fontSize: 13, color: Colors.grey)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: _emotionOptions.map((e) {
            final selected = _emotion == e;
            return ChoiceChip(
              label: Text(e),
              selected: selected,
              onSelected: (_) => setState(() => _emotion = selected ? null : e),
              selectedColor: const Color(0xFF2C2C2E),
              labelStyle: TextStyle(color: selected ? Colors.white : Colors.black87),
            );
          }).toList(),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('情绪强度', style: TextStyle(fontSize: 13, color: Colors.grey)),
            const Spacer(),
            Text('$_emotionIntensity / 10',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          ],
        ),
        Slider(
          value: _emotionIntensity.toDouble(),
          min: 1, max: 10, divisions: 9,
          activeColor: const Color(0xFFE8A87C),
          onChanged: (v) => setState(() => _emotionIntensity = v.round()),
        ),
        const SizedBox(height: 8),
        _buildField(
          controller: _emotionReactionCtrl,
          label: '反应方式',
          hint: '例：回避、刷手机、找人倾诉',
          maxLines: 2,
        ),
      ],
    );
  }

  Widget _buildCognitionFields() {
    return _FormCard(
      title: '认知详情',
      children: [
        _buildField(
          controller: _autoThoughtCtrl,
          label: '自动想法',
          hint: '当时脑子里第一个念头是什么？\n例："反正做不完"',
          maxLines: 2,
        ),
        const SizedBox(height: 12),
        _buildField(
          controller: _followBehaviorCtrl,
          label: '后续行为',
          hint: '这个想法让你做了什么？',
          maxLines: 2,
        ),
      ],
    );
  }

  Widget _buildResultFields() {
    return _FormCard(
      title: '结果分析',
      children: [
        _buildField(
          controller: _shortTermCtrl,
          label: '短期结果',
          hint: '当下直接发生了什么？',
          maxLines: 2,
        ),
        const SizedBox(height: 12),
        _buildField(
          controller: _longTermCtrl,
          label: '长期影响',
          hint: '这个行为长期会带来什么？',
          maxLines: 2,
        ),
      ],
    );
  }

  Widget _buildBodyFields() {
    return _FormCard(
      title: '身体状态',
      children: [
        Row(
          children: [
            Expanded(child: _buildField(controller: _sleepTimeCtrl, label: '入睡时间', hint: '如 23:30')),
            const SizedBox(width: 10),
            Expanded(child: _buildField(controller: _wakeTimeCtrl, label: '起床时间', hint: '如 07:00')),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('精力水平', style: TextStyle(fontSize: 13, color: Colors.grey)),
            const Spacer(),
            Text(_energyLabel,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          ],
        ),
        Slider(
          value: _energyLevel.toDouble(),
          min: 1, max: 5, divisions: 4,
          activeColor: const Color(0xFF4CAF50),
          onChanged: (v) => setState(() => _energyLevel = v.round()),
        ),
      ],
    );
  }

  String get _energyLabel {
    const labels = ['', '很差', '较差', '一般', '较好', '很好'];
    return labels[_energyLevel];
  }

  Widget _buildField({
    required TextEditingController controller,
    required String label,
    String? hint,
    bool required = false,
    int maxLines = 1,
  }) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        hintStyle: TextStyle(fontSize: 12, color: Colors.grey[400]),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFE8A87C), width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        filled: true,
        fillColor: const Color(0xFFFAF8F5),
      ),
    );
  }
}

class _FormCard extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _FormCard({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(
                  fontWeight: FontWeight.bold, fontSize: 13, color: Colors.grey)),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }
}
