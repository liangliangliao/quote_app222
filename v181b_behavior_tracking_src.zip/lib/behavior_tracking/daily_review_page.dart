// ============================================================
// daily_review_page.dart
// ============================================================

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'behavior_tracking_models.dart';
import 'behavior_tracking_dao.dart';

class DailyReviewPage extends StatefulWidget {
  final DateTime date;

  const DailyReviewPage({super.key, required this.date});

  @override
  State<DailyReviewPage> createState() => _DailyReviewPageState();
}

class _DailyReviewPageState extends State<DailyReviewPage> {
  final _dao = BehaviorTrackingDao();
  bool _loading = true;
  bool _saving = false;

  final _sleepCtrl = TextEditingController();
  final _importantCtrl = TextEditingController();
  final _wastedCtrl = TextEditingController();
  final _emotionCtrl = TextEditingController();
  final _triggerCtrl = TextEditingController();
  final _tomorrowCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadExisting();
  }

  @override
  void dispose() {
    for (final c in [
      _sleepCtrl, _importantCtrl, _wastedCtrl,
      _emotionCtrl, _triggerCtrl, _tomorrowCtrl, _noteCtrl
    ]) { c.dispose(); }
    super.dispose();
  }

  Future<void> _loadExisting() async {
    try {
      final review = await _dao.fetchReview(widget.date);
      if (!mounted) return;
      if (review != null) {
        _sleepCtrl.text = review.sleepRecord;
        _importantCtrl.text = review.importantActions;
        _wastedCtrl.text = review.wastedTime;
        _emotionCtrl.text = review.mainEmotion;
        _triggerCtrl.text = review.trigger;
        _tomorrowCtrl.text = review.tomorrowAdjust;
        _noteCtrl.text = review.extraNote;
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      final review = DailyReview(
        date: widget.date,
        sleepRecord: _sleepCtrl.text.trim(),
        importantActions: _importantCtrl.text.trim(),
        wastedTime: _wastedCtrl.text.trim(),
        mainEmotion: _emotionCtrl.text.trim(),
        trigger: _triggerCtrl.text.trim(),
        tomorrowAdjust: _tomorrowCtrl.text.trim(),
        extraNote: _noteCtrl.text.trim(),
      );
      await _dao.saveReview(review);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('复盘已保存 ✓'), behavior: SnackBarBehavior.floating),
      );
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('保存失败：$e'), behavior: SnackBarBehavior.floating),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat('yyyy年MM月dd日');
    return Scaffold(
      backgroundColor: const Color(0xFFF6F4EF),
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C2C2E),
        foregroundColor: Colors.white,
        title: Text('复盘 · ${fmt.format(widget.date)}'),
        actions: [
          TextButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('保存', style: TextStyle(color: Color(0xFFE8A87C), fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 60),
              children: [
                _buildBanner(),
                const SizedBox(height: 20),
                _buildSection(
                  icon: '😴',
                  title: '睡眠',
                  description: '几点睡？几点起？睡眠质量如何？',
                  controller: _sleepCtrl,
                  hint: '例：23:30 睡，7:00 起，睡眠质量一般',
                  maxLines: 2,
                ),
                _buildSection(
                  icon: '✅',
                  title: '重要行为',
                  description: '今天最重要的 1–3 件事是什么？',
                  controller: _importantCtrl,
                  hint: '例：完成报告初稿，运动 20 分钟，主动联系了老朋友',
                  maxLines: 3,
                ),
                _buildSection(
                  icon: '⚠️',
                  title: '时间失控',
                  description: '哪段时间失控了？具体做了什么？',
                  controller: _wastedCtrl,
                  hint: '例：晚上 22:00–00:30 刷短视频，超出计划 2 小时',
                  maxLines: 3,
                ),
                _buildSection(
                  icon: '💭',
                  title: '主要情绪',
                  description: '今天主要的情绪状态是什么？',
                  controller: _emotionCtrl,
                  hint: '例：上午焦虑，下午平静，晚上有些逃避',
                  maxLines: 2,
                ),
                _buildSection(
                  icon: '🔍',
                  title: '触发点',
                  description: '什么导致了今天的好/坏行为？',
                  controller: _triggerCtrl,
                  hint: '例：任务太大不知从哪里开始，触发了拖延',
                  maxLines: 3,
                ),
                _buildSection(
                  icon: '🎯',
                  title: '明日调整',
                  description: '明天只改一个点，是什么？',
                  controller: _tomorrowCtrl,
                  hint: '例：把大任务拆成 25 分钟小块，用番茄钟启动',
                  maxLines: 2,
                ),
                _buildSection(
                  icon: '📝',
                  title: '其他补充',
                  description: '还有什么想记录的？',
                  controller: _noteCtrl,
                  hint: '可选',
                  maxLines: 3,
                ),
              ],
            ),
    );
  }

  Widget _buildBanner() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF2C2C2E), Color(0xFF3D3B38)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('每日复盘',
              style: TextStyle(color: Color(0xFFE8A87C),
                  fontWeight: FontWeight.bold, fontSize: 18)),
          const SizedBox(height: 8),
          const Text(
            '今天我做了什么？\n当时为什么这么做？\n这个行为让我变好还是变差？',
            style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.7),
          ),
        ],
      ),
    );
  }

  Widget _buildSection({
    required String icon,
    required String title,
    required String description,
    required TextEditingController controller,
    String? hint,
    int maxLines = 1,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(icon, style: const TextStyle(fontSize: 20)),
              const SizedBox(width: 8),
              Text(title,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 15)),
            ],
          ),
          const SizedBox(height: 4),
          Text(description,
              style: TextStyle(fontSize: 12, color: Colors.grey[500])),
          const SizedBox(height: 12),
          TextField(
            controller: controller,
            maxLines: maxLines,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(fontSize: 12, color: Colors.grey[400]),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: Color(0xFFE8A87C), width: 1.5),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              filled: true,
              fillColor: const Color(0xFFFAF8F5),
            ),
          ),
        ],
      ),
    );
  }
}
