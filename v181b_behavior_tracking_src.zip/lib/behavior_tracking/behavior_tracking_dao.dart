// ============================================================
// behavior_tracking_dao.dart
// ============================================================

import 'package:sqflite/sqflite.dart';
import '../data/db.dart';
import 'behavior_tracking_models.dart';

class BehaviorTrackingDao {
  // ---- Init tables ----
  static Future<void> ensureTables() async {
    final db = await AppDatabase.instance();
    await db.execute('''
      CREATE TABLE IF NOT EXISTS behavior_records (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at      TEXT NOT NULL,
        layer           INTEGER NOT NULL DEFAULT 0,
        what            TEXT NOT NULL DEFAULT '',
        why             TEXT NOT NULL DEFAULT '',
        result          TEXT NOT NULL DEFAULT '',
        note            TEXT NOT NULL DEFAULT '',
        emotion         TEXT,
        emotion_intensity INTEGER,
        emotion_reaction TEXT,
        situation       TEXT,
        auto_thought    TEXT,
        follow_behavior TEXT,
        short_term_result TEXT,
        long_term_impact TEXT,
        sleep_time      TEXT,
        wake_time       TEXT,
        energy_level    INTEGER,
        time_start      TEXT,
        time_end        TEXT,
        time_category   TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS daily_reviews (
        id                INTEGER PRIMARY KEY AUTOINCREMENT,
        date              TEXT NOT NULL UNIQUE,
        sleep_record      TEXT NOT NULL DEFAULT '',
        important_actions TEXT NOT NULL DEFAULT '',
        wasted_time       TEXT NOT NULL DEFAULT '',
        main_emotion      TEXT NOT NULL DEFAULT '',
        trigger           TEXT NOT NULL DEFAULT '',
        tomorrow_adjust   TEXT NOT NULL DEFAULT '',
        extra_note        TEXT NOT NULL DEFAULT ''
      )
    ''');
  }

  // ---- BehaviorRecord CRUD ----

  Future<int> insertRecord(BehaviorRecord record) async {
    await ensureTables();
    final db = await AppDatabase.instance();
    return db.insert('behavior_records', record.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<BehaviorRecord>> fetchRecords({
    BehaviorLayer? layer,
    DateTime? from,
    DateTime? to,
    int limit = 100,
    int offset = 0,
  }) async {
    await ensureTables();
    final db = await AppDatabase.instance();
    final where = <String>[];
    final args = <dynamic>[];

    if (layer != null) {
      where.add('layer = ?');
      args.add(layer.index);
    }
    if (from != null) {
      where.add('created_at >= ?');
      args.add(from.toIso8601String());
    }
    if (to != null) {
      where.add('created_at <= ?');
      args.add(to.toIso8601String());
    }

    final rows = await db.query(
      'behavior_records',
      where: where.isEmpty ? null : where.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'created_at DESC',
      limit: limit,
      offset: offset,
    );
    return rows.map(BehaviorRecord.fromMap).toList();
  }

  Future<List<BehaviorRecord>> fetchTodayRecords() async {
    final now = DateTime.now();
    final from = DateTime(now.year, now.month, now.day);
    final to = from.add(const Duration(days: 1));
    return fetchRecords(from: from, to: to, limit: 200);
  }

  Future<void> deleteRecord(int id) async {
    await ensureTables();
    final db = await AppDatabase.instance();
    await db.delete('behavior_records', where: 'id = ?', whereArgs: [id]);
  }

  // ---- DailyReview CRUD ----

  Future<void> saveReview(DailyReview review) async {
    await ensureTables();
    final db = await AppDatabase.instance();
    await db.insert('daily_reviews', review.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<DailyReview?> fetchReview(DateTime date) async {
    await ensureTables();
    final db = await AppDatabase.instance();
    final key = date.toIso8601String().substring(0, 10);
    final rows = await db.query('daily_reviews',
        where: 'date = ?', whereArgs: [key], limit: 1);
    if (rows.isEmpty) return null;
    return DailyReview.fromMap(rows.first);
  }

  Future<List<DailyReview>> fetchRecentReviews({int limit = 30}) async {
    await ensureTables();
    final db = await AppDatabase.instance();
    final rows = await db.query('daily_reviews',
        orderBy: 'date DESC', limit: limit);
    return rows.map(DailyReview.fromMap).toList();
  }

  // ---- Stats ----

  Future<Map<String, int>> fetchLayerCounts({int days = 7}) async {
    await ensureTables();
    final db = await AppDatabase.instance();
    final from = DateTime.now().subtract(Duration(days: days));
    final rows = await db.rawQuery(
      'SELECT layer, COUNT(*) as cnt FROM behavior_records '
      'WHERE created_at >= ? GROUP BY layer',
      [from.toIso8601String()],
    );
    final result = <String, int>{};
    for (final row in rows) {
      final idx = row['layer'] as int? ?? 0;
      if (idx >= 0 && idx < BehaviorLayer.values.length) {
        final label = BehaviorLayer.values[idx].label;
        result[label] = (row['cnt'] as int?) ?? 0;
      }
    }
    return result;
  }
}
