// ============================================================
// behavior_tracking_models.dart
// ============================================================

/// 行为记录的层面类型
enum BehaviorLayer {
  time,       // 时间层面
  behavior,   // 行为层面
  emotion,    // 情绪层面
  cognition,  // 认知层面
  result,     // 结果层面
  environment,// 环境层面
  body,       // 身体状态层面
}

extension BehaviorLayerExt on BehaviorLayer {
  String get label {
    switch (this) {
      case BehaviorLayer.time:        return '时间';
      case BehaviorLayer.behavior:    return '行为';
      case BehaviorLayer.emotion:     return '情绪';
      case BehaviorLayer.cognition:   return '认知';
      case BehaviorLayer.result:      return '结果';
      case BehaviorLayer.environment: return '环境';
      case BehaviorLayer.body:        return '身体';
    }
  }

  String get icon {
    switch (this) {
      case BehaviorLayer.time:        return '⏱';
      case BehaviorLayer.behavior:    return '✅';
      case BehaviorLayer.emotion:     return '💭';
      case BehaviorLayer.cognition:   return '🧠';
      case BehaviorLayer.result:      return '📊';
      case BehaviorLayer.environment: return '🌍';
      case BehaviorLayer.body:        return '💪';
    }
  }

  String get description {
    switch (this) {
      case BehaviorLayer.time:        return '我把时间花在哪里';
      case BehaviorLayer.behavior:    return '我具体做了哪些事';
      case BehaviorLayer.emotion:     return '我在什么情况下有什么感受';
      case BehaviorLayer.cognition:   return '我当时是怎么想的';
      case BehaviorLayer.result:      return '行为带来了什么后果';
      case BehaviorLayer.environment: return '什么环境影响了我';
      case BehaviorLayer.body:        return '身体如何影响行为';
    }
  }
}

/// 一条行为记录
class BehaviorRecord {
  final int? id;
  final DateTime createdAt;
  final BehaviorLayer layer;

  // 通用字段
  final String what;       // 做了什么 / 事件
  final String why;        // 为什么做 / 触发原因
  final String result;     // 产生了什么结果
  final String note;       // 补充备注

  // 情绪相关
  final String? emotion;         // 情绪标签
  final int? emotionIntensity;   // 情绪强度 1-10
  final String? emotionReaction; // 反应方式

  // 认知相关
  final String? situation;       // 情境
  final String? autoThought;     // 自动想法
  final String? followBehavior;  // 后续行为

  // 结果：长期/短期
  final String? shortTermResult;  // 短期结果
  final String? longTermImpact;   // 长期影响

  // 身体状态
  final String? sleepTime;    // 入睡时间
  final String? wakeTime;     // 起床时间
  final int? energyLevel;     // 精力水平 1-5

  // 时间块
  final String? timeStart;
  final String? timeEnd;
  final String? timeCategory;  // 工作/娱乐/生活/休息/人际

  const BehaviorRecord({
    this.id,
    required this.createdAt,
    required this.layer,
    required this.what,
    this.why = '',
    this.result = '',
    this.note = '',
    this.emotion,
    this.emotionIntensity,
    this.emotionReaction,
    this.situation,
    this.autoThought,
    this.followBehavior,
    this.shortTermResult,
    this.longTermImpact,
    this.sleepTime,
    this.wakeTime,
    this.energyLevel,
    this.timeStart,
    this.timeEnd,
    this.timeCategory,
  });

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'created_at': createdAt.toIso8601String(),
    'layer': layer.index,
    'what': what,
    'why': why,
    'result': result,
    'note': note,
    'emotion': emotion,
    'emotion_intensity': emotionIntensity,
    'emotion_reaction': emotionReaction,
    'situation': situation,
    'auto_thought': autoThought,
    'follow_behavior': followBehavior,
    'short_term_result': shortTermResult,
    'long_term_impact': longTermImpact,
    'sleep_time': sleepTime,
    'wake_time': wakeTime,
    'energy_level': energyLevel,
    'time_start': timeStart,
    'time_end': timeEnd,
    'time_category': timeCategory,
  };

  factory BehaviorRecord.fromMap(Map<String, dynamic> m) => BehaviorRecord(
    id: m['id'] as int?,
    createdAt: DateTime.parse(m['created_at'] as String),
    layer: BehaviorLayer.values[(m['layer'] as int?) ?? 0],
    what: m['what'] as String? ?? '',
    why: m['why'] as String? ?? '',
    result: m['result'] as String? ?? '',
    note: m['note'] as String? ?? '',
    emotion: m['emotion'] as String?,
    emotionIntensity: m['emotion_intensity'] as int?,
    emotionReaction: m['emotion_reaction'] as String?,
    situation: m['situation'] as String?,
    autoThought: m['auto_thought'] as String?,
    followBehavior: m['follow_behavior'] as String?,
    shortTermResult: m['short_term_result'] as String?,
    longTermImpact: m['long_term_impact'] as String?,
    sleepTime: m['sleep_time'] as String?,
    wakeTime: m['wake_time'] as String?,
    energyLevel: m['energy_level'] as int?,
    timeStart: m['time_start'] as String?,
    timeEnd: m['time_end'] as String?,
    timeCategory: m['time_category'] as String?,
  );

  BehaviorRecord copyWith({
    int? id,
    DateTime? createdAt,
    BehaviorLayer? layer,
    String? what,
    String? why,
    String? result,
    String? note,
    String? emotion,
    int? emotionIntensity,
    String? emotionReaction,
    String? situation,
    String? autoThought,
    String? followBehavior,
    String? shortTermResult,
    String? longTermImpact,
    String? sleepTime,
    String? wakeTime,
    int? energyLevel,
    String? timeStart,
    String? timeEnd,
    String? timeCategory,
  }) => BehaviorRecord(
    id: id ?? this.id,
    createdAt: createdAt ?? this.createdAt,
    layer: layer ?? this.layer,
    what: what ?? this.what,
    why: why ?? this.why,
    result: result ?? this.result,
    note: note ?? this.note,
    emotion: emotion ?? this.emotion,
    emotionIntensity: emotionIntensity ?? this.emotionIntensity,
    emotionReaction: emotionReaction ?? this.emotionReaction,
    situation: situation ?? this.situation,
    autoThought: autoThought ?? this.autoThought,
    followBehavior: followBehavior ?? this.followBehavior,
    shortTermResult: shortTermResult ?? this.shortTermResult,
    longTermImpact: longTermImpact ?? this.longTermImpact,
    sleepTime: sleepTime ?? this.sleepTime,
    wakeTime: wakeTime ?? this.wakeTime,
    energyLevel: energyLevel ?? this.energyLevel,
    timeStart: timeStart ?? this.timeStart,
    timeEnd: timeEnd ?? this.timeEnd,
    timeCategory: timeCategory ?? this.timeCategory,
  );
}

/// 每日复盘
class DailyReview {
  final int? id;
  final DateTime date;
  final String sleepRecord;     // 几点睡，几点起
  final String importantActions;// 今天最重要的1-3件事
  final String wastedTime;      // 哪段时间失控了
  final String mainEmotion;     // 今天主要情绪
  final String trigger;         // 触发点
  final String tomorrowAdjust;  // 明天调整
  final String extraNote;       // 额外笔记

  const DailyReview({
    this.id,
    required this.date,
    this.sleepRecord = '',
    this.importantActions = '',
    this.wastedTime = '',
    this.mainEmotion = '',
    this.trigger = '',
    this.tomorrowAdjust = '',
    this.extraNote = '',
  });

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'date': date.toIso8601String().substring(0, 10),
    'sleep_record': sleepRecord,
    'important_actions': importantActions,
    'wasted_time': wastedTime,
    'main_emotion': mainEmotion,
    'trigger': trigger,
    'tomorrow_adjust': tomorrowAdjust,
    'extra_note': extraNote,
  };

  factory DailyReview.fromMap(Map<String, dynamic> m) => DailyReview(
    id: m['id'] as int?,
    date: DateTime.parse(m['date'] as String),
    sleepRecord: m['sleep_record'] as String? ?? '',
    importantActions: m['important_actions'] as String? ?? '',
    wastedTime: m['wasted_time'] as String? ?? '',
    mainEmotion: m['main_emotion'] as String? ?? '',
    trigger: m['trigger'] as String? ?? '',
    tomorrowAdjust: m['tomorrow_adjust'] as String? ?? '',
    extraNote: m['extra_note'] as String? ?? '',
  );
}
