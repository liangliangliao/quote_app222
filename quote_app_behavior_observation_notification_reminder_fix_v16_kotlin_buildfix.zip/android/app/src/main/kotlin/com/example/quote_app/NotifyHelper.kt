package com.example.quote_app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.content.Intent
import android.app.PendingIntent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import org.json.JSONObject

object NotifyHelper {
  private const val DEFAULT_CHANNEL_ID = "quote_default_v2"
  private const val DEFAULT_CHANNEL_NAME = "Quotes"

  @JvmStatic
  fun send(
    ctx: Context,
    id: Int,
    title: String,
    body: String,
    avatarPath: String?,
    notifType: String? = null,
    payload: String? = null
  ) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // Android 13+ 需要 POST_NOTIFICATIONS 运行时权限；若缺失，静默失败。这里直接短路并记录。
    if (Build.VERSION.SDK_INT >= 33) {
      if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] skip: no POST_NOTIFICATIONS permission") } catch (_: Throwable) {}
        return
      }
    }

    // 系统级通知开关被关也会静默丢弃
    if (!nm.areNotificationsEnabled()) {
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] skip: notifications disabled at system level") } catch (_: Throwable) {}
      return
    }

    // 8.0+ 必须先创建渠道
    if (Build.VERSION.SDK_INT >= 26) {
      // 记录当前渠道的重要级别，帮助排查通知是否被静音/折叠
      try {
        val existing = nm.getNotificationChannel(DEFAULT_CHANNEL_ID)
        if (existing != null) {
          com.example.quote_app.data.DbRepo.log(
            ctx,
            null,
            "[Notify] existing channel id=%s importance=%d".format(DEFAULT_CHANNEL_ID, existing.importance)
          )
        } else {
          com.example.quote_app.data.DbRepo.log(
            ctx,
            null,
            "[Notify] creating new channel id=%s".format(DEFAULT_CHANNEL_ID)
          )
        }
      } catch (_: Throwable) {}


      val ch = NotificationChannel(
        DEFAULT_CHANNEL_ID,
        DEFAULT_CHANNEL_NAME,
        NotificationManager.IMPORTANCE_HIGH
      )
      nm.createNotificationChannel(ch)
    }

    val builder = NotificationCompat.Builder(ctx, DEFAULT_CHANNEL_ID)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setContentTitle(title.ifBlank { "愿景提醒" })
      .setContentText(body)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)
      // Open MainActivity when tapping notification; extras carry notification type and payload for navigation
      .apply {
        val launchIntent = Intent(ctx, MainActivity::class.java).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
          putExtra("from_notification", true)
          if (notifType != null) putExtra("notif_type", notifType)
          if (payload != null) putExtra("payload", payload)
        }
        val pi = PendingIntent.getActivity(
          ctx,
          1001,
          launchIntent,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        setContentIntent(pi)
      }


    if (!avatarPath.isNullOrEmpty()) {
      try {
        val bmp = BitmapFactory.decodeFile(avatarPath)
        if (bmp != null) builder.setLargeIcon(bmp)
      } catch (_: Throwable) {}
    }

    nm.notify(id, builder.build())
    try { com.example.quote_app.data.DbRepo.log(ctx, null, "[Notify] posted id="+id+" chan="+DEFAULT_CHANNEL_ID) } catch (_: Throwable) {}
  }

  // 兼容旧版 Java 调用（仅有 avatarPath，缺少 notifType / payload）
  // Java 侧会匹配到这个重载方法，内部再委托给带完整参数的实现。
  @JvmStatic
  fun send(
    ctx: Context,
    id: Int,
    title: String,
    body: String,
    avatarPath: String?
  ) {
    send(ctx, id, title, body, avatarPath, null, null)
  }



  // =========================
  // Behavior Observation: inline notification form
  // =========================
  private const val BEHAVIOR_CHANNEL_ID = "behavior_observation_v1"
  private const val BEHAVIOR_CHANNEL_NAME = "行为观察提醒"
  private const val BEHAVIOR_GROUP_KEY = "behavior_observation_quick_record_group"

  private fun ensureBehaviorObservationChannel(ctx: Context, nm: NotificationManager) {
    if (Build.VERSION.SDK_INT >= 26) {
      val ch = NotificationChannel(
        BEHAVIOR_CHANNEL_ID,
        BEHAVIOR_CHANNEL_NAME,
        NotificationManager.IMPORTANCE_HIGH
      ).apply {
        description = "行为观察快捷记录：可在通知中选择层面并直接输入保存"
        enableVibration(true)
        setShowBadge(true)
      }
      nm.createNotificationChannel(ch)
    }
  }

  private fun mutableBroadcastFlags(): Int {
    return if (Build.VERSION.SDK_INT >= 31) {
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
    } else {
      PendingIntent.FLAG_UPDATE_CURRENT
    }
  }

  private fun behaviorLayerMeta(): List<BehaviorLayerActionMeta> = listOf(
    BehaviorLayerActionMeta("时间层面", "时间", "time_block", "时间表单：做了什么；开始-结束；类别；备注"),
    BehaviorLayerActionMeta("行为层面", "行为", "quick_capture", "行为表单：具体做了什么；为什么做；类别；备注"),
    BehaviorLayerActionMeta("情绪层面", "情绪", "emotion_thought", "情绪表单：事件；情绪；强度；当时反应"),
    BehaviorLayerActionMeta("认知层面", "认知", "emotion_thought", "认知表单：情境；自动想法；后续行为"),
    BehaviorLayerActionMeta("结果层面", "结果", "tbr", "结果表单：行为；短期结果；长期影响"),
    BehaviorLayerActionMeta("环境层面", "环境", "full_observation", "环境表单：地点；身边人；物品/手机；影响"),
    BehaviorLayerActionMeta("身体状态层面", "身体", "body_snapshot", "身体表单：睡眠；精力；疲劳；运动/步数")
  )

  private data class BehaviorLayerActionMeta(
    val layer: String,
    val label: String,
    val templateKey: String,
    val formHint: String
  )

  private fun mergeBehaviorPayload(payload: String?, meta: BehaviorLayerActionMeta): String {
    return try {
      val obj = JSONObject(payload ?: "{}")
      obj.put("module", "behavior_tracking")
      obj.put("route", "/behavior_tracking")
      obj.put("templateKey", meta.templateKey)
      obj.put("primaryLayer", meta.layer)
      obj.put("entryMode", "notification_layer_form")
      obj.toString()
    } catch (_: Throwable) {
      "{\"module\":\"behavior_tracking\",\"route\":\"/behavior_tracking\",\"templateKey\":\"${meta.templateKey}\",\"primaryLayer\":\"${meta.layer}\",\"entryMode\":\"notification_layer_form\"}"
    }
  }

  @JvmStatic
  fun sendBehaviorObservationReminder(
    ctx: Context,
    id: Int,
    title: String,
    body: String,
    payload: String?
  ) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "[BehaviorObservation] skip reminder: no POST_NOTIFICATIONS permission") } catch (_: Throwable) {}
      return
    }
    if (!nm.areNotificationsEnabled()) return
    ensureBehaviorObservationChannel(ctx, nm)

    val safeTitle = title.ifBlank { "行为观察提醒" }
    val safeBody = body.ifBlank { "展开通知后，可看到 7 个观察层面；每一层都能直接输入并保存。" }

    val summaryIntent = Intent(ctx, MainActivity::class.java).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
      putExtra("from_notification", true)
      putExtra("notif_type", "behavior_tracking")
      putExtra("payload", payload ?: "{}")
    }
    val summaryPi = PendingIntent.getActivity(
      ctx,
      id + 9100,
      summaryIntent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val metas = behaviorLayerMeta()
    // Android 系统通知动作在很多机型上最多只展示 3 个按钮；为了让 7 个层面都真实可用，
    // 这里改为“通知组”：1 条总提醒 + 7 条子通知。每条子通知都有自己的 RemoteInput 表单。
    metas.forEachIndexed { index, meta ->
      val childId = id + 12000 + index
      val layerPayload = mergeBehaviorPayload(payload, meta)
      val openLayerIntent = Intent(ctx, MainActivity::class.java).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        putExtra("from_notification", true)
        putExtra("notif_type", "behavior_tracking")
        putExtra("payload", layerPayload)
      }
      val openPi = PendingIntent.getActivity(
        ctx,
        id + 15000 + index,
        openLayerIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )
      val input = RemoteInput.Builder(BehaviorObservationQuickRecordReceiver.KEY_TEXT)
        .setLabel(meta.formHint)
        .build()
      val actionIntent = Intent(ctx, BehaviorObservationQuickRecordReceiver::class.java).apply {
        action = BehaviorObservationQuickRecordReceiver.ACTION + "." + index
        putExtra(BehaviorObservationQuickRecordReceiver.EXTRA_LAYER, meta.layer)
        putExtra(BehaviorObservationQuickRecordReceiver.EXTRA_PAYLOAD, layerPayload)
        putExtra(BehaviorObservationQuickRecordReceiver.EXTRA_NOTIFICATION_ID, childId)
        putExtra(BehaviorObservationQuickRecordReceiver.EXTRA_SUMMARY_NOTIFICATION_ID, id)
      }
      val actionPi = PendingIntent.getBroadcast(ctx, id * 10 + index, actionIntent, mutableBroadcastFlags())
      val action = NotificationCompat.Action.Builder(android.R.drawable.ic_menu_edit, "填写${meta.label}表单", actionPi)
        .addRemoteInput(input)
        .setAllowGeneratedReplies(true)
        .build()
      val child = NotificationCompat.Builder(ctx, BEHAVIOR_CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("${meta.label}观察")
        .setContentText(meta.formHint)
        .setStyle(NotificationCompat.BigTextStyle().bigText("${meta.formHint}\n\n点击下方“填写${meta.label}表单”可不打开 App 直接输入保存；点击本通知可打开对应完整表单。"))
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        .setOnlyAlertOnce(true)
        .setSilent(true)
        .setContentIntent(openPi)
        .setAutoCancel(false)
        .setGroup(BEHAVIOR_GROUP_KEY)
        .setCategory(NotificationCompat.CATEGORY_REMINDER)
        .addAction(action)
        .build()
      nm.notify(childId, child)
    }

    val summaryText = "展开可看到 7 个层面：时间、行为、情绪、认知、结果、环境、身体。点击任一层可打开完整表单，也可在通知内直接输入保存。"
    val summary = NotificationCompat.Builder(ctx, BEHAVIOR_CHANNEL_ID)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setContentTitle(safeTitle)
      .setContentText(safeBody)
      .setStyle(NotificationCompat.BigTextStyle().bigText(summaryText))
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
      .setDefaults(NotificationCompat.DEFAULT_ALL)
      .setContentIntent(summaryPi)
      .setAutoCancel(false)
      .setGroup(BEHAVIOR_GROUP_KEY)
      .setGroupSummary(true)
      .setCategory(NotificationCompat.CATEGORY_REMINDER)
      .build()
    nm.notify(id, summary)
    try { com.example.quote_app.data.DbRepo.log(ctx, null, "[BehaviorObservation] posted grouped 7-layer reminder id=$id") } catch (_: Throwable) {}
  }


  @JvmStatic
  fun sendBehaviorObservationAutoSyncResult(ctx: Context, id: Int, body: String?) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
    ensureBehaviorObservationChannel(ctx, nm)
    val text = body?.takeIf { it.isNotBlank() } ?: "自动读取完成，结果已进入待确认队列。"
    val launchIntent = Intent(ctx, MainActivity::class.java).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
      putExtra("from_notification", true)
      putExtra("notif_type", "behavior_tracking")
      putExtra("payload", "{\"module\":\"behavior_tracking\",\"route\":\"/behavior_tracking\",\"templateKey\":\"data_sources\"}")
    }
    val pi = PendingIntent.getActivity(ctx, id + 9400, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val n = NotificationCompat.Builder(ctx, BEHAVIOR_CHANNEL_ID)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setContentTitle("行为观察自动读取完成")
      .setContentText(text)
      .setStyle(NotificationCompat.BigTextStyle().bigText(text + "\n点击进入数据源页查看待确认项。"))
      .setPriority(NotificationCompat.PRIORITY_DEFAULT)
      .setContentIntent(pi)
      .setAutoCancel(true)
      .build()
    nm.notify(id, n)
  }

  @JvmStatic
  fun sendBehaviorObservationSaved(ctx: Context, id: Int, layer: String, text: String?, savedId: Long) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
    ensureBehaviorObservationChannel(ctx, nm)
    val ok = savedId > 0L
    val body = if (ok) {
      val t = (text ?: "").trim().ifBlank { "已保存一条记录" }
      "已保存到行为观察：${layer.replace("层面", "")} · $t"
    } else {
      "保存失败：请打开 App 后再试，或检查数据库是否已初始化。"
    }
    val launchIntent = Intent(ctx, MainActivity::class.java).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
      putExtra("from_notification", true)
      putExtra("notif_type", "behavior_tracking")
      putExtra("payload", "{\"module\":\"behavior_tracking\",\"route\":\"/behavior_tracking\",\"templateKey\":\"quick_capture\"}")
    }
    val pi = PendingIntent.getActivity(ctx, id + 9300, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val n = NotificationCompat.Builder(ctx, BEHAVIOR_CHANNEL_ID)
      .setSmallIcon(if (ok) android.R.drawable.ic_dialog_info else android.R.drawable.ic_dialog_alert)
      .setContentTitle(if (ok) "行为观察已保存" else "行为观察保存失败")
      .setContentText(body)
      .setStyle(NotificationCompat.BigTextStyle().bigText(body))
      .setPriority(NotificationCompat.PRIORITY_DEFAULT)
      .setContentIntent(pi)
      .setAutoCancel(true)
      .setTimeoutAfter(8000)
      .build()
    nm.notify(id, n)
  }

  /**
   * 解锁提醒专用通知发送入口：
   * - 使用独立的解锁提醒通知渠道（quote_unlock_v1），便于和普通通知区分；
   * - 渠道重要级别固定为 IMPORTANCE_HIGH，默认开启声音与震动，提升被系统弹出的概率；
   * - 在发送前详细记录渠道状态与每一步操作，方便后续从数据库日志中还原通知行为。
   */
  @JvmStatic
  fun sendUnlockReminder(
    ctx: Context,
    id: Int,
    title: String,
    body: String
  ) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val channelId = "quote_unlock_v1"
    val channelName = "解锁提醒"

    try {
      com.example.quote_app.data.DbRepo.log(
        ctx,
        null,
        "【解锁提醒-通知助手】准备通过专用渠道发送解锁提醒通知，id=" + id + "，title=" + title
      )
    } catch (_: Throwable) {
    }

    // 统一在这里再次确认系统级通知总开关状态，避免在被关闭时反复尝试发送
    try {
      if (!nm.areNotificationsEnabled()) {
        com.example.quote_app.data.DbRepo.log(
          ctx,
          null,
          "【解锁提醒-通知助手】系统级通知总开关已关闭，本次解锁提醒通知将被静默丢弃"
        )
        return
      }
    } catch (_: Throwable) {
      // 读取通知开关状态失败不影响后续流程，仅记录日志
      try {
        com.example.quote_app.data.DbRepo.log(
          ctx,
          null,
          "【解锁提醒-通知助手】检查系统通知总开关状态时发生异常，继续尝试发送解锁提醒通知"
        )
      } catch (_: Throwable) {
      }
    }

    // Android 8.0+ 需要确保渠道存在，这里专门为解锁提醒维护一个高优先级渠道
    if (Build.VERSION.SDK_INT >= 26) {
      try {
        val existing = nm.getNotificationChannel(channelId)
        if (existing != null) {
          com.example.quote_app.data.DbRepo.log(
            ctx,
            null,
            "【解锁提醒-通知助手】检测到解锁提醒通知渠道已存在，id=" + channelId +
              "，importance=" + existing.importance
          )
        } else {
          com.example.quote_app.data.DbRepo.log(
            ctx,
            null,
            "【解锁提醒-通知助手】未检测到解锁提醒通知渠道，将以 IMPORTANCE_HIGH 创建新渠道，id=" + channelId
          )
        }
      } catch (_: Throwable) {
      }

      try {
        val ch = NotificationChannel(
          channelId,
          channelName,
          NotificationManager.IMPORTANCE_HIGH
        ).apply {
          enableVibration(true)
          enableLights(true)
          setShowBadge(true)
        }
        nm.createNotificationChannel(ch)
      } catch (e: Throwable) {
        try {
          com.example.quote_app.data.DbRepo.log(
            ctx,
            null,
            "【解锁提醒-通知助手】创建解锁提醒通知渠道时发生异常，exception=" +
              e.javaClass.simpleName + "，message=" + (e.message ?: "null")
          )
        } catch (_: Throwable) {
        }
      }
    }

    val builder = NotificationCompat.Builder(ctx, channelId)
      .setContentTitle(title.ifBlank { "愿景提醒" })
      .setContentText(body)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      // 默认开启声音与震动，增加被系统识别为“需要提醒”的概率
      .setDefaults(NotificationCompat.DEFAULT_ALL)
      .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
      .apply {
        // 解锁提醒点击后统一跳转到 MainActivity，并携带 notif_type=vision_focus 方便页面做精确导航
        try {
          val launchIntent = Intent(ctx, com.example.quote_app.MainActivity::class.java).apply {
            addFlags(
              Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            )
            putExtra("from_notification", true)
            putExtra("notif_type", "vision_focus")
          }
          val pi = PendingIntent.getActivity(
            ctx,
            2000,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
          )
          setContentIntent(pi)
        } catch (e: Throwable) {
          try {
            com.example.quote_app.data.DbRepo.log(
              ctx,
              null,
              "【解锁提醒-通知助手】构建解锁提醒 PendingIntent 时发生异常，exception=" +
                e.javaClass.simpleName + "，message=" + (e.message ?: "null")
            )
          } catch (_: Throwable) {
          }
        }
      }

    try {
      nm.notify(id, builder.build())
      com.example.quote_app.data.DbRepo.log(
        ctx,
        null,
        "【解锁提醒-通知助手】解锁提醒通知已通过专用渠道交给系统展示，id=" + id +
          "，channelId=" + channelId
      )
    } catch (e: Throwable) {
      try {
        com.example.quote_app.data.DbRepo.log(
          ctx,
          null,
          "【解锁提醒-通知助手】调用 NotificationManager.notify 发送解锁提醒通知失败，exception=" +
            e.javaClass.simpleName + "，message=" + (e.message ?: "null")
        )
      } catch (_: Throwable) {
      }
    }
  }

  // =========================
  // Sport: alarm full-screen + reminder
  // =========================

  private const val SPORT_CHANNEL_ID = "sport_alarm_v1"
  private const val SPORT_CHANNEL_NAME = "运动提醒提醒"

  private fun ensureSportChannel(ctx: Context, nm: NotificationManager) {
    if (Build.VERSION.SDK_INT >= 26) {
      try {
        val existing = nm.getNotificationChannel(SPORT_CHANNEL_ID)
        if (existing == null) {
          val ch = NotificationChannel(
            SPORT_CHANNEL_ID,
            SPORT_CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH
          )
          nm.createNotificationChannel(ch)
        }
      } catch (_: Throwable) {}
    }
  }

  @JvmStatic
  fun sendSportReminder(
    ctx: Context,
    id: Int,
    title: String,
    body: String,
    notifType: String,
    payload: String
  ) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    if (Build.VERSION.SDK_INT >= 33) {
      if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        try { com.example.quote_app.data.DbRepo.log(ctx, null, "[SportNotify] skip: no POST_NOTIFICATIONS permission") } catch (_: Throwable) {}
        return
      }
    }
    if (!nm.areNotificationsEnabled()) return
    ensureSportChannel(ctx, nm)

    val launchIntent = Intent(ctx, MainActivity::class.java).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
      putExtra("from_notification", true)
      putExtra("notif_type", notifType)
      putExtra("payload", payload)
    }
    val pi = PendingIntent.getActivity(
      ctx,
      3001 + (id % 100000),
      launchIntent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val builder = NotificationCompat.Builder(ctx, SPORT_CHANNEL_ID)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setCategory(NotificationCompat.CATEGORY_REMINDER)
      .setContentTitle(title)
      .setContentText(body)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)
      .setContentIntent(pi)

    nm.notify(id, builder.build())
  }

  @JvmStatic
  fun sendSportFullScreen(
    ctx: Context,
    id: Int,
    title: String,
    body: String,
    notifType: String,
    payload: String
  ) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    if (Build.VERSION.SDK_INT >= 33) {
      if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        try { com.example.quote_app.data.DbRepo.log(ctx, null, "[SportNotify] skip: no POST_NOTIFICATIONS permission") } catch (_: Throwable) {}
        return
      }
    }
    if (!nm.areNotificationsEnabled()) return
    ensureSportChannel(ctx, nm)

    val launchIntent = Intent(ctx, MainActivity::class.java).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
      putExtra("from_notification", true)
      putExtra("notif_type", notifType)
      putExtra("payload", payload)
    }
    val pi = PendingIntent.getActivity(
      ctx,
      4001 + (id % 100000),
      launchIntent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val builder = NotificationCompat.Builder(ctx, SPORT_CHANNEL_ID)
      .setPriority(NotificationCompat.PRIORITY_MAX)
      .setCategory(NotificationCompat.CATEGORY_ALARM)
      .setContentTitle(title)
      .setContentText(body)
      .setSmallIcon(android.R.drawable.ic_dialog_info)
      .setAutoCancel(true)
      .setContentIntent(pi)
      // Full-screen intent: tries to immediately bring MainActivity to foreground (alarm-like)
      .setFullScreenIntent(pi, true)

    nm.notify(id, builder.build())
  }

}
