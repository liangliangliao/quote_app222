import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../platform/intimacy_wallpaper_bridge.dart';

class TouchMystifyWallpaperPage extends StatefulWidget {
  const TouchMystifyWallpaperPage({super.key});

  @override
  State<TouchMystifyWallpaperPage> createState() => _TouchMystifyWallpaperPageState();
}

class _TouchMystifyWallpaperPageState extends State<TouchMystifyWallpaperPage> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  Duration _elapsed = Duration.zero;

  int _style = 0;
  double _intimacy = 0.72;
  double _randomness = 0.60;
  double _ribbonWidth = 0.55;
  double _trail = 0.62;
  double _fullScreenCoverage = 0.96;
  double _strokeDensity = 0.46;
  bool _previewAccelerated = false;
  double _previewCycleMinutes = 3.0;
  bool _bubbles = true;
  bool _powerSave = false;
  bool _randomCycle = true;
  double _cycleMinDays = 1.0;
  double _cycleMaxDays = 365.0;
  double _fixedCycleDays = 30.0;
  double _ratioSeparation = 0.46;
  double _ratioAttraction = 0.22;
  double _ratioSync = 0.22;
  double _ratioCritical = 0.06;
  double _ratioRelease = 0.02;
  double _ratioAfterglow = 0.02;
  int _previewSeed = 7;

  final List<String> _styles = const ['Mystify 经典黑底', '深海蓝黑', '紫粉梦境', '银白冷光', '金色余韵'];

  @override
  void initState() {
    super.initState();
    _ticker = createTicker((elapsed) {
      setState(() => _elapsed = elapsed);
    })..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  Future<void> _saveAndOpen() async {
    final ok = await IntimacyWallpaperBridge.saveConfig(
      style: _style,
      intimacy: _intimacy,
      randomness: _randomness,
      ribbonWidth: _ribbonWidth,
      trail: _trail,
      fullScreenCoverage: _fullScreenCoverage,
      strokeDensity: _strokeDensity,
      previewAccelerated: _previewAccelerated,
      previewCycleMinutes: _previewCycleMinutes,
      bubbles: _bubbles,
      powerSave: _powerSave,
      randomCycle: _randomCycle,
      cycleMinDays: _cycleMinDays,
      cycleMaxDays: _cycleMaxDays,
      fixedCycleDays: _fixedCycleDays,
      ratioSeparation: _ratioSeparation,
      ratioAttraction: _ratioAttraction,
      ratioSync: _ratioSync,
      ratioCritical: _ratioCritical,
      ratioRelease: _ratioRelease,
      ratioAfterglow: _ratioAfterglow,
    );
    if (!mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('当前平台不支持 Android 动态壁纸设置')),
      );
      return;
    }
    await IntimacyWallpaperBridge.openLiveWallpaper();
  }

  Future<void> _saveOnly() async {
    final ok = await IntimacyWallpaperBridge.saveConfig(
      style: _style,
      intimacy: _intimacy,
      randomness: _randomness,
      ribbonWidth: _ribbonWidth,
      trail: _trail,
      fullScreenCoverage: _fullScreenCoverage,
      strokeDensity: _strokeDensity,
      previewAccelerated: _previewAccelerated,
      previewCycleMinutes: _previewCycleMinutes,
      bubbles: _bubbles,
      powerSave: _powerSave,
      randomCycle: _randomCycle,
      cycleMinDays: _cycleMinDays,
      cycleMaxDays: _cycleMaxDays,
      fixedCycleDays: _fixedCycleDays,
      ratioSeparation: _ratioSeparation,
      ratioAttraction: _ratioAttraction,
      ratioSync: _ratioSync,
      ratioCritical: _ratioCritical,
      ratioRelease: _ratioRelease,
      ratioAfterglow: _ratioAfterglow,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(ok ? '已保存壁纸参数，已安装的动态壁纸会自动读取新设置' : '当前平台不支持 Android 动态壁纸')),
    );
  }

  void _randomizePreview() {
    setState(() {
      _previewSeed = math.Random().nextInt(999999);
      _randomness = (0.28 + math.Random().nextDouble() * 0.52).clamp(0.0, 1.0).toDouble();
    });
  }

  @override
  Widget build(BuildContext context) {
    final seconds = _elapsed.inMilliseconds / 1000.0;
    return Scaffold(
      backgroundColor: const Color(0xFF050714),
      appBar: AppBar(
        title: const Text('触摸 · Mystify 亲密艺术壁纸'),
        backgroundColor: const Color(0xFF050714),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          _HeroPreview(
            seconds: seconds,
            style: _style,
            intimacy: _intimacy,
            randomness: _randomness,
            ribbonWidth: _ribbonWidth,
            trail: _trail,
            fullScreenCoverage: _fullScreenCoverage,
            bubbles: _bubbles,
            ratioSeparation: _ratioSeparation,
            ratioAttraction: _ratioAttraction,
            ratioSync: _ratioSync,
            ratioCritical: _ratioCritical,
            ratioRelease: _ratioRelease,
            ratioAfterglow: _ratioAfterglow,
            seed: _previewSeed,
          ),
          const SizedBox(height: 16),
          _IntroCard(),
          const SizedBox(height: 16),
          _SectionCard(
            title: '视觉风格',
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (int i = 0; i < _styles.length; i++)
                  ChoiceChip(
                    label: Text(_styles[i]),
                    selected: _style == i,
                    onSelected: (_) => setState(() => _style = i),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: '表达参数',
            child: Column(
              children: [
                _SliderRow(
                  label: '亲密张力',
                  value: _intimacy,
                  description: '控制两条生命轨迹从吸引、同步、缠绕到释放的戏剧强度。',
                  onChanged: (v) => setState(() => _intimacy = v),
                ),
                _SliderRow(
                  label: 'Mystify 随机性',
                  value: _randomness,
                  description: '控制轨迹变化莫测程度；越高越像随机屏保，但仍保持主线克制。',
                  onChanged: (v) => setState(() => _randomness = v),
                ),
                _SliderRow(
                  label: '光带宽度',
                  value: _ribbonWidth,
                  description: '控制主丝带的柔光厚度和高级感。',
                  onChanged: (v) => setState(() => _ribbonWidth = v),
                ),
                _SliderRow(
                  label: '残影长度',
                  value: _trail,
                  description: '控制 Windows Mystify 式拖尾；越高余韵越长。',
                  onChanged: (v) => setState(() => _trail = v),
                ),
                _SliderRow(
                  label: '全屏活动范围',
                  value: _fullScreenCoverage,
                  description: '控制随机运动点是否覆盖手机可见屏幕任意位置。默认接近全屏，避免线条只在中心或小区域活动。',
                  onChanged: (v) => setState(() => _fullScreenCoverage = v),
                ),
                _SliderRow(
                  label: '线条出现密度',
                  value: _strokeDensity,
                  description: '控制随机即时线条发生器的出生频率。过低更像黑场留白，过高更容易杂乱。',
                  onChanged: (v) => setState(() => _strokeDensity = v),
                ),
                SwitchListTile(
                  value: _bubbles,
                  onChanged: (v) => setState(() => _bubbles = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('余韵气泡/光尘', style: TextStyle(color: Colors.white)),
                  subtitle: const Text('只在释放后的余韵阶段少量出现，避免画面杂乱。', style: TextStyle(color: Colors.white60)),
                ),
                SwitchListTile(
                  value: _powerSave,
                  onChanged: (v) => setState(() => _powerSave = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('省电模式', style: TextStyle(color: Colors.white)),
                  subtitle: const Text('降低动态壁纸帧率，适合长期作为主屏/锁屏使用。', style: TextStyle(color: Colors.white60)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: '完整周期（以天为单位）',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SwitchListTile(
                  value: _randomCycle,
                  onChanged: (v) => setState(() => _randomCycle = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('每轮随机生成周期', style: TextStyle(color: Colors.white)),
                  subtitle: Text(
                    _randomCycle
                        ? '当前范围：${_cycleMinDays.round()}～${_cycleMaxDays.round()} 天。每完成一轮后，会重新随机生成下一轮周期。'
                        : '关闭后使用固定周期：${_fixedCycleDays.round()} 天。',
                    style: const TextStyle(color: Colors.white60),
                  ),
                ),
                SwitchListTile(
                  value: _previewAccelerated,
                  onChanged: (v) => setState(() => _previewAccelerated = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('壁纸加速演示模式', style: TextStyle(color: Colors.white)),
                  subtitle: Text(
                    _previewAccelerated
                        ? '已开启：动态壁纸会用约 ${_previewCycleMinutes.toStringAsFixed(1)} 分钟演示完整过程，便于调试观察。正式使用建议关闭。'
                        : '关闭后按真实天数推进完整周期。若你想快速检查临界、释放、余韵，可以临时开启。',
                    style: const TextStyle(color: Colors.white60),
                  ),
                ),
                if (_previewAccelerated)
                  _MinuteSliderRow(
                    label: '演示周期',
                    value: _previewCycleMinutes,
                    min: 0.5,
                    max: 60.0,
                    onChanged: (v) => setState(() => _previewCycleMinutes = v),
                  ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: Text('随机范围：${_cycleMinDays.round()}～${_cycleMaxDays.round()} 天', style: const TextStyle(color: Colors.white70))),
                  ],
                ),
                RangeSlider(
                  values: RangeValues(_cycleMinDays, _cycleMaxDays),
                  min: 1.0,
                  max: 365.0,
                  divisions: 364,
                  labels: RangeLabels('${_cycleMinDays.round()}天', '${_cycleMaxDays.round()}天'),
                  onChanged: (values) {
                    setState(() {
                      _cycleMinDays = values.start.clamp(1.0, 365.0).toDouble();
                      _cycleMaxDays = values.end.clamp(_cycleMinDays, 365.0).toDouble();
                      _fixedCycleDays = _fixedCycleDays.clamp(_cycleMinDays, _cycleMaxDays).toDouble();
                    });
                  },
                ),
                if (!_randomCycle)
                  _DaySliderRow(
                    label: '固定周期',
                    value: _fixedCycleDays,
                    min: _cycleMinDays,
                    max: _cycleMaxDays,
                    onChanged: (v) => setState(() => _fixedCycleDays = v),
                  ),
                const Text(
                  '实际动态壁纸按真实天数推进；本页预览已改成随机 Stroke 发生器，用于快速检查全屏随机、阶段比例和 Mystify 观感；真实壁纸仍以原生 OpenGL 渲染为准。',
                  style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.35),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: '阶段出现频率',
            child: Column(
              children: [
                _RatioSliderRow(label: '分离', value: _ratioSeparation, description: '默认最大比例：黑场、留白、低频单线，表达两个生命仍处于分离状态。', onChanged: (v) => setState(() => _ratioSeparation = v)),
                _RatioSliderRow(label: '吸引', value: _ratioAttraction, description: '主要比例：线条从任意位置出现，彼此被牵引但尚未合一。', onChanged: (v) => setState(() => _ratioAttraction = v)),
                _RatioSliderRow(label: '同步', value: _ratioSync, description: '主要比例：两条轨迹节奏趋同，张力持续升高。', onChanged: (v) => setState(() => _ratioSync = v)),
                _RatioSliderRow(label: '临界', value: _ratioCritical, description: '小比例：短暂缠绕、压缩、接近峰值。', onChanged: (v) => setState(() => _ratioCritical = v)),
                _RatioSliderRow(label: '释放', value: _ratioRelease, description: '最小比例：短促柔光脉冲，避免变成烟花式爆炸。', onChanged: (v) => setState(() => _ratioRelease = v)),
                _RatioSliderRow(label: '余韵', value: _ratioAfterglow, description: '最小比例：残影、少量光尘、快速回到黑场。', onChanged: (v) => setState(() => _ratioAfterglow = v)),
                _PhaseRatioSummary(
                  separation: _ratioSeparation,
                  attraction: _ratioAttraction,
                  sync: _ratioSync,
                  critical: _ratioCritical,
                  release: _ratioRelease,
                  afterglow: _ratioAfterglow,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _randomizePreview,
                  icon: const Icon(Icons.auto_awesome),
                  label: const Text('随机新构图'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _saveOnly,
                  icon: const Icon(Icons.save_alt),
                  label: const Text('保存参数'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: _saveAndOpen,
              icon: const Icon(Icons.wallpaper),
              label: const Text('设置为主屏幕/锁屏动态壁纸'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            '说明：Android 会打开系统动态壁纸预览页，能否单独设置锁屏取决于手机系统/厂商。已安装壁纸会从本页读取最新参数。',
            style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.45),
          ),
        ],
      ),
    );
  }
}

class _IntroCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withOpacity(0.08),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: const Text(
        '设计思想：参考 Windows Mystify 屏保视频，不做具象身体描绘；现在预览和真实壁纸都按“随机 Stroke 事件”工作：线条从手机可见范围任意位置即时出生、伸展、衰减和消失，而不是两条预设曲线移动。默认分离占最大比例，吸引和同步占主要比例，临界较少，释放和余韵最少；完整周期默认在 1～365 天之间随机生成；如需检查完整效果，可临时开启加速演示模式。',
        style: TextStyle(color: Colors.white70, height: 1.55),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withOpacity(0.06),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _SliderRow extends StatelessWidget {
  const _SliderRow({required this.label, required this.value, required this.description, required this.onChanged});
  final String label;
  final double value;
  final String description;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text('${(value * 100).round()}%', style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(value: value, onChanged: onChanged),
          Text(description, style: const TextStyle(color: Colors.white54, fontSize: 12, height: 1.35)),
        ],
      ),
    );
  }
}

class _DaySliderRow extends StatelessWidget {
  const _DaySliderRow({required this.label, required this.value, required this.min, required this.max, required this.onChanged});
  final String label;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    final safeMax = math.max(min, max);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text('${value.round()} 天', style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(
            value: value.clamp(min, safeMax).toDouble(),
            min: min,
            max: safeMax,
            divisions: math.max(1, (safeMax - min).round()),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}


class _MinuteSliderRow extends StatelessWidget {
  const _MinuteSliderRow({required this.label, required this.value, required this.min, required this.max, required this.onChanged});
  final String label;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text('${value.toStringAsFixed(1)} 分钟', style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(
            value: value.clamp(min, max).toDouble(),
            min: min,
            max: max,
            divisions: 119,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class _RatioSliderRow extends StatelessWidget {
  const _RatioSliderRow({required this.label, required this.value, required this.description, required this.onChanged});
  final String label;
  final double value;
  final String description;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text(value.toStringAsFixed(3), style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(value: value.clamp(0.002, 0.70).toDouble(), min: 0.002, max: 0.70, onChanged: onChanged),
          Text(description, style: const TextStyle(color: Colors.white54, fontSize: 12, height: 1.35)),
        ],
      ),
    );
  }
}

class _PhaseRatioSummary extends StatelessWidget {
  const _PhaseRatioSummary({required this.separation, required this.attraction, required this.sync, required this.critical, required this.release, required this.afterglow});
  final double separation;
  final double attraction;
  final double sync;
  final double critical;
  final double release;
  final double afterglow;

  @override
  Widget build(BuildContext context) {
    final total = math.max(0.001, separation + attraction + sync + critical + release + afterglow);
    String pct(double v) => '${(v / total * 100).toStringAsFixed(1)}%';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: Colors.black.withOpacity(0.18),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Text(
        '归一化后：分离 ${pct(separation)} · 吸引 ${pct(attraction)} · 同步 ${pct(sync)} · 临界 ${pct(critical)} · 释放 ${pct(release)} · 余韵 ${pct(afterglow)}',
        style: const TextStyle(color: Colors.white60, fontSize: 12, height: 1.45),
      ),
    );
  }
}

class _HeroPreview extends StatelessWidget {
  const _HeroPreview({
    required this.seconds,
    required this.style,
    required this.intimacy,
    required this.randomness,
    required this.ribbonWidth,
    required this.trail,
    required this.fullScreenCoverage,
    required this.bubbles,
    required this.ratioSeparation,
    required this.ratioAttraction,
    required this.ratioSync,
    required this.ratioCritical,
    required this.ratioRelease,
    required this.ratioAfterglow,
    required this.seed,
  });

  final double seconds;
  final int style;
  final double intimacy;
  final double randomness;
  final double ribbonWidth;
  final double trail;
  final double fullScreenCoverage;
  final bool bubbles;
  final double ratioSeparation;
  final double ratioAttraction;
  final double ratioSync;
  final double ratioCritical;
  final double ratioRelease;
  final double ratioAfterglow;
  final int seed;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 9 / 13,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: CustomPaint(
          painter: _MystifyPreviewPainter(
            seconds: seconds,
            style: style,
            intimacy: intimacy,
            randomness: randomness,
            ribbonWidth: ribbonWidth,
            trail: trail,
            fullScreenCoverage: fullScreenCoverage,
            bubbles: bubbles,
            ratioSeparation: ratioSeparation,
            ratioAttraction: ratioAttraction,
            ratioSync: ratioSync,
            ratioCritical: ratioCritical,
            ratioRelease: ratioRelease,
            ratioAfterglow: ratioAfterglow,
            seed: seed,
          ),
          child: Container(
            alignment: Alignment.topLeft,
            padding: const EdgeInsets.all(18),
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.24),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Text('加速预览：全屏随机 Stroke 发生器', style: TextStyle(color: Colors.white70, fontSize: 12)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}


class _MystifyPreviewPainter extends CustomPainter {
  _MystifyPreviewPainter({
    required this.seconds,
    required this.style,
    required this.intimacy,
    required this.randomness,
    required this.ribbonWidth,
    required this.trail,
    required this.fullScreenCoverage,
    required this.bubbles,
    required this.ratioSeparation,
    required this.ratioAttraction,
    required this.ratioSync,
    required this.ratioCritical,
    required this.ratioRelease,
    required this.ratioAfterglow,
    required this.seed,
  });

  final double seconds;
  final int style;
  final double intimacy;
  final double randomness;
  final double ribbonWidth;
  final double trail;
  final double fullScreenCoverage;
  final bool bubbles;
  final double ratioSeparation;
  final double ratioAttraction;
  final double ratioSync;
  final double ratioCritical;
  final double ratioRelease;
  final double ratioAfterglow;
  final int seed;

  static const List<List<Color>> palettes = [
    [Color(0xFF7DD3FC), Color(0xFFC4B5FD), Color(0xFFF472B6), Color(0xFFFDE68A), Color(0xFF030712)],
    [Color(0xFF67E8F9), Color(0xFF93C5FD), Color(0xFFC4B5FD), Color(0xFFFDE68A), Color(0xFF020617)],
    [Color(0xFFA78BFA), Color(0xFFD8B4FE), Color(0xFFF9A8D4), Color(0xFFFFF7ED), Color(0xFF050316)],
    [Color(0xFFE5E7EB), Color(0xFFFFFFFF), Color(0xFF93C5FD), Color(0xFFD1D5DB), Color(0xFF000000)],
    [Color(0xFFFDE68A), Color(0xFFFFF7ED), Color(0xFFFB7185), Color(0xFFFACC15), Color(0xFF06030A)],
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final palette = palettes[style % palettes.length];
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = palette[4]);

    final cycle = 36.0;
    final u = (seconds % cycle) / cycle;
    final phase = _phase(u);
    final local = _smooth((u - phase.start) / math.max(0.001, phase.end - phase.start));
    final release = phase.name == '释放' ? math.sin(local * math.pi) : 0.0;
    final after = phase.name == '余韵' ? local : 0.0;
    final intensity = (phase.intensity * (0.76 + intimacy * 0.52)).clamp(0.0, 1.25).toDouble();
    final tension = (phase.tension * (0.74 + intimacy * 0.56)).clamp(0.0, 1.25).toDouble();

    // 这版预览不再画“两个固定曲线对象”。它模拟真实 Mystify：
    // 多个 StrokeEvent 从全屏任意位置出生，每帧即时画当前线段，旧事件只以残影形式短暂存在。
    final coverage = fullScreenCoverage.clamp(0.35, 1.0).toDouble();
    final safe = Rect.fromLTWH(
      size.width * (1 - coverage) * 0.5,
      size.height * (1 - coverage) * 0.5,
      size.width * coverage,
      size.height * coverage,
    );

    final densityByPhase = switch (phase.name) {
      '分离' => 0.42,
      '吸引' => 0.76,
      '同步' => 0.86,
      '临界' => 1.12,
      '释放' => 1.24,
      _ => 0.46,
    };
    final basePeriod = lerpDouble(4.8, 1.45, (randomness * 0.55 + densityByPhase * 0.45).clamp(0.0, 1.0))!;
    final activeBack = 7 + (trail * 5).round();
    final currentIndex = (seconds / basePeriod).floor();

    // Sparse soft field only, not decorative clutter.
    if (intensity > 0.15 || release > 0.0 || after > 0.0) {
      final fieldCenter = _eventPoint(currentIndex - 1, 91, safe, size);
      final field = Paint()
        ..shader = RadialGradient(
          colors: [
            palette[1].withOpacity(0.05 + intensity * 0.06 + release * 0.15),
            palette[2].withOpacity(0.025 + intensity * 0.035),
            Colors.transparent,
          ],
        ).createShader(Rect.fromCircle(center: fieldCenter, radius: size.shortestSide * (0.25 + intensity * 0.20 + release * 0.24)));
      canvas.drawCircle(fieldCenter, size.shortestSide * (0.25 + intensity * 0.20 + release * 0.24), field);
    }

    for (int event = currentIndex - activeBack; event <= currentIndex + 1; event++) {
      final start = event * basePeriod + _hash01(event, 19) * basePeriod * 0.35;
      final life = basePeriod * (1.20 + _hash01(event, 23) * 1.50 + trail * 0.95);
      final age = seconds - start;
      if (age < 0 || age > life) continue;
      final progress = (age / life).clamp(0.0, 1.0).toDouble();
      final fade = math.sin(progress * math.pi).clamp(0.0, 1.0).toDouble();
      final eventPhase = _phaseForEvent(phase.name, event);
      final alphaBase = (0.10 + fade * (0.24 + intensity * 0.40)) * (eventPhase == '分离' ? 0.62 : 1.0);
      final trailSteps = 3 + (trail * 7).round();
      for (int step = trailSteps; step >= 0; step--) {
        final lag = step * 0.055 * (0.6 + trail);
        final localAge = (age - lag).clamp(0.0, life).toDouble();
        final localProgress = (localAge / life).clamp(0.0, 1.0).toDouble();
        final lagAlpha = alphaBase * math.pow(1.0 - step / (trailSteps + 1), 1.8) * (step == 0 ? 1.0 : 0.42);
        _drawStrokeEvent(
          canvas,
          size,
          safe,
          palette,
          event,
          localProgress,
          seconds - lag,
          lagAlpha,
          intensity,
          tension,
          release,
          eventPhase,
        );
      }
    }

    if (release > 0.0) {
      final center = _eventPoint(currentIndex, 777, safe, size);
      final pulse = Paint()
        ..shader = RadialGradient(
          colors: [Colors.white.withOpacity(0.62 * release), palette[3].withOpacity(0.20 * release), Colors.transparent],
        ).createShader(Rect.fromCircle(center: center, radius: size.shortestSide * (0.08 + release * 0.62)));
      canvas.drawCircle(center, size.shortestSide * (0.08 + release * 0.62), pulse);
    }

    if (bubbles && after > 0.02) {
      final bubblePaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withOpacity(0.07 * after);
      for (int i = 0; i < 6; i++) {
        final c = _eventPoint(currentIndex - i, 111 + i, safe, size);
        final r = size.shortestSide * (0.020 + _hash01(i + seed, 77) * 0.040 + after * 0.030);
        canvas.drawCircle(c, r, bubblePaint);
      }
    }

    final textPaint = TextPainter(
      text: TextSpan(text: phase.name, style: const TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.w600)),
      textDirection: TextDirection.ltr,
    )..layout();
    textPaint.paint(canvas, Offset(size.width - textPaint.width - 18, 18));
  }

  String _phaseForEvent(String mainPhase, int event) {
    if (mainPhase == '分离') {
      return _hash01(event, 401) < 0.78 ? '分离' : '吸引';
    }
    if (mainPhase == '吸引') {
      return _hash01(event, 402) < 0.66 ? '吸引' : '分离';
    }
    if (mainPhase == '同步') {
      return _hash01(event, 403) < 0.70 ? '同步' : '吸引';
    }
    if (mainPhase == '临界') {
      return _hash01(event, 404) < 0.68 ? '临界' : '同步';
    }
    if (mainPhase == '释放') return '释放';
    return _hash01(event, 405) < 0.72 ? '余韵' : '分离';
  }

  void _drawStrokeEvent(
    Canvas canvas,
    Size size,
    Rect safe,
    List<Color> palette,
    int event,
    double progress,
    double t,
    double alpha,
    double intensity,
    double tension,
    double release,
    String eventPhase,
  ) {
    if (alpha <= 0.002) return;
    final mode = (_hash01(event, 3) * 6).floor();
    final points = <Offset>[];
    final controlCount = 2 + (_hash01(event, 5) * 4).floor();
    for (int i = 0; i < controlCount; i++) {
      final base = _basePointForMode(event, i, mode, safe, size);
      final amp = size.shortestSide * (0.020 + randomness * 0.045 + tension * 0.030);
      final vx = math.sin(t * (0.42 + _hash01(event, 30 + i) * 0.72) + event * 0.37 + i * 1.9) * amp;
      final vy = math.cos(t * (0.36 + _hash01(event, 70 + i) * 0.66) + event * 0.29 + i * 1.4) * amp;
      var p = Offset(base.dx + vx, base.dy + vy);

      if (eventPhase == '吸引' || eventPhase == '同步' || eventPhase == '临界') {
        final attract = _eventPoint(event, 818, safe, size);
        final pull = eventPhase == '吸引' ? 0.05 : eventPhase == '同步' ? 0.10 : 0.16;
        p = Offset.lerp(p, attract, pull * intensity)!;
      }
      if (eventPhase == '释放') {
        final center = _eventPoint(event, 919, safe, size);
        p = Offset.lerp(p, center, release * 0.58)!;
      }
      points.add(p);
    }
    if (points.length < 2) return;

    // Mystify 是“正在画出来”的线，不是整条线整体移动；预览中只显示当前事件的一段。
    final visible = (progress < 0.55)
        ? _smooth(progress / 0.55)
        : (1.0 - _smooth((progress - 0.55) / 0.45) * 0.22);
    final sampled = _sampleCurve(points, 54);
    final count = (sampled.length * visible).round().clamp(2, sampled.length);
    final startDrop = progress > 0.72 ? ((progress - 0.72) / 0.28 * sampled.length * 0.38).round() : 0;
    final visiblePts = sampled.sublist(startDrop.clamp(0, count - 2), count);
    if (visiblePts.length < 2) return;
    final path = Path()..moveTo(visiblePts.first.dx, visiblePts.first.dy);
    for (int i = 1; i < visiblePts.length; i++) {
      path.lineTo(visiblePts[i].dx, visiblePts[i].dy);
    }

    final colorA = palette[(event + 1) % 4];
    final colorB = palette[(event + 2) % 4];
    final baseWidth = (1.6 + ribbonWidth * 5.2) * (0.72 + intensity * 0.78 + release * 0.34);
    final shader = LinearGradient(colors: [colorA.withOpacity(0.90), colorB.withOpacity(0.90)]).createShader(Offset.zero & size);

    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..shader = shader
      ..strokeWidth = baseWidth * (eventPhase == '分离' ? 2.4 : 3.8)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, baseWidth * 1.3)
      ..color = Colors.white.withOpacity(alpha * 0.55);
    canvas.drawPath(path, glow);

    final body = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..shader = shader
      ..strokeWidth = baseWidth * (eventPhase == '分离' ? 0.62 : 0.92)
      ..color = Colors.white.withOpacity(alpha);
    canvas.drawPath(path, body);

    final core = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = math.max(0.8, baseWidth * 0.16)
      ..color = Colors.white.withOpacity((alpha * 1.35).clamp(0.0, 0.86));
    canvas.drawPath(path, core);
  }

  List<Offset> _sampleCurve(List<Offset> controls, int samples) {
    final pts = <Offset>[];
    if (controls.length == 2) return [controls[0], controls[1]];
    for (int s = 0; s < samples; s++) {
      final u = s / (samples - 1);
      final scaled = u * (controls.length - 1);
      final i = scaled.floor().clamp(0, controls.length - 2);
      final local = scaled - i;
      final p0 = controls[(i - 1).clamp(0, controls.length - 1)];
      final p1 = controls[i];
      final p2 = controls[(i + 1).clamp(0, controls.length - 1)];
      final p3 = controls[(i + 2).clamp(0, controls.length - 1)];
      pts.add(_catmull(p0, p1, p2, p3, local));
    }
    return pts;
  }

  Offset _catmull(Offset p0, Offset p1, Offset p2, Offset p3, double t) {
    final t2 = t * t;
    final t3 = t2 * t;
    return Offset(
      0.5 * ((2 * p1.dx) + (-p0.dx + p2.dx) * t + (2*p0.dx - 5*p1.dx + 4*p2.dx - p3.dx) * t2 + (-p0.dx + 3*p1.dx - 3*p2.dx + p3.dx) * t3),
      0.5 * ((2 * p1.dy) + (-p0.dy + p2.dy) * t + (2*p0.dy - 5*p1.dy + 4*p2.dy - p3.dy) * t2 + (-p0.dy + 3*p1.dy - 3*p2.dy + p3.dy) * t3),
    );
  }

  Offset _basePointForMode(int event, int index, int mode, Rect safe, Size size) {
    final a = _hash01(event * 17 + index, 101);
    final b = _hash01(event * 17 + index, 102);
    switch (mode) {
      case 0: // left/right edge sweep
        return Offset(index == 0 ? safe.left : index == 1 ? safe.right : lerpDouble(safe.left, safe.right, a)!, lerpDouble(safe.top, safe.bottom, b)!);
      case 1: // top/bottom edge sweep
        return Offset(lerpDouble(safe.left, safe.right, a)!, index == 0 ? safe.top : index == 1 ? safe.bottom : lerpDouble(safe.top, safe.bottom, b)!);
      case 2: // diagonal full-screen trace
        final reverse = _hash01(event, 120) < 0.5;
        final s = (index / 4.0).clamp(0.0, 1.0);
        final x = reverse ? lerpDouble(safe.right, safe.left, s)! : lerpDouble(safe.left, safe.right, s)!;
        final y = _hash01(event, 121) < 0.5 ? lerpDouble(safe.top, safe.bottom, s)! : lerpDouble(safe.bottom, safe.top, s)!;
        return Offset(x, y);
      case 3: // arbitrary long line
        return _eventPoint(event + index * 37, 133, safe, size);
      case 4: // corner cut-in
        final corner = (_hash01(event, 140) * 4).floor();
        final cornerP = [safe.topLeft, safe.topRight, safe.bottomRight, safe.bottomLeft][corner];
        return Offset.lerp(cornerP, _eventPoint(event + index * 13, 141, safe, size), (index / 3.0).clamp(0.0, 1.0))!;
      default: // short local arc but still anywhere on screen
        final center = _eventPoint(event, 150, safe, size);
        final radius = math.min(safe.width, safe.height) * (0.10 + _hash01(event, 151) * 0.18);
        final angle = _hash01(event, 152) * math.pi * 2 + index * 0.75;
        return Offset(center.dx + math.cos(angle) * radius, center.dy + math.sin(angle) * radius * 0.72);
    }
  }

  Offset _eventPoint(int event, int salt, Rect safe, Size size) {
    return Offset(
      lerpDouble(safe.left, safe.right, _hash01(event, salt))!,
      lerpDouble(safe.top, safe.bottom, _hash01(event, salt + 1))!,
    );
  }

  double _hash01(int n, int salt) {
    var x = (n + seed * 1009 + salt * 9176) & 0x7fffffff;
    x = (x ^ 61) ^ (x >> 16);
    x = x + (x << 3);
    x = x ^ (x >> 4);
    x = x * 0x27d4eb2d;
    x = x ^ (x >> 15);
    return ((x & 0x7fffffff) / 0x7fffffff).clamp(0.0, 1.0).toDouble();
  }

  _Phase _phase(double u) {
    final total = math.max(0.001, ratioSeparation + ratioAttraction + ratioSync + ratioCritical + ratioRelease + ratioAfterglow);
    final r0 = ratioSeparation / total;
    final r1 = ratioAttraction / total;
    final r2 = ratioSync / total;
    final r3 = ratioCritical / total;
    final r4 = ratioRelease / total;
    final s1 = r0;
    final s2 = s1 + r1;
    final s3 = s2 + r2;
    final s4 = s3 + r3;
    final s5 = s4 + r4;
    if (u < s1) return _Phase('分离', 0.0, s1, 0.06, 0.00, 0.04);
    if (u < s2) return _Phase('吸引', s1, s2, 0.24, 0.16, 0.16);
    if (u < s3) return _Phase('同步', s2, s3, 0.58, 0.58, 0.52);
    if (u < s4) return _Phase('临界', s3, s4, 0.98, 0.92, 1.00);
    if (u < s5) return _Phase('释放', s4, s5, 1.00, 1.00, 0.46);
    return _Phase('余韵', s5, 1.0, 0.22, 0.54, 0.08);
  }

  double _smooth(double x) {
    x = x.clamp(0.0, 1.0);
    return x * x * (3 - 2 * x);
  }

  @override
  bool shouldRepaint(covariant _MystifyPreviewPainter oldDelegate) => true;
}

class _Phase {
  const _Phase(this.name, this.start, this.end, this.intensity, this.closeness, this.tension);
  final String name;
  final double start;
  final double end;
  final double intensity;
  final double closeness;
  final double tension;
}
