package com.example.quote_app.wallpaper;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.util.Random;

/**
 * 发现之旅/触摸：Mystify 风格动态艺术壁纸。
 *
 * V2 参考用户提供的 Windows Mystify 屏保视频重新设计：
 * 1. 大面积黑场留白，不再把画面填满。
 * 2. 每次只出现 1~2 条主光带，偶尔出现扇形平行残影，避免杂乱。
 * 3. 活动范围、线条数量、方向、曲率、宽度、颜色、出现位置全部随机。
 * 4. 临界/释放/余韵阶段占比很少；大部分时间停留在吸引、同步、升高。
 * 5. 以抽象的两条生命轨迹表达亲密过程，不出现任何具象身体或露骨画面。
 */
public class IntimacyMystifyWallpaperService extends WallpaperService {
    public static final String PREFS = "intimacy_mystify_wallpaper";

    @Override
    public Engine onCreateEngine() {
        return new MystifyEngine();
    }

    final class MystifyEngine extends Engine {
        private RenderThread renderThread;
        private boolean visible = false;

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            ensureThread(holder);
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            if (renderThread != null) renderThread.resize(width, height);
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            if (renderThread != null) renderThread.setVisible(visible);
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
        }

        @Override
        public void onDestroy() {
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
            super.onDestroy();
        }

        private void ensureThread(SurfaceHolder holder) {
            if (renderThread == null) {
                renderThread = new RenderThread(getApplicationContext(), holder);
                renderThread.setVisible(visible);
                renderThread.start();
            }
        }
    }

    static final class RenderThread extends Thread {
        private final Context context;
        private final SurfaceHolder holder;
        private final SharedPreferences prefs;
        private final Random random = new Random();

        private volatile boolean running = true;
        private volatile boolean visible = false;
        private int width = 1;
        private int height = 1;
        private Bitmap buffer;
        private Canvas bufferCanvas;

        private final Paint fadePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint corePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint softPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pulsePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bubblePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private Config cfg = new Config();
        private long lastConfigRead = 0L;
        private long startMs = SystemClock.elapsedRealtime();
        private long sceneStartMs = startMs;
        private float sceneDurationSec = 5.0f;
        private float nextAutoSceneSec = 0f;
        private float seedPhase = 0f;

        private MystifyScene scene;

        RenderThread(Context context, SurfaceHolder holder) {
            super("IntimacyMystifyWallpaperRenderer");
            this.context = context.getApplicationContext();
            this.holder = holder;
            this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

            fadePaint.setStyle(Paint.Style.FILL);
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeCap(Paint.Cap.ROUND);
            glowPaint.setStrokeJoin(Paint.Join.ROUND);
            bodyPaint.setStyle(Paint.Style.STROKE);
            bodyPaint.setStrokeCap(Paint.Cap.ROUND);
            bodyPaint.setStrokeJoin(Paint.Join.ROUND);
            corePaint.setStyle(Paint.Style.STROKE);
            corePaint.setStrokeCap(Paint.Cap.ROUND);
            corePaint.setStrokeJoin(Paint.Join.ROUND);
            softPaint.setStyle(Paint.Style.FILL);
            pulsePaint.setStyle(Paint.Style.FILL);
            bubblePaint.setStyle(Paint.Style.STROKE);

            readConfig(true);
            randomizeScene(true, Phase.ALL[0]);
        }

        void setVisible(boolean visible) { this.visible = visible; }
        void requestStop() { running = false; interrupt(); }

        synchronized void resize(int w, int h) {
            if (w <= 0 || h <= 0) return;
            width = w;
            height = h;
            if (buffer != null) buffer.recycle();
            buffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bufferCanvas = new Canvas(buffer);
            bufferCanvas.drawColor(Color.BLACK);
            randomizeScene(true, Phase.ALL[0]);
        }

        @Override
        public void run() {
            long lastFrame = SystemClock.elapsedRealtime();
            while (running) {
                if (!visible) {
                    sleepQuiet(120);
                    lastFrame = SystemClock.elapsedRealtime();
                    continue;
                }
                long now = SystemClock.elapsedRealtime();
                float dt = Math.min(0.05f, (now - lastFrame) / 1000f);
                lastFrame = now;
                if (now - lastConfigRead > 900L) readConfig(false);
                drawFrame(now, dt);
                sleepQuiet(cfg.powerSave ? 44 : 26);
            }
        }

        private void drawFrame(long nowMs, float dt) {
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;
                if (width <= 2 || height <= 2) resize(canvas.getWidth(), canvas.getHeight());
                if (buffer == null || bufferCanvas == null) resize(canvas.getWidth(), canvas.getHeight());

                float sec = (nowMs - startMs) / 1000f;
                float cycle = 120f;
                float u = (sec % cycle) / cycle;
                Phase phase = Phase.of(u);
                float local = smooth((u - phase.start) / Math.max(0.001f, phase.end - phase.start));
                float release = phase.name.equals("释放") ? (float)Math.sin(local * Math.PI) : 0f;
                float after = phase.name.equals("余韵") ? local : 0f;
                float intimacyScale = 0.74f + 0.54f * cfg.intimacy;
                float intensity = clamp(phase.intensity * intimacyScale, 0f, 1.35f);
                float closeness = clamp(phase.closeness + (float)Math.sin(local * Math.PI) * 0.05f, 0f, 1f);
                float tension = clamp(phase.tension * (0.72f + 0.62f * cfg.intimacy), 0f, 1.25f);

                // 参考 Mystify：短场景不断切换，每次位置、方向、线条形态都不同。
                if (scene == null || sec > nextAutoSceneSec) {
                    randomizeScene(false, phase);
                    nextAutoSceneSec = sec + sceneDurationSec;
                }

                int[] colors = palette(cfg.style);
                // 黑底 + 适度残影。数值越大残影越短，避免上一版糊成一团。
                int fadeAlpha = (int)lerp(42f, 86f, 1f - cfg.trail);
                fadeAlpha += cfg.powerSave ? 10 : 0;
                if (scene.justBorn) fadeAlpha = 156; // 换场时快速清黑，形成 Windows 屏保式“重新出现”。
                fadePaint.setColor(Color.argb(clampInt(fadeAlpha, 0, 255), 0, 0, 0));
                bufferCanvas.drawRect(0, 0, width, height, fadePaint);
                scene.justBorn = false;

                float sceneAge = (nowMs - sceneStartMs) / 1000f;
                updateScene(scene, dt, sec, sceneAge, phase, intensity, closeness, tension, release);

                drawSparseBackground(bufferCanvas, colors, phase, intensity, release, after, sec);
                drawScene(bufferCanvas, scene, colors, phase, intensity, tension, release, after, sec);
                drawRarePulse(bufferCanvas, scene, colors, release, after, sec);
                if (cfg.bubbles) drawMinimalAfterglow(bufferCanvas, scene, colors, after, sec);

                canvas.drawColor(Color.BLACK);
                canvas.drawBitmap(buffer, 0, 0, null);
            } catch (Throwable ignored) {
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas); } catch (Throwable ignored) {}
                }
            }
        }

        private void updateScene(MystifyScene s, float dt, float sec, float sceneAge, Phase phase,
                                 float intensity, float closeness, float tension, float release) {
            float dt60 = dt * 60f;
            float speedScale = s.speed * (0.40f + 0.70f * intensity + 0.40f * tension);
            float cx = s.bounds.centerX();
            float cy = s.bounds.centerY();
            for (int si = 0; si < s.strokeCount; si++) {
                Stroke stroke = s.strokes[si];
                for (int i = 0; i < stroke.count; i++) {
                    float rel = (i - (stroke.count - 1) * 0.5f) / Math.max(1f, (stroke.count - 1) * 0.5f);
                    float wave = (float)Math.sin(sec * (0.75f + stroke.freq) + i * 0.92f + stroke.seed);
                    float drift = (float)Math.cos(sec * (0.43f + stroke.freq * 0.4f) + i * 1.37f + stroke.seed);

                    stroke.vx[i] += wave * 0.018f * width * speedScale * (0.45f + cfg.randomness);
                    stroke.vy[i] += drift * 0.018f * height * speedScale * (0.45f + cfg.randomness);

                    // 不同阶段的“关系力”：吸引很轻，靠近/同步/升高更明显；释放时短促合拢。
                    float relation = phase.relation * (0.18f + cfg.intimacy * 0.60f);
                    float targetX = cx;
                    float targetY = cy;
                    if (s.mode == MystifyScene.MODE_EDGE_SWEEP) {
                        targetX = lerp(s.bounds.left, s.bounds.right, 0.5f + 0.22f * (float)Math.sin(sec * 0.32f + s.seed));
                        targetY = lerp(s.bounds.top, s.bounds.bottom, 0.5f + 0.18f * (float)Math.cos(sec * 0.27f + s.seed));
                    }
                    float attraction = 0.0018f * relation * dt60;
                    stroke.vx[i] += (targetX - stroke.x[i]) * attraction;
                    stroke.vy[i] += (targetY - stroke.y[i]) * attraction;

                    if (release > 0f) {
                        stroke.vx[i] += (cx - stroke.x[i]) * release * 0.018f * dt60;
                        stroke.vy[i] += (cy - stroke.y[i]) * release * 0.018f * dt60;
                    }

                    stroke.x[i] += stroke.vx[i] * dt60;
                    stroke.y[i] += stroke.vy[i] * dt60;
                    stroke.vx[i] *= 0.955f;
                    stroke.vy[i] *= 0.955f;

                    // Mystify 式反弹：随机子区域内活动，不总是居中。
                    float pad = Math.max(16f, Math.min(width, height) * 0.025f);
                    if (stroke.x[i] < s.bounds.left + pad) { stroke.x[i] = s.bounds.left + pad; stroke.vx[i] = Math.abs(stroke.vx[i]) * 0.92f; }
                    if (stroke.x[i] > s.bounds.right - pad) { stroke.x[i] = s.bounds.right - pad; stroke.vx[i] = -Math.abs(stroke.vx[i]) * 0.92f; }
                    if (stroke.y[i] < s.bounds.top + pad) { stroke.y[i] = s.bounds.top + pad; stroke.vy[i] = Math.abs(stroke.vy[i]) * 0.92f; }
                    if (stroke.y[i] > s.bounds.bottom - pad) { stroke.y[i] = s.bounds.bottom - pad; stroke.vy[i] = -Math.abs(stroke.vy[i]) * 0.92f; }
                }
            }
        }

        private void drawScene(Canvas c, MystifyScene s, int[] colors, Phase phase, float intensity,
                               float tension, float release, float after, float sec) {
            for (int i = 0; i < s.strokeCount; i++) {
                Stroke stroke = s.strokes[i];
                int colorA = stroke.colorA;
                int colorB = stroke.colorB;
                Path path = stroke.path();

                // Fan 模式：少量平行残影，类似视频中偶尔出现的“梳状/扇形 Mystify 线”。
                if (stroke.fanLines > 0) {
                    float nx = (float)Math.cos(stroke.fanAngle);
                    float ny = (float)Math.sin(stroke.fanAngle);
                    int fanCount = stroke.fanLines;
                    for (int f = fanCount; f >= 1; f--) {
                        c.save();
                        float off = (f - fanCount * 0.5f) * stroke.fanGap * (0.55f + intensity);
                        c.translate(nx * off, ny * off);
                        bodyPaint.setShader(null);
                        bodyPaint.setColor(withAlpha(colorB, (int)((20 + intensity * 38) * (1f - f / (fanCount + 2f)))));
                        bodyPaint.setStrokeWidth(Math.max(0.7f, stroke.baseWidth * (0.30f + 0.10f * intensity)));
                        bodyPaint.setMaskFilter(null);
                        c.drawPath(path, bodyPaint);
                        c.restore();
                    }
                }

                float baseWidth = lerp(1.4f, 7.2f, cfg.ribbonWidth) * stroke.widthScale * (0.70f + intensity * 0.86f + release * 0.58f);
                float glowWidth = baseWidth * stroke.glowScale * (4.0f + intensity * 1.5f);
                Shader shader = new LinearGradient(stroke.x[0], stroke.y[0], stroke.x[stroke.count - 1], stroke.y[stroke.count - 1],
                        withAlpha(colorA, 245), withAlpha(colorB, 235), Shader.TileMode.CLAMP);

                glowPaint.setShader(shader);
                glowPaint.setStrokeWidth(glowWidth);
                glowPaint.setAlpha((int)(34 + intensity * 52 + release * 68));
                glowPaint.setMaskFilter(new BlurMaskFilter(Math.max(4f, baseWidth * 1.7f), BlurMaskFilter.Blur.NORMAL));
                c.drawPath(path, glowPaint);

                bodyPaint.setShader(shader);
                bodyPaint.setStrokeWidth(baseWidth * (1.50f + 0.36f * tension));
                bodyPaint.setAlpha((int)(86 + intensity * 92 + release * 45));
                bodyPaint.setMaskFilter(null);
                c.drawPath(path, bodyPaint);

                corePaint.setShader(null);
                corePaint.setColor(withAlpha(Color.WHITE, (int)(138 + intensity * 94 + release * 35)));
                corePaint.setStrokeWidth(Math.max(0.8f, baseWidth * 0.22f));
                corePaint.setMaskFilter(null);
                c.drawPath(path, corePaint);

                glowPaint.setShader(null);
                bodyPaint.setShader(null);
            }
        }

        private void drawSparseBackground(Canvas c, int[] colors, Phase phase, float intensity, float release, float after, float sec) {
            if (scene == null) return;
            // 只保留极淡背景呼吸，不再画大量光环/粒子。
            float cx = scene.bounds.centerX();
            float cy = scene.bounds.centerY();
            float r = Math.min(width, height) * (0.16f + intensity * 0.08f + release * 0.22f);
            int alpha = (int)(8 + intensity * 14 + release * 42 - after * 8);
            if (alpha <= 0) return;
            softPaint.setShader(new RadialGradient(cx, cy, r, new int[]{withAlpha(colors[1], alpha), withAlpha(colors[2], alpha / 2), Color.TRANSPARENT}, null, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, softPaint);
            softPaint.setShader(null);
        }

        private void drawRarePulse(Canvas c, MystifyScene s, int[] colors, float release, float after, float sec) {
            if (release <= 0.001f && after <= 0.001f) return;
            float cx = s.bounds.centerX();
            float cy = s.bounds.centerY();
            float radius = Math.min(width, height) * (0.025f + release * 0.46f + after * 0.08f);
            int alpha = (int)(release * 185 + after * 22);
            pulsePaint.setShader(new RadialGradient(cx, cy, radius, new int[]{withAlpha(Color.WHITE, alpha), withAlpha(colors[3], alpha / 3), Color.TRANSPARENT}, null, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, radius, pulsePaint);
            pulsePaint.setShader(null);
            if (release > 0f) {
                corePaint.setShader(null);
                corePaint.setColor(withAlpha(colors[3], (int)(release * 126)));
                corePaint.setStrokeWidth(1.2f + release * 3.2f);
                c.drawCircle(cx, cy, Math.min(width, height) * (0.055f + release * 0.28f), corePaint);
            }
        }

        private void drawMinimalAfterglow(Canvas c, MystifyScene s, int[] colors, float after, float sec) {
            if (after <= 0.03f) return;
            float cx = s.bounds.centerX();
            float cy = s.bounds.centerY();
            bubblePaint.setStyle(Paint.Style.STROKE);
            bubblePaint.setStrokeWidth(1.0f);
            for (int i = 0; i < 4; i++) {
                float a = (float)(i * Math.PI * 0.5f + sec * (0.07f + i * 0.01f) + s.seed);
                float rr = Math.min(width, height) * (0.08f + i * 0.025f + after * 0.10f);
                float x = cx + (float)Math.cos(a) * rr;
                float y = cy + (float)Math.sin(a * 1.19f) * rr * 0.62f;
                int alpha = (int)(after * 20f * (1f - i * 0.12f));
                bubblePaint.setColor(withAlpha(i % 2 == 0 ? colors[1] : colors[2], alpha));
                c.drawCircle(x, y, Math.min(width, height) * (0.012f + i * 0.002f), bubblePaint);
            }
        }

        private void randomizeScene(boolean hardClear, Phase phase) {
            if (width <= 2 || height <= 2) return;
            seedPhase = random.nextFloat() * (float)Math.PI * 2f;
            sceneStartMs = SystemClock.elapsedRealtime();
            sceneDurationSec = 3.2f + random.nextFloat() * (3.8f + cfg.randomness * 2.2f);
            scene = new MystifyScene();
            scene.seed = random.nextFloat() * (float)Math.PI * 2f;
            scene.mode = randomMode(phase);
            scene.speed = 0.46f + random.nextFloat() * (0.55f + cfg.randomness * 0.65f);
            scene.justBorn = true;

            // 活动范围随机：有时在左/右/上/下角，有时横向扫过，不再永远居中。
            float bw = width * (0.32f + random.nextFloat() * 0.42f);
            float bh = height * (0.22f + random.nextFloat() * 0.46f);
            if (scene.mode == MystifyScene.MODE_LONG_SWEEP) {
                bw = width * (0.72f + random.nextFloat() * 0.24f);
                bh = height * (0.16f + random.nextFloat() * 0.30f);
            }
            float left = random.nextFloat() * Math.max(1f, width - bw);
            float top = random.nextFloat() * Math.max(1f, height - bh);
            scene.bounds = new RectF(left, top, left + bw, top + bh);

            // 线条数不是固定两条：视频里经常只有一条；同步/升高阶段才更常出现两条。
            float twoChance = 0.22f + phase.relation * 0.44f + cfg.intimacy * 0.14f;
            scene.strokeCount = random.nextFloat() < twoChance ? 2 : 1;
            if (phase.name.equals("升高") && random.nextFloat() < 0.18f) scene.strokeCount = 3;
            if (phase.name.equals("吸引") && random.nextFloat() < 0.72f) scene.strokeCount = 1;
            scene.strokes = new Stroke[scene.strokeCount];

            int[] colors = palette(cfg.style);
            for (int i = 0; i < scene.strokeCount; i++) {
                Stroke stroke = new Stroke(3 + random.nextInt(4));
                stroke.seed = random.nextFloat() * (float)Math.PI * 2f;
                stroke.freq = 0.22f + random.nextFloat() * 0.85f;
                stroke.baseWidth = 1.0f + random.nextFloat() * 2.8f;
                stroke.widthScale = 0.62f + random.nextFloat() * 1.18f;
                stroke.glowScale = 0.72f + random.nextFloat() * 1.05f;
                stroke.colorA = pickColor(colors, i * 2);
                stroke.colorB = pickColor(colors, i * 2 + 1);
                // 偶尔出现 Mystify 参考视频里的平行扇形线，不能总出现。
                if (random.nextFloat() < (0.14f + cfg.randomness * 0.18f) && scene.mode != MystifyScene.MODE_SINGLE_ARC) {
                    stroke.fanLines = 4 + random.nextInt(9);
                    stroke.fanGap = Math.min(width, height) * (0.010f + random.nextFloat() * 0.018f);
                    stroke.fanAngle = random.nextFloat() * (float)Math.PI;
                } else {
                    stroke.fanLines = 0;
                    stroke.fanGap = 0f;
                    stroke.fanAngle = 0f;
                }
                initStroke(stroke, scene, i);
                scene.strokes[i] = stroke;
            }

            if (hardClear && bufferCanvas != null) bufferCanvas.drawColor(Color.BLACK, PorterDuff.Mode.SRC);
        }

        private int randomMode(Phase phase) {
            float r = random.nextFloat();
            if (phase.name.equals("吸引")) {
                if (r < 0.56f) return MystifyScene.MODE_SINGLE_ARC;
                if (r < 0.78f) return MystifyScene.MODE_EDGE_SWEEP;
                return MystifyScene.MODE_LONG_SWEEP;
            }
            if (phase.name.equals("同步")) {
                if (r < 0.38f) return MystifyScene.MODE_CROSSING;
                if (r < 0.68f) return MystifyScene.MODE_LONG_SWEEP;
                return MystifyScene.MODE_SINGLE_ARC;
            }
            if (phase.name.equals("升高")) {
                if (r < 0.42f) return MystifyScene.MODE_CROSSING;
                if (r < 0.74f) return MystifyScene.MODE_FAN;
                return MystifyScene.MODE_LONG_SWEEP;
            }
            if (phase.name.equals("临界") || phase.name.equals("释放")) return MystifyScene.MODE_CROSSING;
            return MystifyScene.MODE_SINGLE_ARC;
        }

        private void initStroke(Stroke s, MystifyScene scene, int index) {
            float angle = random.nextFloat() * (float)Math.PI * 2f;
            if (scene.mode == MystifyScene.MODE_LONG_SWEEP) angle = random.nextBoolean() ? 0f : (float)Math.PI;
            if (scene.mode == MystifyScene.MODE_EDGE_SWEEP) angle = random.nextFloat() * (float)Math.PI;
            float len = Math.min(scene.bounds.width(), scene.bounds.height()) * (0.18f + random.nextFloat() * 0.32f);
            float cx = lerp(scene.bounds.left, scene.bounds.right, 0.18f + random.nextFloat() * 0.64f);
            float cy = lerp(scene.bounds.top, scene.bounds.bottom, 0.18f + random.nextFloat() * 0.64f);
            if (scene.strokeCount >= 2) {
                float side = index == 0 ? -1f : 1f;
                cx = scene.bounds.centerX() + side * scene.bounds.width() * (0.18f + random.nextFloat() * 0.22f);
                cy = scene.bounds.centerY() + (random.nextFloat() - 0.5f) * scene.bounds.height() * 0.28f;
            }
            float speed = Math.min(width, height) * (0.0025f + random.nextFloat() * 0.0065f);
            for (int i = 0; i < s.count; i++) {
                float rel = (i - (s.count - 1) * 0.5f) / Math.max(1f, (s.count - 1) * 0.5f);
                float curve = (float)Math.sin(i * 1.25f + s.seed) * len * 0.55f;
                s.x[i] = cx + (float)Math.cos(angle) * rel * len + (float)Math.cos(angle + Math.PI / 2f) * curve;
                s.y[i] = cy + (float)Math.sin(angle) * rel * len + (float)Math.sin(angle + Math.PI / 2f) * curve;
                s.vx[i] = (float)Math.cos(angle) * speed * (0.8f + random.nextFloat() * 1.4f) + (random.nextFloat() - 0.5f) * speed;
                s.vy[i] = (float)Math.sin(angle) * speed * (0.8f + random.nextFloat() * 1.4f) + (random.nextFloat() - 0.5f) * speed;
            }
        }

        private int pickColor(int[] colors, int idx) {
            switch (Math.floorMod(idx + random.nextInt(4), 4)) {
                case 0: return colors[0];
                case 1: return colors[1];
                case 2: return colors[2];
                default: return colors[3];
            }
        }

        private void readConfig(boolean force) {
            long now = SystemClock.elapsedRealtime();
            if (!force && now - lastConfigRead < 500L) return;
            lastConfigRead = now;
            cfg.style = prefs.getInt("style", 0);
            cfg.intimacy = prefs.getFloat("intimacy", 0.72f);
            cfg.randomness = prefs.getFloat("randomness", 0.48f);
            cfg.ribbonWidth = prefs.getFloat("ribbonWidth", 0.55f);
            cfg.trail = prefs.getFloat("trail", 0.62f);
            cfg.bubbles = prefs.getBoolean("bubbles", true);
            cfg.powerSave = prefs.getBoolean("powerSave", false);
            long savedSeed = prefs.getLong("seed", 0L);
            if (savedSeed != 0L && random.nextInt(800) == 7) random.setSeed(savedSeed ^ now);
        }

        private int[] palette(int style) {
            switch (Math.floorMod(style, 5)) {
                case 1: return new int[]{0xFF67E8F9, 0xFF93C5FD, 0xFFC4B5FD, 0xFFFDE68A, 0xFF020617};
                case 2: return new int[]{0xFFA78BFA, 0xFFD8B4FE, 0xFFF9A8D4, 0xFFFFF7ED, 0xFF050316};
                case 3: return new int[]{0xFFE5E7EB, 0xFFFFFFFF, 0xFF93C5FD, 0xFFD1D5DB, 0xFF000000};
                case 4: return new int[]{0xFFFDE68A, 0xFFFFF7ED, 0xFFFB7185, 0xFFFACC15, 0xFF06030A};
                default: return new int[]{0xFF7DD3FC, 0xFFC4B5FD, 0xFFF472B6, 0xFFFDE68A, 0xFF030712};
            }
        }

        private static int withAlpha(int color, int alpha) {
            return (clampInt(alpha, 0, 255) << 24) | (color & 0x00FFFFFF);
        }
        private static int clampInt(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }
        private static float clamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }
        private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
        private static float smooth(float x) { x = clamp(x, 0f, 1f); return x * x * (3f - 2f * x); }
        private static void sleepQuiet(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }
    }

    static final class MystifyScene {
        static final int MODE_SINGLE_ARC = 0;
        static final int MODE_LONG_SWEEP = 1;
        static final int MODE_EDGE_SWEEP = 2;
        static final int MODE_CROSSING = 3;
        static final int MODE_FAN = 4;

        RectF bounds = new RectF(0, 0, 1, 1);
        Stroke[] strokes = new Stroke[0];
        int strokeCount = 0;
        int mode = MODE_SINGLE_ARC;
        float speed = 1f;
        float seed = 0f;
        boolean justBorn = true;
    }

    static final class Stroke {
        final int count;
        final float[] x;
        final float[] y;
        final float[] vx;
        final float[] vy;
        int colorA;
        int colorB;
        float seed;
        float freq;
        float baseWidth = 1f;
        float widthScale = 1f;
        float glowScale = 1f;
        int fanLines = 0;
        float fanGap = 0f;
        float fanAngle = 0f;

        Stroke(int count) {
            this.count = count;
            x = new float[count]; y = new float[count]; vx = new float[count]; vy = new float[count];
        }

        Path path() {
            Path p = new Path();
            if (count <= 0) return p;
            p.moveTo(x[0], y[0]);
            for (int i = 1; i < count - 1; i++) {
                float mx = (x[i] + x[i + 1]) * 0.5f;
                float my = (y[i] + y[i + 1]) * 0.5f;
                p.quadTo(x[i], y[i], mx, my);
            }
            p.lineTo(x[count - 1], y[count - 1]);
            return p;
        }
    }

    static final class Config {
        int style = 0;
        float intimacy = 0.72f;
        float randomness = 0.48f;
        float ribbonWidth = 0.55f;
        float trail = 0.62f;
        boolean bubbles = true;
        boolean powerSave = false;
    }

    static final class Phase {
        final String name;
        final float start;
        final float end;
        final float intensity;
        final float closeness;
        final float tension;
        final float relation;

        Phase(String name, float start, float end, float intensity, float closeness, float tension, float relation) {
            this.name = name;
            this.start = start;
            this.end = end;
            this.intensity = intensity;
            this.closeness = closeness;
            this.tension = tension;
            this.relation = relation;
        }

        // 临界 + 释放 + 余韵合计只有 10%，绝大多数时间用于吸引、同步、升高。
        static final Phase[] ALL = new Phase[]{
                new Phase("吸引", 0.00f, 0.30f, 0.23f, 0.10f, 0.12f, 0.10f),
                new Phase("靠近", 0.30f, 0.38f, 0.38f, 0.34f, 0.28f, 0.42f),
                new Phase("同步", 0.38f, 0.66f, 0.56f, 0.58f, 0.48f, 0.68f),
                new Phase("升高", 0.66f, 0.90f, 0.78f, 0.76f, 0.74f, 0.82f),
                new Phase("临界", 0.90f, 0.94f, 0.95f, 0.90f, 1.00f, 0.96f),
                new Phase("释放", 0.94f, 0.965f, 1.00f, 1.00f, 0.44f, 1.00f),
                new Phase("余韵", 0.965f, 1.00f, 0.26f, 0.54f, 0.08f, 0.24f),
        };

        static Phase of(float u) {
            for (Phase p : ALL) if (u >= p.start && u < p.end) return p;
            return ALL[ALL.length - 1];
        }
    }
}
