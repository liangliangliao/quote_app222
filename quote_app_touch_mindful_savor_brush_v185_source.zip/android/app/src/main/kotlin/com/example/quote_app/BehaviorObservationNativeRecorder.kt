package com.example.quote_app

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.text.TextUtils
import com.example.quote_app.data.DbInspector
import org.json.JSONArray
import java.io.File
import java.util.Calendar

/**
 * V13 行为观察：通知快捷记录的原生落库器。
 *
 * 设计目标：用户收到提醒后，不必打开 Flutter 页面，直接在通知动作中选择观察层面、输入文字，
 * 原生侧把记录写入同一个 sqflite SQLite 数据库。
 */
object BehaviorObservationNativeRecorder {
  private const val TABLE = "behavior_tracking_records"

  @JvmStatic
  fun saveFromNotification(ctx: Context, layer: String?, text: String?, payload: String?): Long {
    val db = openAppDb(ctx) ?: return -1L
    return try {
      ensureTable(db)
      val now = System.currentTimeMillis()
      val recordDay = dayStartMs(now)
      val cleanLayer = normalizeLayer(layer)
      val content = (text ?: "").trim().ifBlank { "通知快捷记录" }
      val values = ContentValues().apply {
        put("created_at_ms", now)
        put("updated_at_ms", now)
        put("record_date_ms", recordDay)
        put("mode", "notification_quick")
        put("entry_mode", "notification_remote_input")
        put("template_key", templateKeyOf(cleanLayer))
        put("method_name", "通知快捷记录")
        put("primary_layer", cleanLayer)
        put("category", categoryOf(cleanLayer))
        put("title", titleOf(cleanLayer, content))
        put("source", "notification_remote_input")
        put("privacy_level", "local_only")
        put("notes", "来自行为观察提醒通知。用户在通知中选择「$cleanLayer」并直接输入保存。")
        put("tags_json", JSONArray(listOf("行为观察", "通知快捷记录", cleanLayer)).toString())
      }
      when (cleanLayer) {
        "时间层面" -> {
          values.put("behavior", content)
          values.put("unit", "分钟")
        }
        "行为层面" -> values.put("behavior", content)
        "情绪层面" -> {
          values.put("emotion", content)
          values.put("behavior", "通知中记录了一条情绪相关行为事实")
        }
        "认知层面" -> {
          values.put("automatic_thought", content)
          values.put("cognition", content)
          values.put("behavior", "通知中记录了一条认知/想法线索")
        }
        "结果层面" -> {
          values.put("short_term_result", content)
          values.put("outcome", content)
          values.put("behavior", "通知中记录了一条结果线索")
        }
        "环境层面" -> {
          values.put("environment", content)
          values.put("behavior", "通知中记录了一条环境线索")
        }
        "身体状态层面" -> {
          values.put("body_state", content)
          values.put("behavior", "通知中记录了一条身体状态线索")
          values.put("category", "休息")
        }
        else -> values.put("behavior", content)
      }
      db.insert(TABLE, null, values)
    } catch (t: Throwable) {
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "[BehaviorObservation] notification save failed: ${t.javaClass.simpleName} ${t.message}") } catch (_: Throwable) {}
      -1L
    } finally {
      try { db.close() } catch (_: Throwable) {}
    }
  }

  private fun openAppDb(ctx: Context): SQLiteDatabase? {
    val candidates = ArrayList<String>()
    try {
      val contract = DbInspector.loadOrLightScan(ctx.applicationContext)
      val path = contract?.dbPath
      if (!path.isNullOrBlank()) candidates.add(path)
    } catch (_: Throwable) {}
    try { candidates.add(File(ctx.applicationInfo.dataDir + "/app_flutter/quotes.db").absolutePath) } catch (_: Throwable) {}
    try { candidates.add(File(ctx.filesDir, "quotes.db").absolutePath) } catch (_: Throwable) {}
    for (path in candidates.distinct()) {
      try {
        if (path.isBlank()) continue
        val f = File(path)
        if (!f.exists()) continue
        return SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READWRITE)
      } catch (_: Throwable) {}
    }
    return null
  }

  private fun ensureTable(db: SQLiteDatabase) {
    db.execSQL("""
      CREATE TABLE IF NOT EXISTS $TABLE (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at_ms INTEGER NOT NULL,
        updated_at_ms INTEGER NOT NULL,
        record_date_ms INTEGER NOT NULL,
        mode TEXT,
        entry_mode TEXT,
        template_key TEXT,
        method_name TEXT,
        primary_layer TEXT,
        category TEXT,
        title TEXT,
        source TEXT,
        privacy_level TEXT,
        start_minute INTEGER,
        end_minute INTEGER,
        behavior TEXT,
        reason TEXT,
        outcome TEXT,
        emotion TEXT,
        emotion_intensity INTEGER,
        trigger_text TEXT,
        cognition TEXT,
        reaction TEXT,
        automatic_thought TEXT,
        short_term_result TEXT,
        long_term_impact TEXT,
        environment TEXT,
        body_state TEXT,
        sleep TEXT,
        steps INTEGER,
        exercise_min INTEGER,
        notes TEXT,
        tags_json TEXT,
        template_answers_json TEXT
      )
    """.trimIndent())
    val needed = linkedMapOf(
      "entry_mode" to "TEXT", "template_key" to "TEXT", "method_name" to "TEXT", "primary_layer" to "TEXT",
      "source" to "TEXT", "privacy_level" to "TEXT", "behavior" to "TEXT", "unit" to "TEXT",
      "outcome" to "TEXT", "cognition" to "TEXT", "automatic_thought" to "TEXT", "short_term_result" to "TEXT",
      "long_term_impact" to "TEXT", "environment" to "TEXT", "body_state" to "TEXT", "notes" to "TEXT", "tags_json" to "TEXT"
    )
    val existing = HashSet<String>()
    var c: Cursor? = null
    try {
      c = db.rawQuery("PRAGMA table_info($TABLE)", null)
      while (c.moveToNext()) existing.add(c.getString(1))
    } finally {
      try { c?.close() } catch (_: Throwable) {}
    }
    for ((name, type) in needed) {
      if (!existing.contains(name)) {
        try { db.execSQL("ALTER TABLE $TABLE ADD COLUMN $name $type") } catch (_: Throwable) {}
      }
    }
  }

  private fun dayStartMs(now: Long): Long {
    val cal = Calendar.getInstance()
    cal.timeInMillis = now
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    return cal.timeInMillis
  }

  private fun normalizeLayer(layer: String?): String {
    val raw = (layer ?: "").trim()
    return when {
      raw.contains("时间") -> "时间层面"
      raw.contains("行为") -> "行为层面"
      raw.contains("情绪") -> "情绪层面"
      raw.contains("认知") || raw.contains("想法") -> "认知层面"
      raw.contains("结果") -> "结果层面"
      raw.contains("环境") -> "环境层面"
      raw.contains("身体") || raw.contains("睡眠") || raw.contains("精力") -> "身体状态层面"
      else -> "行为层面"
    }
  }

  private fun templateKeyOf(layer: String): String = when (layer) {
    "时间层面" -> "time_block"
    "行为层面" -> "quick_capture"
    "情绪层面" -> "emotion_thought"
    "认知层面" -> "emotion_thought"
    "结果层面" -> "tbr"
    "环境层面" -> "full_observation"
    "身体状态层面" -> "body_snapshot"
    else -> "quick_capture"
  }

  private fun categoryOf(layer: String): String = when (layer) {
    "身体状态层面" -> "休息"
    else -> "未分类"
  }

  private fun titleOf(layer: String, content: String): String {
    val short = if (content.length > 18) content.substring(0, 18) + "…" else content
    return "通知记录 · ${layer.replace("层面", "")}：$short"
  }
}
