package com.example.quote_app.wallpaper;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.graphics.Color;
import android.graphics.RectF;
import android.opengl.GLES20;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;

/**
 * 发现之旅/触摸：Mystify 亲密艺术动态壁纸。
 *
 * V8 解决三个核心问题：
 * 1) 底层从 Canvas/Bitmap 升级为 OpenGL ES + FBO ping-pong 残影。
 *    真正采用“每帧即时绘制当前随机线条，上一帧只靠 FBO 残影衰减保留”的 Mystify 逻辑。
 * 2) 引入全屏 Stroke Event Generator：每条线从手机可见屏幕任意位置、任意边缘、任意角落、任意两点即时生成，
 *    并用热区采样器避免长期集中在一小块区域。
 * 3) 增加 phosphor decay、加色混合、扇形光网、纤维丝带、点线喷洒与棱镜余影，
 *    对齐参考视频里“黑场中彩色光迹生成、折叠、拖尾、淡出”的观感。
 * 5) V28 新增艺术导演：花瓣钩弧、叶片藤蔓、电子纱扇、银白折刃、菱形框片、长弓光桥等母型轮换，
 *    避免所有点线组成近似同一形状，也减少无组织散乱感。
 * 6) V29 新增“反重复生命系统”：母型冷却记忆、低差异黄金采样、非周期相位、深层变体、
 *    水母触须/星云涡旋/折纸光片/星座碎链，让长期播放更难出现雷同画面。
 * 7) V30 从“点线网状”升级为“雕塑形态”：液态光泡、羽翼、花冠、丝绸幕、能量环、晶体光片。
 * 8) V31 把余韵阶段升级为深蓝水域气泡；V32 去除大圆盘和旧小残泡，改为中心爆散的透明彩膜气泡。
 * 9) V33 进一步把气泡做成水晶薄膜：蓝色水域背景、透明折射感、随机爆散；同时在余韵/新周期做 FBO 清洁，避免旧线条留下脏痕。
 * 10) V34 把“释放”阶段从普通圆形脉冲升级为抽象能量爆发：白金光心、粗大放射光束、暖金/橙红辉光、
 *     高速碎光粒子洪流与短暂满屏白化；只借鉴爆发节奏与光效层次，不复制参考视频中的角色、武器或道具。
 * 11) V35 继续强化释放阶段的“突然颤抖 + 强刺激爆光 + 扫屏光柱 + 碎光洪流”：
 *     通过高频错位重影、短促白化、宽幅冲击楔面、斜切扫光和更密的抽象碎片，增强视频中先抖动再爆发的冲击。
 * 12) V36 把释放开头改为更短、更快、更剧烈的硬震颤；同时余韵气泡改为无 FBO 拖尾的逐帧水晶泡，
 *     避免移动时出现筒状重影/残影，只保留透明膜边、白色高光与轻微折射。
 * 13) V37 把释放震颤升级为“硬震屏错位”：按真实秒数驱动 0.5 秒可见强震窗口，加入全屏白闪、
 *     斜向撕裂光带、核心多重错帧和大幅跳变偏移，让肉眼明确看到先剧烈颤动再爆发。
 * 14) V38 根据用户参考视频/桌面截图，把主体形体从“线条/点网”升级为“单体丝绸刃翼”：
 *     大面积半透明弧面、单侧厚翼、另一侧薄刃、尖端收束、白色切边、绿色/紫色光晕与细密等高线肋纹。
 *     大形体优先，细线只做边缘高光，不再让画面主要由细网格/点阵构成.
 * 15) V40 根据用户截图反馈，只重做“主体阶段”的形体生成与绘制：
 *     移除贯穿屏幕的粗直白带/灰白大宽面，改为参考视频里的局部彩色丝绸/蝠翼光膜、弯曲尖端和贴面细密肋纹。
 *     释放阶段和余韵阶段保持 V38 现有逻辑不变。
 * 16) V41 继续细化主体形体：从“沿中心线加宽的飘带”改为“单侧扇形薄膜/折叠光幕”。
 *     宽面从屏幕边缘/暗处展开，沿弯曲折脊收束到尖钩；肋纹贴着膜面汇聚，白光只保留为短折脊/尖端高光。
 *     仍只作用于分离、吸引、同步、临界主体阶段；释放和余韵阶段绘制函数保持不动。
 * 17) V57 根据用户反馈，把主体阶段改为“现场作画式”实时生成：
 *     当前画面由移动笔尖和短时间历史轨迹共同生成，历史长度逐渐增长，膜面、折脊、外缘、肋线每帧连续变化。
 *     重点解决完整主体直接出现、形体切换不够丝滑、缺少逐笔绘画过程的问题；释放和余韵阶段保持不动。
 * 18) V58 根据标准视频文字画像继续深度改造主体阶段：
 *     不再只画完整历史轮廓，而是按“光笔正在黑场作画”的方式，把新鲜笔尖、湿润外缘、透明膜面、
 *     细密肋线、短回声和颜色流动绑定在同一个时间窗口内。每段膜面/线条都按年龄分段衰减，
 *     让形体看起来是一笔一笔被画出、展开、扭转、收束、消散，而不是完整物体平移或换形。
 * 19) V59 按“光笔画出会呼吸的透明生命体”重新校正主体阶段：
 *     取消厚实带状主体，改为笔尖推进 + 中段开膜 + 喉口扇骨 + 细密流线 + 极短湿迹回声。
 *     膜面只是低透明承托，主体显形主要依靠外缘高光、折脊、肋线和随笔尖年龄衰减的颜色流动。
 * 20) V60 新增“审美导演 / 美感约束”主体系统：
 *     笔尖轨迹不再直接随机，而是由若干书法式样条候选生成、评分、择优；用曲率、纵横比、弯折节奏、
 *     自交风险、宽度分布来过滤丑形。膜面改成沿主脊线生长，肋线改为贴膜短骨与局部喉口扇骨混合，
 *     避免三角纸片、尾部打结、完整厚带和机械漂移。
 * 21) V61 新增“美学骨架锁定 / 大形体光膜”主体系统：
 *     不再让审美评分只挑出一条细弧线，而是先从精选书法光膜母型库中抽取优雅骨架，再用评分过滤。
 *     宽度包络改为黄金胸腔式开膜，主体中段形成可欣赏的透明翼幕/水母伞/折扇肋线；头尾仍保持笔尖
 *     推进与湿迹收束。每一帧都需要同时具备主骨架、负空间、透明膜面、细密肋线和局部高光.
 * 22) V62 立刻修复：主体阶段改为“吸引点光弦网 / 流线场生成器”。
 * 23) V63 修复：去掉硬边界 clamp，放大流线场，加入推进式笔尖与持续流场运动。
 *     由动态喉口、几十条等距弧形光线、负空间、透视压缩、颜色沿线流动和极淡透明膜面共同构成主体。
 *     线条主导，膜面辅助，彻底避免闭合叶片/布片轮廓；保留笔尖推进、短历史残影和实时呼吸变形。
 * 24) V64 修复：把主体从“画完后轻微呼吸”改成“全程滚动写入的活体光弦网”。
 * 25) V65 修复：增强“朝屏幕随机游走 + 形体持续千变万化”，用滚动书写相位替代一次性 reveal。
 *     当前帧只绘制随笔尖推进移动的时间窗口，旧窗口由短 FBO 湿迹保留并淡出；主脊线/喉口/旋涡/展开角持续重构，
 *     让画面始终处在写出、开膜、卷曲、收束、再生长的过程里，同时放大主体舞台和可见运动幅度。
 * 4) 保留天级宏观周期：分离最大，吸引/同步主要，临界较少，释放/余韵最少；所有比例和 1～365 天周期可配置.
 *
 * 动画只以抽象线条关系表达分离、吸引、同步、临界、释放、余韵，不出现任何具象身体或露骨画面。
 */
public class IntimacyMystifyWallpaperService extends WallpaperService {
    public static final String PREFS = "intimacy_mystify_wallpaper";

    @Override
    public Engine onCreateEngine() {
        return new MystifyEngine();
    }

    final class MystifyEngine extends Engine {
        private GLRenderThread renderThread;
        private boolean visible = false;

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            ensureThread(holder);
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            if (renderThread != null) renderThread.resize(width, height);
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            if (renderThread != null) renderThread.setVisible(visible);
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
        }

        @Override
        public void onDestroy() {
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
            super.onDestroy();
        }

        private void ensureThread(SurfaceHolder holder) {
            if (renderThread == null) {
                renderThread = new GLRenderThread(getApplicationContext(), holder, isPreview());
                renderThread.setVisible(visible);
                renderThread.start();
            }
        }
    }

    static final class GLRenderThread extends Thread {
        private static final int EGL_CONTEXT_CLIENT_VERSION = 0x3098;
        private static final int EGL_OPENGL_ES2_BIT = 4;
        private static final int GRID_COLS = 6;
        private static final int GRID_ROWS = 10;

        private final Context context;
        private final SurfaceHolder holder;
        private final boolean enginePreview;
        private final SharedPreferences prefs;
        private final OnSharedPreferenceChangeListener prefListener;
        private volatile boolean configDirty = true;
        private String visualConfigSignature = "";
        private static final int MOTIF_COUNT = 18;
        private final Random random = new Random();
        private final ArrayList<StrokeEvent> strokes = new ArrayList<>();
        private final int[] spawnHeat = new int[GRID_COLS * GRID_ROWS];
        // V29：短期形态记忆。不是禁止重复，而是让最近出现过的母型降权，避免几分钟内
        // 反复看到同一种“线条整体轮廓”。
        private final int[] motifCooldown = new int[MOTIF_COUNT];
        private int artSpawnIndex = 0;

        private volatile boolean running = true;
        private volatile boolean visible = false;
        private volatile int requestedWidth = 1;
        private volatile int requestedHeight = 1;
        private volatile boolean resizePending = true;

        private int width = 1;
        private int height = 1;
        private int spawnCounter = 0;

        private EGL10 egl;
        private EGLDisplay eglDisplay;
        private EGLConfig eglConfig;
        private EGLContext eglContext;
        private EGLSurface eglSurface;

        private int textureProgram = 0;
        private int colorProgram = 0;
        private int[] fbo = new int[]{0, 0};
        private int[] tex = new int[]{0, 0};
        private int readIndex = 0;
        private int writeIndex = 1;
        private boolean fboReady = false;

        private Config cfg = new Config();
        private long lastConfigRead = 0L;
        private long startMs = SystemClock.elapsedRealtime();
        private float nextSpawnSec = 0f;
        private float nextHardClearSec = 8f;
        private long cycleStartWallMs = 0L;
        private float cycleDurationSec = 86400f;
        private float cycleCriticalStartSec = 0f;
        private float cycleReleaseStartSec = 0f;
        private float cycleReleaseDurationSec = 12f;
        private float cycleAfterglowDurationSec = 24f;
        private float cycleCriticalDurationSec = 60f;
        private float lastVisualSec = -1f;
        private String cycleSignature = "";
        private float pulseX = 0.5f;
        private float pulseY = 0.5f;
        private boolean releasePulseArmed = true;
        // V33：余韵气泡每一轮都使用新的随机种子；阶段切换时清理 FBO，避免上一阶段线条在桌面上留下灰黑痕迹。
        private int afterglowSeed = random.nextInt();
        private int releaseSeed = random.nextInt();
        private String lastPhaseName = "";
        private int cachedAestheticEpisode = Integer.MIN_VALUE;
        private int cachedAestheticGesture = 0;

        GLRenderThread(Context context, SurfaceHolder holder, boolean enginePreview) {
            super("IntimacyMystifyGLRendererV65KineticFlowCreature");
            this.context = context.getApplicationContext();
            this.holder = holder;
            this.enginePreview = enginePreview;
            this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            this.prefListener = new OnSharedPreferenceChangeListener() {
                @Override public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                    configDirty = true;
                }
            };
            this.prefs.registerOnSharedPreferenceChangeListener(this.prefListener);
            readConfig(true);
        }

        void setVisible(boolean visible) { this.visible = visible; }
        void requestStop() { running = false; interrupt(); }
        void resize(int w, int h) {
            if (w > 0 && h > 0) {
                requestedWidth = w;
                requestedHeight = h;
                resizePending = true;
            }
        }

        @Override
        public void run() {
            if (!initEgl()) return;
            try {
                initGlObjects();
                long last = SystemClock.elapsedRealtime();
                while (running) {
                    if (!visible) {
                        sleepQuiet(120);
                        last = SystemClock.elapsedRealtime();
                        continue;
                    }
                    long now = SystemClock.elapsedRealtime();
                    float dt = clamp((now - last) / 1000f, 0.001f, 0.055f);
                    last = now;
                    if (configDirty || now - lastConfigRead > 3000L) readConfig(false);
                    if (resizePending || !fboReady) {
                        applyResize();
                    }
                    renderFrame(now, dt);
                    egl.eglSwapBuffers(eglDisplay, eglSurface);
                    sleepQuiet(cfg.powerSave ? 38 : 18);
                }
            } catch (Throwable ignored) {
            } finally {
                try { prefs.unregisterOnSharedPreferenceChangeListener(prefListener); } catch (Throwable ignored) {}
                releaseGl();
            }
        }

        private boolean initEgl() {
            try {
                egl = (EGL10) EGLContext.getEGL();
                eglDisplay = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
                if (eglDisplay == EGL10.EGL_NO_DISPLAY) return false;
                int[] version = new int[2];
                if (!egl.eglInitialize(eglDisplay, version)) return false;
                int[] configAttrs = new int[]{
                        EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
                        EGL10.EGL_RED_SIZE, 8,
                        EGL10.EGL_GREEN_SIZE, 8,
                        EGL10.EGL_BLUE_SIZE, 8,
                        EGL10.EGL_ALPHA_SIZE, 8,
                        EGL10.EGL_DEPTH_SIZE, 0,
                        EGL10.EGL_STENCIL_SIZE, 0,
                        EGL10.EGL_NONE
                };
                EGLConfig[] configs = new EGLConfig[1];
                int[] num = new int[1];
                if (!egl.eglChooseConfig(eglDisplay, configAttrs, configs, 1, num) || num[0] <= 0) return false;
                eglConfig = configs[0];
                int[] ctxAttrs = new int[]{EGL_CONTEXT_CLIENT_VERSION, 2, EGL10.EGL_NONE};
                eglContext = egl.eglCreateContext(eglDisplay, eglConfig, EGL10.EGL_NO_CONTEXT, ctxAttrs);
                if (eglContext == EGL10.EGL_NO_CONTEXT) return false;
                eglSurface = egl.eglCreateWindowSurface(eglDisplay, eglConfig, holder, null);
                if (eglSurface == null || eglSurface == EGL10.EGL_NO_SURFACE) return false;
                return egl.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext);
            } catch (Throwable ignored) {
                return false;
            }
        }

        private void initGlObjects() {
            textureProgram = createProgram(TEXTURE_VERTEX, TEXTURE_FRAGMENT);
            colorProgram = createProgram(COLOR_VERTEX, COLOR_FRAGMENT);
            GLES20.glDisable(GLES20.GL_DEPTH_TEST);
            GLES20.glDisable(GLES20.GL_CULL_FACE);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            applyResize();
        }

        private void applyResize() {
            resizePending = false;
            width = Math.max(2, requestedWidth);
            height = Math.max(2, requestedHeight);
            GLES20.glViewport(0, 0, width, height);
            recreateFbos(width, height);
            strokes.clear();
            resetSpawnHeat();
            nextSpawnSec = 0f;
            nextHardClearSec = 6f + random.nextFloat() * 12f;
            afterglowSeed = random.nextInt();
            lastPhaseName = "";
            startMs = SystemClock.elapsedRealtime();
        }

        private void recreateFbos(int w, int h) {
            deleteFbos();
            GLES20.glGenTextures(2, tex, 0);
            GLES20.glGenFramebuffers(2, fbo, 0);
            for (int i = 0; i < 2; i++) {
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[i]);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
                GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null);
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[i]);
                GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, tex[i], 0);
                GLES20.glViewport(0, 0, w, h);
                GLES20.glClearColor(0f, 0f, 0f, 1f);
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            }
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
            readIndex = 0;
            writeIndex = 1;
            fboReady = true;
        }

        private void renderFrame(long nowMs, float dt) {
            if (!fboReady) return;
            ensureCycleState(false);

            // V25：新增“调试循环模式”。
            // debugLoopEnabled 会同时作用于 App 原生预览和真实桌面/锁屏动态壁纸，
            // 按分钟把一次完整过程无限循环，专门用于验证阶段比例和短阶段持续时间是否生效。
            // previewAccelerated 仍只作用于系统/应用预览，不影响正式壁纸。
            boolean useDebugLoop = cfg.debugLoopEnabled;
            boolean useAcceleratedPreview = !useDebugLoop && enginePreview && cfg.previewAccelerated;
            float durationSec = useDebugLoop
                    ? Math.max(60f, cfg.debugCycleMinutes * 60f)
                    : (useAcceleratedPreview ? Math.max(30f, cfg.previewCycleMinutes * 60f) : Math.max(1f, cycleDurationSec));

            float sec;
            if (useDebugLoop) {
                float raw = (SystemClock.elapsedRealtime() - startMs) / 1000f;
                sec = raw % durationSec;
            } else if (useAcceleratedPreview) {
                // 单次预览：只跑一次完整过程，不循环释放/余韵。
                float raw = (SystemClock.elapsedRealtime() - startMs) / 1000f;
                sec = Math.min(raw, Math.max(0.001f, durationSec - 0.001f));
            } else {
                sec = currentCycleElapsedSec();
                if (sec >= cycleDurationSec) {
                    beginNewCycle(System.currentTimeMillis());
                    sec = 0f;
                }
            }

            if (lastVisualSec >= 0f && sec + 0.20f < lastVisualSec) {
                // 只处理真实周期重置或配置变更造成的时间回退；演示模式不再循环。
                nextSpawnSec = 0f;
                nextHardClearSec = 6f + random.nextFloat() * 12f;
                strokes.clear();
                resetSpawnHeat();
                clearFbos();
                releasePulseArmed = true;
                afterglowSeed = random.nextInt();
                releaseSeed = random.nextInt();
                lastPhaseName = "";
            }
            lastVisualSec = sec;
            CyclePlan plan = (useDebugLoop || useAcceleratedPreview) ? previewPlan(durationSec) : storedCyclePlan(durationSec);
            Phase phase = Phase.of(sec, durationSec, cfg, plan);
            if (!phase.name.equals(lastPhaseName)) {
                String previousPhase = lastPhaseName;
                // V34：进入释放时重置释放特效种子，并洗掉前段过多线条，让释放画面像一次干净、强烈的能量爆发。
                if (phase.name.equals("释放")) {
                    releaseSeed = random.nextInt();
                    resetSpawnHeat();
                    clearFbos();
                }
                // 进入余韵时立即清空释放阶段的大形体残影，让气泡层从干净黑/蓝水域中出现。
                if (phase.name.equals("余韵") && cfg.bubbles) {
                    strokes.clear();
                    resetSpawnHeat();
                    clearFbos();
                    afterglowSeed = random.nextInt();
                    nextSpawnSec = sec + 9999f;
                }
                // 余韵结束后也清一次，避免透明泡泡/旧光迹在桌面上留下截图里那种灰黑网状痕迹。
                if (phase.name.equals("分离") && "余韵".equals(previousPhase)) {
                    strokes.clear();
                    resetSpawnHeat();
                    clearFbos();
                    nextSpawnSec = sec + 0.10f;
                }
                lastPhaseName = phase.name;
            }
            float rawLocal = clamp((sec - phase.start) / Math.max(0.001f, phase.end - phase.start), 0f, 1f);
            float local = smooth(rawLocal);
            float release = phase.name.equals("释放") ? (float)Math.sin(local * Math.PI) : 0f;
            float after = phase.name.equals("余韵") ? local : 0f;
            float intensity = clamp(phase.intensity * (0.74f + 0.52f * cfg.intimacy), 0f, 1.30f);
            float tension = clamp(phase.tension * (0.72f + 0.56f * cfg.intimacy), 0f, 1.35f);

            if (!phase.name.equals("释放")) releasePulseArmed = true;
            if (phase.name.equals("释放") && releasePulseArmed) {
                float[] p = pickLeastUsedPoint(false);
                pulseX = p[0] / Math.max(1f, width);
                pulseY = p[1] / Math.max(1f, height);
                releaseSeed = random.nextInt();
                releasePulseArmed = false;
            }

            boolean observedVideoSubjectPhase = !phase.name.equals("释放") && !phase.name.equals("余韵");
            if (observedVideoSubjectPhase) {
                // V47：主体阶段完全改为逐帧程序化视频薄膜，不再继续生成/更新旧 Mystify 光迹。
                // 这样可以根除用户截图中仍然出现的粗白斜带、黄带交叉、巨大灰白扇面和多主体叠加。
                strokes.clear();
            } else {
                if (sec >= nextSpawnSec && !(phase.name.equals("余韵") && cfg.bubbles)) spawnAccordingToPhase(phase, sec);
                updateStrokes(sec, dt, phase, intensity, tension, release);
            }

            // Windows Mystify 的“离开”不是突然清除，也不是对象死亡，而是上一帧缓慢被黑场吞没。
            // 因此这里不再定时 hard clear，只做 FBO 反馈衰减；trail 越高，背影越慢消失。
            // V17：Windows Mystify 的背影是“慢慢被黑场吞没”，不是快速衰亡。
            // 这里提高最低残留，让尾部能在头部继续游走时同步、缓慢、淡淡退场。
            float fade = lerp(0.940f, 0.985f, cfg.trail);
            if (phase.name.equals("余韵") && cfg.bubbles) {
                // V36：气泡不是依靠 FBO 拖尾移动。每帧先清空旧帧，再绘制当前透明泡，
                // 彻底避免截图中那种随运动拉成长筒的重影/残影。
                fade = 0.0f;
            } else if (phase.name.equals("余韵")) {
                fade = Math.min(fade, 0.955f);
            } else if (!phase.name.equals("释放")) {
                // V59：主体阶段需要可见但很短的湿迹回声；衰减太快会看不到“现场作画”，
                // 衰减太慢又会糊成脏带。这里保留数帧光痕，配合当前帧的年龄衰减线条。
                fade = cfg.powerSave ? 0.62f : lerp(0.68f, 0.78f, cfg.trail);
            }
            if (phase.name.equals("释放")) fade = Math.min(fade, lerp(0.780f, 0.900f, cfg.trail));
            if (cfg.powerSave) fade = Math.min(fade, 0.955f);

            // 1) FBO 残影：把上一帧纹理衰减写入新 FBO。
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[writeIndex]);
            GLES20.glViewport(0, 0, width, height);
            GLES20.glDisable(GLES20.GL_BLEND);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            drawTexture(tex[readIndex], fade);

            // 2) 即时绘制当前随机线条。旧线条历史不由对象保存，只由 FBO 残影留下。
            GLES20.glEnable(GLES20.GL_BLEND);
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE);
            if (observedVideoSubjectPhase) {
                drawObservedVideoMembrane(sec, rawLocal, phase, intensity, tension);
            } else if (!(phase.name.equals("余韵") && cfg.bubbles) && !(phase.name.equals("释放") && local > 0.16f)) {
                drawAllStrokes(phase, intensity, tension, release, after);
            }
            if (phase.name.equals("释放")) drawReleaseEruption(rawLocal, release, phase);
            drawAfterglowBubbleAquarium(sec, after, phase);
            GLES20.glDisable(GLES20.GL_BLEND);

            // 3) 输出到真实壁纸 Surface。
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
            GLES20.glViewport(0, 0, width, height);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            drawTexture(tex[writeIndex], 1f);

            int tmp = readIndex;
            readIndex = writeIndex;
            writeIndex = tmp;
        }

        private void spawnAccordingToPhase(Phase phase, float sec) {
            decayArtMemory();
            artSpawnIndex++;

            // V43：参考视频的主体不是两片大色带相互穿插，而是黑场中“一片主膜 + 极少量暗回声”。
            // 因此只在主体阶段（分离/吸引/同步/临界）改成单主体生成；释放与余韵继续走下面的旧逻辑。
            boolean videoSubjectPhase = !phase.name.equals("释放") && !phase.name.equals("余韵");
            if (videoSubjectPhase) {
                while (strokes.size() > 0) strokes.remove(0);
                int actor = phase.name.equals("分离") ? 1 : 2;
                StrokeEvent subject = createStroke(phase, random.nextBoolean() ? -1 : 1, false, actor);
                subject.relation = phase.name.equals("临界") ? 0.14f : (phase.name.equals("同步") ? 0.08f : 0.02f);
                strokes.add(subject);

                float base;
                if (phase.name.equals("分离")) base = 20.0f + random.nextFloat() * 26.0f;
                else if (phase.name.equals("吸引")) base = 15.0f + random.nextFloat() * 18.0f;
                else if (phase.name.equals("同步")) base = 10.0f + random.nextFloat() * 14.0f;
                else base = 7.0f + random.nextFloat() * 9.0f;
                float densityScale = lerp(1.40f, 0.78f, cfg.strokeDensity);
                if (cfg.powerSave) densityScale *= 1.35f;
                nextSpawnSec = sec + base * lerp(1.05f, 0.74f, cfg.randomness) * densityScale;
                return;
            }

            // V26：性交意蕴不再只靠“单条光迹”隐喻，而是默认同时保留两个不同主体：
            // A：冷色、较细、较锋利，像主动追寻的轨迹；
            // B：暖色、较柔、点线喷洒更丰富，像被吸引并回应的轨迹。
            // 两者在“分离”阶段远离且互不牵引，在“吸引/同步”阶段逐渐同频，
            // 在“临界/释放”阶段短暂向共同能量场聚拢，余韵后再回到分离。
            int maxStrokes = cfg.powerSave ? 2 : 2;
            if (phase.name.equals("临界") && !cfg.powerSave && cfg.strokeDensity > 0.55f) maxStrokes = 4;
            while (strokes.size() > maxStrokes) strokes.remove(0);

            // V30：扇面网格只作为少数回声出现，不再让整屏偏“细线网状”。
            boolean fanA = random.nextFloat() < phase.fanChance * (0.025f + cfg.randomness * 0.055f);
            boolean fanB = random.nextFloat() < phase.fanChance * (0.045f + cfg.randomness * 0.085f);
            if (phase.name.equals("分离")) { fanA = false; fanB = false; }
            if (phase.name.equals("余韵")) { fanA = false; fanB = false; }

            StrokeEvent a = createStroke(phase, -1, fanA, 1);
            StrokeEvent b = createStroke(phase, 1, fanB, 2);
            tuneActorPairForPhase(a, b, phase);
            strokes.add(a);
            strokes.add(b);

            float base;
            // 两个主体始终可见，但出生间隔仍保持克制，避免画面变成杂乱线团。
            if (phase.name.equals("分离")) base = 14.0f + random.nextFloat() * 26.0f;
            else if (phase.name.equals("吸引")) base = 7.0f + random.nextFloat() * 14.0f;
            else if (phase.name.equals("同步")) base = 4.5f + random.nextFloat() * 10.0f;
            else if (phase.name.equals("临界")) base = 2.0f + random.nextFloat() * 3.8f;
            else if (phase.name.equals("释放")) base = 6.5f + random.nextFloat() * 10.0f;
            else base = 13.0f + random.nextFloat() * 24.0f;
            float densityScale = lerp(1.55f, 0.58f, cfg.strokeDensity);
            if (cfg.powerSave) densityScale *= 1.40f;
            nextSpawnSec = sec + base * lerp(1.08f, 0.68f, cfg.randomness) * densityScale;
        }

        private void tuneActorPairForPhase(StrokeEvent a, StrokeEvent b, Phase phase) {
            a.partner = b;
            b.partner = a;
            if (phase.name.equals("分离")) {
                a.relation = 0f;
                b.relation = 0f;
                a.attractX = width * (0.12f + random.nextFloat() * 0.20f);
                b.attractX = width * (0.68f + random.nextFloat() * 0.20f);
                a.attractY = height * (0.18f + random.nextFloat() * 0.64f);
                b.attractY = height * (0.18f + random.nextFloat() * 0.64f);
                return;
            }
            float commonX = width * (0.32f + random.nextFloat() * 0.36f);
            float commonY = height * (0.26f + random.nextFloat() * 0.48f);
            if (phase.name.equals("吸引")) {
                a.relation = 0.18f;
                b.relation = 0.18f;
                a.attractX = lerp(a.attractX, commonX, 0.42f);
                a.attractY = lerp(a.attractY, commonY, 0.42f);
                b.attractX = lerp(b.attractX, commonX, 0.42f);
                b.attractY = lerp(b.attractY, commonY, 0.42f);
            } else if (phase.name.equals("同步")) {
                a.relation = 0.58f;
                b.relation = 0.58f;
                b.seed = a.seed + 0.18f + random.nextFloat() * 0.26f;
                b.speed = lerp(b.speed, a.speed, 0.72f);
                a.attractX = b.attractX = commonX;
                a.attractY = b.attractY = commonY;
            } else if (phase.name.equals("临界") || phase.name.equals("释放")) {
                a.relation = 0.92f;
                b.relation = 0.92f;
                b.seed = a.seed + 0.06f + random.nextFloat() * 0.12f;
                b.speed = lerp(b.speed, a.speed, 0.86f);
                a.attractX = b.attractX = commonX;
                a.attractY = b.attractY = commonY;
                a.widthScale *= 1.10f;
                b.widthScale *= 1.16f;
            } else { // 余韵
                a.relation = 0.08f;
                b.relation = 0.08f;
                a.attractX = lerp(a.attractX, commonX, 0.18f);
                a.attractY = lerp(a.attractY, commonY, 0.18f);
                b.attractX = lerp(b.attractX, commonX, 0.18f);
                b.attractY = lerp(b.attractY, commonY, 0.18f);
            }
        }


        private void decayArtMemory() {
            for (int i = 0; i < motifCooldown.length; i++) {
                motifCooldown[i] = Math.max(0, motifCooldown[i] - 1);
            }
        }

        private void rememberMotif(int motif) {
            if (motif < 0 || motif >= motifCooldown.length) return;
            motifCooldown[motif] = Math.max(motifCooldown[motif], 4);
            int neighborA = Math.max(0, motif - 1);
            int neighborB = Math.min(motifCooldown.length - 1, motif + 1);
            motifCooldown[neighborA] = Math.max(motifCooldown[neighborA], 1);
            motifCooldown[neighborB] = Math.max(motifCooldown[neighborB], 1);
        }

        private int chooseArtMotif(Phase phase, int actor) {
            float[] w = motifWeightsForPhase(phase.name);
            // V30：优先选择有完整轮廓的大形体，降低“电子纱扇/星座碎链”这类细网比例。
            // 12 liquid pod, 13 wing, 14 blossom, 15 silk sheet, 16 orbit halo, 17 crystal shard.
            if (actor == 1) {
                w[3] *= 1.15f;   // silver blade
                w[10] *= 0.92f;  // origami sheet
                w[13] *= 1.35f;  // wing
                w[15] *= 1.22f;  // silk sheet
                w[17] *= 1.32f;  // crystal shard
                w[2] *= 0.42f;   // less fan lattice
                w[11] *= 0.34f;  // less dot chain
            } else if (actor == 2) {
                w[4] *= 1.05f;   // petal hook
                w[6] *= 0.95f;   // vine
                w[12] *= 1.45f;  // liquid pod
                w[14] *= 1.58f;  // blossom
                w[16] *= 1.26f;  // orbit halo
                w[2] *= 0.35f;
                w[11] *= 0.28f;
            }

            // V29/V30：非周期“天气”。不同天气推动不同雕塑形态，而不是反复刷同一种曲线。
            float t = (SystemClock.elapsedRealtime() - startMs) / 1000f;
            float weatherA = 0.5f + 0.5f * (float)Math.sin(t * 0.0173f + artSpawnIndex * 0.618f);
            float weatherB = 0.5f + 0.5f * (float)Math.sin(t * 0.0117f + artSpawnIndex * 1.4142f + 2.1f);
            float weatherC = 0.5f + 0.5f * (float)Math.sin(t * 0.0079f + artSpawnIndex * 1.7320f + 4.7f);
            w[8] *= 0.66f + weatherB * 0.78f;
            w[9] *= 0.62f + weatherC * 0.92f;
            w[12] *= 0.70f + weatherA * 1.35f;
            w[13] *= 0.72f + weatherB * 1.22f;
            w[14] *= 0.68f + weatherC * 1.38f;
            w[15] *= 0.74f + (1f - weatherA) * 1.20f;
            w[16] *= 0.72f + (1f - weatherB) * 1.26f;
            w[17] *= 0.76f + (1f - weatherC) * 1.18f;
            w[2] *= 0.25f + weatherA * 0.18f;
            w[11] *= 0.20f + weatherB * 0.16f;
            // V33：整体更偏“有形状的生命体/光膜/花瓣/晶体”，减少奇怪细线和网状语言。
            for (int i = 0; i < 12; i++) w[i] *= 0.82f;
            for (int i = 12; i <= 17; i++) w[i] *= 1.28f;

            // V41：只修正“主体阶段”的形体。
            // 之前 V38 只是提高视频母型权重，仍会混入旧银白刃/大灰面，并且 13/15/17 本身会生成贯穿屏幕的白色斜带。
            // 这里在分离/吸引/同步/临界阶段锁定为参考视频主体：单侧折叠膜面 + 宽端裁切 + 弯曲尖端 + 贴面肋纹。
            // 释放阶段和余韵阶段不在这里强改，保持现有释放爆发与余韵气泡逻辑不变。
            if (!phase.name.equals("释放") && !phase.name.equals("余韵")) {
                float bladeBias = phase.name.equals("分离") ? 1.00f
                        : (phase.name.equals("吸引") ? 1.10f
                        : (phase.name.equals("同步") ? 1.18f
                        : (phase.name.equals("临界") ? 1.26f : 1.00f)));
                for (int i = 0; i < w.length; i++) w[i] = 0f;
                // V44：主体阶段锁定为“视频单片卷曲薄膜”。13/17 只作为同一膜面的窄态/尖钩态，避免多形体拼贴和大色带交叉。
                w[13] = phase.name.equals("分离") ? 0.30f * bladeBias : 0.12f * bladeBias;
                w[15] = 1.00f * bladeBias;
                w[17] = phase.name.equals("临界") ? 0.16f * bladeBias : 0.05f * bladeBias;
            } else {
                float bladeBias = phase.name.equals("释放") ? 1.38f : 1.08f;
                w[13] *= 1.95f * bladeBias;
                w[15] *= 2.28f * bladeBias;
                w[17] *= 1.82f * bladeBias;
                w[12] *= 0.54f;
                w[14] *= 0.46f;
                w[16] *= 0.62f;
                w[2] *= 0.22f;
                w[11] *= 0.24f;
            }

            // 反重复冷却：最近出现过的母型降权。雕塑类也参与冷却，防止连续看到同一类大形体。
            for (int i = 0; i < w.length; i++) {
                w[i] *= 1f / (1f + motifCooldown[i] * (isSculpturalMotif(i) ? 0.72f : 0.58f));
                if (cfg.powerSave && (i == 8 || i == 9 || i == 11 || i == 14 || i == 16)) w[i] *= 0.68f;
            }

            int motif = weightedMotif(w);
            rememberMotif(motif);
            return motif;
        }

        private float[] motifWeightsForPhase(String phaseName) {
            // 0 comet arc, 1 veil ribbon, 2 electronic fan, 3 silver blade,
            // 4 petal hook, 5 prism polygon, 6 falling leaf, 7 long bridge,
            // 8 jellyfish tendril, 9 nebula coil, 10 origami sheet, 11 constellation chain,
            // 12 liquid pod, 13 luminous wing, 14 blossom crown, 15 silk banner,
            // 16 orbit halo, 17 crystal shard.
            if (phaseName.equals("分离")) {
                return new float[]{1.08f, 0.74f, 0.06f, 0.98f, 0.20f, 0.34f, 0.82f, 1.02f, 0.38f, 0.30f, 0.52f, 0.18f, 0.62f, 1.05f, 0.28f, 0.96f, 0.52f, 0.92f};
            }
            if (phaseName.equals("吸引")) {
                return new float[]{0.60f, 0.95f, 0.12f, 0.38f, 0.86f, 0.46f, 0.92f, 0.42f, 0.74f, 0.54f, 0.46f, 0.12f, 1.24f, 1.12f, 1.42f, 1.05f, 0.78f, 0.52f};
            }
            if (phaseName.equals("同步")) {
                return new float[]{0.34f, 0.86f, 0.30f, 0.48f, 0.72f, 0.58f, 0.44f, 0.32f, 0.50f, 0.64f, 0.72f, 0.16f, 1.06f, 1.30f, 1.20f, 1.34f, 1.18f, 0.76f};
            }
            if (phaseName.equals("临界")) {
                return new float[]{0.22f, 0.56f, 0.28f, 1.02f, 0.56f, 0.62f, 0.24f, 0.48f, 0.42f, 0.76f, 0.92f, 0.20f, 1.22f, 1.18f, 1.06f, 1.28f, 1.46f, 1.32f};
            }
            if (phaseName.equals("释放")) {
                return new float[]{0.24f, 0.40f, 0.22f, 1.14f, 0.32f, 0.46f, 0.22f, 0.94f, 0.34f, 0.72f, 0.88f, 0.22f, 1.48f, 1.06f, 0.86f, 0.92f, 1.70f, 1.46f};
            }
            return new float[]{0.86f, 0.62f, 0.08f, 0.74f, 0.28f, 0.26f, 0.92f, 0.68f, 0.42f, 0.28f, 0.38f, 0.14f, 0.94f, 0.72f, 0.74f, 0.86f, 0.78f, 0.66f};
        }

        private boolean isSculpturalMotif(int motif) {
            return motif >= 12 && motif <= 17;
        }

        private int weightedMotif(float[] w) {
            float total = 0f;
            for (float v : w) total += Math.max(0f, v);
            if (total <= 0.0001f) return random.nextInt(Math.max(1, w.length));
            float r = random.nextFloat() * total;
            for (int i = 0; i < w.length; i++) {
                r -= Math.max(0f, w[i]);
                if (r <= 0f) return i;
            }
            return w.length - 1;
        }

        private int motifControlCount(int motif) {
            switch (motif) {
                case 2: return 6 + random.nextInt(3);   // fan shell
                case 3: return 3 + random.nextInt(2);   // blade shard
                case 4: return 5 + random.nextInt(2);   // petal hook
                case 5: return 5;                       // prism polygon
                case 6: return 5 + random.nextInt(2);   // leaf/vine
                case 7: return 4 + random.nextInt(2);   // long bridge
                case 8: return 6 + random.nextInt(3);   // jellyfish tendril
                case 9: return 6 + random.nextInt(3);   // nebula coil
                case 10: return 5 + random.nextInt(2);  // origami sheet
                case 11: return 4 + random.nextInt(4);  // constellation chain
                case 12: return 5 + random.nextInt(3);  // liquid pod
                case 13: return 5 + random.nextInt(3);  // luminous wing
                case 14: return 6 + random.nextInt(3);  // blossom crown
                case 15: return 5 + random.nextInt(3);  // silk banner
                case 16: return 5 + random.nextInt(3);  // orbit halo
                case 17: return 4 + random.nextInt(3);  // crystal shard
                default: return 4 + random.nextInt(3);
            }
        }

        private StrokeEvent createStroke(Phase phase, int side, boolean fan, int actor) {
            int motif = chooseArtMotif(phase, actor);
            int count = motifControlCount(motif);
            StrokeEvent s = new StrokeEvent(count);
            s.actor = actor;
            s.motif = motif;
            s.motifStrength = 0.72f + random.nextFloat() * 0.70f;
            s.variant = random.nextInt(100000);
            s.flowA = 0.65f + random.nextFloat() * 1.70f;
            s.flowB = 0.35f + random.nextFloat() * 1.45f;
            s.flowC = random.nextBoolean() ? 1f : -1f;
            s.asymmetry = -1f + random.nextFloat() * 2f;
            // V15：生命周期表示“一笔光迹从起笔到尾部完全滑出”的飞行时间。
            // 不是整条线慢慢死亡；真正的尾部退场由移动窗口 + FBO 慢衰减共同完成。
            s.life = 2.8f + random.nextFloat() * (4.2f + cfg.randomness * 2.8f);
            if (phase.name.equals("分离")) s.life *= 1.25f;
            if (phase.name.equals("吸引")) s.life *= 1.10f;
            if (phase.name.equals("同步")) s.life *= 0.95f;
            if (phase.name.equals("临界")) s.life *= 0.72f;
            if (phase.name.equals("释放")) s.life *= 0.45f;
            // V18：不再允许出现截图中那种“残缺的短小点线”。
            // 一个笔触从可见开始就必须具备足够长度，像 Windows/Ribbons 那种完整的一笔光迹，
            // 而不是小虫子或短残片。
            s.visibleWindow = 0.32f + random.nextFloat() * 0.24f;
            if (phase.name.equals("分离")) s.visibleWindow *= 0.92f;
            if (phase.name.equals("同步")) s.visibleWindow *= 1.10f;
            if (phase.name.equals("临界")) s.visibleWindow *= 1.18f;
            if (phase.name.equals("释放")) s.visibleWindow *= 1.24f;
            s.headLead = 0.06f + random.nextFloat() * 0.13f;
            s.seed = random.nextFloat() * (float)Math.PI * 2f;
            s.widthScale = 0.54f + random.nextFloat() * 0.72f;
            s.speed = Math.min(width, height) * (0.82f + random.nextFloat() * (0.90f + cfg.randomness * 0.55f));
            s.turn = 0.06f + random.nextFloat() * (0.20f + cfg.randomness * 0.18f);
            s.relation = phase.relation;
            s.fan = fan || motif == 2;
            s.fanLines = s.fan ? 4 + random.nextInt(8) : 0;
            s.fanGapPx = Math.min(width, height) * (0.003f + random.nextFloat() * 0.009f);
            int[] colors = palette(cfg.style);
            if (actor == 1) {
                // 主动追寻者：冷色、锋利、较直、点线更克制。
                s.colorA = colors[0];
                s.colorB = random.nextFloat() < 0.62f ? colors[1] : Color.WHITE;
                s.widthScale *= 0.82f;
                s.turn *= 0.68f;
                s.visibleWindow *= 0.94f;
                s.fan = false;
                s.fanLines = 0;
            } else if (actor == 2) {
                // 回应者：暖色、柔和、点线喷洒更丰富。
                s.colorA = colors[2];
                s.colorB = random.nextFloat() < 0.58f ? colors[3] : Color.WHITE;
                s.widthScale *= 1.10f;
                s.turn *= 1.18f;
                s.visibleWindow *= 1.05f;
                if (!phase.name.equals("分离") && random.nextFloat() < 0.035f + cfg.randomness * 0.055f) {
                    s.fan = true;
                    s.fanLines = 2 + random.nextInt(2);
                }
            } else {
                s.colorA = pickColor(colors);
                s.colorB = random.nextFloat() < 0.20f ? Color.WHITE : pickColor(colors);
            }
            boolean v41SubjectPhase = !phase.name.equals("释放") && !phase.name.equals("余韵");
            // V28：不同母型有不同的运动气质，避免“所有线条长得一样”。
            if (s.motif == 2) { // electronic fan / shell
                s.fan = true;
                s.fanLines = Math.max(s.fanLines, 7 + random.nextInt(8));
                s.visibleWindow *= 1.18f;
                s.widthScale *= 0.92f;
                s.turn *= 0.78f;
            } else if (s.motif == 3) { // silver blade
                s.widthScale *= 0.72f;
                s.turn *= 0.48f;
                s.visibleWindow *= 0.92f;
                s.colorA = Color.WHITE;
            } else if (s.motif == 4) { // petal hook
                s.widthScale *= 1.12f;
                s.turn *= 1.35f;
                s.visibleWindow *= 1.10f;
            } else if (s.motif == 5) { // prism polygon
                s.widthScale *= 0.86f;
                s.turn *= 0.58f;
                s.visibleWindow *= 0.96f;
            } else if (s.motif == 6) { // falling leaf / vine
                s.widthScale *= 1.04f;
                s.turn *= 1.16f;
            } else if (s.motif == 7) { // long bridge arc
                s.visibleWindow *= 1.22f;
                s.turn *= 0.62f;
            } else if (s.motif == 8) { // jellyfish tendril / water grass
                s.widthScale *= 0.94f;
                s.turn *= 1.42f;
                s.visibleWindow *= 1.18f;
            } else if (s.motif == 9) { // nebula coil / smoke spiral
                s.widthScale *= 1.06f;
                s.turn *= 1.08f;
                s.visibleWindow *= 1.12f;
            } else if (s.motif == 10) { // origami light sheet
                s.widthScale *= 0.92f;
                s.turn *= 0.74f;
                s.visibleWindow *= 1.08f;
                if (random.nextFloat() < 0.42f) { s.fan = true; s.fanLines = Math.max(s.fanLines, 5 + random.nextInt(5)); }
            } else if (s.motif == 11) { // constellation broken chain
                s.widthScale *= 0.56f;
                s.turn *= 0.86f;
                s.visibleWindow *= 0.86f;
            } else if (s.motif == 12) { // liquid light pod: rounded glowing body
                s.widthScale *= 1.85f;
                s.turn *= 0.62f;
                s.visibleWindow *= 1.22f;
                s.fan = false;
                s.fanLines = 0;
            } else if (s.motif == 13) { // video wing
                if (v41SubjectPhase) {
                    // V44：主体阶段只让宽度服务于边缘/肋线，不再把整条轨迹放大成白色彩带。
                    s.widthScale *= 0.82f;
                    s.turn *= 0.18f;
                    s.visibleWindow = Math.max(s.visibleWindow * 1.18f, 0.56f);
                    s.life *= 1.18f;
                } else {
                    // 释放/余韵保持 V38 既有参数。
                    s.widthScale *= 2.36f;
                    s.turn *= 0.36f;
                    s.visibleWindow *= 1.52f;
                    s.life *= 1.14f;
                }
                s.fan = false;
                s.fanLines = 0;
            } else if (s.motif == 14) { // blossom crown: petal cluster
                s.widthScale *= 1.72f;
                s.turn *= 0.84f;
                s.visibleWindow *= 1.20f;
                s.fan = false;
                s.fanLines = 0;
            } else if (s.motif == 15) { // silk banner / main video subject
                if (v41SubjectPhase) {
                    // V44：主膜面靠自定义 profile 展开，baseWidth 只留给极细折脊。
                    s.widthScale *= 0.90f;
                    s.turn *= 0.18f;
                    s.visibleWindow = Math.max(s.visibleWindow * 1.22f, 0.62f);
                    s.life *= 1.22f;
                } else {
                    // 释放/余韵保持 V38 既有参数。
                    s.widthScale *= 2.78f;
                    s.turn *= 0.38f;
                    s.visibleWindow *= 1.64f;
                    s.life *= 1.18f;
                }
                s.fan = false;
                s.fanLines = 0;
            } else if (s.motif == 16) { // orbit halo: luminous ring / crescent
                s.widthScale *= 1.34f;
                s.turn *= 0.66f;
                s.visibleWindow *= 1.12f;
                s.fan = false;
                s.fanLines = 0;
            } else if (s.motif == 17) { // crystal edge / shard
                if (v41SubjectPhase) {
                    s.widthScale *= 0.62f;
                    s.turn *= 0.15f;
                    s.visibleWindow = Math.max(s.visibleWindow * 1.10f, 0.50f);
                    s.life *= 1.12f;
                } else {
                    // 释放/余韵保持 V38 既有参数。
                    s.widthScale *= 1.84f;
                    s.turn *= 0.30f;
                    s.visibleWindow *= 1.24f;
                    s.life *= 1.08f;
                }
                s.fan = false;
                s.fanLines = 0;
            }

            if (s.motif == 13 || s.motif == 15 || s.motif == 17) {
                if (v41SubjectPhase) {
                    // V43：主体阶段限制在参考视频常见的绿/紫/青色族，移除黄色/橙色宽带。
                    int v = Math.floorMod(s.variant, 6);
                    if (v == 0) { s.colorA = 0xFF20F05A; s.colorB = 0xFF7C3AED; }
                    else if (v == 1) { s.colorA = 0xFF2EE67A; s.colorB = 0xFFB000FF; }
                    else if (v == 2) { s.colorA = 0xFF16D977; s.colorB = 0xFF3EEBFF; }
                    else if (v == 3) { s.colorA = 0xFF7C3AED; s.colorB = 0xFF23F06D; }
                    else if (v == 4) { s.colorA = 0xFF39FF74; s.colorB = 0xFF3EEBFF; }
                    else { s.colorA = 0xFF22C55E; s.colorB = 0xFFA855F7; }
                    s.asymmetry = (strokeHash(s, 17, 1181) < 0.5f ? -1f : 1f) * (0.86f + strokeHash(s, 19, 1187) * 0.42f);
                } else {
                    // 释放/余韵保持 V38 的色相族。
                    int v = Math.floorMod(s.variant, 5);
                    if (v == 0) { s.colorA = 0xFF22C55E; s.colorB = 0xFFA78BFA; }
                    else if (v == 1) { s.colorA = 0xFF7C3AED; s.colorB = 0xFFE5E7EB; }
                    else if (v == 2) { s.colorA = 0xFF34D399; s.colorB = 0xFFECFEFF; }
                    else if (v == 3) { s.colorA = 0xFFC4B5FD; s.colorB = 0xFFFFFFFF; }
                    else { s.colorA = 0xFF4ADE80; s.colorB = 0xFF60A5FA; }
                    s.asymmetry = (strokeHash(s, 17, 1181) < 0.5f ? -1f : 1f) * (0.72f + strokeHash(s, 19, 1187) * 0.52f);
                }
            }

            s.bounds = fullScreenBounds();
            initStrokeFromAnyVisiblePosition(s, side, phase);
            return s;
        }

        private RectF fullScreenBounds() {
            float padX = width * lerp(0.08f, 0.22f, cfg.fullScreenCoverage);
            float padY = height * lerp(0.08f, 0.22f, cfg.fullScreenCoverage);
            return new RectF(-padX, -padY, width + padX, height + padY);
        }

        private void initStrokeFromAnyVisiblePosition(StrokeEvent s, int side, Phase phase) {
            if (initStrokeByArtMotif(s, side, phase)) return;
            // 这一步是 V8 的重点：控制点直接从全屏可见坐标系生成，而不是从中心曲线移动出来。
            // 热区采样保证长期覆盖整块手机屏幕。
            int mode = random.nextInt(100);
            float x0, y0, x1, y1;
            if (mode < 30) {
                float[] p0 = randomEdgePoint(side);
                float[] p1 = pickLeastUsedPoint(false);
                x0 = p0[0]; y0 = p0[1]; x1 = p1[0]; y1 = p1[1];
            } else if (mode < 72) {
                float[] p0 = pickLeastUsedPoint(false);
                float[] p1 = pickLeastUsedPoint(true);
                x0 = p0[0]; y0 = p0[1]; x1 = p1[0]; y1 = p1[1];
                float minDist = Math.min(width, height) * 0.36f;
                int guard = 0;
                while (distance(x0, y0, x1, y1) < minDist && guard++ < 10) {
                    p1 = pickLeastUsedPoint(true);
                    x1 = p1[0]; y1 = p1[1];
                }
            } else {
                float[] p0 = randomCornerOrDiagonalStart();
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                x0 = p0[0]; y0 = p0[1]; x1 = p1[0]; y1 = p1[1];
            }

            markSpawnHeat(x0, y0);
            markSpawnHeat(x1, y1);

            // 以“从某处喷洒/飞掠到另一处”的长势能曲线生成控制点。
            // 不再围绕一个小中心随意弯曲，避免像蚯蚓；每次都是一段有方向、有起笔、有收笔的 Mystify 光迹。
            float angle = (float)Math.atan2(y1 - y0, x1 - x0) + (random.nextFloat() - 0.5f) * (0.12f + cfg.randomness * 0.30f);
            float length = Math.max(Math.min(width, height) * 0.42f, distance(x0, y0, x1, y1));
            float perp = Math.min(width, height) * (0.045f + random.nextFloat() * (0.12f + cfg.randomness * 0.06f));
            float bendSign = random.nextBoolean() ? 1f : -1f;
            float phaseOffset = random.nextFloat() * (float)Math.PI * 2f;
            float coherentV = s.speed * (0.72f + random.nextFloat() * 0.70f);
            for (int i = 0; i < s.count; i++) {
                float u = i / Math.max(1f, (s.count - 1f));
                float baseX = lerp(x0, x1, u);
                float baseY = lerp(y0, y1, u);
                float broadArc = (float)Math.sin(u * Math.PI) * perp * bendSign;
                float fineArc = (float)Math.sin(u * Math.PI * 2f + phaseOffset) * perp * 0.22f;
                float curve = broadArc + fineArc;
                s.x[i] = baseX - (float)Math.sin(angle) * curve;
                s.y[i] = baseY + (float)Math.cos(angle) * curve;
                float sideDrift = (i - (s.count - 1) * 0.5f) / Math.max(1f, (s.count - 1f));
                s.vx[i] = (float)Math.cos(angle) * coherentV - (float)Math.sin(angle) * coherentV * sideDrift * 0.055f;
                s.vy[i] = (float)Math.sin(angle) * coherentV + (float)Math.cos(angle) * coherentV * sideDrift * 0.055f;
                markSpawnHeat(s.x[i], s.y[i]);
            }
            s.attractX = lerp(0f, width, random.nextFloat());
            s.attractY = lerp(0f, height, random.nextFloat());
        }


        private boolean initVideoSilkBladeSubject(StrokeEvent s, int side, int motif, Phase phase) {
            // V44：根据视频逐帧重新抽象主体骨架：不是横竖交叉的宽彩带，也不是居中白脊，
            // 而是一条弯曲折脊牵引的单侧卷曲薄膜。它从黑场局部浮出，宽肩逐渐展开，末端收成细钩/细茎。
            float minDim = Math.max(1f, Math.min(width, height));
            float spanBase = phase.name.equals("分离") ? 0.30f
                    : (phase.name.equals("吸引") ? 0.34f
                    : (phase.name.equals("同步") ? 0.40f
                    : (phase.name.equals("临界") ? 0.46f : 0.36f)));
            float span = minDim * (spanBase + 0.12f * strokeHash(s, 11, 1401));
            if (motif == 13) span *= 0.86f;
            if (motif == 17) span *= 0.76f;

            float safeL = width * 0.14f;
            float safeR = width * 0.86f;
            float safeT = height * 0.18f;
            float safeB = height * 0.82f;

            int pose = Math.floorMod(s.variant, 7);
            float jitter = (strokeHash(s, 17, 1407) - 0.5f) * 0.50f;
            float angle;
            if (phase.name.equals("分离")) {
                angle = (pose % 2 == 0 ? 0.04f : (float)Math.PI - 0.04f) + jitter * 0.62f;       // 细 S 线横向漂移
            } else if (phase.name.equals("吸引")) {
                angle = (pose % 3 == 0 ? 0.22f : (pose % 3 == 1 ? -0.22f : 2.70f)) + jitter * 0.70f;
            } else if (phase.name.equals("同步")) {
                angle = (pose % 2 == 0 ? -0.86f : 2.28f) + jitter * 0.58f;                        // 紫色月牙/卷帘
            } else if (phase.name.equals("临界")) {
                angle = (pose % 2 == 0 ? -1.18f : 2.04f) + jitter * 0.52f;                        // 绿膜+细茎
            } else {
                angle = (pose < 3 ? 0.18f : (pose < 5 ? -0.92f : 2.20f)) + jitter;
            }
            float tx = (float)Math.cos(angle);
            float ty = (float)Math.sin(angle);
            float nx = -ty;
            float ny = tx;
            float sideSign = s.asymmetry == 0f ? (strokeHash(s, 53, 1421) < 0.5f ? -1f : 1f) : (s.asymmetry < 0f ? -1f : 1f);

            // 只让少数宽端被画面裁切；大多数主体保持局部悬浮，避免再次出现贯穿桌面的长白/黄带。
            float cx = lerp(safeL, safeR, strokeHash(s, 23, 1427));
            float cy = lerp(safeT, safeB, strokeHash(s, 29, 1429));
            boolean croppedShoulder = strokeHash(s, 31, 1433) < (phase.name.equals("临界") ? 0.42f : 0.26f);
            float tailX = cx - tx * span * 0.56f - nx * sideSign * span * 0.10f;
            float tailY = cy - ty * span * 0.56f - ny * sideSign * span * 0.10f;
            float tipX = cx + tx * span * 0.44f + nx * sideSign * span * 0.05f;
            float tipY = cy + ty * span * 0.44f + ny * sideSign * span * 0.05f;
            if (croppedShoulder) {
                float edgePad = minDim * (0.03f + 0.07f * strokeHash(s, 37, 1439));
                if (Math.abs(tx) > Math.abs(ty)) tailX = tx > 0f ? -edgePad : width + edgePad;
                else tailY = ty > 0f ? -edgePad : height + edgePad;
                tipX = tailX + tx * span;
                tipY = tailY + ty * span;
            }

            float curveAmp = minDim * (0.060f + 0.092f * strokeHash(s, 41, 1447)) * sideSign;
            if (phase.name.equals("分离")) curveAmp *= 0.74f;
            if (phase.name.equals("临界")) curveAmp *= 1.10f;
            float counter = minDim * (0.018f + 0.040f * strokeHash(s, 43, 1451)) * -sideSign;
            float hookAmp = minDim * (0.050f + 0.068f * strokeHash(s, 47, 1453)) * -sideSign;
            float speed = s.speed * (0.10f + 0.075f * strokeHash(s, 59, 1459));

            for (int i = 0; i < s.count; i++) {
                float u = i / Math.max(1f, s.count - 1f);
                float su = smooth(u);
                float alongX = lerp(tailX, tipX, su);
                float alongY = lerp(tailY, tipY, su);
                float mainBend = (float)Math.sin(su * Math.PI) * curveAmp;
                float sBend = (float)Math.sin(su * Math.PI * 2.0f + s.seed * 0.37f) * counter * (0.25f + 0.75f * (float)Math.sin(su * Math.PI));
                float hook = (float)Math.pow(clamp((su - 0.70f) / 0.30f, 0f, 1f), 1.45f) * hookAmp;
                float shoulderFold = (float)Math.pow(1f - su, 2.35f) * curveAmp * 0.15f;
                float curl = mainBend + sBend + hook - shoulderFold;
                s.x[i] = alongX + nx * curl;
                s.y[i] = alongY + ny * curl;

                float tangentBoost = 0.36f + 0.34f * su;
                float normalDrift = speed * (0.006f + 0.014f * strokeHash(s, 71 + i, 1469)) * sideSign * (1.0f - su);
                s.vx[i] = tx * speed * tangentBoost + nx * normalDrift;
                s.vy[i] = ty * speed * tangentBoost + ny * normalDrift;
                markSpawnHeat(s.x[i], s.y[i]);
            }
            s.attractX = lerp(tailX, tipX, 0.68f) + nx * curveAmp * 0.18f;
            s.attractY = lerp(tailY, tipY, 0.68f) + ny * curveAmp * 0.18f;
            s.bounds = new RectF(-width * 0.22f, -height * 0.22f, width * 1.22f, height * 1.22f);
            return true;
        }


        
private boolean initStrokeByArtMotif(StrokeEvent s, int side, Phase phase) {
            float minDim = Math.max(1f, Math.min(width, height));
            int motif = s.motif;
            if (motif == 1 || motif == 0) return false;
            if (motif == 13 || motif == 15 || motif == 17) return initVideoSilkBladeSubject(s, side, motif, phase);

            if (motif == 2) { // electronic fan / shell: hidden pivot + gradually opening ribs
                float[] pivot = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float sweep = (0.75f + random.nextFloat() * 1.35f) * (random.nextBoolean() ? 1f : -1f);
                float squash = 0.62f + random.nextFloat() * 0.34f;
                float speed = s.speed * (0.36f + random.nextFloat() * 0.35f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float su = smooth(u);
                    float rr = minDim * (0.038f + 0.36f * su) * s.motifStrength;
                    float ang = base + sweep * su;
                    s.x[i] = pivot[0] + (float)Math.cos(ang) * rr;
                    s.y[i] = pivot[1] + (float)Math.sin(ang) * rr * squash;
                    float tangent = ang + (sweep >= 0f ? 1f : -1f) * (float)Math.PI * 0.5f;
                    s.vx[i] = (float)Math.cos(tangent) * speed * (0.45f + u);
                    s.vy[i] = (float)Math.sin(tangent) * speed * squash * (0.45f + u);
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = pivot[0];
                s.attractY = pivot[1];
                return true;
            }

            if (motif == 3) { // silver blade: straight diagonal energy with one sharp crease
                float[] p0 = randomEdgePoint(side);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float crease = (random.nextFloat() - 0.5f) * minDim * (0.16f + cfg.randomness * 0.16f);
                float speed = s.speed * (0.82f + random.nextFloat() * 0.45f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float blade = (float)Math.sin(Math.PI * u) * crease;
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * blade;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * blade;
                    s.vx[i] = dx / len * speed + nx * (i - (s.count - 1) * 0.5f) * speed * 0.035f;
                    s.vy[i] = dy / len * speed + ny * (i - (s.count - 1) * 0.5f) * speed * 0.035f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.55f);
                s.attractY = lerp(p0[1], p1[1], 0.55f);
                return true;
            }

            if (motif == 4) { // petal hook: vertical stem curling into a flower-like head
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float sweep = (1.18f + random.nextFloat() * 1.64f) * (random.nextBoolean() ? 1f : -1f);
                float speed = s.speed * (0.42f + random.nextFloat() * 0.35f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float rr = minDim * (0.045f + 0.22f * (float)Math.pow(u, 0.72f)) * s.motifStrength;
                    float ang = base + sweep * u * u;
                    float stem = minDim * 0.11f * (0.5f - u);
                    float sx = (float)Math.cos(base + Math.PI * 0.5f) * stem;
                    float sy = (float)Math.sin(base + Math.PI * 0.5f) * stem;
                    s.x[i] = c[0] + sx + (float)Math.cos(ang) * rr;
                    s.y[i] = c[1] + sy + (float)Math.sin(ang) * rr * (0.58f + random.nextFloat() * 0.24f);
                    float tangent = ang + (sweep >= 0f ? 1f : -1f) * (float)Math.PI * 0.5f;
                    s.vx[i] = (float)Math.cos(tangent) * speed * (0.54f + u * 0.35f);
                    s.vy[i] = (float)Math.sin(tangent) * speed * (0.54f + u * 0.35f);
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 5) { // prism polygon: diamond/square frame briefly turning in darkness
                float[] c = pickLeastUsedPoint(false);
                float radius = minDim * (0.10f + random.nextFloat() * 0.22f) * s.motifStrength;
                float rot = random.nextFloat() * (float)Math.PI * 2f;
                float[][] corners = new float[][]{
                        {(float)Math.cos(rot) * radius, (float)Math.sin(rot) * radius * 0.72f},
                        {(float)Math.cos(rot + Math.PI * 0.5f) * radius * 0.72f, (float)Math.sin(rot + Math.PI * 0.5f) * radius},
                        {(float)Math.cos(rot + Math.PI) * radius, (float)Math.sin(rot + Math.PI) * radius * 0.72f},
                        {(float)Math.cos(rot + Math.PI * 1.5f) * radius * 0.72f, (float)Math.sin(rot + Math.PI * 1.5f) * radius},
                        {(float)Math.cos(rot) * radius, (float)Math.sin(rot) * radius * 0.72f}
                };
                float drift = s.speed * (0.28f + random.nextFloat() * 0.26f);
                float moveAng = rot + (random.nextBoolean() ? 1f : -1f) * (float)Math.PI * 0.35f;
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    int seg = Math.min(3, (int)(u * 4f));
                    float local = u * 4f - seg;
                    s.x[i] = c[0] + lerp(corners[seg][0], corners[seg + 1][0], local);
                    s.y[i] = c[1] + lerp(corners[seg][1], corners[seg + 1][1], local);
                    s.vx[i] = (float)Math.cos(moveAng) * drift + (float)Math.cos(rot + i) * drift * 0.08f;
                    s.vy[i] = (float)Math.sin(moveAng) * drift + (float)Math.sin(rot + i) * drift * 0.08f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 6) { // falling leaf / vine: slender soft S curve
                float[] p0 = pickLeastUsedPoint(false);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float amp = minDim * (0.055f + random.nextFloat() * 0.11f) * s.motifStrength;
                float speed = s.speed * (0.46f + random.nextFloat() * 0.32f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float leaf = (float)Math.sin(Math.PI * u) * amp + (float)Math.sin(Math.PI * 2f * u) * amp * 0.28f;
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * leaf;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * leaf;
                    s.vx[i] = dx / len * speed + nx * speed * (0.10f - u * 0.06f);
                    s.vy[i] = dy / len * speed + ny * speed * (0.06f + u * 0.05f);
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.60f);
                s.attractY = lerp(p0[1], p1[1], 0.60f);
                return true;
            }

            if (motif == 7) { // long bridge arc: wide magenta/green bow spanning the black field
                float[] p0 = randomCornerOrDiagonalStart();
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float amp = minDim * (0.09f + random.nextFloat() * 0.20f) * (random.nextBoolean() ? 1f : -1f);
                float speed = s.speed * (0.58f + random.nextFloat() * 0.40f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float arc = (float)Math.sin(Math.PI * u) * amp;
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * arc;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * arc;
                    s.vx[i] = dx / len * speed;
                    s.vy[i] = dy / len * speed;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.50f);
                s.attractY = lerp(p0[1], p1[1], 0.50f);
                return true;
            }

            if (motif == 8) { // jellyfish tendril: many-control soft hanging curve with a drifting head
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float sweep = (0.55f + random.nextFloat() * 0.85f) * (random.nextBoolean() ? 1f : -1f);
                float len = minDim * (0.22f + random.nextFloat() * 0.28f) * s.motifStrength;
                float speed = s.speed * (0.34f + random.nextFloat() * 0.26f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float droop = len * (u - 0.5f);
                    float wave = (float)Math.sin(u * Math.PI * 1.7f + s.seed) * minDim * (0.045f + random.nextFloat() * 0.030f);
                    float ang = base + sweep * u;
                    float tx = (float)Math.cos(base) * droop + (float)Math.cos(ang + Math.PI * 0.5f) * wave;
                    float ty = (float)Math.sin(base) * droop + (float)Math.sin(ang + Math.PI * 0.5f) * wave;
                    s.x[i] = c[0] + tx;
                    s.y[i] = c[1] + ty;
                    s.vx[i] = (float)Math.cos(base + 0.22f * s.flowC) * speed + (float)Math.cos(ang) * speed * 0.12f;
                    s.vy[i] = (float)Math.sin(base + 0.22f * s.flowC) * speed + (float)Math.sin(ang) * speed * 0.12f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 9) { // nebula coil: open spiral, not a closed circle
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float handed = random.nextBoolean() ? 1f : -1f;
                float radius = minDim * (0.035f + random.nextFloat() * 0.075f);
                float grow = minDim * (0.16f + random.nextFloat() * 0.23f) * s.motifStrength;
                float drift = s.speed * (0.28f + random.nextFloat() * 0.26f);
                float move = base + handed * (float)Math.PI * 0.35f;
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float rr = radius + grow * smooth(u);
                    float a = base + handed * (0.75f + 2.15f * u + 0.30f * (float)Math.sin(u * Math.PI));
                    s.x[i] = c[0] + (float)Math.cos(a) * rr;
                    s.y[i] = c[1] + (float)Math.sin(a) * rr * (0.62f + random.nextFloat() * 0.18f);
                    s.vx[i] = (float)Math.cos(move) * drift + (float)Math.cos(a + Math.PI * 0.5f) * drift * 0.18f;
                    s.vy[i] = (float)Math.sin(move) * drift + (float)Math.sin(a + Math.PI * 0.5f) * drift * 0.18f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 10) { // origami sheet: folded luminous paper, two creases
                float[] p0 = randomEdgePoint(side);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float fold = minDim * (0.060f + random.nextFloat() * 0.16f) * (random.nextBoolean() ? 1f : -1f);
                float speed = s.speed * (0.52f + random.nextFloat() * 0.34f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float kink = ((u < 0.48f ? u / 0.48f : (1f - u) / 0.52f));
                    float zig = (i % 2 == 0 ? -0.45f : 0.45f) * fold * (0.25f + 0.75f * (float)Math.sin(Math.PI * u));
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * (fold * kink + zig);
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * (fold * kink + zig);
                    s.vx[i] = dx / len * speed + nx * speed * (i - (s.count - 1) * 0.5f) * 0.025f;
                    s.vy[i] = dy / len * speed + ny * speed * (i - (s.count - 1) * 0.5f) * 0.025f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.52f);
                s.attractY = lerp(p0[1], p1[1], 0.52f);
                return true;
            }

            if (motif == 12) { // liquid pod: slow oval body with inner drift, not a point cloud
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float rx = minDim * (0.11f + random.nextFloat() * 0.18f) * s.motifStrength;
                float ry = rx * (0.52f + random.nextFloat() * 0.36f);
                float drift = s.speed * (0.24f + random.nextFloat() * 0.22f);
                float move = base + (random.nextBoolean() ? 1f : -1f) * (float)Math.PI * 0.28f;
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float a = base + (u - 0.5f) * (1.45f + random.nextFloat() * 1.05f);
                    float breathe = 0.82f + 0.18f * (float)Math.sin(u * Math.PI);
                    s.x[i] = c[0] + (float)Math.cos(a) * rx * breathe;
                    s.y[i] = c[1] + (float)Math.sin(a) * ry * breathe;
                    s.vx[i] = (float)Math.cos(move) * drift + (float)Math.cos(a + Math.PI * 0.5f) * drift * 0.10f;
                    s.vy[i] = (float)Math.sin(move) * drift + (float)Math.sin(a + Math.PI * 0.5f) * drift * 0.10f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 13) { // luminous wing: broad asymmetric wing crossing the black field
                float[] p0 = randomEdgePoint(side);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float amp = minDim * (0.12f + random.nextFloat() * 0.22f) * (random.nextBoolean() ? 1f : -1f);
                float speed = s.speed * (0.42f + random.nextFloat() * 0.30f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float lift = (float)Math.sin(Math.PI * u) * amp;
                    float secondary = (float)Math.sin(Math.PI * 2f * u + s.seed) * amp * 0.16f;
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * (lift + secondary);
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * (lift + secondary);
                    s.vx[i] = dx / len * speed + nx * speed * (0.06f - u * 0.04f);
                    s.vy[i] = dy / len * speed + ny * speed * (0.05f + u * 0.03f);
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.48f);
                s.attractY = lerp(p0[1], p1[1], 0.48f);
                return true;
            }

            if (motif == 14) { // blossom crown: looped petal arc around a soft center
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float radius = minDim * (0.08f + random.nextFloat() * 0.15f) * s.motifStrength;
                float petals = 3f + random.nextInt(4);
                float drift = s.speed * (0.25f + random.nextFloat() * 0.24f);
                float move = base + (float)Math.PI * 0.42f;
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float a = base + u * (float)Math.PI * 1.65f;
                    float flower = radius * (0.66f + 0.34f * (float)Math.sin(petals * a));
                    s.x[i] = c[0] + (float)Math.cos(a) * flower;
                    s.y[i] = c[1] + (float)Math.sin(a) * flower * (0.70f + random.nextFloat() * 0.18f);
                    s.vx[i] = (float)Math.cos(move) * drift + (float)Math.cos(a + Math.PI * 0.5f) * drift * 0.12f;
                    s.vy[i] = (float)Math.sin(move) * drift + (float)Math.sin(a + Math.PI * 0.5f) * drift * 0.12f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 15) { // silk banner: broad flowing sheet, intentionally not a mesh
                float[] p0 = randomCornerOrDiagonalStart();
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float amp = minDim * (0.06f + random.nextFloat() * 0.12f) * (random.nextBoolean() ? 1f : -1f);
                float speed = s.speed * (0.34f + random.nextFloat() * 0.28f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float wave = (float)Math.sin(Math.PI * u) * amp + (float)Math.sin(Math.PI * 3f * u + s.seed) * amp * 0.20f;
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * wave;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * wave;
                    s.vx[i] = dx / len * speed + nx * speed * 0.035f * (0.5f - u);
                    s.vy[i] = dy / len * speed + ny * speed * 0.035f * (0.5f - u);
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.52f);
                s.attractY = lerp(p0[1], p1[1], 0.52f);
                return true;
            }

            if (motif == 16) { // orbit halo: crescent/ring body, not random dots
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float sweep = (1.55f + random.nextFloat() * 1.25f) * (random.nextBoolean() ? 1f : -1f);
                float rx = minDim * (0.13f + random.nextFloat() * 0.20f) * s.motifStrength;
                float ry = rx * (0.48f + random.nextFloat() * 0.38f);
                float drift = s.speed * (0.22f + random.nextFloat() * 0.20f);
                float move = base + (random.nextBoolean() ? 1f : -1f) * (float)Math.PI * 0.30f;
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float a = base + sweep * u;
                    s.x[i] = c[0] + (float)Math.cos(a) * rx;
                    s.y[i] = c[1] + (float)Math.sin(a) * ry;
                    s.vx[i] = (float)Math.cos(move) * drift + (float)Math.cos(a + Math.PI * 0.5f) * drift * 0.08f;
                    s.vy[i] = (float)Math.sin(move) * drift + (float)Math.sin(a + Math.PI * 0.5f) * drift * 0.08f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 17) { // crystal shard: moving faceted luminous plate
                float[] p0 = randomEdgePoint(side);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float speed = s.speed * (0.58f + random.nextFloat() * 0.34f);
                float shard = minDim * (0.09f + random.nextFloat() * 0.16f) * (random.nextBoolean() ? 1f : -1f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float angular = (i % 2 == 0 ? -0.55f : 0.70f) * shard * (0.35f + 0.65f * (float)Math.sin(Math.PI * u));
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * angular;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * angular;
                    s.vx[i] = dx / len * speed + nx * speed * (i - (s.count - 1) * 0.5f) * 0.030f;
                    s.vy[i] = dy / len * speed + ny * speed * (i - (s.count - 1) * 0.5f) * 0.030f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.50f);
                s.attractY = lerp(p0[1], p1[1], 0.50f);
                return true;
            }

            if (motif == 11) { // constellation chain: sparse angular path with glowing nodes
                float[] p0 = pickLeastUsedPoint(false);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float speed = s.speed * (0.45f + random.nextFloat() * 0.34f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float step = (random.nextFloat() - 0.5f) * minDim * (0.07f + cfg.randomness * 0.06f);
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * step;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * step;
                    s.vx[i] = dx / len * speed + nx * speed * (random.nextFloat() - 0.5f) * 0.08f;
                    s.vy[i] = dy / len * speed + ny * speed * (random.nextFloat() - 0.5f) * 0.08f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.50f);
                s.attractY = lerp(p0[1], p1[1], 0.50f);
                return true;
            }
            return false;
        }

        private float[] randomEdgePoint(int side) {
            int edge = random.nextInt(4);
            if (side < 0) edge = random.nextBoolean() ? 0 : 2;
            if (side > 0) edge = random.nextBoolean() ? 1 : 3;
            float oX = width * (0.02f + random.nextFloat() * 0.18f);
            float oY = height * (0.02f + random.nextFloat() * 0.18f);
            switch (edge) {
                case 0: return new float[]{-oX, random.nextFloat() * height};
                case 1: return new float[]{width + oX, random.nextFloat() * height};
                case 2: return new float[]{random.nextFloat() * width, -oY};
                default: return new float[]{random.nextFloat() * width, height + oY};
            }
        }

        private float[] randomCornerOrDiagonalStart() {
            float oX = width * (0.04f + random.nextFloat() * 0.20f);
            float oY = height * (0.04f + random.nextFloat() * 0.20f);
            switch (random.nextInt(4)) {
                case 0: return new float[]{-oX, -oY};
                case 1: return new float[]{width + oX, -oY};
                case 2: return new float[]{width + oX, height + oY};
                default: return new float[]{-oX, height + oY};
            }
        }

        private float[] randomOppositeLongPoint(float x0, float y0) {
            float x = x0 < width * 0.5f ? width * (0.55f + random.nextFloat() * 0.65f) : -width * (0.05f + random.nextFloat() * 0.55f);
            float y = y0 < height * 0.5f ? height * (0.48f + random.nextFloat() * 0.72f) : -height * (0.04f + random.nextFloat() * 0.60f);
            return new float[]{x, y};
        }

        private float[] pickLeastUsedPoint(boolean farPreference) {
            // V29：热区采样 + 黄金比例低差异采样混合。热区避免局部重复，黄金序列避免
            // 伪随机长期形成可见簇团，使出生点更像“永远换位置的星图”。
            int best = 0;
            int bestScore = Integer.MAX_VALUE;
            int samples = 10 + random.nextInt(12);
            for (int i = 0; i < samples; i++) {
                int idx = random.nextInt(GRID_COLS * GRID_ROWS);
                int score = spawnHeat[idx] + random.nextInt(4);
                if (score < bestScore) { bestScore = score; best = idx; }
            }
            int col = best % GRID_COLS;
            int row = best / GRID_COLS;
            float cw = width / (float)GRID_COLS;
            float ch = height / (float)GRID_ROWS;
            float heatX = col * cw + random.nextFloat() * cw;
            float heatY = row * ch + random.nextFloat() * ch;

            float phi = 0.61803398875f;
            float psi = 0.754877666f;
            float gx = fract(0.13f + (artSpawnIndex + spawnCounter * 0.37f) * phi + random.nextFloat() * 0.037f);
            float gy = fract(0.71f + (artSpawnIndex + spawnCounter * 0.41f) * psi + random.nextFloat() * 0.037f);
            float goldX = lerp(-width * 0.06f, width * 1.06f, gx);
            float goldY = lerp(-height * 0.06f, height * 1.06f, gy);

            float mix = 0.38f + random.nextFloat() * 0.28f;
            float x = lerp(heatX, goldX, mix);
            float y = lerp(heatY, goldY, mix);
            if (farPreference && random.nextFloat() < 0.40f) {
                x = width - x + (random.nextFloat() - 0.5f) * cw;
                y = height - y + (random.nextFloat() - 0.5f) * ch;
            }
            x = clamp(x, -width * 0.10f, width * 1.10f);
            y = clamp(y, -height * 0.10f, height * 1.10f);
            markSpawnHeat(x, y);
            return new float[]{x, y};
        }

        private void markSpawnHeat(float x, float y) {
            int col = clampInt((int)(clamp(x, 0f, Math.max(1, width - 1)) / Math.max(1f, width) * GRID_COLS), 0, GRID_COLS - 1);
            int row = clampInt((int)(clamp(y, 0f, Math.max(1, height - 1)) / Math.max(1f, height) * GRID_ROWS), 0, GRID_ROWS - 1);
            int idx = row * GRID_COLS + col;
            spawnHeat[idx] = Math.min(100000, spawnHeat[idx] + 4);
            spawnCounter++;
            if (spawnCounter % 36 == 0) {
                for (int i = 0; i < spawnHeat.length; i++) spawnHeat[i] = Math.max(0, spawnHeat[i] - 1);
            }
        }

        private void resetSpawnHeat() {
            for (int i = 0; i < spawnHeat.length; i++) spawnHeat[i] = 0;
            spawnCounter = 0;
        }

        private void updateStrokes(float sec, float dt, Phase phase, float intensity, float tension, float release) {
            Iterator<StrokeEvent> it = strokes.iterator();
            while (it.hasNext()) {
                StrokeEvent s = it.next();
                s.age += dt;
                if (s.age > s.life) {
                    it.remove();
                    continue;
                }
                updateStroke(s, sec, dt, phase, intensity, tension, release);
            }
        }

        private void updateStroke(StrokeEvent s, float sec, float dt, Phase phase, float intensity, float tension, float release) {
            float relationPull = s.relation * (0.00018f + 0.00036f * cfg.intimacy) * (0.5f + tension);
            if (phase.name.equals("分离")) relationPull = 0f;
            if (phase.name.equals("吸引")) relationPull *= 0.22f;
            if (phase.name.equals("临界")) relationPull *= 1.55f;

            s.attractX += Math.sin(sec * (0.024f + s.turn * 0.009f) + s.seed) * width * 0.012f * dt;
            s.attractY += Math.cos(sec * (0.021f + s.turn * 0.008f) + s.seed) * height * 0.012f * dt;
            s.attractX = clamp(s.attractX, -width * 0.14f, width * 1.14f);
            s.attractY = clamp(s.attractY, -height * 0.14f, height * 1.14f);

            for (int i = 0; i < s.count; i++) {
                float wobble = (float)Math.sin(sec * (0.8f + s.turn * s.flowA) + s.seed + i * (1.05f + 0.18f * s.flowB));
                float wobble2 = (float)Math.cos(sec * (0.72f + s.turn * 0.76f * s.flowB) + s.seed * 1.37f + i * 1.67f);
                float eddy = (float)Math.sin(sec * (0.19f + 0.031f * s.flowA) + s.seed * 2.31f + i * 2.414f);
                // V29：非周期小流场。控制点仍保持整体势能，但每一类母型拥有不同“呼吸”，
                // 避免长期播放时所有线都像同一条曲线换皮。
                float motifFlow = isSculpturalMotif(s.motif) ? 0.56f : ((s.motif == 8 || s.motif == 9) ? 1.22f : (s.motif == 3 || s.motif == 10 ? 0.72f : 1.0f));
                s.vx[i] += (wobble + eddy * 0.42f * s.flowC) * s.speed * s.turn * motifFlow * (0.030f + cfg.randomness * 0.052f) * dt;
                s.vy[i] += (wobble2 - eddy * 0.36f * s.flowC) * s.speed * s.turn * motifFlow * (0.030f + cfg.randomness * 0.052f) * dt;
                s.vx[i] += (s.attractX - s.x[i]) * relationPull * 60f * dt;
                s.vy[i] += (s.attractY - s.y[i]) * relationPull * 60f * dt;
                if (release > 0f) {
                    s.vx[i] += (s.attractX - s.x[i]) * release * 0.016f;
                    s.vy[i] += (s.attractY - s.y[i]) * release * 0.016f;
                }
                s.x[i] += s.vx[i] * dt;
                s.y[i] += s.vy[i] * dt;
                s.vx[i] *= 0.998f;
                s.vy[i] *= 0.998f;
                bounce(s, i);
            }
        }

        private void bounce(StrokeEvent s, int i) {
            RectF b = s.bounds;
            if (s.x[i] < b.left) { s.x[i] = b.left; s.vx[i] = Math.abs(s.vx[i]) * (0.82f + random.nextFloat()*0.22f); }
            if (s.x[i] > b.right) { s.x[i] = b.right; s.vx[i] = -Math.abs(s.vx[i]) * (0.82f + random.nextFloat()*0.22f); }
            if (s.y[i] < b.top) { s.y[i] = b.top; s.vy[i] = Math.abs(s.vy[i]) * (0.82f + random.nextFloat()*0.22f); }
            if (s.y[i] > b.bottom) { s.y[i] = b.bottom; s.vy[i] = -Math.abs(s.vy[i]) * (0.82f + random.nextFloat()*0.22f); }
        }

        private void drawAllStrokes(Phase phase, float intensity, float tension, float release, float after) {
            for (int i = 0; i < strokes.size(); i++) {
                StrokeEvent s = strokes.get(i);
                drawStroke(s, phase, intensity, tension, release, after);
            }
        }

        private void drawStroke(StrokeEvent s, Phase phase, float intensity, float tension, float release, float after) {
            // V17：真正做“头部游走显现 + 尾部同步缓慢消失”。
            // 不再只画当前一段，也不让整条笔触整体衰老；而是把同一条光迹按时间切成多层。
            // 每层都是过去某个瞬间的可见窗口：越靠近头部越亮，越靠尾部越淡。
            // FBO 再继续保留更旧的尾迹，形成 Windows Mystify 那种“后会有期”的淡出背影。
            float progress = clamp(s.age / Math.max(0.001f, s.life), 0f, 1f);
            float born = smooth(Math.min(1f, s.age / Math.max(0.001f, s.life * 0.08f)));
            if (born <= 0.015f) return;

            ArrayList<float[]> all = sampleStroke(s);
            if (all.size() < 2) return;

            int ca = s.colorA;
            int cb = s.colorB;
            float baseWidth = lerp(0.52f, 3.20f, cfg.ribbonWidth) * s.widthScale * (0.64f + intensity * 0.58f + release * 0.32f);
            float[] c1 = color4(ca, 1f);
            float[] c2 = color4(cb, 1f);
            float[] mix = new float[]{(c1[0]+c2[0])*0.5f, (c1[1]+c2[1])*0.5f, (c1[2]+c2[2])*0.5f, 1f};

            // 过去的窗口层数。trail 越长，尾巴越柔和、越慢退场。
            int layers = cfg.powerSave ? 7 : (10 + (int)(cfg.trail * 18f));
            float step = lerp(0.018f, 0.010f, cfg.trail);
            for (int layer = layers; layer >= 0; layer--) {
                float p = progress - layer * step;
                if (p <= -0.08f || p >= 1.18f) continue;
                ArrayList<float[]> pts = visibleSegmentAt(all, s, p);
                if (pts.size() < 2) continue;

                float depth = layer / Math.max(1f, (float)layers);
                float afterStroke = phase.name.equals("余韵") && cfg.bubbles
                        ? (0.12f * (1f - 0.42f * after))
                        : (1f - after * 0.55f);
                float layerAlpha = born * (float)Math.pow(1f - depth, 2.15f) * afterStroke;
                if (layer == 0) layerAlpha *= 1.14f;
                if (layerAlpha <= 0.006f) continue;

                drawStrokeLayer(s, pts, phase, baseWidth, mix, layerAlpha, intensity, tension, release, layer == 0);
            }
        }

        private void drawStrokeLayer(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                     float[] mix, float alpha, float intensity, float tension, float release, boolean headLayer) {
            if (pts.size() < 2 || alpha <= 0.004f) return;
            boolean sculptural = isSculpturalMotif(s.motif);
            if (s.fan && headLayer && (s.motif == 2 || s.motif == 5)) {
                float nx = (float)Math.cos(s.seed + Math.PI / 2f);
                float ny = (float)Math.sin(s.seed + Math.PI / 2f);
                for (int k = s.fanLines; k >= 1; k--) {
                    float off = (k - s.fanLines * 0.5f) * s.fanGapPx * (0.70f + intensity);
                    drawTaperedStrip(offsetPoints(pts, nx * off, ny * off), baseWidth * 0.16f, mix[0], mix[1], mix[2], alpha * (0.010f + intensity * 0.018f));
                }
            }

            // V30：雕塑形态优先以“面/体/片/环”出现；纤维与点线只保留给非雕塑轨迹。
            if (!sculptural) {
                drawFiberVeil(s, pts, baseWidth, mix[0], mix[1], mix[2], alpha, intensity, tension, release, headLayer);
            }
            // 扇形光网降级为少数专属母型，不再每条线都展开网状肋纹。
            if ((s.motif == 2 && (headLayer || s.fan)) || (s.motif == 5 && headLayer && tension > 0.38f)) {
                drawMystifyFanLattice(s, pts, phase, baseWidth, mix[0], mix[1], mix[2], alpha * 0.82f, intensity, tension, release);
            }
            drawArtMotifAccent(s, pts, phase, baseWidth, mix[0], mix[1], mix[2], alpha, intensity, tension, release, headLayer);

            float actorFace = s.actor == 1 ? 0.86f : (s.actor == 2 ? 1.14f : 1.0f);
            float actorLine = s.actor == 1 ? 0.92f : (s.actor == 2 ? 1.08f : 1.0f);
            if (sculptural) {
                if (s.motif == 13 || s.motif == 15 || s.motif == 17) {
                    // V43：主体面已由单侧折叠膜面绘制；这里只保留极暗骨架，不再补彩色粗带。
                    drawTaperedStrip(pts, Math.max(0.08f, baseWidth * actorLine * 0.010f), mix[0], mix[1], mix[2], alpha * (0.006f + intensity * 0.003f));
                } else {
                    drawTaperedStrip(pts, baseWidth * actorFace * (10.5f + tension * 2.2f), mix[0], mix[1], mix[2], alpha * (0.020f + intensity * 0.026f + release * 0.034f));
                    drawTaperedStrip(pts, baseWidth * actorLine * (1.10f + tension * 0.22f), mix[0], mix[1], mix[2], alpha * (0.105f + intensity * 0.075f + release * 0.050f));
                }
            } else {
                // 面：宽而极淡，构成参考图里“喷洒在黑纸上”的半透明羽化面。
                drawTaperedStrip(pts, baseWidth * actorFace * (6.2f + tension * 1.4f), mix[0], mix[1], mix[2], alpha * (0.008f + intensity * 0.015f + release * 0.024f));
                // 线：主光带，仍然克制，避免蚯蚓感。
                drawTaperedStrip(pts, baseWidth * actorLine * (1.95f + tension * 0.42f), mix[0], mix[1], mix[2], alpha * (0.040f + intensity * 0.048f + release * 0.034f));
                drawTaperedStrip(pts, baseWidth * actorLine * (0.64f + tension * 0.12f), mix[0], mix[1], mix[2], alpha * (0.17f + intensity * 0.12f + release * 0.060f));
            }
            if (headLayer && !sculptural && s.motif != 11) drawActorHeadCluster(s, pts, baseWidth, mix[0], mix[1], mix[2], alpha, intensity, tension, release);

            // 点线喷洒只作为少量纹理；雕塑类、扇面和星座链不再继续喷点，避免“网状/散点”主导。
            if (!sculptural && s.motif != 2 && s.motif != 11 && (headLayer || alpha > 0.105f)) {
                drawPointLineSpray(s, pts, phase, baseWidth, mix[0], mix[1], mix[2], alpha * 0.58f, intensity, tension, release);
            }
            // 核心亮线：视频主体只保留几乎不可见的折脊暗示；真正的亮尖已在 drawVideoSilkBladeSubject 末端局部绘制。
            if (s.motif == 13 || s.motif == 15 || s.motif == 17) {
                drawTaperedStrip(pts, Math.max(0.08f, baseWidth * 0.004f), 0.62f, 1.00f, 0.86f, alpha * (0.004f + intensity * 0.002f));
            } else {
                drawTaperedStrip(pts, Math.max(0.30f, baseWidth * (sculptural ? 0.050f : 0.075f)), 1f, 1f, 1f, alpha * (sculptural ? 0.24f : 0.34f + intensity * 0.17f));
            }
        }

        private void drawMystifyFanLattice(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                        float r, float g, float b, float alpha, float intensity,
                                        float tension, float release) {
            if (pts.size() < 5 || alpha <= 0.004f) return;
            boolean motifFan = s.motif == 2 || s.motif == 5 || s.motif == 10;
            boolean phaseAllows = phase.name.equals("同步") || phase.name.equals("临界") || phase.name.equals("释放") || motifFan;
            float chance = (s.fan || motifFan ? 1.0f : 0.10f + cfg.randomness * 0.18f + tension * 0.18f);
            if (!phaseAllows && !s.fan) return;
            if (!s.fan && !motifFan && strokeHash(s, 0, 881) > chance) return;

            float[] first = pts.get(0);
            float[] last = pts.get(pts.size() - 1);
            float dx = last[0] - first[0];
            float dy = last[1] - first[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) return;
            float tx = dx / len;
            float ty = dy / len;
            float nx = -ty;
            float ny = tx;

            int ribs = s.fan ? Math.max(5, s.fanLines + 4) : 5 + (int)(cfg.randomness * 7f + tension * 4f);
            if (phase.name.equals("临界")) ribs += 3;
            if (phase.name.equals("释放")) ribs += 1;
            ribs = Math.min(18, Math.max(4, ribs));
            float spread = baseWidth * (5.8f + cfg.randomness * 4.8f + tension * 5.2f + release * 4.2f);
            float originBias = strokeHash(s, 1, 883) < 0.5f ? 0f : 1f;
            for (int j = 0; j < ribs; j++) {
                float jj = ribs == 1 ? 0f : (j / (float)(ribs - 1));
                float centered = (jj - 0.5f) * 2f;
                float hash = strokeHash(s, j, 887);
                float off = centered * spread * (0.55f + hash * 0.55f);
                float phaseShift = (strokeHash(s, j, 889) - 0.5f) * baseWidth * (1.2f + tension);
                ArrayList<float[]> rib = new ArrayList<>(pts.size());
                for (int i = 0; i < pts.size(); i++) {
                    float u = i / Math.max(1f, pts.size() - 1f);
                    float fanGrow = originBias < 0.5f ? smooth(u) : smooth(1f - u);
                    float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                    float shimmer = (float)Math.sin(u * Math.PI * 2.0f + s.seed * 1.7f + j * 0.41f)
                            * baseWidth * (0.35f + tension * 0.25f) * feather;
                    float[] p = pts.get(i);
                    rib.add(new float[]{
                            p[0] + nx * (off * fanGrow + shimmer) + tx * phaseShift * feather,
                            p[1] + ny * (off * fanGrow + shimmer) + ty * phaseShift * feather
                    });
                }
                float ribWidth = Math.max(0.22f, baseWidth * (0.040f + strokeHash(s, j, 891) * 0.060f));
                float ribAlpha = alpha * (0.020f + intensity * 0.026f + release * 0.030f) * (0.55f + hash * 0.70f);
                drawTaperedStrip(rib, ribWidth, r, g, b, ribAlpha);
            }

            // 扇面内增加极淡的横向折线，形成“电子纱/贝壳肋纹”的网感。
            int cross = Math.min(6, Math.max(2, ribs / 3));
            for (int k = 1; k <= cross; k++) {
                float u = k / (float)(cross + 1);
                int idx = clampInt((int)(u * (pts.size() - 1)), 1, pts.size() - 2);
                float[] p = pts.get(idx);
                float span = spread * (0.22f + 0.52f * (originBias < 0.5f ? smooth(u) : smooth(1f - u)));
                ArrayList<float[]> crossPts = new ArrayList<>(2);
                crossPts.add(new float[]{p[0] - nx * span, p[1] - ny * span});
                crossPts.add(new float[]{p[0] + nx * span, p[1] + ny * span});
                drawTaperedStrip(crossPts, Math.max(0.18f, baseWidth * 0.025f), r, g, b,
                        alpha * (0.008f + intensity * 0.014f + release * 0.012f));
            }
        }


        private void drawAsymmetricRibbon(ArrayList<float[]> pts, float leftMax, float rightMax,
                                           float r, float g, float b, float a, float power) {
            if (pts.size() < 2 || a <= 0.001f) return;
            int n = pts.size();
            float[] verts = new float[n * 2 * 2];
            int vi = 0;
            for (int i = 0; i < n; i++) {
                float u = i / Math.max(1f, n - 1f);
                float profile = (float)Math.pow(Math.max(0f, Math.sin(Math.PI * u)), power);
                float[] prev = pts.get(Math.max(0, i - 1));
                float[] next = pts.get(Math.min(n - 1, i + 1));
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float x = pts.get(i)[0];
                float y = pts.get(i)[1];
                putNdc(verts, vi, x + nx * leftMax * profile, y + ny * leftMax * profile); vi += 2;
                putNdc(verts, vi, x - nx * rightMax * profile, y - ny * rightMax * profile); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }


        private void drawRuledSurface(ArrayList<float[]> inner, ArrayList<float[]> outer,
                                      float r, float g, float b, float a) {
            if (inner.size() < 2 || outer.size() < 2 || a <= 0.001f) return;
            int n = Math.min(inner.size(), outer.size());
            float[] verts = new float[n * 2 * 2];
            int vi = 0;
            for (int i = 0; i < n; i++) {
                float[] p0 = inner.get(i);
                float[] p1 = outer.get(i);
                putNdc(verts, vi, p0[0], p0[1]); vi += 2;
                putNdc(verts, vi, p1[0], p1[1]); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void drawEllipse(float cx, float cy, float rx, float ry, float rot, float r, float g, float b, float a, int segments) {
            if (a <= 0f || rx <= 0f || ry <= 0f) return;
            float[] verts = new float[(segments + 2) * 2];
            putNdc(verts, 0, cx, cy);
            float co = (float)Math.cos(rot);
            float si = (float)Math.sin(rot);
            int vi = 2;
            for (int i = 0; i <= segments; i++) {
                float ang = i / (float)segments * (float)Math.PI * 2f;
                float x = (float)Math.cos(ang) * rx;
                float y = (float)Math.sin(ang) * ry;
                putNdc(verts, vi, cx + x * co - y * si, cy + x * si + y * co);
                vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_FAN, r, g, b, a);
        }

        private void drawArcStrip(float cx, float cy, float radius, float widthPx, float startAng, float sweep,
                                  float r, float g, float b, float a, int segments) {
            if (a <= 0f || radius <= 0f || widthPx <= 0f || segments < 2) return;
            float[] verts = new float[(segments + 1) * 2 * 2];
            int vi = 0;
            for (int i = 0; i <= segments; i++) {
                float u = i / (float)segments;
                float ang = startAng + sweep * u;
                float co = (float)Math.cos(ang);
                float si = (float)Math.sin(ang);
                float fade = (float)Math.pow(Math.max(0f, Math.sin(Math.PI * u)), 0.35f);
                float outer = radius + widthPx * (0.35f + 0.65f * fade);
                float inner = Math.max(0f, radius - widthPx * (0.35f + 0.65f * fade));
                putNdc(verts, vi, cx + co * outer, cy + si * outer); vi += 2;
                putNdc(verts, vi, cx + co * inner, cy + si * inner); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void drawFilledPolygon(ArrayList<float[]> poly, float r, float g, float b, float a) {
            if (poly.size() < 3 || a <= 0.001f) return;
            float[] verts = new float[poly.size() * 2];
            int vi = 0;
            for (int i = 0; i < poly.size(); i++) {
                float[] p = poly.get(i);
                putNdc(verts, vi, p[0], p[1]);
                vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_FAN, r, g, b, a);
        }



        private void drawObservedVideoMembrane(float sec, float local, Phase phase, float intensity, float tension) {
            // V81：单笔书写生命体版。
            // 强调“先在某个位置落下一笔，然后持续向四面八方延展、改写、擦去旧形”，
            // 让主体看起来更像一支光笔在黑场中实时作画，而不是整个物体在移动。
            drawFlowStringNetSubject(sec, phase, intensity, tension, 1.00f, false);
        }

        private void drawFlowStringNetSubject(float drawSec, Phase phase, float intensity, float tension,
                                              float echoAlpha, boolean echoLayer) {
            if (drawSec <= 0.01f || echoAlpha <= 0.002f) return;
            float minDim = Math.max(1f, Math.min(width, height));
            float w = Math.max(1f, width);
            float h = Math.max(1f, height);

            // V65：主体必须“朝屏幕随机游走 + 持续变形”，而不是每个 episode 只 reveal 一次。
            // episode 只决定一段舞步的总体方向；真正的书写推进由 rollingPhase 持续循环驱动。
            // 这样每几秒都有新的笔尖推进、喉口迁移、线场重构，肉眼能看到主体一直在运动和变形。
            // V81：继续拉长整轮表演，让“落笔—延展—改写—擦除”更完整、更可读。
            float episodeLen = cfg.powerSave ? 138.0f : 122.0f;
            int episode = (int)Math.floor(drawSec / episodeLen);
            float episodeStart = episode * episodeLen;
            float e = clamp((drawSec - episodeStart) / Math.max(0.001f, episodeLen), 0f, 1f);

            // 几乎整段持续可见，只在极短首尾做轻微呼吸式出入场。
            float enter = smoother(clamp(e / 0.010f, 0f, 1f));
            float exit = 1f - smoother(clamp((e - 0.9990f) / 0.0010f, 0f, 1f));
            float stageAlpha = enter * exit * echoAlpha * (1.96f + 0.66f * intensity);
            if (stageAlpha <= 0.0009f) return;

            float seedA = stableHash01(episode, 1201) * 6.2831853f;
            float seedB = stableHash01(episode, 1207) * 6.2831853f;
            float seedC = stableHash01(episode, 1213) * 6.2831853f;
            float side = stableHash01(episode, 1217) < 0.50f ? -1f : 1f;

            // V81：书写周期略收敛，让每一笔既足够从容，又能清楚看到尾部被逐渐擦去。
            float writeCycleLen = cfg.powerSave ? 19.0f : 15.5f;
            float rolling = drawSec / writeCycleLen + stableHash01(episode, 1801) * 0.73f;
            float rollingPhase = rolling - (float)Math.floor(rolling);
            float writeEase = smoother(rollingPhase);
            // 笔尖每轮都从细线写入到喉口，叠加轻微提按，形成“持续正在画”的状态。
            float head = clamp(0.90f + 0.10f * writeEase
                    + 0.003f * (float)Math.sin(drawSec * 0.42f + seedA)
                    + 0.0016f * (float)Math.sin(drawSec * 0.72f + seedC), 0.90f, 1f);
            float livingPulse = 0.5f + 0.5f * (float)Math.sin(drawSec * 0.82f + seedA);
            float breathing = 0.5f + 0.5f * (float)Math.sin(drawSec * 0.54f + seedB);
            float pose = 0.5f + 0.5f * (float)Math.sin(drawSec * 0.132f + seedA + 1.0f * (float)Math.sin(drawSec * 0.055f + seedC));
            // V81：继续弱化整体位移，强化“笔尖推进 + 尾部擦除”。
            float performanceDrive = smoother(clamp((e - 0.028f) / 0.74f, 0f, 1f));
            float motionGain = lerp(0.08f, 0.80f, performanceDrive);
            float tailFade = smoother(clamp((e - 0.966f) / 0.022f, 0f, 1f));

            // V79：中心仍会随机游走，但游走只是舞台位移；真正的主体变化由内部向四面八方的延伸来完成。
            float calmCx = w * (0.34f + 0.32f * stableHash01(episode, 1229));
            float calmCy = h * (0.32f + 0.24f * stableHash01(episode, 1231));
            int roamSegments = 6;
            float roamProg = e * roamSegments;
            int roamIdx = clampInt((int)Math.floor(roamProg), 0, roamSegments - 1);
            float roamT = clamp(roamProg - roamIdx, 0f, 1f);
            float rt2 = roamT * roamT;
            float rt3 = rt2 * roamT;
            int i0 = Math.floorMod(roamIdx - 1, roamSegments);
            int i1 = roamIdx;
            int i2 = Math.floorMod(roamIdx + 1, roamSegments);
            int i3 = Math.floorMod(roamIdx + 2, roamSegments);
            float x0 = w * (0.09f + 0.82f * stableHash01(episode, 2200 + i0 * 17));
            float y0 = h * (0.09f + 0.74f * stableHash01(episode, 2207 + i0 * 17));
            float x1 = w * (0.09f + 0.82f * stableHash01(episode, 2200 + i1 * 17));
            float y1 = h * (0.09f + 0.74f * stableHash01(episode, 2207 + i1 * 17));
            float x2 = w * (0.09f + 0.82f * stableHash01(episode, 2200 + i2 * 17));
            float y2 = h * (0.09f + 0.74f * stableHash01(episode, 2207 + i2 * 17));
            float x3 = w * (0.09f + 0.82f * stableHash01(episode, 2200 + i3 * 17));
            float y3 = h * (0.09f + 0.74f * stableHash01(episode, 2207 + i3 * 17));
            float roamCx = 0.5f * ((2f * x1) + (-x0 + x2) * roamT + (2f * x0 - 5f * x1 + 4f * x2 - x3) * rt2 + (-x0 + 3f * x1 - 3f * x2 + x3) * rt3);
            float roamCy = 0.5f * ((2f * y1) + (-y0 + y2) * roamT + (2f * y0 - 5f * y1 + 4f * y2 - y3) * rt2 + (-y0 + 3f * y1 - 3f * y2 + y3) * rt3);
            float vx = 0.5f * ((-x0 + x2) + 2f * (2f * x0 - 5f * x1 + 4f * x2 - x3) * roamT + 3f * (-x0 + 3f * x1 - 3f * x2 + x3) * rt2);
            float vy = 0.5f * ((-y0 + y2) + 2f * (2f * y0 - 5f * y1 + 4f * y2 - y3) * roamT + 3f * (-y0 + 3f * y1 - 3f * y2 + y3) * rt2);
            float orbitA = drawSec * (0.13f + 0.04f * stableHash01(episode, 2251)) + seedA;
            float orbitB = drawSec * (0.22f + 0.05f * stableHash01(episode, 2257)) + seedB;
            float orbitX = w * (0.016f + 0.016f * stableHash01(episode, 2261)) * (float)Math.sin(orbitA)
                    + w * (0.010f + 0.009f * stableHash01(episode, 2267)) * (float)Math.sin(orbitB + 0.70f * (float)Math.sin(orbitA));
            float orbitY = h * (0.016f + 0.014f * stableHash01(episode, 2273)) * (float)Math.cos(orbitA * 0.91f)
                    + h * (0.010f + 0.009f * stableHash01(episode, 2279)) * (float)Math.sin(orbitB * 0.87f);
            // V81：中心位置主要作为“落笔舞台”，只做缓慢挪移；可见主体主要通过内部延展来变化。
            float anchorHold = 1f - smoother(clamp((e - 0.16f) / 0.42f, 0f, 1f));
            float roamMix = 0.10f + 0.28f * smoother(clamp((e - 0.20f) / 0.52f, 0f, 1f));
            float cx = lerp(calmCx, roamCx, roamMix) + roamMix * 0.60f * orbitX;
            float cy = lerp(calmCy, roamCy, roamMix) + roamMix * 0.60f * orbitY;
            cx = lerp(cx, calmCx, 0.52f * anchorHold);
            cy = lerp(cy, calmCy, 0.52f * anchorHold);
            cx += motionGain * (w * (0.010f + 0.010f * stableHash01(episode, 1501)) * (float)Math.sin(drawSec * (0.10f + 0.03f * stableHash01(episode, 1502)) + seedB)
                    + w * (0.006f + 0.006f * stableHash01(episode, 1503)) * (float)Math.sin(drawSec * (0.22f + 0.04f * stableHash01(episode, 1504)) + seedC));
            cy += motionGain * (h * (0.010f + 0.010f * stableHash01(episode, 1511)) * (float)Math.sin(drawSec * (0.09f + 0.03f * stableHash01(episode, 1512)) + seedC)
                    + h * (0.006f + 0.006f * stableHash01(episode, 1513)) * (float)Math.sin(drawSec * (0.20f + 0.04f * stableHash01(episode, 1514)) + seedA));
            float travelDx = roamMix * 0.55f * (vx / Math.max(1f, w)) + 0.030f * (float)Math.cos(orbitA) + 0.020f * (float)Math.cos(orbitB + 0.70f * (float)Math.sin(orbitA));
            float travelDy = roamMix * 0.55f * (vy / Math.max(1f, h)) - 0.028f * (float)Math.sin(orbitA * 0.91f) + 0.018f * (float)Math.cos(orbitB * 0.87f);
            float travelAngle = (float)Math.atan2(travelDy, travelDx + 0.0001f);
            float travelEnergy = clamp((float)Math.sqrt(travelDx * travelDx + travelDy * travelDy) * 1.28f + 0.08f * motionGain, 0f, 0.72f);
            cx = clamp(cx, w * 0.08f, w * 0.92f);
            cy = clamp(cy, h * 0.08f, h * 0.82f);

            float baseRot = stableHash01(episode, 1223) * 6.2831853f;
            float rot = baseRot
                    + motionGain * (side * (0.12f + 0.28f * (float)Math.sin(drawSec * 0.12f + seedA))
                    + side * 0.12f * (float)Math.sin(drawSec * 0.28f + seedB)
                    + 0.09f * (float)Math.sin(drawSec * 0.46f + seedC)
                    + 0.08f * travelEnergy * (float)Math.sin(travelAngle + drawSec * 0.10f));
            float lateralFlip = stableHash01(episode, 1225) < 0.5f ? -1f : 1f;
            float verticalFlip = stableHash01(episode, 1227) < 0.5f ? -1f : 1f;
            if (phase.name.equals("同步")) rot *= 0.90f;
            float co = (float)Math.cos(rot);
            float si = (float)Math.sin(rot);

            // V81：更像从落笔点不断长出，因此整体扩张尺度更聚焦于“延展半径”而非整幅漂移。
            float span = w * (0.54f + 0.14f * stableHash01(episode, 1237));
            float fanHeight = h * (0.30f + 0.22f * stableHash01(episode, 1249));
            // 大尺度开合：让形体从细光弦到大光幕之间持续变化，而不是固定一张网。
            float openWave = 0.5f + 0.5f * (float)Math.sin(drawSec * 0.18f + seedA + 0.8f * (float)Math.sin(drawSec * 0.07f + seedB));
            span *= (0.96f - 0.05f * (1f - motionGain)) + (0.10f + 0.22f * motionGain) * openWave + 0.05f * motionGain * (float)Math.sin(drawSec * 0.33f + seedC);
            fanHeight *= (0.88f - 0.06f * (1f - motionGain)) + (0.10f + 0.26f * motionGain) * breathing;
            if (phase.name.equals("分离")) { span *= 1.10f; fanHeight *= 0.98f; }
            if (phase.name.equals("临界")) { span *= 1.03f; fanHeight *= 1.14f; }

            float hueDriver = 0.5f + 0.5f * (float)Math.sin(drawSec * 0.128f + seedA + pose * 1.2f);
            float[] deep = new float[]{0.006f, 0.075f + 0.070f * hueDriver, 0.42f + 0.34f * hueDriver};
            float[] mid = new float[]{0.012f, 0.37f + 0.30f * hueDriver, 0.95f};
            float[] cyan = new float[]{0.09f + 0.18f * hueDriver, 0.92f, 0.96f};
            float[] white = new float[]{0.78f, 1.00f, 0.96f};

            int lineCount = cfg.powerSave ? 72 : 116;
            int samples = cfg.powerSave ? 116 : 188;
            ArrayList<ArrayList<float[]>> curves = new ArrayList<>(lineCount);
            ArrayList<Float> lineWeights = new ArrayList<>(lineCount);

            float throatTightness = 0.013f + (0.018f + 0.020f * motionGain) * breathing + (0.006f + 0.014f * motionGain) * openWave;
            float vortex = side * motionGain * (0.18f + 0.22f * (float)Math.sin(drawSec * 0.10f + seedC)
                    + 0.08f * (float)Math.sin(drawSec * 0.22f + seedA)
                    + 0.05f * (float)Math.sin(drawSec * 0.38f + seedB)) * (0.90f + 0.28f * travelEnergy);
            // V81：书写窗口不再几乎整段全留，而是明确形成“前端继续画、后端逐渐被擦去”的单笔感。
            float baseWindow = 0.42f + 0.16f * openWave + 0.10f * livingPulse + 0.08f * motionGain;

            float currentTipX = cx;
            float currentTipY = cy;
            int currentTipN = 0;

            for (int j = 0; j < lineCount; j++) {
                float f = (j + 0.5f) / lineCount;
                float k = (f - 0.5f) * 2f;
                float absK = Math.abs(k);
                float density = 1f - 0.18f * absK;

                // 线束的每根线有不同书写相位，整体像一群光弦被同一只手不断重画。
                float stagger = 0.125f * stableHash01(episode, 1300 + j * 19);
                float localHead = clamp((head - stagger) / Math.max(0.001f, 1f - stagger), 0f, 1f);
                if (localHead <= 0.020f) continue;
                float sEnd = localHead;
                float widthWindow = baseWindow * (0.88f + 0.18f * (float)Math.sin(j * 0.21f + seedB));
                float earlyFill = smoother(clamp(sEnd / 0.42f, 0f, 1f));
                float eraseGate = smoother(clamp((sEnd - 0.38f) / 0.48f, 0f, 1f));
                float preservedLen = lerp(0.96f, widthWindow, eraseGate);
                float sStart = Math.max(0f, sEnd - preservedLen);
                // 前半程先把“初始主体”从落笔点画出来；后半程再让旧尾巴慢慢追上来。
                if (eraseGate < 0.02f) sStart = 0f;
                sStart = lerp(0f, sStart, Math.max(earlyFill, eraseGate));
                float tailTrim = tailFade * (0.010f + 0.034f * stableHash01(episode, 1700 + j * 13));
                sStart = Math.max(sStart, Math.min(sEnd - 0.24f, tailTrim));
                int pointCount = clampInt((int)((sEnd - sStart) * (samples - 1)) + 8, 6, samples);

                ArrayList<float[]> line = new ArrayList<>(pointCount);
                for (int i = 0; i < pointCount; i++) {
                    float u = i / Math.max(1f, pointCount - 1f);
                    float s = lerp(sStart, sEnd, u);
                    float[] p = flowStringPoint(f, s, drawSec, episode, span, fanHeight,
                            throatTightness, vortex, seedA, seedB, seedC, motionGain, travelAngle, travelEnergy);
                    p[0] *= lateralFlip;
                    p[1] *= verticalFlip;
                    float x = cx + (p[0] * co - p[1] * si);
                    float y = cy + (p[0] * si + p[1] * co);
                    float perspective = 1f + 0.145f * smoother(s) * (1f - 0.54f * absK)
                            - 0.055f * (1f - smoother(s));
                    x = cx + (x - cx) * perspective;
                    y = cy + (y - cy) * perspective;
                    line.add(new float[]{x, y});
                    if (i == pointCount - 1 && absK < 0.22f) {
                        currentTipX += x;
                        currentTipY += y;
                        currentTipN++;
                    }
                }
                if (line.size() >= 2) {
                    curves.add(line);
                    lineWeights.add(density);
                }
            }
            if (currentTipN > 0) {
                currentTipX /= (currentTipN + 1f);
                currentTipY /= (currentTipN + 1f);
            }

            float echoMul = 1.0f;
            float aBase = stageAlpha * echoMul;

            // 极淡膜面：只连接当前滚动窗口中部，让线主导、膜辅助，避免变回叶片。
            if (!echoLayer && curves.size() > 8) {
                int step = cfg.powerSave ? 4 : 3;
                for (int j = 0; j + step < curves.size(); j += step) {
                    ArrayList<float[]> a = curves.get(j);
                    ArrayList<float[]> b = curves.get(j + step);
                    int n = Math.min(a.size(), b.size());
                    if (n < 10) continue;
                    int start = clampInt((int)(n * 0.10f), 0, n - 2);
                    int end = clampInt((int)(n * 0.92f), start + 1, n - 1);
                    float jj = j / Math.max(1f, (float)curves.size());
                    float fog = (0.0028f + 0.0052f * (float)Math.sin(jj * Math.PI));
                    drawRuledSurface(slicePoints(a, start, end), slicePoints(b, start, end),
                            mid[0], mid[1], mid[2], aBase * fog);
                }
            }

            for (int j = 0; j < curves.size(); j++) {
                ArrayList<float[]> line = curves.get(j);
                float density = lineWeights.get(j);
                int n = line.size();
                if (n < 3) continue;
                float edgeBoost = (j == 0 || j == curves.size() - 1) ? 1.28f : 1.0f;
                float centerBoost = 1f + 0.34f * (1f - Math.abs((j / Math.max(1f, (float)(curves.size() - 1))) * 2f - 1f));
                float common = aBase * density * edgeBoost * centerBoost;
                int a1 = clampInt((int)(n * 0.44f), 1, n - 1);
                int a2 = clampInt((int)(n * 0.74f), a1 + 1, n - 1);
                float width1 = Math.max(0.32f, minDim * 0.00110f);
                float width2 = Math.max(0.54f, minDim * 0.00195f);
                float width3 = Math.max(0.94f, minDim * 0.00310f);
                drawAgeFadedStrip(slicePoints(line, 0, a1), width1,
                        deep[0], deep[1], deep[2], common * 0.055f, 0.16f, 0.008f);
                drawAgeFadedStrip(slicePoints(line, Math.max(0, a1 - 1), a2), width2,
                        mid[0], mid[1], mid[2], common * 0.142f, 0.38f, 0.05f);
                drawAgeFadedStrip(slicePoints(line, Math.max(0, a2 - 1), n - 1), width3,
                        cyan[0], cyan[1], cyan[2], common * 0.335f, 0.82f, 0.12f);
            }

            if (!echoLayer && curves.size() > 4) {
                // 动态喉口/笔尖短骨：它随 head 移动，是“当前正在画”的位置。
                int spokes = cfg.powerSave ? 1 : 2;
                for (int j = 0; j < spokes; j++) {
                    float f = (j + 0.5f) / spokes;
                    ArrayList<float[]> spoke = new ArrayList<>(16);
                    float spokeEnd = clamp(head + 0.008f * (float)Math.sin(j * 0.42f + seedA), 0.42f, 1.0f);
                    float spokeStart = Math.max(0f, spokeEnd - 0.12f - 0.025f * breathing);
                    for (int i = 0; i < 16; i++) {
                        float s = lerp(spokeStart, spokeEnd, i / 15f);
                        float[] p = flowStringPoint(f, clamp(s, 0f, 1f), drawSec + 0.018f * j, episode,
                                span, fanHeight, throatTightness, vortex * 1.10f, seedA, seedB, seedC, motionGain, travelAngle, travelEnergy);
                        float x = cx + (p[0] * co - p[1] * si);
                        float y = cy + (p[0] * si + p[1] * co);
                        spoke.add(new float[]{x, y});
                    }
                    drawTaperedStrip(spoke, Math.max(0.24f, minDim * 0.00092f), cyan[0], cyan[1], cyan[2], stageAlpha * 0.026f);
                }

                ArrayList<float[]> heroLine = curves.get(curves.size() / 2);
                int heroHeadStart = Math.max(0, heroLine.size() - 14);
                drawTaperedStrip(slicePoints(heroLine, heroHeadStart, heroLine.size() - 1), Math.max(0.30f, minDim * 0.00105f),
                        white[0], white[1], white[2], stageAlpha * 0.070f);

                float tipRot = rot + side * (0.23f + 0.12f * (float)Math.sin(drawSec * 0.56f + seedC));
                drawEllipse(currentTipX, currentTipY, Math.max(1.80f, minDim * 0.0062f), Math.max(0.66f, minDim * 0.0023f), tipRot,
                        cyan[0], cyan[1], cyan[2], stageAlpha * 0.170f, 18);
                drawEllipse(currentTipX + minDim * 0.010f * (float)Math.cos(tipRot), currentTipY + minDim * 0.010f * (float)Math.sin(tipRot),
                        Math.max(0.72f, minDim * 0.0024f), Math.max(0.28f, minDim * 0.0010f), tipRot,
                        white[0], white[1], white[2], stageAlpha * 0.125f, 14);
            }
        }

        private float[] flowShapeProfile(int id) {
            switch (Math.floorMod(id, 10)) {
                case 0: // 海葵式扩张
                    return new float[]{1.00f, 0.18f, 0.18f, 0.18f, 5.0f, 0.22f, 0.12f, 0.16f, 0.16f, 0.12f};
                case 1: // 弓月回锋
                    return new float[]{0.34f, 1.00f, 0.10f, 0.22f, 3.0f, 0.30f, 0.20f, 0.16f, 0.10f, 0.24f};
                case 2: // 鳍翼翻卷
                    return new float[]{0.42f, 0.22f, 1.00f, 0.18f, 4.0f, 0.22f, 0.28f, 0.22f, 0.18f, 0.16f};
                case 3: // 波鞭喷发
                    return new float[]{0.20f, 0.38f, 0.22f, 1.00f, 6.0f, 0.20f, 0.30f, 0.32f, 0.18f, 0.36f};
                case 4: // 花苞鼓胀
                    return new float[]{0.14f, 0.14f, 0.50f, 0.16f, 7.0f, 0.34f, 0.10f, 0.10f, 0.36f, 0.10f};
                case 5: // 水袖分岔
                    return new float[]{0.50f, 0.20f, 0.16f, 0.42f, 8.0f, 0.28f, 0.28f, 0.26f, 0.14f, 0.30f};
                case 6: // 星冠放射
                    return new float[]{0.70f, 0.08f, 0.22f, 0.30f, 9.0f, 0.18f, 0.22f, 0.18f, 0.10f, 0.18f};
                case 7: // 双翼分流
                    return new float[]{0.56f, 0.26f, 0.12f, 0.56f, 4.0f, 0.32f, 0.24f, 0.24f, 0.18f, 0.28f};
                case 8: // 羽枝舒展
                    return new float[]{0.68f, 0.24f, 0.14f, 0.46f, 10.0f, 0.20f, 0.18f, 0.30f, 0.12f, 0.22f};
                default: // 墨滴回卷
                    return new float[]{0.26f, 0.42f, 0.36f, 0.22f, 5.0f, 0.36f, 0.34f, 0.16f, 0.24f, 0.14f};
            }
        }

        private float[] flowStringPoint(float f, float s, float sec, int episode, float span, float fanHeight,
                                        float throatTightness, float vortex, float seedA, float seedB, float seedC,
                                        float motionGain, float travelAngle, float travelEnergy) {
            // V81：主体被定义成“不断书写与擦除的一笔”。
            // 重点不是整体物体位移，而是从一个落笔核心持续向各个方向长出、改写，并把更旧的部分慢慢擦去。
            f = clamp(f, 0f, 1f);
            s = clamp(s, 0f, 1f);
            float thetaSeed = 6.2831853f * f;
            float ss = smoother(s);
            float live = sec;
            float minDim = Math.max(1f, Math.min(width, height));
            float centerBias = 1f - Math.abs((f - 0.5f) * 2f);

            float inhale = 0.5f + 0.5f * (float)Math.sin(live * 0.082f + seedA + 0.20f * (float)Math.sin(live * 0.028f + seedB));
            float pulse = 0.5f + 0.5f * (float)Math.sin(live * 0.15f + seedC);
            float bloomBreath = 0.88f + 0.24f * inhale + 0.10f * pulse;
            float travelWave = 0.5f + 0.5f * (float)Math.sin(travelAngle + live * 0.10f + f * 1.8f);

            float morphRoll = live / (cfg.powerSave ? 7.8f : 6.1f)
                    + stableHash01(episode, 2601) * 8.2f
                    + 0.16f * (float)Math.sin(live * 0.08f + seedA)
                    + 0.10f * (float)Math.sin(live * 0.05f + seedB);
            int shapeA = Math.floorMod((int)Math.floor(morphRoll), 10);
            int shapeB = (shapeA + 1) % 10;
            float phase = morphRoll - (float)Math.floor(morphRoll);
            float morphPhase = smoother(phase);
            float[] pa = flowShapeProfile(shapeA);
            float[] pb = flowShapeProfile(shapeB);

            // 多方向生长头：它们像不同笔势轮流接管当前正在书写的方向。
            float dir1 = seedA + live * (0.10f + 0.02f * pa[3]) + 0.42f * (float)Math.sin(live * 0.05f + seedB);
            float dir2 = seedC - live * (0.08f + 0.02f * pb[3]) + 0.38f * (float)Math.sin(live * 0.06f + seedA);
            float dir3 = travelAngle + 0.55f * (float)Math.sin(live * 0.07f + seedC);
            float dir4 = seedB + 1.7f + 0.44f * (float)Math.sin(live * 0.04f + seedA);

            float width = 0.14f + 0.08f * motionGain;
            float radialFront = morphPhase;
            float radialReplace = smoother(clamp((ss - (radialFront - width * 0.5f)) / Math.max(0.0001f, width), 0f, 1f));
            float sectorA = (float)Math.pow(Math.max(0f, (float)Math.cos(thetaSeed - dir1)), 2.2f);
            float sectorB = (float)Math.pow(Math.max(0f, (float)Math.cos(thetaSeed - dir2)), 2.6f);
            float sectorC = (float)Math.pow(Math.max(0f, (float)Math.cos(thetaSeed - dir3)), 2.0f);
            float sectorD = (float)Math.pow(Math.max(0f, (float)Math.cos(thetaSeed - dir4)), 2.8f);
            float directionalReplace = clamp(0.46f * sectorA + 0.28f * sectorB + 0.20f * sectorC + 0.18f * sectorD, 0f, 1f);
            float newBlend = clamp(0.58f * radialReplace + 0.42f * directionalReplace * (0.42f + 0.58f * morphPhase), 0f, 1f);
            newBlend = smoother(newBlend);
            float oldBlend = 1f - newBlend;

            float spreadP = lerp(pa[0], pb[0], newBlend);
            float arcP = lerp(pa[1], pb[1], newBlend);
            float cavityP = lerp(pa[2], pb[2], newBlend);
            float branchP = lerp(pa[3], pb[3], newBlend);
            float petalP = lerp(pa[4], pb[4], newBlend);
            float swirlP = lerp(pa[5], pb[5], newBlend);
            float curlP = lerp(pa[6], pb[6], newBlend);
            float veinP = lerp(pa[7], pb[7], newBlend);
            float pinchP = lerp(pa[8], pb[8], newBlend);
            float thrustP = lerp(pa[9], pb[9], newBlend);

            float theta = thetaSeed
                    + 0.15f * (float)Math.sin(live * 0.08f + seedA)
                    + 0.20f * swirlP * (ss - 0.5f)
                    + 0.10f * (float)Math.sin(thetaSeed * 3.2f + live * 0.11f + seedB)
                    + 0.06f * thrustP * (float)Math.sin(travelAngle - thetaSeed);

            float petalCount = Math.max(3f, petalP);
            float bloom1 = 0.5f + 0.5f * (float)Math.cos(theta * petalCount - live * (0.16f + 0.03f * branchP) + seedA);
            float bloom2 = 0.5f + 0.5f * (float)Math.cos(theta * (petalCount + 1.5f) + live * (0.13f + 0.03f * curlP) + seedB);
            float bloom3 = 0.5f + 0.5f * (float)Math.sin(theta * (2.0f + branchP * 1.8f) - live * 0.15f + seedC);
            float bloom4 = 0.5f + 0.5f * (float)Math.sin(theta * (1.0f + 0.18f * petalCount) + live * 0.10f + seedA + seedC);
            float directionBurst = clamp(0.30f * bloom1 + 0.22f * bloom2 + 0.18f * bloom3 + 0.14f * bloom4 + 0.20f * directionalReplace, 0f, 1f);

            float outwardLife = smoother(clamp((ss - 0.05f) / 0.90f, 0f, 1f));
            float seedGrowth = smoother(clamp(ss / 0.18f, 0f, 1f));
            float coreR = minDim * (0.020f + 0.018f * cavityP + 0.008f * pulse);
            float radialMax = minDim * (0.142f + 0.060f * spreadP + 0.032f * branchP + 0.026f * thrustP);
            radialMax *= bloomBreath * (0.94f + 0.16f * travelWave);
            float radius = coreR + radialMax * (0.10f + 0.90f * ss);
            radius *= (0.40f + 0.60f * seedGrowth);
            radius *= 0.86f + 0.22f * spreadP + (0.16f + 0.42f * motionGain) * outwardLife * directionBurst;
            radius *= 1.00f + 0.10f * (newBlend - oldBlend) * (0.2f + 0.8f * outwardLife);

            float cavityWindow = smoother(clamp((ss - 0.10f) / 0.26f, 0f, 1f)) * (1f - smoother(clamp((ss - 0.84f) / 0.14f, 0f, 1f)));
            float cavity = (0.08f + 0.18f * cavityP + 0.08f * pulse) * cavityWindow * (0.44f + 0.56f * centerBias);
            radius -= minDim * cavity;
            radius *= 1.0f - 0.10f * pinchP * (1f - directionBurst) * (0.30f + 0.70f * ss);

            // 尖端推进与尾部回收：前端更活，后部更安静。
            float leadPush = smoother(clamp((ss - 0.62f) / 0.28f, 0f, 1f));
            float tailQuiet = 1f - smoother(clamp((ss - 0.32f) / 0.36f, 0f, 1f));
            radius *= 1.0f + leadPush * (0.08f * sectorA + 0.07f * sectorB + 0.06f * sectorC + 0.05f * sectorD);
            radius *= 1.0f - tailQuiet * oldBlend * 0.08f;

            float splitGate = smoother(clamp((ss - 0.56f) / 0.24f, 0f, 1f));
            float splitPhase = (float)Math.sin(thetaSeed * (1.1f + 0.18f * petalCount) + live * (0.16f + 0.02f * branchP) + seedB);
            float splitMag = splitGate * (0.018f + 0.08f * branchP + 0.04f * motionGain);
            float tangentTheta = theta + (splitPhase >= 0f ? 1f : -1f) * splitMag;
            tangentTheta += (0.008f + 0.028f * curlP + 0.020f * motionGain) * outwardLife
                    * (float)Math.sin(live * (0.18f + 0.03f * curlP) + ss * (3.6f + 2.0f * veinP) + thetaSeed * (1.2f + 0.5f * branchP) + seedA);

            float ex = radius * (float)Math.cos(tangentTheta);
            float ey = radius * (float)Math.sin(tangentTheta);
            ex *= 1.00f + 0.10f * arcP;
            ey *= 0.94f + 0.18f * spreadP;

            // 在外缘做书写式脉冲，让画面像笔在向不同方位不断勾勒新轮廓。
            float branchPulse1 = smoother(clamp(1f - Math.abs(ss - (0.24f + 0.16f * sectorA)) / (0.12f + 0.03f * spreadP), 0f, 1f));
            float branchPulse2 = smoother(clamp(1f - Math.abs(ss - (0.48f + 0.18f * sectorB)) / (0.10f + 0.03f * branchP), 0f, 1f));
            float branchPulse3 = smoother(clamp(1f - Math.abs(ss - (0.72f + 0.14f * sectorD)) / (0.08f + 0.03f * thrustP), 0f, 1f));
            ex += minDim * (0.030f * branchPulse1 * sectorA + 0.024f * branchPulse2 * sectorB) * (float)Math.cos(dir1 + 0.4f * swirlP);
            ey += minDim * (0.028f * branchPulse1 * sectorA + 0.020f * branchPulse2 * sectorB) * (float)Math.sin(dir2 - 0.4f * swirlP);
            ex += minDim * 0.020f * branchPulse3 * sectorD * (float)Math.cos(dir4 + 0.7f * curlP);
            ey += minDim * 0.018f * branchPulse3 * sectorD * (float)Math.sin(dir4 - 0.5f * curlP);

            ex += span * 0.010f * swirlP * (float)Math.sin(live * 0.10f + ss * 4.0f + seedB);
            ey += fanHeight * 0.014f * veinP * (float)Math.cos(live * 0.11f + ss * 4.6f + seedC);

            // 新形前推、旧形内缩，保证看起来像同一支笔不断改写，而非整块主体平移。
            float replaceBias = (newBlend - oldBlend) * (0.06f + 0.06f * travelWave);
            ex += minDim * replaceBias * (float)Math.cos(theta + 0.7f * swirlP);
            ey += minDim * replaceBias * 0.9f * (float)Math.sin(theta - 0.5f * swirlP);
            float retract = oldBlend * (0.06f + 0.10f * (1f - outwardLife));
            ex *= 1f - retract;
            ey *= 1f - retract;

            return new float[]{ex, ey};
        }

        private void drawPainterlyLivingSubject(float drawSec, Phase phase, float intensity, float tension,
                                                float echoAlpha, boolean echoLayer) {
            if (drawSec <= 0.01f || echoAlpha <= 0.002f) return;
            float minDim = Math.max(1f, Math.min(width, height));
            float w = Math.max(1f, width);
            float h = Math.max(1f, height);
            float episodeLen = painterEpisodeLen();
            int episode = (int)Math.floor(drawSec / episodeLen);
            float episodeStart = episode * episodeLen;
            float e = clamp((drawSec - episodeStart) / Math.max(0.001f, episodeLen), 0f, 1f);
            float available = Math.max(0f, drawSec - episodeStart);

            // V60：落笔、行笔、收笔都用长 Hermite 缓动。主体不是突然出现的形状，
            // 而是一支光笔把历史湿迹逐段拉成透明生命膜。
            float enter = smoother(clamp(e / 0.070f, 0f, 1f));
            float exit = 1f - smoother(clamp((e - 0.955f) / 0.045f, 0f, 1f));
            float stageAlpha = enter * exit * echoAlpha * (1.02f + 0.18f * intensity);
            if (stageAlpha <= 0.0025f) return;

            // 历史窗口不能太短，否则没有“作画过程”；也不能太长，否则变成完整物体拖尾。
            float baseHistory = lerp(5.20f, 7.20f, cfg.randomness);
            if (phase.name.equals("分离")) baseHistory *= 1.03f;
            if (phase.name.equals("同步")) baseHistory *= 1.06f;
            if (phase.name.equals("临界")) baseHistory *= 0.95f;
            if (cfg.powerSave) baseHistory *= 0.80f;
            float grow = smoother(clamp(available / Math.max(0.001f, baseHistory * 0.72f), 0f, 1f));
            float historySec = Math.min(baseHistory, available) * (0.18f + 0.82f * grow);
            if (historySec < 0.075f) return;

            int n = cfg.powerSave ? 86 : 138;
            ArrayList<float[]> fold = new ArrayList<>(n);
            ArrayList<float[]> inner = new ArrayList<>(n);
            ArrayList<float[]> outer = new ArrayList<>(n);
            ArrayList<float[]> outerGlow = new ArrayList<>(n);
            ArrayList<float[]> caustic = new ArrayList<>(n);
            ArrayList<float[]> brush = new ArrayList<>(n);
            ArrayList<Float> ages = new ArrayList<>(n);
            ArrayList<Float> widths = new ArrayList<>(n);

            int gesture = selectedAestheticGesture(episode);
            float sideSign = stableHash01(episode, 610 + gesture * 13) < 0.5f ? -1f : 1f;
            float seedA = stableHash01(episode, 631 + gesture * 17) * 6.2831853f;
            float seedB = stableHash01(episode, 647 + gesture * 19) * 6.2831853f;
            float seedC = stableHash01(episode, 653 + gesture * 23) * 6.2831853f;
            float phaseEnergy = phase.name.equals("临界") ? 1.10f : (phase.name.equals("同步") ? 1.06f : 1.0f);

            // 审美导演只允许开膜发生在身体中段，避免头尾鼓包、三角纸片和尾部打结。
            float apertureCenter = clamp(0.50f + 0.045f * (float)Math.sin((drawSec - episodeStart) * 0.20f + seedB)
                    + 0.025f * stableSigned(episode, 673 + gesture), 0.43f, 0.57f);
            float apertureSpan = 0.42f + 0.075f * (0.5f + 0.5f * (float)Math.sin((drawSec - episodeStart) * 0.17f + seedC));
            float poseOpen = painterPoseOpenScale(gesture);

            for (int i = 0; i < n; i++) {
                float u = i / Math.max(1f, n - 1f); // 0=旧尾迹，1=正在推进的笔尖
                float age = historySec * (1f - u);
                float t = drawSec - age;
                float localT = Math.max(0f, t - episodeStart);
                float[] p = painterPathPoint(t, episodeStart, episode, w, h, minDim);
                float[] pPrev = painterPathPoint(Math.max(episodeStart, t - 0.046f), episodeStart, episode, w, h, minDim);
                float[] pNext = painterPathPoint(Math.min(drawSec, t + 0.046f), episodeStart, episode, w, h, minDim);
                float dx = pNext[0] - pPrev[0];
                float dy = pNext[1] - pPrev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float tx = dx / len;
                float ty = dy / len;
                float nx = -dy / len;
                float ny = dx / len;

                // 曲率保护：弯得优雅时开膜，弯成死结时自动收窄。
                float midX = (pPrev[0] + pNext[0]) * 0.5f;
                float midY = (pPrev[1] + pNext[1]) * 0.5f;
                float bendErr = (float)Math.sqrt((p[0] - midX) * (p[0] - midX) + (p[1] - midY) * (p[1] - midY)) / Math.max(1f, minDim);
                float curvatureGuard = 1f - 0.46f * smoother(clamp((bendErr - 0.010f) / 0.052f, 0f, 1f));

                // 三个慢变量表达“呼吸、卷曲、回收”，不直接决定形状模板，只影响笔势。
                float fanPulse = 0.5f + 0.5f * (float)Math.sin(localT * 0.36f + seedA);
                float hookPulse = 0.5f + 0.5f * (float)Math.sin(localT * 0.27f + seedB + 0.45f * (float)Math.sin(localT * 0.073f));
                float twistPulse = 0.5f + 0.5f * (float)Math.sin(localT * 0.21f + seedC);
                float fan = smoother(clamp((fanPulse - 0.08f) / 0.92f, 0f, 1f));
                float hook = smoother(clamp((hookPulse - 0.16f) / 0.84f, 0f, 1f));
                float twist = smoother(twistPulse);

                // 宽度包络：尾部淡、笔尖细、中段开膜；它是“身体生长”不是随机粗细。
                float tailInk = smoother(clamp(u / 0.095f, 0f, 1f));
                float tipNeedle = 1f - 0.930f * smoother(clamp((u - 0.865f) / 0.135f, 0f, 1f));
                float lobe = (float)Math.pow(Math.max(0f, Math.sin(Math.PI * u)), 0.82f);
                float chest = (float)Math.exp(-Math.pow((u - apertureCenter) / Math.max(0.001f, apertureSpan), 2.0f));
                float shoulder = smoother(clamp((u - 0.18f) / 0.22f, 0f, 1f)) * (1f - smoother(clamp((u - 0.88f) / 0.12f, 0f, 1f)));
                float narrowWaist = 1f - 0.18f * smoother(clamp(1f - Math.abs(u - (0.64f + 0.045f * twist)) / 0.21f, 0f, 1f));
                float breath = 1f + 0.095f * (float)Math.sin(t * 0.82f + u * 6.7f + seedB);
                float profile = tailInk * tipNeedle * narrowWaist * breath
                        * (0.24f * lobe + (0.88f + 0.20f * fan) * chest + 0.18f * hook * shoulder);
                profile = clamp(profile * curvatureGuard, 0f, 1.22f);

                float maxWidth = minDim * (0.052f + 0.060f * fan + 0.022f * hook + 0.018f * twist)
                        * (0.94f + 0.16f * tension) * phaseEnergy * poseOpen;
                float localWidth = clamp(maxWidth * profile * (0.42f + 0.58f * grow), 0f, minDim * 0.168f);
                widths.add(localWidth);

                // 外缘只在一侧舒展，另一侧保持细脊；切向轻微错位形成书法飞白，但禁止大幅打结。
                float curl = sideSign * localWidth * (0.10f + 0.18f * hook)
                        * (float)Math.sin(u * Math.PI * (1.05f + 0.16f * twist) + t * 0.54f + seedC);
                float shear = minDim * (0.004f + 0.017f * fan)
                        * (float)Math.sin(u * Math.PI) * (float)Math.sin(t * 0.27f + seedA);
                float rootTug = smoother(clamp(1f - Math.abs(u - apertureCenter) / (apertureSpan * 0.80f), 0f, 1f));
                float rootBend = minDim * sideSign * (0.006f + 0.018f * fan) * rootTug
                        * (float)Math.sin(seedB + t * 0.21f);

                float foldBack = 0.055f + 0.035f * (float)Math.sin(u * Math.PI + seedA);
                float innerSpread = 0.23f + 0.07f * twist;
                float[] f = new float[]{p[0] - nx * sideSign * localWidth * foldBack + tx * shear * 0.025f,
                                         p[1] - ny * sideSign * localWidth * foldBack + ty * shear * 0.025f};
                float[] in = new float[]{p[0] + nx * sideSign * localWidth * innerSpread + tx * shear * 0.15f,
                                          p[1] + ny * sideSign * localWidth * innerSpread + ty * shear * 0.15f};
                float[] out = new float[]{p[0] + nx * sideSign * localWidth * 1.06f + tx * shear + nx * curl + tx * rootBend * 0.06f,
                                           p[1] + ny * sideSign * localWidth * 1.06f + ty * shear + ny * curl + ty * rootBend * 0.06f};
                float[] glow = new float[]{p[0] + nx * sideSign * localWidth * 1.17f + tx * shear * 0.98f + nx * curl * 1.06f,
                                            p[1] + ny * sideSign * localWidth * 1.17f + ty * shear * 0.98f + ny * curl * 1.06f};
                float[] c = new float[]{p[0] + nx * sideSign * localWidth * (0.46f + 0.10f * (float)Math.sin(u * Math.PI + seedA)) + tx * shear * 0.34f,
                                         p[1] + ny * sideSign * localWidth * (0.46f + 0.10f * (float)Math.sin(u * Math.PI + seedA)) + ty * shear * 0.34f};
                fold.add(f);
                inner.add(in);
                outer.add(out);
                outerGlow.add(glow);
                caustic.add(c);
                brush.add(p);
                ages.add(u);
            }

            float hue = 3.001f * (0.5f + 0.5f * (float)Math.sin(drawSec * 0.118f + seedA));
            hue += 0.28f * (float)Math.sin(drawSec * 0.31f + seedC);
            float[] body = livingPalette(hue, 0);
            float[] edge = livingPalette(hue, 1);
            float[] hot = livingPalette(hue, 2);
            float echoMul = echoLayer ? 0.30f : 1.0f;
            float a = stageAlpha * echoMul;

            // 透明膜面低透明托底，主体显形依赖线束；避免“厚塑料带/丑叶片”。
            drawRuledSurfaceAgeFaded(fold, outerGlow, body[0], body[1], body[2], a * 0.0105f, 0.66f);
            drawRuledSurfaceAgeFaded(fold, outer, body[0], body[1], body[2], a * 0.0155f, 0.60f);
            drawRuledSurfaceAgeFaded(fold, inner, edge[0], edge[1], edge[2], a * 0.0064f, 0.62f);

            // 湿亮外缘、折脊与焦散线：用非常细的线条建立生命体骨架。
            drawAgeFadedStrip(outer, Math.max(0.20f, minDim * 0.00104f), edge[0], edge[1], edge[2], a * 0.285f, 0.46f, 0.34f);
            drawAgeFadedStrip(fold, Math.max(0.13f, minDim * 0.00066f), hot[0], hot[1], hot[2], a * 0.155f, 0.54f, 0.24f);
            drawAgeFadedStrip(caustic, Math.max(0.09f, minDim * 0.00046f), hot[0], hot[1], hot[2], a * 0.082f, 0.60f, 0.18f);
            drawAgeFadedStrip(brush, Math.max(0.070f, minDim * 0.00034f), hot[0], hot[1], hot[2], a * 0.052f, 0.76f, 0.18f);

            if (!echoLayer) {
                // V60：肋线不再全部从一个点拉到外缘形成丑三角，而是“贴膜短骨 + 局部喉口扇骨”。
                int ribs = cfg.powerSave ? 24 : 46;
                for (int j = 0; j < ribs; j++) {
                    float f = (j + 0.5f) / ribs;
                    float u = lerp(0.16f, 0.82f, f);
                    int idx = clampInt((int)(u * (n - 1)), 3, n - 4);
                    int idx2 = clampInt(idx + (int)(sideSign * stableSigned(episode, 811 + j * 9) * 3f), 2, n - 3);
                    float[] r0 = fold.get(idx);
                    float[] r1 = caustic.get(idx2);
                    float[] r2 = outerGlow.get(idx2);
                    ArrayList<float[]> rib = new ArrayList<>(4);
                    rib.add(r0);
                    rib.add(new float[]{lerp(r0[0], r1[0], 0.48f), lerp(r0[1], r1[1], 0.48f)});
                    rib.add(new float[]{lerp(r1[0], r2[0], 0.70f), lerp(r1[1], r2[1], 0.70f)});
                    rib.add(r2);
                    float[] rc = livingPalette(hue + 0.24f * (f - 0.5f), (j % 6 == 0) ? 2 : 1);
                    float wAt = widths.get(idx);
                    float ribA = stageAlpha * (0.014f + 0.026f * smoother(clamp(wAt / Math.max(1f, minDim * 0.095f), 0f, 1f)))
                            * (0.46f + 0.54f * (float)Math.sin(f * Math.PI));
                    drawTaperedStrip(rib, Math.max(0.030f, minDim * 0.00036f), rc[0], rc[1], rc[2], ribA);
                }

                // 局部喉口：只绘制少量短扇骨，作为“关节/笔锋”而非整片三角扇面。
                int rootIndex = clampInt((int)(n * apertureCenter), 6, n - 8);
                float[] root = fold.get(rootIndex);
                int throatRibs = cfg.powerSave ? 7 : 12;
                for (int j = 0; j < throatRibs; j++) {
                    float f = (j + 1f) / (throatRibs + 1f);
                    int idx = clampInt(rootIndex + (int)lerp(-13f, 15f, f), 3, n - 4);
                    ArrayList<float[]> rib = new ArrayList<>(4);
                    float[] m = caustic.get(idx);
                    float[] o = outerGlow.get(idx);
                    rib.add(root);
                    rib.add(new float[]{lerp(root[0], m[0], 0.34f), lerp(root[1], m[1], 0.34f)});
                    rib.add(new float[]{lerp(m[0], o[0], 0.66f), lerp(m[1], o[1], 0.66f)});
                    rib.add(o);
                    float[] rc = livingPalette(hue + 0.32f * (f - 0.5f), 2);
                    drawTaperedStrip(rib, Math.max(0.026f, minDim * 0.00030f), rc[0], rc[1], rc[2], stageAlpha * 0.016f);
                }

                // 贴面流线：少量随膜面流动的“丝”，不是叶脉。
                int contourLines = cfg.powerSave ? 12 : 22;
                for (int j = 1; j <= contourLines; j++) {
                    float f = j / (float)(contourLines + 1);
                    ArrayList<float[]> contour = new ArrayList<>(n);
                    float lineWave = 0.012f * (float)Math.sin(drawSec * 0.62f + j * 0.53f + seedB);
                    for (int i = 0; i < n; i++) {
                        float u = ages.get(i);
                        float ff = clamp(f + lineWave * (float)Math.sin(u * Math.PI), 0.035f, 0.92f);
                        float[] p0 = fold.get(i);
                        float[] p1 = outer.get(i);
                        contour.add(new float[]{lerp(p0[0], p1[0], ff), lerp(p0[1], p1[1], ff)});
                    }
                    float[] cc = livingPalette(hue + 0.18f * (f - 0.5f), 0);
                    float lineA = stageAlpha * 0.0088f * (0.42f + 0.58f * (float)Math.sin(f * Math.PI));
                    drawAgeFadedStrip(contour, Math.max(0.024f, minDim * 0.00028f), cc[0], cc[1], cc[2], lineA, 0.80f, 0.10f);
                }

                // 喉口高光改为小而柔的光核，不再画出明显圆环/打结尾巴。
                drawEllipse(root[0], root[1], Math.max(0.35f, minDim * 0.0010f), Math.max(0.22f, minDim * 0.00062f), seedB,
                        hot[0], hot[1], hot[2], stageAlpha * 0.040f, 14);
            }

            // 新鲜笔尖：细亮、短、干净。明确“正在写”，但不生成尾部环结。
            int headStart = clampInt((int)(n * 0.890f), 0, n - 2);
            ArrayList<float[]> headOuter = slicePoints(outer, headStart, n - 1);
            ArrayList<float[]> headFold = slicePoints(fold, headStart, n - 1);
            ArrayList<float[]> headBrush = slicePoints(brush, headStart, n - 1);
            drawTaperedStrip(headOuter, Math.max(0.15f, minDim * 0.00086f), hot[0], hot[1], hot[2], stageAlpha * 0.205f);
            drawTaperedStrip(headFold, Math.max(0.095f, minDim * 0.00050f), 0.88f, 1.00f, 0.94f, stageAlpha * 0.132f);
            drawTaperedStrip(headBrush, Math.max(0.065f, minDim * 0.00034f), hot[0], hot[1], hot[2], stageAlpha * 0.082f);
            float[] tip = brush.get(n - 1);
            drawEllipse(tip[0], tip[1], Math.max(0.28f, minDim * 0.00095f), Math.max(0.18f, minDim * 0.00058f), seedA,
                    hot[0], hot[1], hot[2], stageAlpha * 0.040f, 12);
        }

        private float painterEpisodeLen() {
            // 更长的段落给“现场作画”足够时间，避免还没看清就换形。
            return cfg.powerSave ? 18.6f : 14.8f;
        }

        private int selectedAestheticGesture(int episode) {
            if (cachedAestheticEpisode == episode) return cachedAestheticGesture;
            // V61：先让每一轮落在一个“精选审美母型”附近，再用评分过滤。
            // 这样既保留随机性，又不会总被评分函数挑成一条过瘦的安全细弧。
            int[] gallery = new int[]{4, 1, 6, 5, 7, 2, 3, 0};
            int preferred = gallery[clampInt((int)Math.floor(stableHash01(episode, 937) * gallery.length), 0, gallery.length - 1)];
            float bestScore = -9999f;
            int best = preferred;
            for (int g = 0; g < gallery.length; g++) {
                float score = scoreAestheticGesture(episode, g);
                score += painterPoseOpenScale(g) * 0.075f;
                if (g == preferred) score += 0.155f;
                if (g == 0) score -= 0.030f; // 月牙可用，但不再长期霸占画面。
                score += stableHash01(episode, 940 + g * 37) * 0.030f;
                if (score > bestScore) {
                    bestScore = score;
                    best = g;
                }
            }
            cachedAestheticEpisode = episode;
            cachedAestheticGesture = best;
            return best;
        }

        private float painterPoseOpenScale(int gesture) {
            switch (gesture) {
                case 1: return 1.12f;
                case 4: return 1.18f;
                case 5: return 1.10f;
                case 6: return 1.14f;
                case 7: return 1.16f;
                case 2: return 1.06f;
                case 3: return 1.04f;
                default: return 1.00f;
            }
        }

        private float scoreAestheticGesture(int episode, int gesture) {
            int samples = 22;
            float prevX = 0f, prevY = 0f;
            float prevTx = 0f, prevTy = 0f;
            float length = 0f;
            float totalTurn = 0f;
            float sharpTurn = 0f;
            float minX = 999f, maxX = -999f, minY = 999f, maxY = -999f;
            float signChanges = 0f;
            float lastCross = 0f;
            for (int i = 0; i < samples; i++) {
                float u = i / (float)(samples - 1);
                float[] p = aestheticCurvePoint(episode, gesture, u);
                minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]);
                minY = Math.min(minY, p[1]); maxY = Math.max(maxY, p[1]);
                if (i > 0) {
                    float dx = p[0] - prevX;
                    float dy = p[1] - prevY;
                    float d = (float)Math.sqrt(dx * dx + dy * dy);
                    if (d > 0.0001f) {
                        float tx = dx / d;
                        float ty = dy / d;
                        length += d;
                        if (i > 1) {
                            float dot = clamp(prevTx * tx + prevTy * ty, -1f, 1f);
                            float cross = prevTx * ty - prevTy * tx;
                            float turn = (float)Math.acos(dot);
                            totalTurn += turn;
                            sharpTurn += smoother(clamp((turn - 0.34f) / 0.58f, 0f, 1f));
                            if (Math.abs(cross) > 0.040f) {
                                float s = cross > 0f ? 1f : -1f;
                                if (lastCross != 0f && s != lastCross) signChanges += 1f;
                                lastCross = s;
                            }
                        }
                        prevTx = tx; prevTy = ty;
                    }
                }
                prevX = p[0]; prevY = p[1];
            }
            float bw = Math.max(0.001f, maxX - minX);
            float bh = Math.max(0.001f, maxY - minY);
            float aspect = bw / bh;
            float logAspect = (float)Math.log(Math.max(0.001f, aspect));
            float aspectScore = 1f - Math.min(1f, Math.abs(logAspect - 0.02f) / 1.12f);
            float lengthScore = 1f - Math.min(1f, Math.abs(length - 1.22f) / 0.70f);
            float turnScore = 1f - Math.min(1f, Math.abs(totalTurn - 2.10f) / 1.55f);
            float flowScore = 1f - Math.min(1f, sharpTurn / 3.2f);
            float balance = 1f - Math.min(1f, signChanges / 2.6f);
            float negativeSpace = clamp((bw * bh) / 0.44f, 0f, 1.18f);
            return aspectScore * 0.20f + lengthScore * 0.18f + turnScore * 0.20f + flowScore * 0.19f + balance * 0.09f + negativeSpace * 0.14f;
        }

        private float[] painterPathPoint(float sec, float episodeStart, int episode, float w, float h, float minDim) {
            float episodeLen = painterEpisodeLen();
            float e = clamp((sec - episodeStart) / Math.max(0.001f, episodeLen), 0f, 0.9999f);
            int gesture = selectedAestheticGesture(episode);
            float[] q = aestheticCurvePoint(episode, gesture, e);

            // 轨迹只在中部小舞台内呼吸，不做“主体漂移”。随机性体现在笔势和曲线，而不是粗暴乱跑。
            float cx = w * (0.50f + 0.045f * stableSigned(episode, 701 + gesture * 5));
            float cy = h * (0.48f + 0.052f * stableSigned(episode, 709 + gesture * 7));
            float scale = minDim * (0.50f + 0.085f * stableHash01(episode, 719 + gesture * 11));
            if (gesture == 1) scale *= 0.96f; // 纵向羽化姿态略收敛，避免太高。
            if (gesture == 4 || gesture == 7) scale *= 1.06f;
            if (gesture == 6) scale *= 1.03f;
            float rot = stableSigned(episode, 727 + gesture * 13) * 0.52f
                    + (gesture == 1 ? 0.44f * stableSigned(episode, 731) : 0f)
                    + (gesture == 5 ? -0.22f : 0f);
            float co = (float)Math.cos(rot);
            float si = (float)Math.sin(rot);
            float x = cx + (q[0] * co - q[1] * si) * scale;
            float y = cy + (q[0] * si + q[1] * co) * scale;

            // 低频手腕颤动很小，只负责“活”，不负责“乱”。
            float seed = stableHash01(episode, 821 + gesture * 17) * 6.2831853f;
            float hand = smoother(clamp((e - 0.04f) / 0.92f, 0f, 1f)) * (1f - 0.55f * smoother(clamp((e - 0.92f) / 0.08f, 0f, 1f)));
            x += minDim * 0.0075f * hand * (float)Math.sin(e * 6.2831853f * 2.10f + seed);
            y += minDim * 0.0065f * hand * (float)Math.sin(e * 6.2831853f * 1.70f + seed * 1.37f);
            float marginX = w * 0.13f;
            float marginY = h * 0.17f;
            return new float[]{clamp(x, marginX, w - marginX), clamp(y, marginY, h - marginY)};
        }

        private float[] aestheticCurvePoint(int episode, int gesture, float u) {
            u = clamp(u, 0f, 1f);
            float su = smoother(u);
            float x;
            float y;
            float phase = stableSigned(episode, 801 + gesture * 23) * 0.22f;
            float asym = stableSigned(episode, 809 + gesture * 29) * 0.14f;
            switch (gesture) {
                case 0: // 青紫月牙：一笔上挑，内部留出漂亮负空间。
                    x = -0.56f + 1.12f * su;
                    y = -0.13f + 0.48f * (float)Math.pow(Math.max(0f, Math.sin(Math.PI * su + phase)), 0.92f)
                            - 0.12f * su - 0.075f * (float)Math.sin(2f * Math.PI * su + phase * 0.6f);
                    break;
                case 1: // 竖向水母羽翼：纵向生长，脊线有柔软腰身。
                    x = -0.20f + 0.34f * (float)Math.sin(Math.PI * su * 0.96f + phase)
                            + 0.11f * (float)Math.sin(2f * Math.PI * su + phase) + 0.11f * (su - 0.5f);
                    y = 0.62f - 1.24f * su + 0.15f * (float)Math.sin(Math.PI * su);
                    break;
                case 2: // S 形舞步：只保留一次优雅换向，像书法转腰。
                    x = -0.54f + 1.08f * su;
                    y = 0.42f * (float)Math.sin(1.55f * Math.PI * (su - 0.08f) + phase)
                            * (float)Math.pow(Math.max(0f, Math.sin(Math.PI * su)), 0.72f);
                    break;
                case 3: // 钩弧回锋：末端收笔，禁止卷成环结。
                    x = -0.52f + 1.02f * su - 0.055f * (float)Math.sin(2f * Math.PI * su);
                    y = -0.30f + 0.58f * (float)Math.sin(Math.PI * su + phase * 0.5f)
                            - 0.12f * su + 0.060f * smoother(clamp((su - 0.74f) / 0.26f, 0f, 1f));
                    break;
                case 4: // 宽缓折扇：中段开阔，头尾收束，是最稳定的“大形体”母型。
                    x = -0.52f + 1.04f * su;
                    y = 0.52f * (float)Math.pow(Math.max(0f, Math.sin(Math.PI * su)), 0.86f)
                            + 0.075f * (float)Math.sin(2f * Math.PI * su + phase) - 0.22f;
                    break;
                case 5: // 开放椭圆弧：像空间中旋转的透明伞盖，永不闭合。
                    float ang = lerp(2.70f, -0.56f, su) + phase * 0.42f;
                    x = 0.56f * (float)Math.cos(ang) + 0.075f * (su - 0.5f);
                    y = 0.42f * (float)Math.sin(ang) + 0.085f * (float)Math.sin(Math.PI * su);
                    break;
                case 6: // 兰花瓣/水袖：一侧鼓起，一侧回收，避免机械对称。
                    x = -0.34f + 0.74f * su + 0.24f * (float)Math.sin(Math.PI * su + phase)
                            - 0.08f * (float)Math.sin(2f * Math.PI * su);
                    y = 0.52f - 1.04f * su + 0.34f * (float)Math.pow(Math.max(0f, Math.sin(Math.PI * su)), 0.78f);
                    break;
                default: // 曼塔翼/大水母伞：横向舒展，但上下都有柔软起伏，不再是一条细线。
                    x = -0.58f + 1.16f * su;
                    y = -0.10f + 0.34f * (float)Math.pow(Math.max(0f, Math.sin(Math.PI * su)), 0.70f)
                            + 0.18f * (float)Math.sin(2f * Math.PI * (su - 0.12f) + phase)
                            * (float)Math.pow(Math.max(0f, Math.sin(Math.PI * su)), 0.96f);
                    break;
            }
            // 微小非对称让它像活物，但强度受限，保证“秩序中的自由”。
            x += asym * 0.032f * (float)Math.sin(2f * Math.PI * su) * (float)Math.sin(Math.PI * su);
            y += asym * 0.050f * (float)Math.sin(Math.PI * su) * (su - 0.5f);
            return new float[]{x, y};
        }

        private ArrayList<float[]> slicePoints(ArrayList<float[]> pts, int start, int end) {
            ArrayList<float[]> out = new ArrayList<>();
            int n = pts.size();
            if (n <= 0) return out;
            start = clampInt(start, 0, n - 1);
            end = clampInt(end, 0, n - 1);
            if (end < start) return out;
            for (int i = start; i <= end; i++) out.add(pts.get(i));
            return out;
        }

        private void drawRuledSurfaceSegment(ArrayList<float[]> inner, ArrayList<float[]> outer, int start, int end,
                                             float r, float g, float b, float a) {
            if (inner.size() < 2 || outer.size() < 2 || a <= 0.001f) return;
            int n = Math.min(inner.size(), outer.size());
            start = clampInt(start, 0, n - 2);
            end = clampInt(end, start + 1, n - 1);
            float[] verts = new float[(end - start + 1) * 2 * 2];
            int vi = 0;
            for (int i = start; i <= end; i++) {
                float[] p0 = inner.get(i);
                float[] p1 = outer.get(i);
                putNdc(verts, vi, p0[0], p0[1]); vi += 2;
                putNdc(verts, vi, p1[0], p1[1]); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void drawRuledSurfaceAgeFaded(ArrayList<float[]> inner, ArrayList<float[]> outer,
                                              float r, float g, float b, float baseA, float tailPower) {
            if (inner.size() < 3 || outer.size() < 3 || baseA <= 0.001f) return;
            int n = Math.min(inner.size(), outer.size());
            int slices = cfg.powerSave ? 10 : 18;
            for (int s = 0; s < slices; s++) {
                int start = clampInt((int)Math.floor(s * (n - 1f) / slices), 0, n - 2);
                int end = clampInt((int)Math.ceil((s + 1f) * (n - 1f) / slices), start + 1, n - 1);
                float u = ((start + end) * 0.5f) / Math.max(1f, n - 1f);
                float age = (float)Math.pow(clamp(u, 0f, 1f), tailPower);
                float wet = 1f + 0.22f * smoother(clamp((u - 0.82f) / 0.18f, 0f, 1f));
                float vanish = 1f - 0.28f * smoother(clamp((u - 0.965f) / 0.035f, 0f, 1f));
                float a = baseA * (0.09f + 0.91f * age) * wet * vanish;
                drawRuledSurfaceSegment(inner, outer, start, end, r, g, b, a);
            }
        }

        private void drawAgeFadedStrip(ArrayList<float[]> pts, float widthPx, float r, float g, float b,
                                       float baseA, float tailPower, float tipBoost) {
            if (pts.size() < 2 || baseA <= 0.001f || widthPx <= 0.04f) return;
            int n = pts.size();
            for (int i = 1; i < n; i++) {
                float u = (i - 0.5f) / Math.max(1f, n - 1f);
                float age = (float)Math.pow(clamp(u, 0f, 1f), tailPower);
                float midProfile = 0.42f + 0.58f * (float)Math.pow(Math.max(0f, Math.sin(Math.PI * u)), 0.25f);
                float head = 1f + tipBoost * smoother(clamp((u - 0.82f) / 0.18f, 0f, 1f));
                float a = baseA * (0.10f + 0.90f * age) * midProfile * head;
                ArrayList<float[]> seg = new ArrayList<>(2);
                seg.add(pts.get(i - 1));
                seg.add(pts.get(i));
                drawStrip(seg, widthPx * midProfile * head, r, g, b, a);
            }
        }

        private void drawReferenceLivingRibbonAtTime(float drawSec, Phase phase, float intensity, float tension,
                                                     float echoAlpha, boolean echoLayer) {
            if (drawSec < 0f || echoAlpha <= 0.002f) return;
            float minDim = Math.max(1f, Math.min(width, height));
            float w = Math.max(1f, width);
            float h = Math.max(1f, height);
            float episodeLen = cfg.powerSave ? 29.0f : 23.20f;
            float epFloat = drawSec / episodeLen;
            int episode = (int)Math.floor(epFloat);
            float e = epFloat - (float)Math.floor(epFloat);

            // 标准视频的主体是一次完整“生命动作”：细线切入 -> 膜面展开 -> 紫色卷幕 -> 绿色大折翼 -> 细茎回收。
            // 这里使用动作关键帧作为艺术骨架，再叠加每轮随机种子与连续噪声，保证不是机械循环。
            float[][] keys = new float[][]{
                    // cx,   cy,   span,  rot,    width, bend,   curl,   hue,  stem, ribs, side
                    {0.33f, 0.36f, 0.34f, -0.04f, 0.055f,  0.070f, -0.030f, 0.00f, 0.10f, 0.18f, -1f},
                    {0.45f, 0.34f, 0.42f,  0.06f, 0.105f,  0.110f, -0.050f, 0.05f, 0.12f, 0.26f, -1f},
                    {0.56f, 0.36f, 0.40f,  0.18f, 0.150f,  0.145f, -0.085f, 0.10f, 0.18f, 0.38f, -1f},
                    {0.52f, 0.44f, 0.34f, -1.22f, 0.075f, -0.035f,  0.155f, 1.08f, 0.60f, 0.25f,  1f},
                    {0.54f, 0.49f, 0.64f, -0.78f, 0.335f,  0.245f, -0.190f, 2.00f, 0.76f, 0.92f,  1f},
                    {0.55f, 0.53f, 0.58f, -0.10f, 0.245f,  0.155f, -0.075f, 2.72f, 0.44f, 0.55f, -1f},
                    {0.61f, 0.57f, 0.70f, -0.86f, 0.395f,  0.335f, -0.245f, 3.00f, 1.00f, 1.00f,  1f},
                    {0.61f, 0.58f, 0.56f, -1.00f, 0.165f,  0.255f, -0.315f, 3.00f, 1.00f, 0.35f,  1f},
                    {0.60f, 0.61f, 0.42f, -1.10f, 0.060f,  0.180f, -0.280f, 3.00f, 0.82f, 0.15f,  1f}
            };
            float[] kt = new float[]{0.000f, 0.105f, 0.225f, 0.355f, 0.505f, 0.640f, 0.790f, 0.905f, 1.000f};
            int seg = 0;
            while (seg < kt.length - 2 && e > kt[seg + 1]) seg++;
            float st = (e - kt[seg]) / Math.max(0.0001f, kt[seg + 1] - kt[seg]);
            st = smoother(st);

            float[] pose = new float[11];
            for (int i = 0; i < pose.length; i++) {
                pose[i] = lerp(keys[seg][i], keys[seg + 1][i], st);
            }

            float appear = smooth(clamp(e / 0.060f, 0f, 1f));
            float disappear = 1f - smooth(clamp((e - 0.955f) / 0.045f, 0f, 1f));
            float bodyAlpha = appear * disappear * echoAlpha;
            if (bodyAlpha <= 0.002f) return;

            // 每一轮给主体一个不同的舞台偏移/尺度/旋向；同时叠加低频连续呼吸，形成“随机但有生命”的运动。
            float rndX = stableSigned(episode, 11);
            float rndY = stableSigned(episode, 13);
            float rndR = stableSigned(episode, 17);
            float rndScale = 0.90f + 0.22f * stableHash01(episode, 19);
            float liveA = (float)Math.sin(drawSec * 0.47f + stableHash01(episode, 23) * 6.2831853f);
            float liveB = (float)Math.sin(drawSec * 0.31f + stableHash01(episode, 29) * 6.2831853f);
            float liveC = (float)Math.sin(drawSec * 0.73f + stableHash01(episode, 31) * 6.2831853f);

            float cx = pose[0] * w + rndX * w * 0.045f + liveA * w * 0.018f;
            float cy = pose[1] * h + rndY * h * 0.035f + liveB * h * 0.014f;
            float span = minDim * pose[2] * rndScale * (0.96f + 0.055f * liveC);
            float rot = pose[3] + rndR * 0.16f + liveA * 0.045f;
            float maxWidth = pose[4] * (0.96f + 0.12f * liveB) * (echoLayer ? 0.985f : 1.0f);
            float bend = pose[5] + liveA * 0.030f + stableSigned(episode, 37) * 0.018f;
            float curl = pose[6] + liveB * 0.035f + stableSigned(episode, 41) * 0.018f;
            float hue = pose[7] + 0.08f * liveC;
            float stem = pose[8];
            float ribMode = pose[9];
            float sideSign = pose[10] < 0f ? -1f : 1f;

            // 入场不是整片叶子出现，而是像视频那样从一小段发光曲线快速切入并写出膜面。
            float write = smooth(clamp(e / 0.135f, 0f, 1f));
            float visibleEnd = clamp(0.26f + 0.74f * write, 0.20f, 1.0f);
            float phaseBoost = phase.name.equals("临界") ? 1.10f : (phase.name.equals("同步") ? 1.04f : 0.98f);
            bodyAlpha *= phaseBoost * (0.90f + 0.28f * intensity);

            drawLivingRibbonGeometry(cx, cy, span, rot, sideSign, maxWidth, bend, curl, hue, stem, ribMode,
                    visibleEnd, drawSec, episode, bodyAlpha, echoLayer, tension);
        }

        private void drawLivingRibbonGeometry(float cx, float cy, float span, float rot, float sideSign,
                                              float maxWidth, float bend, float curl, float hue, float stem,
                                              float ribMode, float visibleEnd, float sec, int episode,
                                              float alpha, boolean echoLayer, float tension) {
            if (alpha <= 0.002f || span <= 1f) return;
            int n = cfg.powerSave ? 44 : 68;
            float minDim = Math.max(1f, Math.min(width, height));
            float tx0 = (float)Math.cos(rot);
            float ty0 = (float)Math.sin(rot);
            float nx0 = -ty0;
            float ny0 = tx0;
            float livePhase = stableHash01(episode, 101) * 6.2831853f;

            ArrayList<float[]> spine = new ArrayList<>(n);
            for (int i = 0; i < n; i++) {
                float v = i / Math.max(1f, n - 1f);
                float u = visibleEnd * v;
                float su = smooth(u);
                float endFade = smooth(clamp(u / 0.055f, 0f, 1f)) * (1f - 0.45f * smooth(clamp((u - 0.92f) / 0.08f, 0f, 1f)));
                float primary = (float)Math.sin(su * Math.PI) * bend;
                float tipHook = (float)Math.pow(clamp((su - 0.58f) / 0.42f, 0f, 1f), 1.65f) * curl;
                float shoulder = (float)Math.pow(Math.max(0f, 1f - su), 1.45f) * (0.036f * sideSign);
                float livingWave = 0.028f * (float)Math.sin(su * Math.PI * 2.15f + sec * 0.86f + livePhase)
                        * (float)Math.sin(su * Math.PI);
                float fineWave = 0.012f * (float)Math.sin(su * Math.PI * 5.4f - sec * 0.58f + livePhase * 0.37f)
                        * (float)Math.sin(su * Math.PI);
                float off = span * sideSign * (primary + tipHook + shoulder + livingWave + fineWave) * endFade;
                float along = span * (su - 0.53f);
                // 轻微“活体收缩”：不是整体漂移，而是沿自身脊线的呼吸。
                along += span * 0.015f * (float)Math.sin(sec * 0.69f + su * 4.8f + livePhase) * (float)Math.sin(su * Math.PI);
                spine.add(new float[]{cx + tx0 * along + nx0 * off, cy + ty0 * along + ny0 * off});
            }

            ArrayList<float[]> fold = new ArrayList<>(n);
            ArrayList<float[]> inner = new ArrayList<>(n);
            ArrayList<float[]> outer = new ArrayList<>(n);
            ArrayList<float[]> outerGlow = new ArrayList<>(n);
            ArrayList<float[]> caustic = new ArrayList<>(n);
            for (int i = 0; i < n; i++) {
                float v = i / Math.max(1f, n - 1f);
                float u = visibleEnd * v;
                float[] prev = spine.get(Math.max(0, i - 1));
                float[] next = spine.get(Math.min(n - 1, i + 1));
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float tx = dx / len;
                float ty = dy / len;
                float nx = -dy / len;
                float ny = dx / len;

                float rise = smooth(clamp(u / 0.10f, 0f, 1f));
                float fall = 1f - smooth(clamp((u - 0.965f) / 0.035f, 0f, 1f));
                float bell = (float)Math.pow(Math.max(0f, Math.sin(Math.PI * u)), 0.52f);
                float shoulderBias = 0.70f + 0.55f * (float)Math.pow(Math.max(0f, 1f - u), 0.72f);
                float fanBreathe = 1f + 0.13f * (float)Math.sin(sec * 0.76f + u * 5.1f + livePhase);
                // 低 ribMode：细流线/普通丝带；高 ribMode：标准视频里的折扇光膜，宽肩在前段展开，尾端收成细茎。
                // 这样避免再次变成“均匀香蕉叶”，让主体更像被控制点实时拉伸的开放光膜。
                float ribbonProfile = rise * fall * bell * shoulderBias;
                float fanProfile = rise * fall
                        * (0.20f + 1.35f * (float)Math.pow(Math.max(0f, 1f - u), 0.42f))
                        * (1f - 0.78f * smooth(clamp((u - 0.62f) / 0.36f, 0f, 1f)));
                float profile = clamp(lerp(ribbonProfile, fanProfile, clamp(ribMode * 0.82f, 0f, 1f)) * fanBreathe, 0f, 1.62f);
                float localWidth = span * maxWidth * profile;
                float shear = span * profile * (0.070f * (1f - u) - 0.040f * u)
                        + span * 0.018f * (float)Math.sin(sec * 0.54f + u * 7.0f + livePhase) * bell;

                float[] p = spine.get(i);
                fold.add(new float[]{p[0] + nx * sideSign * localWidth * 0.075f + tx * shear * 0.08f,
                                      p[1] + ny * sideSign * localWidth * 0.075f + ty * shear * 0.08f});
                inner.add(new float[]{p[0] + nx * sideSign * localWidth * 0.34f + tx * shear * 0.34f,
                                       p[1] + ny * sideSign * localWidth * 0.34f + ty * shear * 0.34f});
                outer.add(new float[]{p[0] + nx * sideSign * localWidth + tx * shear,
                                       p[1] + ny * sideSign * localWidth + ty * shear});
                outerGlow.add(new float[]{p[0] + nx * sideSign * localWidth * 1.12f + tx * shear * 1.08f,
                                           p[1] + ny * sideSign * localWidth * 1.12f + ty * shear * 1.08f});
                caustic.add(new float[]{p[0] + nx * sideSign * localWidth * (0.12f + 0.06f * (float)Math.sin(u * Math.PI)) + tx * shear * 0.18f,
                                         p[1] + ny * sideSign * localWidth * (0.12f + 0.06f * (float)Math.sin(u * Math.PI)) + ty * shear * 0.18f});
            }

            float[] body = livingPalette(hue, 0);
            float[] edge = livingPalette(hue, 1);
            float[] hot = livingPalette(hue, 2);
            float echoMul = echoLayer ? 0.58f : 1.0f;

            // 膜面：非常薄的半透明色，不画封闭叶形，只画一侧开放光膜。
            drawRuledSurface(fold, outerGlow, body[0], body[1], body[2], alpha * echoMul * 0.013f);
            drawRuledSurface(fold, outer, body[0], body[1], body[2], alpha * echoMul * 0.024f);
            drawRuledSurface(fold, inner, edge[0], edge[1], edge[2], alpha * echoMul * 0.010f);

            if (!echoLayer) {
                int fanLines = cfg.powerSave ? 22 : (int)lerp(24f, 58f, clamp(ribMode, 0f, 1f));
                // 标准视频中的美感很大一部分来自“光膜被许多细线拉成的折扇/丝绸面”。
                // 高 ribMode 时用扇形肋线：多数线汇向下方尾茎，形成绿/紫大折翼；低 ribMode 时用贴面短肋，保持细流线阶段轻盈。
                if (ribMode > 0.52f && n > 8) {
                    int rootIndex = clampInt((int)(n * (0.70f + 0.12f * stem)), 1, n - 2);
                    float[] root = fold.get(rootIndex);
                    for (int j = 0; j < fanLines; j++) {
                        float f = (j + 1f) / (fanLines + 1f);
                        float u = lerp(0.07f, 0.90f, f);
                        int idx = clampInt((int)(u * (n - 1)), 0, n - 1);
                        float[] a = outerGlow.get(idx);
                        float[] m = caustic.get(clampInt((idx + rootIndex) / 2, 0, n - 1));
                        ArrayList<float[]> rib = new ArrayList<>(4);
                        rib.add(a);
                        rib.add(new float[]{lerp(a[0], m[0], 0.52f), lerp(a[1], m[1], 0.52f)});
                        rib.add(new float[]{lerp(m[0], root[0], 0.62f), lerp(m[1], root[1], 0.62f)});
                        rib.add(root);
                        float ribA = alpha * (0.020f + 0.020f * ribMode) * (0.45f + 0.55f * (float)Math.sin(f * Math.PI));
                        drawTaperedStrip(rib, Math.max(0.035f, minDim * 0.00055f), body[0], body[1], body[2], ribA);
                    }
                } else {
                    int contourLines = cfg.powerSave ? 12 : 20;
                    for (int j = 1; j <= contourLines; j++) {
                        float f = j / (float)(contourLines + 1);
                        ArrayList<float[]> contour = new ArrayList<>(n);
                        float wave = 0.020f * (float)Math.sin(sec * 0.85f + j * 0.61f + livePhase);
                        for (int i = 0; i < n; i++) {
                            float u = i / Math.max(1f, n - 1f);
                            float ff = clamp(f + wave * (float)Math.sin(u * Math.PI), 0.02f, 0.98f);
                            float[] a = fold.get(i);
                            float[] b = outer.get(i);
                            contour.add(new float[]{lerp(a[0], b[0], ff), lerp(a[1], b[1], ff)});
                        }
                        drawTaperedStrip(contour, Math.max(0.030f, minDim * 0.00036f), body[0], body[1], body[2],
                                alpha * 0.010f * (0.70f + 0.30f * (float)Math.sin(f * Math.PI)));
                    }
                }
            }

            // 轮廓和折脊：主体真正“显形”的地方，必须可见，但不能变成粗白带。
            drawTaperedStrip(outer, Math.max(0.22f, minDim * 0.00125f), edge[0], edge[1], edge[2], alpha * echoMul * 0.135f);
            drawTaperedStrip(fold, Math.max(0.18f, minDim * 0.00090f), hot[0], hot[1], hot[2], alpha * echoMul * 0.072f);
            drawTaperedStrip(caustic, Math.max(0.13f, minDim * 0.00060f), hot[0], hot[1], hot[2], alpha * echoMul * 0.052f);

            // 尖端/尾钩：不是叶尖，而是视频中不断拉出的细亮“生命线”。
            int tipStart = Math.max(0, (int)(n * 0.78f));
            ArrayList<float[]> tip = new ArrayList<>(n - tipStart);
            for (int i = tipStart; i < n; i++) tip.add(outer.get(i));
            drawTaperedStrip(tip, Math.max(0.18f, minDim * 0.00105f), hot[0], hot[1], hot[2], alpha * echoMul * 0.150f);

            if (stem > 0.18f && !echoLayer) {
                int rootIndex = clampInt((int)(n * (0.72f + 0.16f * stem)), 1, n - 2);
                float[] root = fold.get(rootIndex);
                float[] prev = fold.get(rootIndex - 1);
                float[] next = fold.get(rootIndex + 1);
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float tx = dx / len;
                float ty = dy / len;
                float nx = -dy / len;
                float ny = dx / len;
                ArrayList<float[]> tail = new ArrayList<>(12);
                for (int k = 0; k < 12; k++) {
                    float v = k / 11f;
                    float reach = span * (0.03f + 0.32f * stem * v);
                    float hook = span * sideSign * (0.035f * (float)Math.sin(v * Math.PI * 1.15f + sec * 0.35f) - 0.050f * v * v);
                    tail.add(new float[]{root[0] - ty * reach + nx * hook, root[1] + tx * reach + ny * hook});
                }
                drawTaperedStrip(tail, Math.max(0.34f, minDim * 0.0020f), body[0], body[1], body[2], alpha * 0.085f);
                drawTaperedStrip(tail, Math.max(0.15f, minDim * 0.00075f), hot[0], hot[1], hot[2], alpha * 0.155f);
            }
        }

        private float[] livingPalette(float hue, int layer) {
            hue = hue % 3.001f;
            if (hue < 0f) hue += 3.001f;
            float[][] body = new float[][]{
                    {0.035f, 0.88f, 0.28f}, // green
                    {0.95f, 0.20f, 0.34f},  // warm magenta/orange
                    {0.56f, 0.08f, 1.00f},  // violet
                    {0.045f, 0.95f, 0.35f}  // green again
            };
            float[][] edge = new float[][]{
                    {0.12f, 1.00f, 0.58f},
                    {1.00f, 0.56f, 0.16f},
                    {0.96f, 0.24f, 1.00f},
                    {0.16f, 1.00f, 0.70f}
            };
            float[][] hot = new float[][]{
                    {0.72f, 1.00f, 0.88f},
                    {1.00f, 0.94f, 0.52f},
                    {0.92f, 0.78f, 1.00f},
                    {0.76f, 1.00f, 0.92f}
            };
            int i = clampInt((int)Math.floor(hue), 0, 2);
            float t = smooth(hue - i);
            float[][] src = layer == 0 ? body : (layer == 1 ? edge : hot);
            return new float[]{lerp(src[i][0], src[i + 1][0], t), lerp(src[i][1], src[i + 1][1], t), lerp(src[i][2], src[i + 1][2], t)};
        }

        private static float smoother(float x) {
            x = clamp(x, 0f, 1f);
            return x * x * x * (x * (x * 6f - 15f) + 10f);
        }

        private static float stableHash01(int seed, int salt) {
            int x = seed * 0x45d9f3b + salt * 0x27d4eb2d;
            x ^= (x >>> 16);
            x *= 0x7feb352d;
            x ^= (x >>> 15);
            x *= 0x846ca68b;
            x ^= (x >>> 16);
            return (x & 0x7fffffff) / 2147483647f;
        }

        private static float stableSigned(int seed, int salt) {
            return stableHash01(seed, salt) * 2f - 1f;
        }


        private void drawObservedMembranePiece(float cx, float cy, float span, float rot, float sideSign, float openScale,
                                               float bodyR, float bodyG, float bodyB, float edgeR, float edgeG, float edgeB,
                                               float alpha, float sec, boolean drawStem, float ribScale) {
            int n = cfg.powerSave ? 34 : 52;
            float minDim = Math.max(1f, Math.min(width, height));
            float tx0 = (float)Math.cos(rot);
            float ty0 = (float)Math.sin(rot);
            float nx0 = -ty0;
            float ny0 = tx0;
            float curlSign = sideSign < 0f ? -1f : 1f;
            float flutter = 0.5f + 0.5f * (float)Math.sin(sec * 0.73f + span * 0.0021f);

            ArrayList<float[]> ridge = new ArrayList<>(n);
            ArrayList<float[]> outer = new ArrayList<>(n);
            ArrayList<float[]> outerGlow = new ArrayList<>(n);
            ArrayList<float[]> inner = new ArrayList<>(n);
            ArrayList<float[]> foldLine = new ArrayList<>(n);

            for (int i = 0; i < n; i++) {
                float u = i / Math.max(1f, n - 1f);
                float su = smooth(u);
                float hook = (float)Math.pow(clamp((su - 0.62f) / 0.38f, 0f, 1f), 1.72f);
                float shoulder = (float)Math.pow(Math.max(0f, 1f - su), 1.35f);
                float bend = span * curlSign * ((float)Math.sin(su * Math.PI) * (0.105f + 0.030f * openScale)
                        - hook * (0.085f + 0.045f * openScale)
                        + shoulder * 0.025f);
                float micro = span * 0.010f * (float)Math.sin(su * Math.PI * 2.4f + sec * 0.46f) * (float)Math.sin(su * Math.PI);
                float x = cx + tx0 * span * (su - 0.52f) + nx0 * (bend + micro);
                float y = cy + ty0 * span * (su - 0.52f) + ny0 * (bend + micro);

                float open = smooth(clamp(su / 0.10f, 0f, 1f));
                float close = 1f - smooth(clamp((su - 0.84f) / 0.16f, 0f, 1f));
                float body = (float)Math.pow(Math.max(0f, Math.sin(Math.PI * su)), 0.52f);
                float shoulderWeight = 0.55f + 0.58f * (1f - smooth(clamp((su - 0.50f) / 0.42f, 0f, 1f)));
                float profile = clamp(open * close * body * shoulderWeight, 0f, 1f);
                float widthProfile = span * (0.030f + 0.185f * openScale) * profile;
                float shear = span * profile * (0.040f * (1f - su) - 0.030f * su) * (0.65f + 0.35f * flutter);

                float foldOffset = widthProfile * (0.055f + 0.035f * (float)Math.sin(su * Math.PI));
                ridge.add(new float[]{x - nx0 * sideSign * foldOffset, y - ny0 * sideSign * foldOffset});
                inner.add(new float[]{x + nx0 * sideSign * widthProfile * 0.34f + tx0 * shear * 0.36f,
                                      y + ny0 * sideSign * widthProfile * 0.34f + ty0 * shear * 0.36f});
                outer.add(new float[]{x + nx0 * sideSign * widthProfile + tx0 * shear,
                                      y + ny0 * sideSign * widthProfile + ty0 * shear});
                outerGlow.add(new float[]{x + nx0 * sideSign * widthProfile * 1.16f + tx0 * shear * 1.08f,
                                          y + ny0 * sideSign * widthProfile * 1.16f + ty0 * shear * 1.08f});
                foldLine.add(new float[]{x + nx0 * sideSign * widthProfile * (0.090f + 0.055f * (float)Math.sin(su * Math.PI)) + tx0 * shear * 0.16f,
                                         y + ny0 * sideSign * widthProfile * (0.090f + 0.055f * (float)Math.sin(su * Math.PI)) + ty0 * shear * 0.16f});
            }

            // 极暗半透明主体，靠外缘和轮廓显形；绝不生成宽白带。
            drawRuledSurface(ridge, outerGlow, bodyR, bodyG, bodyB, alpha * 0.010f);
            drawRuledSurface(ridge, outer, bodyR, bodyG, bodyB, alpha * 0.026f);
            drawRuledSurface(ridge, inner, edgeR, edgeG, edgeB, alpha * 0.014f);

            // 贴面等高线：沿膜面方向走的细密肋纹，替代旧版横向放射肋。
            int contours = cfg.powerSave ? 14 : Math.max(18, (int)(30f * ribScale));
            for (int j = 1; j <= contours; j++) {
                float f = j / (float)(contours + 1);
                if (f < 0.08f || f > 0.94f) continue;
                ArrayList<float[]> line = new ArrayList<>(n);
                float lineWave = 0.012f * (float)Math.sin(sec * 0.91f + j * 0.73f);
                for (int i = 0; i < n; i++) {
                    float u = i / Math.max(1f, n - 1f);
                    float localF = clamp(f + lineWave * (float)Math.sin(u * Math.PI), 0.02f, 0.98f);
                    float[] a = ridge.get(i);
                    float[] b = outer.get(i);
                    line.add(new float[]{lerp(a[0], b[0], localF), lerp(a[1], b[1], localF)});
                }
                float taper = 0.45f + 0.55f * (float)Math.sin(f * Math.PI);
                float rr = lerp(bodyR, edgeR, f);
                float gg = lerp(bodyG, edgeG, f);
                float bb = lerp(bodyB, edgeB, f);
                drawTaperedStrip(line, Math.max(0.035f, minDim * 0.00042f), rr, gg, bb, alpha * 0.0065f * taper);
            }

            // 外缘和折脊是视频主体的“形体边界”，但只画成冷色细线/窄亮边。
            drawTaperedStrip(outer, Math.max(0.28f, minDim * 0.00125f), edgeR, edgeG, edgeB, alpha * 0.105f);
            drawTaperedStrip(foldLine, Math.max(0.20f, minDim * 0.00082f), 0.55f, 1.00f, 0.78f, alpha * 0.052f);
            drawTaperedStrip(ridge, Math.max(0.16f, minDim * 0.00055f), bodyR, bodyG, bodyB, alpha * 0.038f);

            int start = Math.max(0, (int)(n * 0.80f));
            ArrayList<float[]> tip = new ArrayList<>(n - start);
            for (int i = start; i < n; i++) tip.add(outer.get(i));
            drawTaperedStrip(tip, Math.max(0.20f, minDim * 0.0010f), 0.70f, 1.00f, 0.88f, alpha * 0.115f);

            if (drawStem) {
                float[] base = ridge.get(Math.max(0, (int)(n * 0.82f)));
                ArrayList<float[]> stem = new ArrayList<>(9);
                for (int k = 0; k < 9; k++) {
                    float v = k / 8f;
                    float drop = span * (0.05f + 0.28f * v);
                    float side = span * sideSign * (0.018f * (float)Math.sin(v * Math.PI * 1.2f + sec * 0.40f) - 0.030f * v);
                    stem.add(new float[]{base[0] + ty0 * drop + nx0 * side, base[1] - tx0 * drop + ny0 * side});
                }
                drawTaperedStrip(stem, Math.max(0.42f, minDim * 0.0022f), 0.06f, 0.98f, 0.75f, alpha * 0.105f);
                drawTaperedStrip(stem, Math.max(0.18f, minDim * 0.0008f), 0.72f, 1.00f, 0.92f, alpha * 0.150f);
            }
        }

        private void drawObservedHairline(float cx, float cy, float span, float rot, float sideSign,
                                          float r, float g, float b, float alpha, float sec) {
            int n = cfg.powerSave ? 12 : 18;
            ArrayList<float[]> pts = new ArrayList<>(n);
            float tx = (float)Math.cos(rot);
            float ty = (float)Math.sin(rot);
            float nx = -ty;
            float ny = tx;
            for (int i = 0; i < n; i++) {
                float u = i / Math.max(1f, n - 1f);
                float bend = sideSign * span * (0.10f * (float)Math.sin(u * Math.PI) - 0.055f * u * u);
                float wob = span * 0.010f * (float)Math.sin(sec * 0.66f + u * 5.2f);
                pts.add(new float[]{cx + tx * span * (u - 0.5f) + nx * (bend + wob),
                                    cy + ty * span * (u - 0.5f) + ny * (bend + wob)});
            }
            float minDim = Math.max(1f, Math.min(width, height));
            drawTaperedStrip(pts, Math.max(0.16f, minDim * 0.00075f), r, g, b, alpha);
        }

        private void drawVideoSilkBladeSubject(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                               float r, float g, float b, float alpha,
                                               float intensity, float tension, float release, boolean headLayer) {
            if (pts.size() < 4 || alpha <= 0.004f) return;
            int n = pts.size();
            float sideSign = s.asymmetry < 0f ? -1f : 1f;
            float minDim = Math.max(1f, Math.min(width, height));
            boolean subjectPhase = !phase.name.equals("释放") && !phase.name.equals("余韵");
            float phaseWide = phase.name.equals("分离") ? 0.56f
                    : (phase.name.equals("吸引") ? 0.70f
                    : (phase.name.equals("同步") ? 0.92f
                    : (phase.name.equals("临界") ? 1.08f : 0.82f)));
            float motifScale = s.motif == 15 ? 1.00f : (s.motif == 13 ? 0.74f : 0.58f);

            // 颜色按视频主体限定：绿/青/紫为主；暖色只做极细早期折线，不再出现黄色宽带。
            float cr, cg, cb, ar, ag, ab;
            if (phase.name.equals("同步")) { cr = 0.50f; cg = 0.10f; cb = 1.00f; ar = 0.16f; ag = 0.95f; ab = 0.48f; }
            else if (phase.name.equals("临界")) { cr = 0.08f; cg = 0.96f; cb = 0.26f; ar = 0.10f; ag = 0.96f; ab = 0.82f; }
            else if (phase.name.equals("吸引")) { cr = 0.10f; cg = 0.86f; cb = 0.34f; ar = 0.64f; ag = 0.13f; ab = 0.96f; }
            else if (phase.name.equals("分离")) { cr = 0.10f; cg = 0.80f; cb = 0.36f; ar = 0.90f; ag = 0.18f; ab = 0.36f; }
            else {
                int hue = Math.floorMod(s.variant, 4);
                if (hue == 0) { cr = 0.08f; cg = 0.96f; cb = 0.30f; ar = 0.60f; ag = 0.15f; ab = 1.00f; }
                else if (hue == 1) { cr = 0.12f; cg = 0.88f; cb = 0.45f; ar = 0.82f; ag = 0.12f; ab = 1.00f; }
                else if (hue == 2) { cr = 0.08f; cg = 0.82f; cb = 0.95f; ar = 0.22f; ag = 1.00f; ab = 0.50f; }
                else { cr = 0.55f; cg = 0.12f; cb = 1.00f; ar = 0.18f; ag = 0.95f; ab = 0.40f; }
            }

            // 真实视频观感：薄膜比截图中的彩带窄得多，亮度也低；形体靠轮廓和贴面肋纹显形。
            float sail = minDim * (0.048f + 0.046f * phaseWide) * motifScale * (0.92f + s.motifStrength * 0.10f);
            float fold = Math.max(0.22f, baseWidth * 0.10f);
            float layerScale = headLayer ? 1.0f : (subjectPhase ? 0.10f : 0.24f);

            ArrayList<float[]> ridge = new ArrayList<>(n);
            ArrayList<float[]> inner = new ArrayList<>(n);
            ArrayList<float[]> outer = new ArrayList<>(n);
            ArrayList<float[]> outerSoft = new ArrayList<>(n);
            ArrayList<float[]> caustic = new ArrayList<>(n);
            for (int i = 0; i < n; i++) {
                float u = i / Math.max(1f, n - 1f);
                float[] prev = pts.get(Math.max(0, i - 1));
                float[] next = pts.get(Math.min(n - 1, i + 1));
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float tx = dx / len;
                float ty = dy / len;
                float nx = -dy / len;
                float ny = dx / len;

                // 宽肩在前半段，尖端快速收束；这是视频“叶片/蝠翼/丝绸折片”的核心轮廓。
                float open = smooth(clamp(u / 0.12f, 0f, 1f));
                float body = (float)Math.pow(Math.max(0f, Math.sin(Math.PI * u)), 0.58f);
                float tipClose = 1f - smooth(clamp((u - 0.74f) / 0.26f, 0f, 1f)) * 0.985f;
                float shoulderBias = 0.62f + 0.38f * (float)Math.pow(Math.max(0f, 1f - u), 0.55f);
                float profile = clamp(open * body * tipClose * shoulderBias, 0f, 1f);
                float notch = (float)Math.sin(u * Math.PI * 2.15f + s.seed * 0.55f) * sail * 0.012f * profile;
                float shear = sail * profile * (0.10f * (1f - u) * (1f - u) - 0.045f * u * (1f - u));
                float x = pts.get(i)[0];
                float y = pts.get(i)[1];

                ridge.add(new float[]{x - nx * sideSign * fold * (0.10f + 0.18f * profile) + tx * notch * 0.10f,
                                      y - ny * sideSign * fold * (0.10f + 0.18f * profile) + ty * notch * 0.10f});
                inner.add(new float[]{x + nx * sideSign * sail * profile * 0.32f + tx * (shear * 0.38f + notch * 0.32f),
                                      y + ny * sideSign * sail * profile * 0.32f + ty * (shear * 0.38f + notch * 0.32f)});
                outer.add(new float[]{x + nx * sideSign * sail * profile + tx * (shear + notch),
                                      y + ny * sideSign * sail * profile + ty * (shear + notch)});
                outerSoft.add(new float[]{x + nx * sideSign * sail * profile * 1.12f + tx * (shear * 1.10f + notch * 1.18f),
                                          y + ny * sideSign * sail * profile * 1.12f + ty * (shear * 1.10f + notch * 1.18f)});
                caustic.add(new float[]{x + nx * sideSign * sail * profile * (0.055f + 0.040f * (float)Math.sin(u * Math.PI)) + tx * notch * 0.18f,
                                        y + ny * sideSign * sail * profile * (0.055f + 0.040f * (float)Math.sin(u * Math.PI)) + ty * notch * 0.18f});
            }

            drawRuledSurface(ridge, outerSoft, cr, cg, cb, alpha * layerScale * (subjectPhase ? 0.0045f : 0.009f));
            drawRuledSurface(ridge, outer, cr, cg, cb, alpha * layerScale * (subjectPhase ? 0.014f : 0.026f));
            drawRuledSurface(ridge, inner, ar, ag, ab, alpha * layerScale * (subjectPhase ? 0.0045f : 0.008f));

            if (!headLayer) {
                drawTaperedStrip(ridge, Math.max(0.05f, baseWidth * 0.006f), ar, ag, ab, alpha * 0.0025f);
                drawTaperedStrip(outer, Math.max(0.06f, baseWidth * 0.008f), cr, cg, cb, alpha * 0.006f);
                return;
            }

            // 贴面细肋：由外缘收束到折脊，不能沿中心线铺成另一条宽带。
            int ribs = phase.name.equals("临界") ? 44 : (phase.name.equals("同步") ? 34 : 24);
            if (cfg.powerSave) ribs = Math.min(ribs, 24);
            for (int j = 1; j <= ribs; j++) {
                float u = j / (float)(ribs + 1);
                if (u < 0.10f || u > 0.88f) continue;
                float pos = u * (n - 1);
                int i0 = clampInt((int)Math.floor(pos), 0, n - 1);
                int i1 = clampInt(i0 + 1, 0, n - 1);
                float f = pos - i0;
                float[] a = new float[]{lerp(outerSoft.get(i0)[0], outerSoft.get(i1)[0], f), lerp(outerSoft.get(i0)[1], outerSoft.get(i1)[1], f)};
                float[] cpt = new float[]{lerp(caustic.get(i0)[0], caustic.get(i1)[0], f), lerp(caustic.get(i0)[1], caustic.get(i1)[1], f)};
                float[] lpt = new float[]{lerp(ridge.get(i0)[0], ridge.get(i1)[0], f), lerp(ridge.get(i0)[1], ridge.get(i1)[1], f)};
                ArrayList<float[]> rib = new ArrayList<>(3);
                rib.add(a);
                rib.add(new float[]{lerp(a[0], cpt[0], 0.52f), lerp(a[1], cpt[1], 0.52f)});
                rib.add(lpt);
                float ribA = alpha * (subjectPhase ? 0.0055f : 0.010f) * (0.72f + 0.28f * (float)Math.sin(u * Math.PI));
                drawTaperedStrip(rib, Math.max(0.045f, baseWidth * 0.004f), cr, cg, cb, ribA);
            }

            drawTaperedStrip(outer, Math.max(0.055f, baseWidth * 0.010f), cr, cg, cb,
                    alpha * (subjectPhase ? 0.020f : 0.044f));
            drawTaperedStrip(ridge, Math.max(0.055f, baseWidth * 0.008f), ar, ag, ab,
                    alpha * (subjectPhase ? 0.022f : 0.048f));
            drawTaperedStrip(caustic, Math.max(0.045f, baseWidth * 0.006f), 0.58f, 1.00f, 0.78f,
                    alpha * (subjectPhase ? 0.014f : 0.032f));

            // 尖端只保留极短冷青亮钩/细茎，不再画长白柱。
            int start = Math.max(0, (int)(n * 0.82f));
            ArrayList<float[]> tipRidge = new ArrayList<>(n - start);
            for (int i = start; i < n; i++) tipRidge.add(ridge.get(i));
            drawTaperedStrip(tipRidge, Math.max(0.05f, baseWidth * 0.010f), 0.68f, 1.00f, 0.86f,
                    alpha * (subjectPhase ? 0.040f : 0.070f));
        }


        
private void drawArtMotifAccent(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                        float r, float g, float b, float alpha, float intensity,
                                        float tension, float release, boolean headLayer) {
            if (pts.size() < 3 || alpha <= 0.004f) return;
            float[] first = pts.get(0);
            float[] last = pts.get(pts.size() - 1);
            float dx = last[0] - first[0];
            float dy = last[1] - first[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) return;
            float tx = dx / len;
            float ty = dy / len;
            float nx = -ty;
            float ny = tx;

            if (s.motif == 13 || s.motif == 15 || s.motif == 17) {
                drawVideoSilkBladeSubject(s, pts, phase, baseWidth, r, g, b, alpha, intensity, tension, release, headLayer);
                return;
            }

            if (s.motif == 12) {
                // Liquid pod: large soft oval body with inner glow and a few broad rings.
                float[] mid = pts.get(pts.size() / 2);
                float rot = (float)Math.atan2(dy, dx);
                float rx = baseWidth * (8.0f + tension * 3.5f + s.motifStrength * 2.2f);
                float ry = baseWidth * (4.5f + release * 2.4f + s.motifStrength * 1.6f);
                drawEllipse(mid[0], mid[1], rx, ry, rot, r, g, b, alpha * (0.070f + intensity * 0.040f + release * 0.040f), 36);
                drawEllipse(mid[0] + nx * rx * 0.10f, mid[1] + ny * rx * 0.10f, rx * 0.54f, ry * 0.50f, rot + 0.22f * s.flowC, 1f, 1f, 1f, alpha * 0.040f, 28);
                drawRing(mid[0], mid[1], Math.max(1f, rx * 0.86f), Math.max(0.55f, baseWidth * 0.12f), r, g, b, alpha * 0.065f, 48);
                return;
            } else if (s.motif == 13) {
                // Luminous wing: two translucent lobes, no mesh ribs.
                drawAsymmetricRibbon(pts, baseWidth * (8.5f + tension * 2.8f), baseWidth * (2.8f + tension), r, g, b, alpha * (0.060f + intensity * 0.035f), 0.74f);
                drawAsymmetricRibbon(pts, baseWidth * (2.6f + tension), baseWidth * (7.6f + tension * 2.2f), r, g, b, alpha * (0.040f + intensity * 0.026f), 0.88f);
                drawTaperedStrip(pts, Math.max(0.38f, baseWidth * 0.16f), 1f, 1f, 1f, alpha * 0.32f);
                return;
            } else if (s.motif == 14) {
                // Blossom crown: visible petals as soft ellipses gathered around a curved center.
                float[] mid = pts.get(pts.size() / 2);
                float rot = (float)Math.atan2(dy, dx);
                int petals = headLayer ? 5 : 3;
                for (int k = 0; k < petals; k++) {
                    float a = rot + (k - (petals - 1) * 0.5f) * 0.58f;
                    float px = mid[0] + (float)Math.cos(a) * baseWidth * (2.6f + k * 0.18f);
                    float py = mid[1] + (float)Math.sin(a) * baseWidth * (2.6f + k * 0.18f);
                    drawEllipse(px, py, baseWidth * (4.7f + tension * 1.9f), baseWidth * (1.75f + intensity), a, r, g, b,
                            alpha * (0.045f + intensity * 0.030f) * (1f - k * 0.055f), 28);
                }
                drawCircle(mid[0], mid[1], baseWidth * (1.4f + release * 1.3f), 1f, 1f, 1f, alpha * 0.070f, 24);
                return;
            } else if (s.motif == 15) {
                // Silk banner: one continuous translucent cloth-like sheet plus a narrow gleaming fold.
                drawAsymmetricRibbon(pts, baseWidth * (7.8f + tension * 2.4f), baseWidth * (6.8f + release * 2.0f), r, g, b, alpha * (0.060f + intensity * 0.028f + release * 0.028f), 0.66f);
                drawAsymmetricRibbon(pts, baseWidth * (3.0f + tension), baseWidth * (2.2f + tension), 1f, 1f, 1f, alpha * 0.026f, 1.0f);
                return;
            } else if (s.motif == 16) {
                // Orbit halo: crescent arcs and one full diffuse ring.
                float[] mid = pts.get(pts.size() / 2);
                float radius = Math.max(baseWidth * 5.0f, Math.min(width, height) * (0.045f + 0.030f * s.motifStrength));
                float start = (float)Math.atan2(first[1] - mid[1], first[0] - mid[0]) + s.seed * 0.23f;
                drawArcStrip(mid[0], mid[1], radius, Math.max(0.75f, baseWidth * 0.62f), start, (float)Math.PI * (1.15f + 0.55f * s.motifStrength) * s.flowC, r, g, b, alpha * (0.15f + intensity * 0.06f), 44);
                drawRing(mid[0], mid[1], radius * 0.66f, Math.max(0.48f, baseWidth * 0.10f), r, g, b, alpha * 0.045f, 48);
                drawCircle(mid[0], mid[1], baseWidth * (1.2f + release), 1f, 1f, 1f, alpha * 0.055f, 18);
                return;
            } else if (s.motif == 17) {
                // Crystal shard: faceted polygon plate with a white edge, replacing net-like crosshatching.
                float[] mid = pts.get(pts.size() / 2);
                ArrayList<float[]> poly = new ArrayList<>(5);
                poly.add(new float[]{first[0], first[1]});
                poly.add(new float[]{mid[0] + nx * baseWidth * (5.2f + tension * 1.7f), mid[1] + ny * baseWidth * (5.2f + tension * 1.7f)});
                poly.add(new float[]{last[0], last[1]});
                poly.add(new float[]{mid[0] - nx * baseWidth * (2.4f + release * 1.4f), mid[1] - ny * baseWidth * (2.4f + release * 1.4f)});
                drawFilledPolygon(poly, r, g, b, alpha * (0.060f + release * 0.030f));
                ArrayList<float[]> edgeA = new ArrayList<>(2);
                edgeA.add(poly.get(0)); edgeA.add(poly.get(1));
                drawTaperedStrip(edgeA, Math.max(0.42f, baseWidth * 0.13f), 1f, 1f, 1f, alpha * 0.32f);
                ArrayList<float[]> edgeB = new ArrayList<>(2);
                edgeB.add(poly.get(1)); edgeB.add(poly.get(2));
                drawTaperedStrip(edgeB, Math.max(0.34f, baseWidth * 0.10f), r, g, b, alpha * 0.20f);
                return;
            }

            if (s.motif == 3 || phase.name.equals("释放")) {
                // Silver blade: a pale triangular face plus a very thin white cutting edge.
                float[] mid = pts.get(pts.size() / 2);
                ArrayList<float[]> blade = new ArrayList<>(3);
                blade.add(new float[]{first[0], first[1]});
                blade.add(new float[]{mid[0] + nx * baseWidth * (2.4f + tension * 1.8f), mid[1] + ny * baseWidth * (2.4f + tension * 1.8f)});
                blade.add(new float[]{last[0], last[1]});
                drawTaperedStrip(blade, baseWidth * (2.8f + release * 2.0f), 1f, 1f, 1f,
                        alpha * (0.028f + release * 0.050f));
                ArrayList<float[]> edge = new ArrayList<>(2);
                edge.add(new float[]{first[0], first[1]});
                edge.add(new float[]{last[0], last[1]});
                drawTaperedStrip(edge, Math.max(0.34f, baseWidth * 0.11f), 1f, 1f, 1f,
                        alpha * (0.40f + intensity * 0.22f));
            } else if (s.motif == 4 || s.motif == 6) {
                // Petal / vine: soft side curls so the body looks like a living leaf or flower edge.
                float side = strokeHash(s, 3, 930) < 0.5f ? -1f : 1f;
                int layers = headLayer ? 3 : 1;
                for (int layer = 0; layer < layers; layer++) {
                    ArrayList<float[]> petal = new ArrayList<>(pts.size());
                    for (int i = 0; i < pts.size(); i++) {
                        float u = i / Math.max(1f, pts.size() - 1f);
                        float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                        float curl = (float)Math.sin(u * Math.PI * 1.5f + layer * 0.52f + s.seed) * baseWidth * (0.9f + tension);
                        float off = side * baseWidth * (1.9f + layer * 0.86f) * feather;
                        float[] p = pts.get(i);
                        petal.add(new float[]{p[0] + nx * off + tx * curl * feather, p[1] + ny * off + ty * curl * feather});
                    }
                    float a = alpha * (0.022f + intensity * 0.042f + release * 0.028f) * (1f - layer * 0.18f);
                    drawTaperedStrip(petal, baseWidth * (0.24f + layer * 0.12f), r, g, b, a);
                }
            } else if (s.motif == 5) {
                // Prism polygon: a few offset echoes make the frame read as a tilted transparent sheet.
                for (int k = -2; k <= 2; k++) {
                    if (k == 0) continue;
                    float off = baseWidth * k * 1.15f;
                    ArrayList<float[]> copy = new ArrayList<>(pts.size());
                    for (int i = 0; i < pts.size(); i++) {
                        float[] p = pts.get(i);
                        copy.add(new float[]{p[0] + nx * off, p[1] + ny * off});
                    }
                    drawTaperedStrip(copy, Math.max(0.22f, baseWidth * 0.055f), r, g, b,
                            alpha * (0.016f + intensity * 0.028f));
                }
            } else if (s.motif == 7) {
                // Long bridge: a strong central bow plus faint parallel ghost line, like the magenta arc in the video.
                ArrayList<float[]> ghost = new ArrayList<>(pts.size());
                float side = strokeHash(s, 4, 941) < 0.5f ? -1f : 1f;
                for (int i = 0; i < pts.size(); i++) {
                    float u = i / Math.max(1f, pts.size() - 1f);
                    float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                    float[] p = pts.get(i);
                    ghost.add(new float[]{p[0] + nx * side * baseWidth * 3.1f * feather, p[1] + ny * side * baseWidth * 3.1f * feather});
                }
                drawTaperedStrip(ghost, Math.max(0.25f, baseWidth * 0.18f), r, g, b,
                        alpha * (0.018f + intensity * 0.022f));
            } else if (s.motif == 8) {
                // Jellyfish tendril: short hanging side filaments near the head, very dim and organic.
                int hairs = headLayer ? 5 : 2;
                for (int h = 0; h < hairs; h++) {
                    float u = 0.45f + strokeHash(s, h, 960) * 0.48f;
                    int idx = clampInt((int)(u * (pts.size() - 1)), 1, pts.size() - 2);
                    float[] p = pts.get(idx);
                    float side2 = strokeHash(s, h, 961) < 0.5f ? -1f : 1f;
                    ArrayList<float[]> hair = new ArrayList<>(3);
                    hair.add(new float[]{p[0], p[1]});
                    hair.add(new float[]{p[0] + nx * side2 * baseWidth * (2.0f + h), p[1] + ny * side2 * baseWidth * (2.0f + h)});
                    hair.add(new float[]{p[0] + nx * side2 * baseWidth * (2.7f + h) + tx * baseWidth * (1.2f + h * 0.2f), p[1] + ny * side2 * baseWidth * (2.7f + h) + ty * baseWidth * (1.2f + h * 0.2f)});
                    drawTaperedStrip(hair, Math.max(0.18f, baseWidth * 0.050f), r, g, b, alpha * (0.018f + intensity * 0.018f));
                }
            } else if (s.motif == 9) {
                // Nebula coil: offset echoes make the stroke read as a luminous smoke curl, not a simple arc.
                for (int k = 1; k <= 3; k++) {
                    ArrayList<float[]> echo = new ArrayList<>(pts.size());
                    float sign = k % 2 == 0 ? -1f : 1f;
                    for (int i = 0; i < pts.size(); i++) {
                        float u = i / Math.max(1f, pts.size() - 1f);
                        float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                        float swirl = (float)Math.sin(u * Math.PI * (1.0f + k * 0.35f) + s.seed) * baseWidth * (1.4f + k * 0.55f) * feather;
                        float[] p = pts.get(i);
                        echo.add(new float[]{p[0] + nx * sign * swirl, p[1] + ny * sign * swirl});
                    }
                    drawTaperedStrip(echo, Math.max(0.20f, baseWidth * (0.070f - k * 0.010f)), r, g, b,
                            alpha * (0.018f + intensity * 0.020f) * (1f - k * 0.18f));
                }
            } else if (s.motif == 10) {
                // Origami sheet: two fold lines and a faint translucent face.
                ArrayList<float[]> foldA = new ArrayList<>(pts.size());
                ArrayList<float[]> foldB = new ArrayList<>(pts.size());
                for (int i = 0; i < pts.size(); i++) {
                    float u = i / Math.max(1f, pts.size() - 1f);
                    float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                    float[] p = pts.get(i);
                    foldA.add(new float[]{p[0] + nx * baseWidth * 2.0f * feather, p[1] + ny * baseWidth * 2.0f * feather});
                    foldB.add(new float[]{p[0] - nx * baseWidth * 1.6f * feather, p[1] - ny * baseWidth * 1.6f * feather});
                }
                drawTaperedStrip(foldA, Math.max(0.22f, baseWidth * 0.060f), 1f, 1f, 1f, alpha * (0.090f + release * 0.045f));
                drawTaperedStrip(foldB, Math.max(0.20f, baseWidth * 0.045f), r, g, b, alpha * (0.030f + intensity * 0.020f));
            } else if (s.motif == 11) {
                // Constellation chain: sparse nodes welded into the moving line, avoiding random dust clutter.
                int nodes = Math.min(6, Math.max(3, pts.size() / 8));
                for (int k = 1; k <= nodes; k++) {
                    int idx = clampInt((int)(k / (float)(nodes + 1) * (pts.size() - 1)), 1, pts.size() - 2);
                    float[] p = pts.get(idx);
                    drawCircle(p[0], p[1], baseWidth * (0.42f + strokeHash(s, k, 980) * 0.44f), r, g, b,
                            alpha * (0.075f + intensity * 0.040f), 12);
                }
            } else if ((s.motif == 2 || s.motif == 10) && headLayer) {
                // Fan/sheet hinge glow, a dim focal phosphor dot that makes the structure appear intentional rather than random.
                float[] pivot = strokeHash(s, 5, 950) < 0.5f ? first : last;
                drawCircle(pivot[0], pivot[1], baseWidth * (10.0f + tension * 7.0f), r, g, b,
                        alpha * 0.030f, 24);
            }
        }

        private void drawFiberVeil(StrokeEvent s, ArrayList<float[]> pts, float baseWidth,
                                   float r, float g, float b, float alpha, float intensity,
                                   float tension, float release, boolean headLayer) {
            if (pts.size() < 4 || alpha <= 0.004f) return;
            float[] first = pts.get(0);
            float[] last = pts.get(pts.size() - 1);
            float dx = last[0] - first[0];
            float dy = last[1] - first[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) return;
            float nx = -dy / len;
            float ny = dx / len;

            int strands = 5 + (int)(cfg.randomness * 5f + intensity * 4f);
            if (s.actor == 1) strands = Math.max(3, strands - 2);
            if (s.actor == 2) strands += 2;
            if (!headLayer) strands = Math.max(3, strands / 2);
            float spread = baseWidth * (1.2f + tension * 1.9f + release * 1.7f) * (s.actor == 2 ? 1.20f : 0.92f);
            for (int j = 0; j < strands; j++) {
                float h = strokeHash(s, j, 701);
                float h2 = strokeHash(s, j, 709);
                float side = (j - (strands - 1) * 0.5f) / Math.max(1f, (strands - 1f));
                float off = side * spread * (0.55f + h * 0.90f);
                float along = (h2 - 0.5f) * baseWidth * (1.0f + tension);
                ArrayList<float[]> strand = new ArrayList<>(pts.size());
                for (int i = 0; i < pts.size(); i++) {
                    float u = i / Math.max(1f, pts.size() - 1f);
                    float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                    float wave = (float)Math.sin(u * Math.PI * 2.0f + s.seed + j * 0.77f) * baseWidth * 0.28f * feather;
                    float[] p = pts.get(i);
                    strand.add(new float[]{p[0] + nx * (off + wave) + dx / len * along * feather,
                                           p[1] + ny * (off + wave) + dy / len * along * feather});
                }
                float strandWidth = Math.max(0.24f, baseWidth * (0.030f + strokeHash(s, j, 719) * 0.070f));
                float strandAlpha = alpha * (0.025f + intensity * 0.035f + release * 0.035f) * (0.45f + h * 0.80f);
                drawTaperedStrip(strand, strandWidth, r, g, b, strandAlpha);
            }
        }

        private ArrayList<float[]> offsetPoints(ArrayList<float[]> src, float dx, float dy) {
            ArrayList<float[]> out = new ArrayList<>(src.size());
            for (int i = 0; i < src.size(); i++) {
                float[] p = src.get(i);
                out.add(new float[]{p[0] + dx, p[1] + dy});
            }
            return out;
        }


        private void drawActorHeadCluster(StrokeEvent s, ArrayList<float[]> pts, float baseWidth,
                                          float r, float g, float b, float alpha,
                                          float intensity, float tension, float release) {
            if (pts.size() < 3 || alpha <= 0.004f) return;
            float[] head = pts.get(pts.size() - 1);
            float[] prev = pts.get(Math.max(0, pts.size() - 4));
            float dx = head[0] - prev[0];
            float dy = head[1] - prev[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) len = 1f;
            float tx = dx / len;
            float ty = dy / len;
            float nx = -ty;
            float ny = tx;
            int dots = s.actor == 2 ? 5 : 3;
            float cluster = baseWidth * (s.actor == 2 ? 2.6f : 1.7f) * (0.80f + tension * 0.40f + release * 0.50f);
            for (int i = 0; i < dots; i++) {
                float h1 = strokeHash(s, i, 901);
                float h2 = strokeHash(s, i, 907);
                float along = (-0.18f + h1 * 0.36f) * cluster;
                float side = (h2 - 0.5f) * 2f * cluster * (s.actor == 2 ? 0.95f : 0.45f);
                float x = head[0] + tx * along + nx * side;
                float y = head[1] + ty * along + ny * side;
                float rr = Math.max(0.40f, baseWidth * (s.actor == 2 ? 0.20f : 0.13f) * (0.55f + h1));
                drawCircle(x, y, rr, r, g, b, alpha * (s.actor == 2 ? 0.050f : 0.034f) * (0.7f + intensity), 10);
            }
            if (s.actor == 2) {
                for (int k = -1; k <= 1; k += 2) {
                    ArrayList<float[]> ray = new ArrayList<>(2);
                    float side = k * cluster * 0.72f;
                    ray.add(new float[]{head[0] - tx * cluster * 0.20f, head[1] - ty * cluster * 0.20f});
                    ray.add(new float[]{head[0] + tx * cluster * 0.55f + nx * side, head[1] + ty * cluster * 0.55f + ny * side});
                    drawTaperedStrip(ray, Math.max(0.24f, baseWidth * 0.045f), r, g, b, alpha * 0.035f);
                }
            }
        }

        private void drawPointLineSpray(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                        float r, float g, float b, float alpha, float intensity, float tension, float release) {
            if (pts.size() < 3 || alpha <= 0.004f) return;
            int n = pts.size();
            float minDim = Math.min(width, height);
            float lifeProgress = clamp(s.age / Math.max(0.001f, s.life), 0f, 1f);
            float headBias = lifeProgress < 0.55f ? smooth(lifeProgress / 0.55f) : 1f;
            float grainBase = phase.name.equals("分离") ? 3f : phase.name.equals("吸引") ? 5f : phase.name.equals("同步") ? 6f : phase.name.equals("临界") ? 8f : 5f;
            if (s.actor == 1) grainBase *= 0.58f;
            if (s.actor == 2) grainBase *= 0.82f;
            int grains = (int)(grainBase + cfg.randomness * (s.actor == 2 ? 4f : 3f) + release * 4f);
            float spray = baseWidth * (1.35f + tension * 1.55f) * (s.actor == 2 ? 1.18f : 0.88f) + minDim * (0.0010f + cfg.randomness * 0.0035f);

            for (int i = 0; i < grains; i++) {
                float h1 = strokeHash(s, i, 11);
                float h2 = strokeHash(s, i, 17);
                float h3 = strokeHash(s, i, 23);
                // 大部分颗粒落在当前光迹前部，少部分散落在尾部，形成“喷洒”而非等宽线条。
                float u = h1 < 0.68f ? lerp(0.58f, 1.0f, h2) : h2;
                u = clamp(lerp(u, headBias, 0.18f * intensity), 0f, 1f);
                int idx = clampInt((int)(u * (n - 1)), 1, n - 2);
                float[] p = pts.get(idx);
                float[] prev = pts.get(idx - 1);
                float[] next = pts.get(idx + 1);
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float tx = dx / len;
                float ty = dy / len;
                float nx = -ty;
                float ny = tx;
                float side = (h2 - 0.5f) * 2f;
                float along = (strokeHash(s, i, 31) - 0.5f) * spray * 0.72f;
                float normal = side * spray * (0.35f + strokeHash(s, i, 37) * 1.25f);
                // 临界/释放更像飞溅；分离更淡、更远。
                float phaseBoost = phase.name.equals("临界") ? 1.30f : phase.name.equals("释放") ? 1.55f : phase.name.equals("分离") ? 0.72f : 1.0f;
                float x = p[0] + tx * along + nx * normal * phaseBoost;
                float y = p[1] + ty * along + ny * normal * phaseBoost;
                float radius = Math.max(0.32f, baseWidth * (0.018f + strokeHash(s, i, 41) * 0.070f) + minDim * 0.00028f);
                float dotAlpha = alpha * (0.014f + 0.060f * intensity + release * 0.055f) * (0.35f + h3 * 0.60f);
                if (phase.name.equals("分离")) dotAlpha *= 0.55f;
                if (s.actor == 1) dotAlpha *= 0.78f;
                if (s.actor == 2) dotAlpha *= 1.18f;
                drawCircle(x, y, radius, r, g, b, dotAlpha, 10);

                // 少量短促微线，形成“点线组成”的笔触纹理，而不是一根孤立线。
                if (strokeHash(s, i, 53) < 0.46f + intensity * 0.20f) {
                    float seg = radius * (5.0f + strokeHash(s, i, 59) * 9.0f);
                    ArrayList<float[]> mini = new ArrayList<>(2);
                    mini.add(new float[]{x - tx * seg * 0.45f, y - ty * seg * 0.45f});
                    mini.add(new float[]{x + tx * seg * 0.55f, y + ty * seg * 0.55f});
                    drawTaperedStrip(mini, Math.max(0.22f, radius * 0.50f), r, g, b, dotAlpha * 0.38f);
                }
            }
        }

        private float strokeHash(StrokeEvent s, int i, int salt) {
            double v = Math.sin(s.seed * 12.9898 + s.variant * 0.013579 + i * 78.233 + salt * 37.719) * 43758.5453;
            return (float)(v - Math.floor(v));
        }

        private ArrayList<float[]> sampleStroke(StrokeEvent s) {
            ArrayList<float[]> pts = new ArrayList<>();
            if (s.count == 2) {
                for (int i = 0; i <= 18; i++) {
                    float t = i / 18f;
                    pts.add(new float[]{lerp(s.x[0], s.x[1], t), lerp(s.y[0], s.y[1], t)});
                }
                return pts;
            }
            int samplesPerSegment = 12;
            for (int i = 0; i < s.count - 1; i++) {
                float x0 = s.x[Math.max(0, i - 1)], y0 = s.y[Math.max(0, i - 1)];
                float x1 = s.x[i], y1 = s.y[i];
                float x2 = s.x[i + 1], y2 = s.y[i + 1];
                float x3 = s.x[Math.min(s.count - 1, i + 2)], y3 = s.y[Math.min(s.count - 1, i + 2)];
                for (int k = 0; k < samplesPerSegment; k++) {
                    float t = k / (float)samplesPerSegment;
                    pts.add(new float[]{catmull(x0, x1, x2, x3, t), catmull(y0, y1, y2, y3, t)});
                }
            }
            pts.add(new float[]{s.x[s.count - 1], s.y[s.count - 1]});
            return pts;
        }

        private ArrayList<float[]> visibleSegment(ArrayList<float[]> all, StrokeEvent s) {
            return visibleSegmentAt(all, s, clamp(s.age / Math.max(0.001f, s.life), 0f, 1f));
        }

        private ArrayList<float[]> visibleSegmentAt(ArrayList<float[]> all, StrokeEvent s, float progress) {
            ArrayList<float[]> out = new ArrayList<>();
            if (all.size() < 2) return out;

            // V17：移动窗口。head 继续向前“写出”，tail 同步跟进；
            // 不再把整条线画出来再整体淡死。
            float eased = smooth(clamp(progress, 0f, 1f));
            float window = clamp(s.visibleWindow, 0.22f, 0.62f);
            float head = lerp(-s.headLead, 1.0f + window + s.headLead, eased);
            float tail = head - window;
            if (tail >= 1.0f || head <= 0.0f) return out;
            float startF = clamp(tail, 0f, 1f);
            float endF = clamp(head, 0f, 1f);
            int start = clampInt((int)(startF * (all.size() - 1)), 0, all.size() - 2);
            int end = clampInt((int)(endF * (all.size() - 1)), start + 1, all.size() - 1);
            for (int i = start; i <= end; i++) out.add(all.get(i));
            // V18：过滤过短可见片段。Mystify/Ribbons 的观感不是“短点线残片”，
            // 而是一笔有势能、有长度、有消失背影的光迹。
            // 开头和结尾如果窗口太短，直接不画，让旧 FBO 残影自然承担退场。
            float minLen = Math.min(width, height) * 0.18f;
            if (polylineLength(out) < minLen) out.clear();
            return out;
        }

        private float polylineLength(ArrayList<float[]> pts) {
            float len = 0f;
            for (int i = 1; i < pts.size(); i++) {
                float[] a = pts.get(i - 1);
                float[] b = pts.get(i);
                float dx = b[0] - a[0];
                float dy = b[1] - a[1];
                len += (float)Math.sqrt(dx * dx + dy * dy);
            }
            return len;
        }

        private void drawTaperedStrip(ArrayList<float[]> pts, float widthPx, float r, float g, float b, float a) {
            if (pts.size() < 2 || a <= 0.001f || widthPx <= 0.05f) return;
            int n = pts.size();
            float[] verts = new float[n * 2 * 2];
            int vi = 0;
            for (int i = 0; i < n; i++) {
                float u = i / Math.max(1f, (n - 1f));
                float profile = (float)Math.pow(Math.max(0.0, Math.sin(Math.PI * u)), 1.22);
                float half = widthPx * 0.5f * (0.004f + 0.996f * profile);
                float[] prev = pts.get(Math.max(0, i - 1));
                float[] next = pts.get(Math.min(n - 1, i + 1));
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float x = pts.get(i)[0];
                float y = pts.get(i)[1];
                putNdc(verts, vi, x + nx * half, y + ny * half); vi += 2;
                putNdc(verts, vi, x - nx * half, y - ny * half); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void drawStrip(ArrayList<float[]> pts, float widthPx, float r, float g, float b, float a) {
            if (pts.size() < 2 || a <= 0.001f || widthPx <= 0.05f) return;
            int n = pts.size();
            float[] verts = new float[n * 2 * 2];
            int vi = 0;
            float half = widthPx * 0.5f;
            for (int i = 0; i < n; i++) {
                float[] prev = pts.get(Math.max(0, i - 1));
                float[] next = pts.get(Math.min(n - 1, i + 1));
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float x = pts.get(i)[0];
                float y = pts.get(i)[1];
                putNdc(verts, vi, x + nx * half, y + ny * half); vi += 2;
                putNdc(verts, vi, x - nx * half, y - ny * half); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }


        private void drawAfterglowBubbleAquarium(float sec, float after, Phase phase) {
            if (!cfg.bubbles || !phase.name.equals("余韵") || after <= 0.006f) return;
            float appear = smooth(Math.min(1f, after / 0.070f));
            float fadeOut = 1f - smooth(Math.max(0f, (after - 0.90f) / 0.10f));
            float aBase = clamp(appear * fadeOut, 0f, 1f);
            if (aBase <= 0.002f) return;
            float minDim = Math.max(1f, Math.min(width, height));
            float cx = pulseX * width;
            float cy = pulseY * height;

            // V36：余韵气泡逐帧清绘；这里给一层干净、稳定的深蓝玻璃水域，
            // 不依靠历史残影叠亮，因此透明泡移动时不会拖成长筒。
            drawSolidRect(0.004f, 0.030f, 0.105f, aBase * 0.155f);
            drawSolidRect(0.000f, 0.110f, 0.220f, aBase * 0.055f);

            // 左下到右上的青绿水光：较亮但很细，模拟参考视频里的斜向光束，不再形成大面积白色斜面。
            for (int k = 0; k < 5; k++) {
                float off = minDim * (-0.16f + k * 0.055f + 0.024f * (float)Math.sin(sec * 0.045f + k * 1.9f));
                float y0 = height * (1.02f + 0.010f * k) + off;
                float y1 = height * (0.36f + 0.036f * k) + off * 0.14f;
                ArrayList<float[]> beam = new ArrayList<>(4);
                beam.add(new float[]{-width * 0.22f, y0});
                beam.add(new float[]{width * 0.18f, lerp(y0, y1, 0.33f)});
                beam.add(new float[]{width * 0.64f, lerp(y0, y1, 0.72f)});
                beam.add(new float[]{width * 1.14f, y1});
                drawTaperedStrip(beam, minDim * (0.014f + k * 0.0022f), 0.07f, 0.74f, 1.00f, aBase * (0.010f - k * 0.0009f));
                drawTaperedStrip(beam, Math.max(0.55f, minDim * (0.0017f + k * 0.00045f)), 0.72f, 1.00f, 0.90f, aBase * (0.040f - k * 0.0040f));
            }

            // 透明肥皂泡爆散：每轮释放使用 afterglowSeed，确保每次出现的数量、方向、大小、薄膜色都不同。
            int count = cfg.powerSave ? 18 : 30;
            for (int i = 0; i < count; i++) {
                int key = afterglowSeed + i * 131;
                float h0 = hash01(key, 3301);
                float h1 = hash01(key, 3303);
                float h2 = hash01(key, 3307);
                float h3 = hash01(key, 3313);
                float h4 = hash01(key, 3319);
                float born = h0 * 0.11f;
                float life = 0.92f + h1 * 0.46f;
                float u = clamp((after - born) / Math.max(0.001f, life), 0f, 1f);
                float live = smooth(Math.min(1f, u / 0.060f)) * (1f - smooth(Math.max(0f, (u - 0.86f) / 0.14f)));
                if (live <= 0.002f) continue;

                float ang = (float)(h2 * Math.PI * 2.0 + 0.16f * Math.sin(sec * 0.10f + i * 0.7f));
                float burst = smooth(Math.min(1f, u / 0.18f));
                float far = minDim * (0.30f + h3 * 0.78f);
                float drift = minDim * (0.060f + h1 * 0.145f) * u;
                float swirl = minDim * (0.012f + h0 * 0.036f) * (float)Math.sin(u * Math.PI * 1.9f + i * 1.3f);
                float nx = (float)Math.cos(ang);
                float ny = (float)Math.sin(ang);
                float tx = -ny;
                float ty = nx;
                float bx = cx + nx * (minDim * 0.012f + far * burst + drift) + tx * swirl;
                float by = cy + ny * (minDim * 0.012f + far * burst + drift) + ty * swirl;
                // 后半段轻微斜向上浮，像水里漂移，而不是固定在释放中心周围转圈。
                bx += minDim * (0.018f + h4 * 0.080f) * u;
                by -= minDim * (0.060f + h1 * 0.150f) * u;

                float radius = minDim * (0.024f + h4 * 0.050f) * (0.90f + 0.18f * (float)Math.sin(Math.PI * u));
                if (i % 9 == 0) radius *= 1.18f;
                radius = Math.min(radius, minDim * 0.088f);
                drawIridescentBubble(bx, by, radius, key, aBase * live, sec);
            }
        }

        private void drawIridescentBubble(float cx, float cy, float radius, int index, float alpha, float sec) {
            if (alpha <= 0.002f || radius <= 0.5f) return;
            // V33：水晶泡泡 = 极淡蓝色内部 + 双层薄膜边缘 + 局部彩虹弧 + 白色椭圆高光。
            // 中心保持透明，不再画成黑珠或实心彩圈。
            drawCircle(cx, cy, radius * 0.98f, 0.020f, 0.210f, 0.410f, alpha * 0.018f, 44);
            drawCircle(cx - radius * 0.13f, cy - radius * 0.18f, radius * 0.62f, 0.32f, 0.86f, 1.00f, alpha * 0.008f, 36);

            float spin = sec * (0.10f + 0.003f * (index & 15)) + index * 0.0137f;
            float w = Math.max(0.55f, radius * 0.030f);
            drawRing(cx, cy, radius * 1.010f, Math.max(0.38f, radius * 0.015f), 0.92f, 0.99f, 1.00f, alpha * 0.24f, 72);
            drawRing(cx, cy, radius * 0.930f, Math.max(0.28f, radius * 0.007f), 0.22f, 0.76f, 1.00f, alpha * 0.045f, 64);
            drawArcStrip(cx, cy, radius * 1.015f, w * 1.36f, spin, (float)Math.PI * 0.50f, 0.96f, 0.30f, 0.78f, alpha * 0.22f, 18);
            drawArcStrip(cx, cy, radius * 1.020f, w * 1.22f, spin + 1.54f, (float)Math.PI * 0.54f, 0.26f, 0.94f, 1.00f, alpha * 0.24f, 20);
            drawArcStrip(cx, cy, radius * 1.015f, w * 1.12f, spin + 2.76f, (float)Math.PI * 0.46f, 0.60f, 1.00f, 0.36f, alpha * 0.18f, 18);
            drawArcStrip(cx, cy, radius * 1.005f, w * 0.96f, spin + 3.86f, (float)Math.PI * 0.38f, 1.00f, 0.86f, 0.34f, alpha * 0.12f, 16);

            float hiAng = -0.98f + 0.16f * (float)Math.sin(spin * 0.8f);
            float hx = cx + (float)Math.cos(hiAng) * radius * 0.44f;
            float hy = cy + (float)Math.sin(hiAng) * radius * 0.44f;
            drawEllipse(hx, hy, radius * 0.155f, radius * 0.052f, hiAng + 0.54f, 1f, 1f, 1f, alpha * 0.50f, 16);
            drawEllipse(cx - radius * 0.26f, cy - radius * 0.18f, radius * 0.40f, radius * 0.014f, hiAng + 0.16f, 0.72f, 0.96f, 1f, alpha * 0.105f, 16);
            drawEllipse(cx + radius * 0.30f, cy + radius * 0.23f, radius * 0.34f, radius * 0.010f, hiAng + 0.12f, 1.0f, 0.55f, 0.94f, alpha * 0.050f, 14);
        }

        private void drawSolidRect(float r, float g, float b, float a) {
            if (a <= 0f) return;
            float[] verts = new float[]{-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f};
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private float hash01(int i, int salt) {
            double v = Math.sin((i + 1) * 12.9898 + salt * 78.233 + cfg.style * 37.719) * 43758.5453;
            return (float)(v - Math.floor(v));
        }

        private void drawReleaseEruption(float local, float release, Phase phase) {
            float baseX = pulseX * width;
            float baseY = pulseY * height;
            float minDim = Math.max(1f, Math.min(width, height));
            float t = clamp(local, 0f, 1f);
            float releaseDurSec = Math.max(0.30f, phase.end - phase.start);
            float elapsed = t * releaseDurSec;

            // V37：震颤按“真实秒数”而不是归一化进度驱动。
            // 这样无论释放阶段被设置为 8 秒还是 24 秒，开头 0.5 秒都会出现肉眼可见的硬抖动。
            float quakeRise = smooth(Math.min(1f, elapsed / 0.020f));
            float quakeDrop = 1f - smooth(Math.max(0f, (elapsed - 0.36f) / 0.18f));
            float preQuake = quakeRise * quakeDrop;
            float quakeStrobe = (((int)Math.floor(elapsed * 34.0f + (releaseSeed & 7)) & 1) == 0) ? 1.0f : 0.18f;
            float quakeSnap = (((int)Math.floor(elapsed * 23.0f + ((releaseSeed >> 4) & 7)) & 1) == 0) ? 1.0f : -1.0f;

            float impactFlash = smooth(Math.min(1f, elapsed / 0.055f)) * (1f - smooth(Math.max(0f, (elapsed - 0.46f) / 0.22f)));
            float beamSurgeTime = smooth(Math.min(1f, (elapsed - 0.12f) / 0.22f)) * (1f - smooth(Math.max(0f, (elapsed - 1.50f) / 0.62f)));
            float beamSurgeNorm = smooth(Math.min(1f, (t - 0.055f) / 0.145f)) * (1f - smooth(Math.max(0f, (t - 0.72f) / 0.28f)));
            float beamSurge = Math.max(beamSurgeTime, beamSurgeNorm * 0.82f);
            float floodSurge = smooth(Math.min(1f, (t - 0.15f) / 0.18f)) * (1f - smooth(Math.max(0f, (t - 0.88f) / 0.12f)));
            float finalClean = 1f - smooth(Math.max(0f, (t - 0.84f) / 0.16f));
            float visibleRelease = Math.max(release, Math.min(1f, preQuake * 0.62f + impactFlash * 0.86f));
            float a = clamp((visibleRelease * 0.82f + impactFlash * 0.55f + preQuake * 0.26f) * (0.90f + 0.38f * cfg.intimacy), 0f, 1.60f);

            // 大幅、非正弦、跳变式偏移：比 V36 更像“画面被猛地撞了几下”，而不是柔和晃动。
            float tremor = preQuake * (0.42f + 0.58f * (float)Math.abs(Math.sin(elapsed * 132.0f + releaseSeed * 0.0017f)));
            float snap = preQuake * (0.55f + 0.45f * quakeStrobe);
            float jx = minDim * (0.026f + 0.108f * tremor) * (float)Math.sin(elapsed * 96.0f + releaseSeed * 0.0023f)
                    + minDim * 0.075f * snap * quakeSnap;
            float jy = minDim * (0.024f + 0.102f * tremor) * (float)Math.cos(elapsed * 117.0f + releaseSeed * 0.0031f)
                    - minDim * 0.058f * snap * ((((int)Math.floor(elapsed * 29.0f)) & 1) == 0 ? 1f : -1f);
            float x = baseX + jx;
            float y = baseY + jy;

            // 明确的“颤抖可见层”：短促白闪 + 橙红热闪 + 撕裂光带。
            drawSolidRect(1.00f, 1.00f, 0.94f, a * preQuake * (0.100f + 0.070f * quakeStrobe));
            drawSolidRect(1.00f, 0.22f, 0.00f, a * preQuake * (0.050f + 0.032f * (1f - quakeStrobe)) * finalClean);
            drawQuakeTearBands(baseX, baseY, minDim, preQuake, quakeStrobe, elapsed, a);

            // 0.00-0.20：突然白化/热红升温，短促、刺激，但不长期烙屏。
            drawSolidRect(1.00f, 0.98f, 0.78f, a * (impactFlash * 0.088f + snap * 0.060f));
            drawSolidRect(1.00f, 0.39f, 0.02f, a * (beamSurge * 0.036f + snap * 0.030f) * finalClean);
            drawSolidRect(0.62f, 0.02f, 0.10f, a * (0.058f * preQuake + 0.020f * floodSurge) * finalClean);

            float coreR = minDim * (0.055f + 0.210f * beamSurge + 0.185f * impactFlash + 0.060f * visibleRelease);

            // V37：多重错帧核心。早期用明显分离的白金光心告诉眼睛“它在抖”。
            if (preQuake > 0.01f) {
                for (int q = 0; q < 7; q++) {
                    int key = releaseSeed + q * 761;
                    float angQ = (float)(hash01(key, 3901) * Math.PI * 2.0 + elapsed * (38.0f + q * 6.5f));
                    float ampQ = minDim * (0.040f + 0.092f * hash01(key, 3903)) * preQuake * (0.55f + 0.45f * quakeStrobe);
                    float qx = baseX + (float)Math.cos(angQ) * ampQ + (q % 2 == 0 ? jx * 0.45f : -jx * 0.36f);
                    float qy = baseY + (float)Math.sin(angQ) * ampQ + (q % 2 == 0 ? jy * 0.45f : -jy * 0.36f);
                    drawCircle(qx, qy, coreR * (0.58f + 0.20f * q), 1.00f, 1.00f, 0.96f, a * preQuake * (0.085f - q * 0.007f), 34);
                    drawCircle(qx, qy, coreR * (1.45f + 0.16f * q), 1.00f, 0.55f, 0.02f, a * preQuake * (0.040f - q * 0.0038f), 42);
                }
            }

            // 颤抖重影核心：白、金、橙、玫红多层错位，形成参考视频那种“强光把细节吞掉”的瞬间。
            for (int g = 0; g < 5; g++) {
                float gh = hash01(releaseSeed + g * 97, 3951);
                float gx = x + (gh - 0.5f) * minDim * 0.130f * preQuake;
                float gy = y + (hash01(releaseSeed + g * 101, 3957) - 0.5f) * minDim * 0.130f * preQuake;
                drawCircle(gx, gy, coreR * (2.65f + g * 0.34f), 1.00f, 0.48f, 0.03f, a * Math.max(0.004f, (0.040f - g * 0.0050f)) * finalClean, 64);
                drawCircle(gx, gy, coreR * (1.55f + g * 0.16f), 1.00f, 0.82f, 0.10f, a * Math.max(0.006f, (0.100f - g * 0.012f)) * finalClean, 64);
            }
            drawCircle(x, y, coreR * 0.88f, 1.00f, 1.00f, 0.96f, a * 0.270f * finalClean, 56);
            drawCircle(x + jx * 0.55f, y - jy * 0.55f, coreR * 0.48f, 1.00f, 1.00f, 1.00f, a * 0.230f * impactFlash, 40);

            // 宽幅冲击楔面：从中心突然推开，模拟视频里的大面积金白爆光与舞台追光，而非单个机械大圆盘。
            int wedges = cfg.powerSave ? 7 : 13;
            for (int w = 0; w < wedges; w++) {
                int key = releaseSeed + w * 137;
                float h0 = hash01(key, 4001);
                float h1 = hash01(key, 4003);
                float ang = (float)(h0 * Math.PI * 2.0 + 0.18f * Math.sin(t * 28.0f + h1 * 6.28f) + preQuake * quakeSnap * 0.20f);
                float sweep = 0.20f + h1 * 0.30f;
                float len = minDim * (0.52f + h1 * 0.90f) * (0.52f + beamSurge * 0.80f + preQuake * 0.22f);
                float inner = minDim * (0.018f + h1 * 0.020f);
                ArrayList<float[]> poly = new ArrayList<>(4);
                poly.add(new float[]{x + (float)Math.cos(ang - sweep) * inner, y + (float)Math.sin(ang - sweep) * inner});
                poly.add(new float[]{x + (float)Math.cos(ang - sweep * 0.72f) * len, y + (float)Math.sin(ang - sweep * 0.72f) * len});
                poly.add(new float[]{x + (float)Math.cos(ang + sweep * 0.72f) * len * (0.92f + h0 * 0.18f), y + (float)Math.sin(ang + sweep * 0.72f) * len * (0.92f + h0 * 0.18f)});
                poly.add(new float[]{x + (float)Math.cos(ang + sweep) * inner, y + (float)Math.sin(ang + sweep) * inner});
                float wa = a * Math.max(beamSurge, preQuake * 0.72f) * (0.035f + h0 * 0.030f) * finalClean;
                drawFilledPolygon(poly, 1.00f, 0.54f + h1 * 0.22f, 0.03f, wa * 0.58f);
                drawFilledPolygon(poly, 1.00f, 0.96f, 0.54f, wa * 0.22f);
            }

            // 粗大放射光柱：数量更密、宽窄交替、中心白芯更亮；加上横向/斜向扫光增强“冲屏”感。
            int beams = cfg.powerSave ? 16 : 32;
            for (int i = 0; i < beams; i++) {
                int key = releaseSeed + i * 193;
                float h0 = hash01(key, 4101);
                float h1 = hash01(key, 4103);
                float h2 = hash01(key, 4107);
                float h3 = hash01(key, 4111);
                float trem = preQuake * (h2 - 0.5f) * 1.10f;
                float ang = (float)(h0 * Math.PI * 2.0 + trem + 0.28f * Math.sin(t * 10.0f + h1 * 6.28f));
                float len = minDim * (0.70f + h1 * 1.18f) * (0.34f + beamSurge * 0.98f + preQuake * 0.20f);
                float sx = x + (float)Math.cos(ang) * minDim * (0.012f + h2 * 0.030f);
                float sy = y + (float)Math.sin(ang) * minDim * (0.012f + h2 * 0.030f);
                float ex = x + (float)Math.cos(ang) * len;
                float ey = y + (float)Math.sin(ang) * len;
                float tx = (float)Math.cos(ang + Math.PI * 0.5f);
                float ty = (float)Math.sin(ang + Math.PI * 0.5f);
                float bend = minDim * (h2 - 0.5f) * 0.24f * (0.35f + beamSurge + preQuake * 0.30f);
                ArrayList<float[]> beam = new ArrayList<>(4);
                beam.add(new float[]{sx, sy});
                beam.add(new float[]{lerp(sx, ex, 0.25f) + tx * bend * 0.22f, lerp(sy, ey, 0.25f) + ty * bend * 0.22f});
                beam.add(new float[]{lerp(sx, ex, 0.67f) + tx * bend, lerp(sy, ey, 0.67f) + ty * bend});
                beam.add(new float[]{ex, ey});
                float beamAlpha = a * (0.046f + h2 * 0.048f) * Math.max(beamSurge, preQuake * 0.52f) * finalClean;
                float beamWidth = minDim * (0.024f + h3 * 0.070f) * (0.72f + 1.12f * visibleRelease + 0.86f * impactFlash + 0.75f * snap);
                drawTaperedStrip(beam, beamWidth * 5.40f, 1.00f, 0.24f + h1 * 0.18f, 0.00f, beamAlpha * 0.36f);
                drawTaperedStrip(beam, beamWidth * 2.45f, 1.00f, 0.70f + h1 * 0.20f, 0.10f, beamAlpha * 0.78f);
                drawTaperedStrip(beam, Math.max(1.10f, beamWidth * 0.25f), 1.00f, 1.00f, 0.92f, beamAlpha * 1.45f);
            }

            // 扫屏光带：参考视频中粗黄光柱横穿画面，加入少量斜切光带，避免只有中心圆爆。
            int sweeps = cfg.powerSave ? 4 : 7;
            for (int sIdx = 0; sIdx < sweeps; sIdx++) {
                int key = releaseSeed + sIdx * 313;
                float h0 = hash01(key, 4161);
                float angle = (float)(-0.54f + h0 * 1.08f + 0.24f * Math.sin(t * 9.0f + sIdx) + preQuake * quakeSnap * 0.16f);
                float dx = (float)Math.cos(angle);
                float dy = (float)Math.sin(angle);
                float nx = -dy;
                float ny = dx;
                float off = minDim * (-0.40f + sIdx * 0.14f + (hash01(key, 4167) - 0.5f) * 0.30f + quakeSnap * preQuake * 0.18f);
                ArrayList<float[]> sweep = new ArrayList<>(4);
                sweep.add(new float[]{x - dx * width * 1.35f + nx * off, y - dy * width * 1.35f + ny * off});
                sweep.add(new float[]{x - dx * width * 0.45f + nx * (off + minDim * 0.03f), y - dy * width * 0.45f + ny * (off + minDim * 0.03f)});
                sweep.add(new float[]{x + dx * width * 0.45f + nx * (off - minDim * 0.02f), y + dy * width * 0.45f + ny * (off - minDim * 0.02f)});
                sweep.add(new float[]{x + dx * width * 1.35f + nx * off, y + dy * width * 1.35f + ny * off});
                float sw = minDim * (0.032f + 0.022f * hash01(key, 4171)) * (0.8f + 1.2f * beamSurge + 0.44f * preQuake);
                drawTaperedStrip(sweep, sw * 3.3f, 1.00f, 0.33f, 0.00f, a * Math.max(beamSurge, preQuake * 0.65f) * 0.028f * finalClean);
                drawTaperedStrip(sweep, sw * 1.05f, 1.00f, 0.95f, 0.42f, a * Math.max(beamSurge, preQuake * 0.65f) * 0.090f * finalClean);
                drawTaperedStrip(sweep, Math.max(0.8f, sw * 0.15f), 1.00f, 1.00f, 0.93f, a * Math.max(beamSurge, preQuake * 0.65f) * 0.140f * finalClean);
            }

            // 热浪/冲击环：只保留断续弧线与外推空气波，避免形成单调大圆盘。
            for (int j = 0; j < 8; j++) {
                float h = hash01(releaseSeed + j * 271, 4201);
                float r = minDim * (0.08f + 0.105f * j + beamSurge * (0.18f + h * 0.20f));
                float start = (float)(h * Math.PI * 2.0 + t * 2.5f + tremor * 0.3f);
                float sweep = (float)Math.PI * (0.26f + hash01(releaseSeed + j, 4207) * 0.74f);
                float alpha = a * (0.078f - j * 0.006f) * beamSurge * finalClean;
                drawArcStrip(x, y, r, Math.max(1.0f, minDim * (0.0060f + j * 0.0009f)), start, sweep,
                        1.00f, 0.64f + h * 0.20f, 0.05f, alpha, 44);
                drawArcStrip(x, y, r * 1.018f, Math.max(0.65f, minDim * 0.0016f), start + 0.07f, sweep * 0.58f,
                        1.00f, 1.00f, 0.80f, alpha * 0.78f, 34);
            }

            drawReleaseParticleFlood(x, y, t, visibleRelease, a, minDim, preQuake, floodSurge);
        }

        private void drawQuakeTearBands(float cx, float cy, float minDim, float quake, float strobe, float elapsed, float alpha) {
            if (quake <= 0.005f || alpha <= 0f) return;
            int bands = cfg.powerSave ? 5 : 9;
            for (int i = 0; i < bands; i++) {
                int key = releaseSeed + i * 881;
                float h0 = hash01(key, 3841);
                float h1 = hash01(key, 3847);
                float angle = (float)(-0.42f + h0 * 0.84f + quake * (((i & 1) == 0) ? 0.16f : -0.16f));
                float dx = (float)Math.cos(angle);
                float dy = (float)Math.sin(angle);
                float nx = -dy;
                float ny = dx;
                float gate = (((int)Math.floor(elapsed * (26f + i * 1.7f) + h1 * 9f)) & 1) == 0 ? 1f : -1f;
                float off = minDim * (-0.46f + i * 0.12f + (h1 - 0.5f) * 0.16f + gate * quake * 0.20f);
                float widthPx = minDim * (0.010f + h0 * 0.024f) * (1.0f + quake * 1.6f);
                ArrayList<float[]> band = new ArrayList<>(4);
                band.add(new float[]{cx - dx * width * 1.35f + nx * off, cy - dy * width * 1.35f + ny * off});
                band.add(new float[]{cx - dx * width * 0.40f + nx * (off + gate * minDim * 0.045f), cy - dy * width * 0.40f + ny * (off + gate * minDim * 0.045f)});
                band.add(new float[]{cx + dx * width * 0.52f + nx * (off - gate * minDim * 0.035f), cy + dy * width * 0.52f + ny * (off - gate * minDim * 0.035f)});
                band.add(new float[]{cx + dx * width * 1.35f + nx * off, cy + dy * width * 1.35f + ny * off});
                float a = alpha * quake * (0.048f + h1 * 0.054f) * (0.55f + 0.45f * strobe);
                drawTaperedStrip(band, widthPx * 5.2f, 1.00f, 0.18f, 0.00f, a * 0.30f);
                drawTaperedStrip(band, widthPx * 1.8f, 1.00f, 0.88f, 0.32f, a * 0.66f);
                drawTaperedStrip(band, Math.max(0.9f, widthPx * 0.28f), 1.00f, 1.00f, 0.96f, a * 1.10f);
            }
        }

        private void drawReleaseParticleFlood(float cx, float cy, float local, float release, float alpha, float minDim, float quake, float floodSurge) {
            int count = cfg.powerSave ? 110 : 230;
            for (int i = 0; i < count; i++) {
                int key = releaseSeed + i * 307;
                float h0 = hash01(key, 4301);
                float h1 = hash01(key, 4303);
                float h2 = hash01(key, 4307);
                float h3 = hash01(key, 4311);
                float h4 = hash01(key, 4319);
                float born = h0 * 0.22f;
                float life = 0.46f + h1 * 0.46f;
                float u = clamp((local - born) / Math.max(0.001f, life), 0f, 1f);
                float live = smooth(Math.min(1f, u / 0.045f)) * (1f - smooth(Math.max(0f, (u - 0.78f) / 0.22f))) * release * (0.55f + 0.85f * floodSurge);
                if (live <= 0.002f) continue;
                float ang = (float)(h2 * Math.PI * 2.0 + 0.18f * Math.sin(u * 9.0f + h3 * 6.28f) + quake * (h4 - 0.5f) * 0.92f);
                float dist = minDim * (0.030f + (0.35f + h3 * 1.30f) * (float)Math.pow(u, 0.50f));
                float drift = minDim * (h4 - 0.5f) * 0.18f * u * u;
                float nx = (float)Math.cos(ang);
                float ny = (float)Math.sin(ang);
                float tx = -ny;
                float ty = nx;
                float x = cx + nx * dist + tx * drift;
                float y = cy + ny * dist + ty * drift;
                float sz = minDim * (0.0030f + h4 * 0.0125f) * (1.12f - u * 0.46f) * (0.90f + floodSurge * 0.32f);
                float rot = ang + h0 * 2.8f + local * (1.2f + h1 * 2.0f);
                float a = alpha * live * (0.22f + h1 * 0.34f);
                if ((i & 3) == 0) {
                    ArrayList<float[]> poly = new ArrayList<>(4);
                    float co = (float)Math.cos(rot), si = (float)Math.sin(rot);
                    float rx = sz * (1.6f + h3 * 2.4f);
                    float ry = sz * (0.38f + h2 * 0.60f);
                    poly.add(new float[]{x + co * rx, y + si * rx});
                    poly.add(new float[]{x - si * ry, y + co * ry});
                    poly.add(new float[]{x - co * rx * 0.68f, y - si * rx * 0.68f});
                    poly.add(new float[]{x + si * ry, y - co * ry});
                    drawFilledPolygon(poly, 1.00f, 0.65f + h1 * 0.28f, 0.04f, a * 0.72f);
                    drawCircle(x, y, Math.max(0.6f, sz * 0.30f), 1f, 1f, 0.90f, a * 0.78f, 10);
                } else if ((i & 3) == 1) {
                    drawEllipse(x, y, sz * (1.8f + h2 * 1.8f), sz * (0.28f + h1 * 0.34f), rot,
                            1.00f, 0.42f + h1 * 0.30f, 0.00f, a * 0.98f, 10);
                    drawEllipse(x, y, sz * 0.80f, Math.max(0.35f, sz * 0.11f), rot, 1f, 1f, 0.86f, a * 0.76f, 8);
                } else if ((i & 3) == 2) {
                    ArrayList<float[]> comet = new ArrayList<>(3);
                    float tail = sz * (3.6f + h1 * 5.0f);
                    comet.add(new float[]{x - nx * tail, y - ny * tail});
                    comet.add(new float[]{x - nx * tail * 0.42f + tx * sz * 0.35f, y - ny * tail * 0.42f + ty * sz * 0.35f});
                    comet.add(new float[]{x, y});
                    drawTaperedStrip(comet, Math.max(0.55f, sz * (0.65f + h2)), 1.00f, 0.92f, 0.26f, a * 0.54f);
                    drawCircle(x, y, Math.max(0.5f, sz * 0.34f), 1f, 1f, 1f, a * 0.56f, 8);
                } else {
                    drawCircle(x, y, sz * (0.40f + h2 * 0.55f), 1.00f, 0.88f, 0.20f, a * 0.42f, 10);
                    drawEllipse(x + tx * sz * 0.20f, y + ty * sz * 0.20f, sz * (0.72f + h1), sz * 0.16f, rot, 1f, 1f, 0.94f, a * 0.66f, 8);
                }
            }
        }

        private void drawCircle(float cx, float cy, float radius, float r, float g, float b, float a, int segments) {
            if (a <= 0f || radius <= 0f) return;
            float[] verts = new float[(segments + 2) * 2];
            putNdc(verts, 0, cx, cy);
            int vi = 2;
            for (int i = 0; i <= segments; i++) {
                float ang = i / (float)segments * (float)Math.PI * 2f;
                putNdc(verts, vi, cx + (float)Math.cos(ang) * radius, cy + (float)Math.sin(ang) * radius);
                vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_FAN, r, g, b, a);
        }

        private void drawRing(float cx, float cy, float radius, float widthPx, float r, float g, float b, float a, int segments) {
            if (a <= 0f || radius <= 0f || widthPx <= 0f) return;
            float[] verts = new float[(segments + 1) * 2 * 2];
            int vi = 0;
            for (int i = 0; i <= segments; i++) {
                float ang = i / (float)segments * (float)Math.PI * 2f;
                float co = (float)Math.cos(ang);
                float si = (float)Math.sin(ang);
                putNdc(verts, vi, cx + co * (radius + widthPx), cy + si * (radius + widthPx)); vi += 2;
                putNdc(verts, vi, cx + co * Math.max(0f, radius - widthPx), cy + si * Math.max(0f, radius - widthPx)); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void putNdc(float[] verts, int idx, float x, float y) {
            verts[idx] = x / Math.max(1f, width) * 2f - 1f;
            verts[idx + 1] = 1f - y / Math.max(1f, height) * 2f;
        }

        private void drawColorVertices(float[] verts, int mode, float r, float g, float b, float a) {
            GLES20.glUseProgram(colorProgram);
            int aPos = GLES20.glGetAttribLocation(colorProgram, "aPosition");
            int uColor = GLES20.glGetUniformLocation(colorProgram, "uColor");
            FloatBuffer buf = makeFloatBuffer(verts);
            GLES20.glEnableVertexAttribArray(aPos);
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, buf);
            GLES20.glUniform4f(uColor, r, g, b, clamp(a, 0f, 1f));
            GLES20.glDrawArrays(mode, 0, verts.length / 2);
            GLES20.glDisableVertexAttribArray(aPos);
        }

        private void drawTexture(int textureId, float fade) {
            float[] verts = new float[]{
                    -1f, -1f, 0f, 0f,
                     1f, -1f, 1f, 0f,
                    -1f,  1f, 0f, 1f,
                     1f,  1f, 1f, 1f
            };
            GLES20.glUseProgram(textureProgram);
            int aPos = GLES20.glGetAttribLocation(textureProgram, "aPosition");
            int aTex = GLES20.glGetAttribLocation(textureProgram, "aTexCoord");
            int uTex = GLES20.glGetUniformLocation(textureProgram, "uTexture");
            int uFade = GLES20.glGetUniformLocation(textureProgram, "uFade");
            FloatBuffer buf = makeFloatBuffer(verts);
            buf.position(0);
            GLES20.glEnableVertexAttribArray(aPos);
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, buf);
            buf.position(2);
            GLES20.glEnableVertexAttribArray(aTex);
            GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, buf);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
            GLES20.glUniform1i(uTex, 0);
            GLES20.glUniform1f(uFade, fade);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            GLES20.glDisableVertexAttribArray(aPos);
            GLES20.glDisableVertexAttribArray(aTex);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
        }

        private int createProgram(String vs, String fs) {
            int v = compileShader(GLES20.GL_VERTEX_SHADER, vs);
            int f = compileShader(GLES20.GL_FRAGMENT_SHADER, fs);
            int p = GLES20.glCreateProgram();
            GLES20.glAttachShader(p, v);
            GLES20.glAttachShader(p, f);
            GLES20.glLinkProgram(p);
            int[] ok = new int[1];
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
            GLES20.glDeleteShader(v);
            GLES20.glDeleteShader(f);
            if (ok[0] == 0) {
                GLES20.glDeleteProgram(p);
                return 0;
            }
            return p;
        }

        private int compileShader(int type, String source) {
            int s = GLES20.glCreateShader(type);
            GLES20.glShaderSource(s, source);
            GLES20.glCompileShader(s);
            int[] ok = new int[1];
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
            if (ok[0] == 0) {
                GLES20.glDeleteShader(s);
                return 0;
            }
            return s;
        }

        private FloatBuffer makeFloatBuffer(float[] data) {
            ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 4);
            bb.order(ByteOrder.nativeOrder());
            FloatBuffer fb = bb.asFloatBuffer();
            fb.put(data);
            fb.position(0);
            return fb;
        }

        private void deleteFbos() {
            if (fbo[0] != 0 || fbo[1] != 0) GLES20.glDeleteFramebuffers(2, fbo, 0);
            if (tex[0] != 0 || tex[1] != 0) GLES20.glDeleteTextures(2, tex, 0);
            fbo[0] = fbo[1] = tex[0] = tex[1] = 0;
            fboReady = false;
        }

        private void releaseGl() {
            try {
                deleteFbos();
                if (textureProgram != 0) GLES20.glDeleteProgram(textureProgram);
                if (colorProgram != 0) GLES20.glDeleteProgram(colorProgram);
                if (egl != null && eglDisplay != null) {
                    egl.eglMakeCurrent(eglDisplay, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                    if (eglSurface != null && eglSurface != EGL10.EGL_NO_SURFACE) egl.eglDestroySurface(eglDisplay, eglSurface);
                    if (eglContext != null && eglContext != EGL10.EGL_NO_CONTEXT) egl.eglDestroyContext(eglDisplay, eglContext);
                    egl.eglTerminate(eglDisplay);
                }
            } catch (Throwable ignored) {}
        }

        private void ensureCycleState(boolean force) {
            long wallNow = System.currentTimeMillis();
            String sig = cycleConfigSignature();
            long savedStart = prefs.getLong("cycleStartWallMs", 0L);
            float savedDuration = prefs.getFloat("cycleDurationSec", 0f);
            String savedSig = prefs.getString("cycleConfigSignature", "");
            boolean missing = savedStart <= 0L || savedDuration <= 0f;
            boolean configChanged = !sig.equals(savedSig);
            boolean completed = !missing && wallNow - savedStart >= (long)(savedDuration * 1000f);
            if (force || missing || configChanged || completed) {
                beginNewCycle(wallNow);
            } else {
                cycleStartWallMs = savedStart;
                cycleDurationSec = savedDuration;
                cycleCriticalStartSec = prefs.getFloat("cycleCriticalStartSec", 0f);
                cycleReleaseStartSec = prefs.getFloat("cycleReleaseStartSec", Math.max(0f, savedDuration - 60f));
                cycleReleaseDurationSec = prefs.getFloat("cycleReleaseDurationSec", 12f);
                cycleAfterglowDurationSec = prefs.getFloat("cycleAfterglowDurationSec", 24f);
                cycleCriticalDurationSec = prefs.getFloat("cycleCriticalDurationSec", 60f);
                cycleSignature = savedSig;
            }
        }

        private void beginNewCycle(long wallNow) {
            cycleStartWallMs = wallNow;
            cycleDurationSec = chooseCycleDurationSec();
            cycleSignature = cycleConfigSignature();
            CyclePlan plan = randomPlanForDuration(cycleDurationSec);
            cycleCriticalStartSec = plan.criticalStartSec;
            cycleReleaseStartSec = plan.releaseStartSec;
            cycleReleaseDurationSec = plan.releaseDurationSec;
            cycleAfterglowDurationSec = plan.afterglowDurationSec;
            cycleCriticalDurationSec = plan.criticalDurationSec;
            prefs.edit()
                    .putLong("cycleStartWallMs", cycleStartWallMs)
                    .putFloat("cycleDurationSec", cycleDurationSec)
                    .putFloat("cycleCriticalStartSec", cycleCriticalStartSec)
                    .putFloat("cycleReleaseStartSec", cycleReleaseStartSec)
                    .putFloat("cycleReleaseDurationSec", cycleReleaseDurationSec)
                    .putFloat("cycleAfterglowDurationSec", cycleAfterglowDurationSec)
                    .putFloat("cycleCriticalDurationSec", cycleCriticalDurationSec)
                    .putString("cycleConfigSignature", cycleSignature)
                    .apply();
            startMs = SystemClock.elapsedRealtime();
            nextSpawnSec = 0f;
            nextHardClearSec = 6f + random.nextFloat() * 12f;
            lastVisualSec = -1f;
            releasePulseArmed = true;
            releaseSeed = random.nextInt();
            strokes.clear();
            resetSpawnHeat();
            clearFbos();
        }

        private void clearFbos() {
            if (!fboReady) return;
            for (int i = 0; i < 2; i++) {
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[i]);
                GLES20.glClearColor(0f, 0f, 0f, 1f);
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            }
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
        }

        private float currentCycleElapsedSec() {
            if (cycleStartWallMs <= 0L) return (SystemClock.elapsedRealtime() - startMs) / 1000f;
            return Math.max(0f, (System.currentTimeMillis() - cycleStartWallMs) / 1000f);
        }

        private CyclePlan storedCyclePlan(float durationSec) {
            CyclePlan p = new CyclePlan();
            p.durationSec = durationSec;
            p.criticalStartSec = cycleCriticalStartSec;
            p.releaseStartSec = cycleReleaseStartSec;
            p.releaseDurationSec = cycleReleaseDurationSec;
            p.afterglowDurationSec = cycleAfterglowDurationSec;
            p.criticalDurationSec = cycleCriticalDurationSec;
            return p.sanitized();
        }

        private CyclePlan previewPlan(float durationSec) {
            // 预览模式仍遵守“只出现一次释放/余韵”，但把真实天级周期压缩到几分钟。
            CyclePlan p = new CyclePlan();
            p.durationSec = durationSec;
            float seedLike = stable01("preview-release");
            p.releaseDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioRelease, cfg.releaseMinSec, cfg.releaseMaxSec, false);
            p.afterglowDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioAfterglow, cfg.afterglowMinSec, cfg.afterglowMaxSec, false);
            p.criticalDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioCritical, cfg.criticalMinSec, cfg.criticalMaxSec, false);
            float latest = Math.max(1f, durationSec - p.releaseDurationSec - p.afterglowDurationSec - 1f);
            float earliest = Math.min(latest, Math.max(1f, durationSec * 0.34f));
            p.releaseStartSec = earliest + (latest - earliest) * seedLike;
            p.criticalStartSec = Math.max(0f, p.releaseStartSec - p.criticalDurationSec);
            return p.sanitized();
        }

        private CyclePlan randomPlanForDuration(float durationSec) {
            CyclePlan p = new CyclePlan();
            p.durationSec = durationSec;
            p.releaseDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioRelease, cfg.releaseMinSec, cfg.releaseMaxSec, true);
            p.afterglowDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioAfterglow, cfg.afterglowMinSec, cfg.afterglowMaxSec, true);
            p.criticalDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioCritical, cfg.criticalMinSec, cfg.criticalMaxSec, true);
            float minPre = Math.max(60f, Math.min(3600f, durationSec * 0.035f));
            float latest = Math.max(minPre, durationSec - p.releaseDurationSec - p.afterglowDurationSec - 60f);
            p.releaseStartSec = minPre + random.nextFloat() * Math.max(0f, latest - minPre);
            p.criticalStartSec = Math.max(0f, p.releaseStartSec - p.criticalDurationSec);
            return p.sanitized();
        }

        private float durationFromRatioAndRange(float totalSec, float ratio, float minSec, float maxSec, boolean randomize) {
            float min = Math.min(minSec, maxSec);
            float max = Math.max(minSec, maxSec);
            // 阶段比例给出该阶段在本轮周期中的目标长度；用户设置的秒级范围是硬边界。
            // 如果目标超出范围，就被钳制到范围内，因此“短阶段持续时间范围”一定真实生效。
            // 若目标位于范围内，随机项只做轻微扰动，避免每轮完全机械一致。
            float target = clamp(totalSec * Math.max(0.0001f, ratio), min, max);
            float jitter = randomize ? randRange(min, max) : stableRange(min, max, "dur-" + Math.round(totalSec) + ":" + Math.round(ratio * 10000f));
            return clamp(lerp(target, jitter, 0.22f), min, max);
        }

        private float stableRange(float a, float b, String salt) {
            float min = Math.min(a, b);
            float max = Math.max(a, b);
            return min + stable01(salt) * Math.max(0f, max - min);
        }

        private float stable01(String salt) {
            int h = (cycleSignature + ":" + salt).hashCode();
            long v = h & 0x7fffffffL;
            return (v % 1000000L) / 1000000f;
        }

        private float randRange(float a, float b) {
            float min = Math.min(a, b);
            float max = Math.max(a, b);
            return min + random.nextFloat() * Math.max(0f, max - min);
        }

        private float chooseCycleDurationSec() {
            float minDays = clamp(cfg.cycleMinDays, 1f, 365f);
            float maxDays = clamp(cfg.cycleMaxDays, minDays, 365f);
            float days;
            if (cfg.randomCycle) days = minDays + random.nextFloat() * Math.max(0f, maxDays - minDays);
            else days = clamp(cfg.fixedCycleDays, minDays, maxDays);
            return Math.max(86400f, days * 86400f);
        }

        private String cycleConfigSignature() {
            return cfg.randomCycle + ":" + Math.round(cfg.cycleMinDays * 10f) + ":" + Math.round(cfg.cycleMaxDays * 10f)
                    + ":" + Math.round(cfg.fixedCycleDays * 10f) + ":" + Math.round(cfg.ratioSeparation * 1000f)
                    + ":" + Math.round(cfg.ratioAttraction * 1000f) + ":" + Math.round(cfg.ratioSync * 1000f)
                    + ":" + Math.round(cfg.ratioCritical * 1000f) + ":" + Math.round(cfg.ratioRelease * 1000f)
                    + ":" + Math.round(cfg.ratioAfterglow * 1000f) + ":" + Math.round(cfg.criticalMinSec) + ":" + Math.round(cfg.criticalMaxSec)
                    + ":" + Math.round(cfg.releaseMinSec) + ":" + Math.round(cfg.releaseMaxSec)
                    + ":" + Math.round(cfg.afterglowMinSec) + ":" + Math.round(cfg.afterglowMaxSec);
        }

        private void readConfig(boolean force) {
            long now = SystemClock.elapsedRealtime();
            if (!force && !configDirty && now - lastConfigRead < 500L) return;
            lastConfigRead = now;
            configDirty = false;
            String oldVisualSignature = visualConfigSignature;
            cfg.style = prefs.getInt("style", 0);
            cfg.intimacy = prefs.getFloat("intimacy", 0.72f);
            cfg.randomness = prefs.getFloat("randomness", 0.66f);
            cfg.ribbonWidth = prefs.getFloat("ribbonWidth", 0.62f);
            cfg.trail = prefs.getFloat("trail", 0.90f);
            cfg.fullScreenCoverage = prefs.getFloat("fullScreenCoverage", 0.96f);
            cfg.strokeDensity = prefs.getFloat("strokeDensity", 0.24f);
            cfg.previewAccelerated = prefs.getBoolean("previewAccelerated", false);
            cfg.previewCycleMinutes = clamp(prefs.getFloat("previewCycleMinutes", 3f), 0.5f, 60f);
            cfg.debugLoopEnabled = prefs.getBoolean("debugLoopEnabled", false);
            cfg.debugCycleMinutes = clamp(prefs.getFloat("debugCycleMinutes", 3f), 1f, 60f);
            cfg.bubbles = prefs.getBoolean("bubbles", true);
            cfg.powerSave = prefs.getBoolean("powerSave", false);
            cfg.cycleMinDays = clamp(prefs.getFloat("cycleMinDays", 1f), 1f, 365f);
            cfg.cycleMaxDays = clamp(prefs.getFloat("cycleMaxDays", 365f), cfg.cycleMinDays, 365f);
            cfg.fixedCycleDays = clamp(prefs.getFloat("fixedCycleDays", 30f), cfg.cycleMinDays, cfg.cycleMaxDays);
            cfg.randomCycle = prefs.getBoolean("randomCycle", true);
            cfg.ratioSeparation = prefs.getFloat("ratioSeparation", 0.46f);
            cfg.ratioAttraction = prefs.getFloat("ratioAttraction", 0.22f);
            cfg.ratioSync = prefs.getFloat("ratioSync", 0.22f);
            cfg.ratioCritical = prefs.getFloat("ratioCritical", 0.06f);
            cfg.ratioRelease = prefs.getFloat("ratioRelease", 0.02f);
            cfg.ratioAfterglow = prefs.getFloat("ratioAfterglow", 0.02f);
            cfg.criticalMinSec = clamp(prefs.getFloat("criticalMinSec", 30f), 5f, 3600f);
            cfg.criticalMaxSec = clamp(prefs.getFloat("criticalMaxSec", 180f), cfg.criticalMinSec, 7200f);
            cfg.releaseMinSec = clamp(prefs.getFloat("releaseMinSec", 8f), 2f, 600f);
            cfg.releaseMaxSec = clamp(prefs.getFloat("releaseMaxSec", 24f), cfg.releaseMinSec, 1200f);
            cfg.afterglowMinSec = clamp(prefs.getFloat("afterglowMinSec", 20f), 3f, 1800f);
            cfg.afterglowMaxSec = clamp(prefs.getFloat("afterglowMaxSec", 90f), cfg.afterglowMinSec, 3600f);
            normalizeRatios(cfg);
            visualConfigSignature = buildVisualConfigSignature();
            if (force || !visualConfigSignature.equals(oldVisualSignature)) {
                strokes.clear();
                resetSpawnHeat();
                nextSpawnSec = 0f;
                nextHardClearSec = 6f + random.nextFloat() * 12f;
                startMs = SystemClock.elapsedRealtime();
                lastVisualSec = -1f;
                releasePulseArmed = true;
                if (fboReady) clearFbos();
            }
            ensureCycleState(force);
        }

        private String buildVisualConfigSignature() {
            return cfg.style + ":" + Math.round(cfg.intimacy * 1000f)
                    + ":" + Math.round(cfg.randomness * 1000f)
                    + ":" + Math.round(cfg.ribbonWidth * 1000f)
                    + ":" + Math.round(cfg.trail * 1000f)
                    + ":" + Math.round(cfg.fullScreenCoverage * 1000f)
                    + ":" + Math.round(cfg.strokeDensity * 1000f)
                    + ":" + cfg.debugLoopEnabled + ":" + Math.round(cfg.debugCycleMinutes * 1000f)
                    + ":" + cfg.bubbles + ":" + cfg.powerSave;
        }

        private void normalizeRatios(Config c) {
            c.ratioSeparation = Math.max(0.01f, c.ratioSeparation);
            c.ratioAttraction = Math.max(0.01f, c.ratioAttraction);
            c.ratioSync = Math.max(0.01f, c.ratioSync);
            c.ratioCritical = Math.max(0.005f, c.ratioCritical);
            c.ratioRelease = Math.max(0.002f, c.ratioRelease);
            c.ratioAfterglow = Math.max(0.002f, c.ratioAfterglow);
            float sum = c.ratioSeparation + c.ratioAttraction + c.ratioSync + c.ratioCritical + c.ratioRelease + c.ratioAfterglow;
            if (sum <= 0f) {
                c.ratioSeparation = 0.46f; c.ratioAttraction = 0.22f; c.ratioSync = 0.22f;
                c.ratioCritical = 0.06f; c.ratioRelease = 0.02f; c.ratioAfterglow = 0.02f;
                return;
            }
            c.ratioSeparation /= sum;
            c.ratioAttraction /= sum;
            c.ratioSync /= sum;
            c.ratioCritical /= sum;
            c.ratioRelease /= sum;
            c.ratioAfterglow /= sum;
        }

        private int[] palette(int style) {
            switch (Math.floorMod(style, 5)) {
                case 1: return new int[]{0xFF34D399, 0xFF67E8F9, 0xFF93C5FD, 0xFFFDE68A, 0xFF020617};
                case 2: return new int[]{0xFFA78BFA, 0xFFD8B4FE, 0xFFF472B6, 0xFFFFFFFF, 0xFF050316};
                case 3: return new int[]{0xFFE5E7EB, 0xFFFFFFFF, 0xFF93C5FD, 0xFFD1D5DB, 0xFF000000};
                case 4: return new int[]{0xFFFDE68A, 0xFFFFF7ED, 0xFFFB7185, 0xFFF97316, 0xFF06030A};
                default: return new int[]{0xFF7DD3FC, 0xFFC4B5FD, 0xFFF472B6, 0xFFFDE68A, 0xFF030712};
            }
        }

        private int pickColor(int[] colors) { return colors[random.nextInt(4)]; }
        private static float catmull(float p0, float p1, float p2, float p3, float t) {
            float t2 = t * t;
            float t3 = t2 * t;
            return 0.5f * ((2f * p1) + (-p0 + p2) * t + (2f*p0 - 5f*p1 + 4f*p2 - p3) * t2 + (-p0 + 3f*p1 - 3f*p2 + p3) * t3);
        }
        private float distance(float x0, float y0, float x1, float y1) {
            float dx = x1 - x0, dy = y1 - y0;
            return (float)Math.sqrt(dx * dx + dy * dy);
        }
        private float[] color4(int color, float alpha) {
            return new float[]{Color.red(color)/255f, Color.green(color)/255f, Color.blue(color)/255f, clamp(alpha, 0f, 1f)};
        }
        private static int clampInt(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }
        private static float clamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }
        private static float fract(float v) { return v - (float)Math.floor(v); }
        private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
        private static float smooth(float x) { x = clamp(x, 0f, 1f); return x * x * (3f - 2f * x); }
        private static void sleepQuiet(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }

        private static final String TEXTURE_VERTEX =
                "attribute vec2 aPosition;\n" +
                "attribute vec2 aTexCoord;\n" +
                "varying vec2 vTexCoord;\n" +
                "void main(){ gl_Position = vec4(aPosition, 0.0, 1.0); vTexCoord = aTexCoord; }";
        private static final String TEXTURE_FRAGMENT =
                "precision mediump float;\n" +
                "uniform sampler2D uTexture;\n" +
                "uniform float uFade;\n" +
                "varying vec2 vTexCoord;\n" +
                // V29 phosphor decay：不是简单乘 fade，而是每帧轻微扣黑，
                // 让尾迹像参考视频那样先失彩、再变细、最后被黑场吞没。
                "void main(){ vec4 c = texture2D(uTexture, vTexCoord); vec3 rgb = max(c.rgb * uFade - vec3(0.00235), vec3(0.0)); rgb = pow(rgb, vec3(1.010)); gl_FragColor = vec4(rgb, 1.0); }";
        private static final String COLOR_VERTEX =
                "attribute vec2 aPosition;\n" +
                "void main(){ gl_Position = vec4(aPosition, 0.0, 1.0); }";
        private static final String COLOR_FRAGMENT =
                "precision mediump float;\n" +
                "uniform vec4 uColor;\n" +
                "void main(){ gl_FragColor = uColor; }";
    }

    static final class StrokeEvent {
        final int count;
        final float[] x, y, vx, vy;
        RectF bounds = new RectF();
        StrokeEvent partner;
        float age = 0f;
        float life = 3f;
        float seed = 0f;
        float widthScale = 1f;
        float speed = 80f;
        float turn = 0.4f;
        float relation = 0f;
        float visibleWindow = 0.26f;
        float headLead = 0.10f;
        float attractX = 0f;
        float attractY = 0f;
        int colorA = Color.WHITE;
        int colorB = Color.WHITE;
        int actor = 0;
        // V29 art motif: 0 comet arc, 1 veil ribbon, 2 electronic fan, 3 silver blade,
        // 4 petal hook, 5 prism polygon, 6 falling leaf, 7 long bridge,
        // 8 jellyfish tendril, 9 nebula coil, 10 origami sheet, 11 constellation chain,
        // 12 liquid pod, 13 wing, 14 blossom, 15 silk banner, 16 orbit halo, 17 crystal shard.
        int motif = 0;
        int variant = 0;
        float motifStrength = 1f;
        float flowA = 1f;
        float flowB = 1f;
        float flowC = 1f;
        float asymmetry = 0f;
        boolean fan = false;
        int fanLines = 0;
        float fanGapPx = 3f;

        StrokeEvent(int count) {
            this.count = Math.max(2, count);
            x = new float[this.count]; y = new float[this.count];
            vx = new float[this.count]; vy = new float[this.count];
        }
    }

    static final class Config {
        int style = 0;
        float intimacy = 0.72f;
        float randomness = 0.66f;
        float ribbonWidth = 0.62f;
        float trail = 0.90f;
        float fullScreenCoverage = 0.96f;
        float strokeDensity = 0.24f;
        boolean previewAccelerated = false;
        float previewCycleMinutes = 3f;
        boolean debugLoopEnabled = false;
        float debugCycleMinutes = 3f;
        boolean bubbles = false;
        boolean powerSave = false;
        boolean randomCycle = true;
        float cycleMinDays = 1f;
        float cycleMaxDays = 365f;
        float fixedCycleDays = 30f;
        float ratioSeparation = 0.46f;
        float ratioAttraction = 0.22f;
        float ratioSync = 0.22f;
        float ratioCritical = 0.06f;
        float ratioRelease = 0.02f;
        float ratioAfterglow = 0.02f;
        float criticalMinSec = 30f;
        float criticalMaxSec = 180f;
        float releaseMinSec = 8f;
        float releaseMaxSec = 24f;
        float afterglowMinSec = 20f;
        float afterglowMaxSec = 90f;
    }

    static final class CyclePlan {
        float durationSec = 86400f;
        float criticalStartSec = 0f;
        float releaseStartSec = 3600f;
        float releaseDurationSec = 12f;
        float afterglowDurationSec = 24f;
        float criticalDurationSec = 60f;
        private static float cpClamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }
        CyclePlan sanitized() {
            durationSec = Math.max(30f, durationSec);
            releaseDurationSec = cpClamp(releaseDurationSec, 1f, Math.max(1f, durationSec * 0.20f));
            afterglowDurationSec = cpClamp(afterglowDurationSec, 1f, Math.max(1f, durationSec * 0.20f));
            criticalDurationSec = cpClamp(criticalDurationSec, 1f, Math.max(1f, durationSec * 0.35f));
            releaseStartSec = cpClamp(releaseStartSec, 1f, Math.max(1f, durationSec - releaseDurationSec - afterglowDurationSec));
            criticalStartSec = cpClamp(releaseStartSec - criticalDurationSec, 0f, releaseStartSec);
            return this;
        }
    }

    static final class Phase {
        final String name;
        final float start, end, intensity, closeness, tension, relation, pairChance, fanChance;
        Phase(String name, float start, float end, float intensity, float closeness, float tension, float relation, float pairChance, float fanChance) {
            this.name = name;
            this.start = start;
            this.end = end;
            this.intensity = intensity;
            this.closeness = closeness;
            this.tension = tension;
            this.relation = relation;
            this.pairChance = pairChance;
            this.fanChance = fanChance;
        }
        static Phase of(float sec, float durationSec, Config cfg, CyclePlan plan) {
            float releaseStart = plan.releaseStartSec;
            float releaseEnd = releaseStart + plan.releaseDurationSec;
            float afterEnd = releaseEnd + plan.afterglowDurationSec;
            float criticalStart = plan.criticalStartSec;

            if (sec >= releaseStart && sec < releaseEnd) {
                return new Phase("释放", releaseStart, releaseEnd, 1.00f, 1.00f, 0.46f, 1.00f, 0.04f, 0.006f);
            }
            if (sec >= releaseEnd && sec < afterEnd) {
                return new Phase("余韵", releaseEnd, afterEnd, 0.22f, 0.54f, 0.08f, 0.12f, 0.02f, 0.004f);
            }
            if (sec >= criticalStart && sec < releaseStart) {
                return new Phase("临界", criticalStart, releaseStart, 0.96f, 0.92f, 1.00f, 0.92f, 0.16f, 0.025f);
            }
            if (sec >= afterEnd) {
                return new Phase("分离", afterEnd, durationSec, 0.08f, 0.00f, 0.04f, 0.00f, 0.00f, 0.004f);
            }

            float pre = Math.max(1f, criticalStart);
            float sum = Math.max(0.001f, cfg.ratioSeparation + cfg.ratioAttraction + cfg.ratioSync);
            float sepDur = pre * (cfg.ratioSeparation / sum);
            float attrDur = pre * (cfg.ratioAttraction / sum);
            float syncDur = Math.max(0f, pre - sepDur - attrDur);
            float sepEnd = sepDur;
            float attrEnd = sepEnd + attrDur;
            float syncEnd = attrEnd + syncDur;
            if (sec < sepEnd) return new Phase("分离", 0f, sepEnd, 0.08f, 0.00f, 0.04f, 0.00f, 0.00f, 0.004f);
            if (sec < attrEnd) return new Phase("吸引", sepEnd, attrEnd, 0.24f, 0.16f, 0.16f, 0.06f, 0.010f, 0.004f);
            return new Phase("同步", attrEnd, Math.max(attrEnd + 0.001f, syncEnd), 0.56f, 0.58f, 0.52f, 0.58f, 0.11f, 0.010f);
        }
    }
}
