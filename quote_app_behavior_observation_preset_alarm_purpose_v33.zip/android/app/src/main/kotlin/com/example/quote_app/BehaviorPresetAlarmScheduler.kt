package com.example.quote_app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

object BehaviorPresetAlarmScheduler {
  @JvmStatic
  fun scheduleNextAfterFire(ctx: Context, rawPayload: String?) {
    try {
      val obj = JSONObject(rawPayload ?: "{}")
      val presetId = obj.optInt("presetId", 0)
      val hour = obj.optInt("reminderHour", 21).coerceIn(0, 23)
      val minute = obj.optInt("reminderMinute", 0).coerceIn(0, 59)
      val weekdays = parseWeekdays(obj.opt("weekdays"))
      val start = Calendar.getInstance()
      start.timeInMillis = obj.optLong("checkDateMs", System.currentTimeMillis())
      start.add(Calendar.DAY_OF_YEAR, 1)
      start.set(Calendar.HOUR_OF_DAY, hour)
      start.set(Calendar.MINUTE, minute)
      start.set(Calendar.SECOND, 0)
      start.set(Calendar.MILLISECOND, 0)
      for (i in 0..31) {
        val c = start.clone() as Calendar
        c.add(Calendar.DAY_OF_YEAR, i)
        val weekday = javaWeekdayToDart(c.get(Calendar.DAY_OF_WEEK))
        if (weekdays.isNotEmpty() && !weekdays.contains(weekday)) continue
        if (c.timeInMillis <= System.currentTimeMillis() + 20_000L) continue
        val dayStart = c.clone() as Calendar
        dayStart.set(Calendar.HOUR_OF_DAY, 0)
        dayStart.set(Calendar.MINUTE, 0)
        dayStart.set(Calendar.SECOND, 0)
        dayStart.set(Calendar.MILLISECOND, 0)
        obj.put("checkDateMs", dayStart.timeInMillis)
        val id = if (presetId > 0) presetAlarmId(presetId, dayStart) else setupAlarmId(dayStart)
        obj.put("alarmId", id)
        if (presetId <= 0) {
          obj.put("type", "behavior_preset_setup_alarm")
          obj.put("setupRequired", true)
        }
        NativeSchedulerK.scheduleExactAt(ctx.applicationContext, id, c.timeInMillis, obj.toString())
        return
      }
    } catch (t: Throwable) {
      try { com.example.quote_app.data.DbRepo.log(ctx, null, "[BehaviorPresetAlarm] schedule next failed: ${t.javaClass.simpleName} ${t.message}") } catch (_: Throwable) {}
    }
  }

  private fun parseWeekdays(raw: Any?): Set<Int> {
    val result = LinkedHashSet<Int>()
    try {
      val arr = when (raw) {
        is JSONArray -> raw
        is String -> if (raw.trim().startsWith("[")) JSONArray(raw) else JSONArray()
        else -> JSONArray()
      }
      for (i in 0 until arr.length()) {
        val v = arr.optInt(i, 0)
        if (v in 1..7) result.add(v)
      }
    } catch (_: Throwable) {}
    return result
  }

  private fun javaWeekdayToDart(javaDay: Int): Int = when (javaDay) {
    Calendar.MONDAY -> 1
    Calendar.TUESDAY -> 2
    Calendar.WEDNESDAY -> 3
    Calendar.THURSDAY -> 4
    Calendar.FRIDAY -> 5
    Calendar.SATURDAY -> 6
    Calendar.SUNDAY -> 7
    else -> 1
  }

  private fun presetAlarmId(presetId: Int, dayStart: Calendar): Int {
    val base = Calendar.getInstance().apply {
      set(2020, Calendar.JANUARY, 1, 0, 0, 0)
      set(Calendar.MILLISECOND, 0)
    }
    val dayNo = ((dayStart.timeInMillis - base.timeInMillis) / 86_400_000L).toInt()
    return 97000000 + ((presetId * 1000 + dayNo) % 900000)
  }

  private fun setupAlarmId(dayStart: Calendar): Int {
    val base = Calendar.getInstance().apply {
      set(2020, Calendar.JANUARY, 1, 0, 0, 0)
      set(Calendar.MILLISECOND, 0)
    }
    val dayNo = ((dayStart.timeInMillis - base.timeInMillis) / 86_400_000L).toInt()
    return 96500000 + (dayNo % 400000)
  }
}
