package com.example.quote_app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.InputType
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * V33：预设行为闹钟的语义调整。
 *
 * 闹钟不是让用户“立刻完成预设行为”，而是：
 * 1）当天没有预设行为时，强制督促用户先完成行为预设；
 * 2）当天已有预设行为时，只要求用户确认已收到/查看预设提醒。
 *
 * 如果当天没有预设行为而用户不填写预设，不能直接跳过；关闭或稍后会 5 分钟后再次提醒。
 */
class BehaviorPresetAlarmFormActivity : Activity() {
  private var payload = JSONObject()
  private var setupRequiredMode = false
  private lateinit var presetNameInput: EditText
  private lateinit var presetCategoryInput: EditText
  private lateinit var presetDurationInput: EditText
  private lateinit var presetNotesInput: EditText
  private var mediaPlayer: MediaPlayer? = null
  private var vibrator: Vibrator? = null

  override fun onCreate(savedInstanceState: Bundle?) {
    requestWindowFeature(Window.FEATURE_NO_TITLE)
    super.onCreate(savedInstanceState)
    if (Build.VERSION.SDK_INT >= 27) {
      setShowWhenLocked(true)
      setTurnScreenOn(true)
    } else {
      @Suppress("DEPRECATION")
      window.addFlags(
        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
          WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
          WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
      )
    }
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    try { payload = JSONObject(intent?.getStringExtra("payload") ?: "{}") } catch (_: Throwable) {}
    setupRequiredMode = shouldRequirePresetSetup()
    startAlarmSignal()
    if (setupRequiredMode) buildPresetSetupUi() else buildPresetAckUi()
  }

  override fun onBackPressed() {
    if (setupRequiredMode) {
      snoozeFiveMinutes("用户返回，仍未完成行为预设")
      Toast.makeText(this, "还没有完成行为预设，5 分钟后会再次提醒", Toast.LENGTH_LONG).show()
      finish()
    } else {
      super.onBackPressed()
    }
  }

  override fun onDestroy() {
    stopAlarmSignal()
    super.onDestroy()
  }

  private fun shouldRequirePresetSetup(): Boolean {
    val presetId = payload.optInt("presetId", 0)
    val explicitSetup = payload.optString("type", "") == "behavior_preset_setup_alarm" || payload.optBoolean("setupRequired", false)
    val dayMs = dayStartMs(payload.optLong("checkDateMs", System.currentTimeMillis()))
    val todayCount = countActivePresetsForDay(dayMs)
    return explicitSetup || presetId <= 0 || todayCount <= 0
  }

  private fun startAlarmSignal() {
    try {
      val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
      if (alarmUri != null) {
        mediaPlayer = MediaPlayer().apply {
          setDataSource(this@BehaviorPresetAlarmFormActivity, alarmUri)
          if (Build.VERSION.SDK_INT >= 21) {
            setAudioAttributes(
              AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            )
          } else {
            @Suppress("DEPRECATION")
            setAudioStreamType(AudioManager.STREAM_ALARM)
          }
          isLooping = true
          prepare()
          start()
        }
      }
    } catch (t: Throwable) {
      try { com.example.quote_app.data.DbRepo.log(this, null, "[BehaviorPresetAlarm] play alarm sound failed: ${t.javaClass.simpleName} ${t.message}") } catch (_: Throwable) {}
    }

    if (!payload.optBoolean("alarmVibrate", true)) return
    try {
      vibrator = if (Build.VERSION.SDK_INT >= 31) {
        (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
      } else {
        @Suppress("DEPRECATION")
        getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
      }
      val pattern = longArrayOf(0L, 800L, 450L, 800L, 450L)
      if (Build.VERSION.SDK_INT >= 26) vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
      else {
        @Suppress("DEPRECATION")
        vibrator?.vibrate(pattern, 0)
      }
    } catch (t: Throwable) {
      try { com.example.quote_app.data.DbRepo.log(this, null, "[BehaviorPresetAlarm] vibrate failed: ${t.javaClass.simpleName} ${t.message}") } catch (_: Throwable) {}
    }
  }

  private fun stopAlarmSignal() {
    try {
      mediaPlayer?.let { player ->
        try { if (player.isPlaying) player.stop() } catch (_: Throwable) {}
        try { player.release() } catch (_: Throwable) {}
      }
    } catch (_: Throwable) {}
    mediaPlayer = null
    try { vibrator?.cancel() } catch (_: Throwable) {}
    vibrator = null
  }

  private fun buildPresetSetupUi() {
    val root = baseRoot()
    root.addView(title("请先完成行为预设"))
    root.addView(desc("这个闹钟不是要求你现在完成某个行为，而是提醒你先把今天要观察/确认的固定行为预设好。当天没有预设行为时不能直接跳过；如果暂不填写，5 分钟后会再次响铃提醒。"))

    presetNameInput = edit("预设行为名称（必填）", "例如：阅读 20 分钟 / 睡前复盘 / 运动", InputType.TYPE_CLASS_TEXT)
    root.addView(presetNameInput)
    presetCategoryInput = edit("类别", "默认：工作/学习，也可写健康、休息、自律等", InputType.TYPE_CLASS_TEXT)
    root.addView(presetCategoryInput)
    presetDurationInput = edit("计划时长（分钟，可选）", "例如 20", InputType.TYPE_CLASS_NUMBER)
    root.addView(presetDurationInput)
    presetNotesInput = edit("备注（可选）", "例如：每天提醒我确认一次", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE, 3)
    root.addView(presetNotesInput)

    root.addView(primaryButton("保存预设并停止闹钟") { savePresetDefinition() })
    root.addView(secondaryText("现在不方便，5 分钟后再次提醒") {
      snoozeFiveMinutes("用户暂不填写预设")
      Toast.makeText(this, "5 分钟后会再次提醒你完成行为预设", Toast.LENGTH_LONG).show()
      finish()
    })
    setContentView(ScrollView(this).apply { addView(root) })
  }

  private fun buildPresetAckUi() {
    val presetName = payload.optString("presetName", "今天的预设行为")
    val category = payload.optString("category", "未分类")
    val unit = payload.optString("unit", "次")
    val target = payload.opt("targetValue")?.toString()?.takeIf { it != "null" }.orEmpty()
    val duration = payload.optInt("defaultDurationMin", 0).takeIf { it > 0 }?.toString().orEmpty()
    val root = baseRoot()
    root.addView(title("预设提醒"))
    root.addView(desc("这是提醒你查看或确认今天的预设，不是要求你现在完成这个行为。实际完成情况仍可在“预设”页的每日确认清单中处理。"))
    root.addView(card("预设", presetName))
    root.addView(card("类别", category))
    val goalText = listOf(
      if (target.isNotBlank()) "$target$unit" else "无固定量",
      if (duration.isNotBlank()) "默认 ${duration}分钟" else null
    ).filterNotNull().joinToString(" · ")
    root.addView(card("计划", goalText))
    root.addView(primaryButton("我已收到预设提醒") { acknowledgePresetReminder() })
    root.addView(secondaryText("5 分钟后再提醒") {
      snoozeFiveMinutes("用户选择稍后再提醒")
      Toast.makeText(this, "5 分钟后会再次提醒", Toast.LENGTH_SHORT).show()
      finish()
    })
    setContentView(ScrollView(this).apply { addView(root) })
  }

  private fun savePresetDefinition() {
    val name = presetNameInput.text?.toString()?.trim().orEmpty()
    if (name.isBlank()) {
      Toast.makeText(this, "请先填写预设行为名称，不能跳过预设", Toast.LENGTH_LONG).show()
      return
    }
    val category = presetCategoryInput.text?.toString()?.trim().ifBlank { "工作/学习" }
    val duration = presetDurationInput.text?.toString()?.trim()
    val note = presetNotesInput.text?.toString()?.trim().orEmpty()
    val id = BehaviorObservationNativeRecorder.savePresetDefinitionFromAlarm(
      this,
      name,
      category,
      duration,
      note,
      payload.optInt("reminderHour", 21),
      payload.optInt("reminderMinute", 0),
      payload.optBoolean("alarmVibrate", true)
    )
    if (id > 0L) {
      Toast.makeText(this, "已保存预设行为", Toast.LENGTH_SHORT).show()
      finish()
    } else {
      Toast.makeText(this, "保存失败，请先打开一次 App 初始化数据库", Toast.LENGTH_LONG).show()
    }
  }

  private fun acknowledgePresetReminder() {
    val presetId = payload.optInt("presetId", 0)
    if (presetId > 0) {
      BehaviorObservationNativeRecorder.savePresetAlarmCheckIn(this, payload, "acknowledged", null, null, "已收到系统闹钟预设提醒")
    }
    Toast.makeText(this, "已确认收到预设提醒", Toast.LENGTH_SHORT).show()
    finish()
  }

  private fun snoozeFiveMinutes(reason: String) {
    try {
      val obj = JSONObject(payload.toString())
      obj.put("snoozeReason", reason)
      obj.put("snoozeAtMs", System.currentTimeMillis())
      if (setupRequiredMode) obj.put("setupRequired", true)
      val id = 96800000 + ((System.currentTimeMillis() / 1000L) % 900000L).toInt()
      obj.put("alarmId", id)
      NativeSchedulerK.scheduleExactAt(applicationContext, id, System.currentTimeMillis() + 5 * 60_000L, obj.toString())
      try { com.example.quote_app.data.DbRepo.log(this, null, "[BehaviorPresetAlarm] snooze 5min: $reason") } catch (_: Throwable) {}
    } catch (_: Throwable) {}
  }

  private fun countActivePresetsForDay(dayMs: Long): Int {
    val db = openDbReadOnly() ?: return 0
    return try {
      val weekday = dartWeekday(dayMs)
      var count = 0
      db.rawQuery("SELECT weekdays_json FROM behavior_observation_presets WHERE active = 1", emptyArray()).use { c ->
        while (c.moveToNext()) {
          val raw = if (c.isNull(0)) "[]" else c.getString(0)
          val days = parseWeekdays(raw)
          if (days.isEmpty() || days.contains(weekday)) count++
        }
      }
      count
    } catch (_: Throwable) { 0 } finally { try { db.close() } catch (_: Throwable) {} }
  }

  private fun openDbReadOnly(): SQLiteDatabase? {
    return try {
      val contract = com.example.quote_app.data.DbInspector.loadOrLightScan(applicationContext)
      val path = contract?.dbPath
      if (!path.isNullOrBlank()) SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY) else null
    } catch (_: Throwable) { null }
  }

  private fun parseWeekdays(raw: String?): Set<Int> {
    val result = LinkedHashSet<Int>()
    try {
      val arr = JSONArray(raw ?: "[]")
      for (i in 0 until arr.length()) {
        val v = arr.optInt(i, 0)
        if (v in 1..7) result.add(v)
      }
    } catch (_: Throwable) {}
    return result
  }

  private fun dartWeekday(ms: Long): Int {
    val cal = Calendar.getInstance().apply { timeInMillis = ms }
    return when (cal.get(Calendar.DAY_OF_WEEK)) {
      Calendar.MONDAY -> 1
      Calendar.TUESDAY -> 2
      Calendar.WEDNESDAY -> 3
      Calendar.THURSDAY -> 4
      Calendar.FRIDAY -> 5
      Calendar.SATURDAY -> 6
      Calendar.SUNDAY -> 7
      else -> 1
    }
  }

  private fun dayStartMs(ms: Long): Long {
    val c = Calendar.getInstance().apply { timeInMillis = ms }
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
  }

  private fun baseRoot(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(20), dp(26), dp(20), dp(20))
    setBackgroundColor(0xFFFFFFFF.toInt())
  }

  private fun title(textValue: String): TextView = TextView(this).apply {
    text = textValue
    textSize = 28f
    setTextColor(0xFF0F172A.toInt())
    typeface = android.graphics.Typeface.DEFAULT_BOLD
  }

  private fun desc(textValue: String): TextView = TextView(this).apply {
    text = textValue
    textSize = 15f
    setTextColor(0xFF64748B.toInt())
    setPadding(0, dp(8), 0, dp(16))
  }

  private fun card(label: String, value: String): TextView = TextView(this).apply {
    text = "$label：$value"
    textSize = 16f
    setTextColor(0xFF0F172A.toInt())
    setPadding(dp(14), dp(12), dp(14), dp(12))
    setBackgroundColor(0xFFF8FAFC.toInt())
  }

  private fun edit(label: String, hintText: String, input: Int, lines: Int = 1): EditText = EditText(this).apply {
    hint = "$label${if (hintText.isNotBlank()) "，$hintText" else ""}"
    textSize = 16f
    inputType = input
    minLines = lines
    maxLines = if (lines > 1) 4 else 1
    setSingleLine(lines == 1)
  }

  private fun primaryButton(textValue: String, action: () -> Unit): Button = Button(this).apply {
    text = textValue
    textSize = 16f
    setTextColor(0xFFFFFFFF.toInt())
    setBackgroundColor(0xFF4F5FA3.toInt())
    setOnClickListener { action() }
  }.also { button ->
    button.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(16) }
  }

  private fun secondaryText(textValue: String, action: () -> Unit): TextView = TextView(this).apply {
    text = textValue
    gravity = Gravity.CENTER
    textSize = 15f
    setTextColor(0xFF64748B.toInt())
    setPadding(0, dp(18), 0, 0)
    setOnClickListener { action() }
  }

  private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
}
