import 'dart:io' show Platform;

import 'package:flutter/services.dart';

class IntimacyWallpaperBridge {
  static const MethodChannel _channel = MethodChannel('com.example.quote_app/intimacy_wallpaper');

  static bool get isAndroid => Platform.isAndroid;

  static Future<bool> saveConfig({
    required int style,
    required double intimacy,
    required double randomness,
    required double ribbonWidth,
    required double trail,
    required bool bubbles,
    required bool powerSave,
  }) async {
    if (!isAndroid) return false;
    final ok = await _channel.invokeMethod<bool>('saveConfig', <String, dynamic>{
      'style': style,
      'intimacy': intimacy,
      'randomness': randomness,
      'ribbonWidth': ribbonWidth,
      'trail': trail,
      'bubbles': bubbles,
      'powerSave': powerSave,
    });
    return ok == true;
  }

  static Future<bool> openLiveWallpaper() async {
    if (!isAndroid) return false;
    final ok = await _channel.invokeMethod<bool>('openLiveWallpaper');
    return ok == true;
  }

  static Future<bool> isSupported() async {
    if (!isAndroid) return false;
    final ok = await _channel.invokeMethod<bool>('isSupported');
    return ok == true;
  }
}
