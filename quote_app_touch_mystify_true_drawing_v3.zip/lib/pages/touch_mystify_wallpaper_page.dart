import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../platform/intimacy_wallpaper_bridge.dart';

class TouchMystifyWallpaperPage extends StatefulWidget {
  const TouchMystifyWallpaperPage({super.key});

  @override
  State<TouchMystifyWallpaperPage> createState() => _TouchMystifyWallpaperPageState();
}

class _TouchMystifyWallpaperPageState extends State<TouchMystifyWallpaperPage> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  Duration _elapsed = Duration.zero;

  int _style = 0;
  double _intimacy = 0.72;
  double _randomness = 0.60;
  double _ribbonWidth = 0.55;
  double _trail = 0.62;
  bool _bubbles = true;
  bool _powerSave = false;
  int _previewSeed = 7;

  final List<String> _styles = const ['Mystify 经典黑底', '深海蓝黑', '紫粉梦境', '银白冷光', '金色余韵'];

  @override
  void initState() {
    super.initState();
    _ticker = createTicker((elapsed) {
      setState(() => _elapsed = elapsed);
    })..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  Future<void> _saveAndOpen() async {
    final ok = await IntimacyWallpaperBridge.saveConfig(
      style: _style,
      intimacy: _intimacy,
      randomness: _randomness,
      ribbonWidth: _ribbonWidth,
      trail: _trail,
      bubbles: _bubbles,
      powerSave: _powerSave,
    );
    if (!mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('当前平台不支持 Android 动态壁纸设置')),
      );
      return;
    }
    await IntimacyWallpaperBridge.openLiveWallpaper();
  }

  Future<void> _saveOnly() async {
    final ok = await IntimacyWallpaperBridge.saveConfig(
      style: _style,
      intimacy: _intimacy,
      randomness: _randomness,
      ribbonWidth: _ribbonWidth,
      trail: _trail,
      bubbles: _bubbles,
      powerSave: _powerSave,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(ok ? '已保存壁纸参数，已安装的动态壁纸会自动读取新设置' : '当前平台不支持 Android 动态壁纸')),
    );
  }

  void _randomizePreview() {
    setState(() {
      _previewSeed = math.Random().nextInt(999999);
      _randomness = (0.28 + math.Random().nextDouble() * 0.52).clamp(0.0, 1.0).toDouble();
    });
  }

  @override
  Widget build(BuildContext context) {
    final seconds = _elapsed.inMilliseconds / 1000.0;
    return Scaffold(
      backgroundColor: const Color(0xFF050714),
      appBar: AppBar(
        title: const Text('触摸 · Mystify 亲密艺术壁纸'),
        backgroundColor: const Color(0xFF050714),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          _HeroPreview(
            seconds: seconds,
            style: _style,
            intimacy: _intimacy,
            randomness: _randomness,
            ribbonWidth: _ribbonWidth,
            trail: _trail,
            bubbles: _bubbles,
            seed: _previewSeed,
          ),
          const SizedBox(height: 16),
          _IntroCard(),
          const SizedBox(height: 16),
          _SectionCard(
            title: '视觉风格',
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (int i = 0; i < _styles.length; i++)
                  ChoiceChip(
                    label: Text(_styles[i]),
                    selected: _style == i,
                    onSelected: (_) => setState(() => _style = i),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: '表达参数',
            child: Column(
              children: [
                _SliderRow(
                  label: '亲密张力',
                  value: _intimacy,
                  description: '控制两条生命轨迹从吸引、同步、缠绕到释放的戏剧强度。',
                  onChanged: (v) => setState(() => _intimacy = v),
                ),
                _SliderRow(
                  label: 'Mystify 随机性',
                  value: _randomness,
                  description: '控制轨迹变化莫测程度；越高越像随机屏保，但仍保持主线克制。',
                  onChanged: (v) => setState(() => _randomness = v),
                ),
                _SliderRow(
                  label: '光带宽度',
                  value: _ribbonWidth,
                  description: '控制主丝带的柔光厚度和高级感。',
                  onChanged: (v) => setState(() => _ribbonWidth = v),
                ),
                _SliderRow(
                  label: '残影长度',
                  value: _trail,
                  description: '控制 Windows Mystify 式拖尾；越高余韵越长。',
                  onChanged: (v) => setState(() => _trail = v),
                ),
                SwitchListTile(
                  value: _bubbles,
                  onChanged: (v) => setState(() => _bubbles = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('余韵气泡/光尘', style: TextStyle(color: Colors.white)),
                  subtitle: const Text('只在释放后的余韵阶段少量出现，避免画面杂乱。', style: TextStyle(color: Colors.white60)),
                ),
                SwitchListTile(
                  value: _powerSave,
                  onChanged: (v) => setState(() => _powerSave = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('省电模式', style: TextStyle(color: Colors.white)),
                  subtitle: const Text('降低动态壁纸帧率，适合长期作为主屏/锁屏使用。', style: TextStyle(color: Colors.white60)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _randomizePreview,
                  icon: const Icon(Icons.auto_awesome),
                  label: const Text('随机新构图'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _saveOnly,
                  icon: const Icon(Icons.save_alt),
                  label: const Text('保存参数'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: _saveAndOpen,
              icon: const Icon(Icons.wallpaper),
              label: const Text('设置为主屏幕/锁屏动态壁纸'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            '说明：Android 会打开系统动态壁纸预览页，能否单独设置锁屏取决于手机系统/厂商。已安装壁纸会从本页读取最新参数。',
            style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.45),
          ),
        ],
      ),
    );
  }
}

class _IntroCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withOpacity(0.08),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: const Text(
        '设计思想：参考 Windows Mystify 屏保视频，不做具象身体描绘；用少量随机发光轨迹表达两个人从吸引、同步、升高到短暂临界、释放、余韵的亲密过程。重点是黑底、留白、随机活动范围、少量主线、短促爆发和克制余韵。',
        style: TextStyle(color: Colors.white70, height: 1.55),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withOpacity(0.07),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _SliderRow extends StatelessWidget {
  const _SliderRow({required this.label, required this.value, required this.description, required this.onChanged});
  final String label;
  final double value;
  final String description;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text('${(value * 100).round()}%', style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(value: value, onChanged: onChanged),
          Text(description, style: const TextStyle(color: Colors.white54, fontSize: 12, height: 1.35)),
        ],
      ),
    );
  }
}

class _HeroPreview extends StatelessWidget {
  const _HeroPreview({
    required this.seconds,
    required this.style,
    required this.intimacy,
    required this.randomness,
    required this.ribbonWidth,
    required this.trail,
    required this.bubbles,
    required this.seed,
  });

  final double seconds;
  final int style;
  final double intimacy;
  final double randomness;
  final double ribbonWidth;
  final double trail;
  final bool bubbles;
  final int seed;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 9 / 13,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: CustomPaint(
          painter: _MystifyPreviewPainter(
            seconds: seconds,
            style: style,
            intimacy: intimacy,
            randomness: randomness,
            ribbonWidth: ribbonWidth,
            trail: trail,
            bubbles: bubbles,
            seed: seed,
          ),
          child: Container(
            alignment: Alignment.topLeft,
            padding: const EdgeInsets.all(18),
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.24),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Text('预览：实际壁纸以原生 Mystify 渲染为准', style: TextStyle(color: Colors.white70, fontSize: 12)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MystifyPreviewPainter extends CustomPainter {
  _MystifyPreviewPainter({
    required this.seconds,
    required this.style,
    required this.intimacy,
    required this.randomness,
    required this.ribbonWidth,
    required this.trail,
    required this.bubbles,
    required this.seed,
  });

  final double seconds;
  final int style;
  final double intimacy;
  final double randomness;
  final double ribbonWidth;
  final double trail;
  final bool bubbles;
  final int seed;

  static const List<List<Color>> palettes = [
    [Color(0xFF7DD3FC), Color(0xFFC4B5FD), Color(0xFFF472B6), Color(0xFFFDE68A), Color(0xFF030712)],
    [Color(0xFF67E8F9), Color(0xFF93C5FD), Color(0xFFC4B5FD), Color(0xFFFDE68A), Color(0xFF020617)],
    [Color(0xFFA78BFA), Color(0xFFD8B4FE), Color(0xFFF9A8D4), Color(0xFFFFF7ED), Color(0xFF050316)],
    [Color(0xFFE5E7EB), Color(0xFFFFFFFF), Color(0xFF93C5FD), Color(0xFFD1D5DB), Color(0xFF000000)],
    [Color(0xFFFDE68A), Color(0xFFFFF7ED), Color(0xFFFB7185), Color(0xFFFACC15), Color(0xFF06030A)],
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final p = palettes[style % palettes.length];
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = p[4]);

    final cycle = 30.0;
    final u = (seconds % cycle) / cycle;
    final phase = _phase(u);
    final local = _smooth((u - phase.start) / math.max(0.001, phase.end - phase.start));
    final intensity = (phase.intensity * (0.72 + 0.56 * intimacy)).clamp(0.0, 1.2).toDouble();
    final closeness = (phase.closeness + math.sin(local * math.pi) * 0.07).clamp(0.0, 1.0).toDouble();
    final tension = (phase.tension * (0.70 + 0.70 * intimacy)).clamp(0.0, 1.2).toDouble();
    final release = phase.name == '释放' ? math.sin(local * math.pi) : 0.0;
    final after = phase.name == '余韵' ? local : 0.0;

    final cx = size.width * 0.5 + math.sin(seconds * 0.13 + seed) * size.width * 0.035;
    final cy = size.height * 0.52 + math.cos(seconds * 0.11 + seed) * size.height * 0.035;
    final center = Offset(cx, cy);

    final bg = Paint()
      ..shader = RadialGradient(
        colors: [p[1].withOpacity(0.24 + intensity * 0.14), p[2].withOpacity(0.08), Colors.transparent],
      ).createShader(Rect.fromCircle(center: center, radius: size.shortestSide * (0.34 + intensity * 0.25)));
    canvas.drawCircle(center, size.shortestSide * (0.34 + intensity * 0.25), bg);

    final dist = lerpDouble(size.shortestSide * 0.34, size.shortestSide * 0.05, closeness)!;
    final orbit = seconds * (0.45 + intensity * 0.45) + seed * 0.01;
    var a = center - Offset(math.cos(orbit) * dist, math.sin(orbit * 1.17) * dist * 0.66);
    var b = center + Offset(math.cos(orbit) * dist, math.sin(orbit * 1.17) * dist * 0.66);
    if (release > 0) {
      a = Offset.lerp(a, center, release * 0.94)!;
      b = Offset.lerp(b, center, release * 0.94)!;
    }

    for (int i = 0; i < 2; i++) {
      final rp = (seconds * (0.028 + intensity * 0.018) + i / 2) % 1.0;
      final rx = size.shortestSide * (0.10 + rp * 0.50);
      final ringPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0 + intensity * 2
        ..color = Colors.white.withOpacity((1 - rp) * (0.015 + intensity * 0.04));
      canvas.save();
      canvas.translate(cx, cy);
      canvas.rotate(seconds * 0.04 + i * 0.18);
      canvas.drawOval(Rect.fromCenter(center: Offset.zero, width: rx * 2, height: rx * (0.74 + intensity * 0.12)), ringPaint);
      canvas.restore();
    }

    _drawRibbon(canvas, size, a, p[0], p[1], seconds, -1, intensity, tension, release);
    _drawRibbon(canvas, size, b, p[2], p[3], seconds, 1, intensity, tension, release);

    if (release > 0 || after > 0) {
      final r = size.shortestSide * (0.05 + release * 0.72 + after * 0.14);
      final pulse = Paint()
        ..shader = RadialGradient(
          colors: [Colors.white.withOpacity(0.75 * release + 0.12 * after), p[3].withOpacity(0.28 * release), Colors.transparent],
        ).createShader(Rect.fromCircle(center: center, radius: r));
      canvas.drawCircle(center, r, pulse);
    }

    if (bubbles && after > 0.02) {
      final bubblePaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withOpacity(0.12 * after);
      for (int i = 0; i < 7; i++) {
        final ang = i / 7 * math.pi * 2 + seconds * 0.16;
        final rr = size.shortestSide * (0.12 + i * 0.028 + after * 0.18);
        canvas.drawCircle(center + Offset(math.cos(ang) * rr, math.sin(ang * 1.23) * rr * 0.66), size.shortestSide * (0.018 + i * 0.002), bubblePaint);
      }
    }

    final textPaint = TextPainter(
      text: TextSpan(text: phase.name, style: const TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.w600)),
      textDirection: TextDirection.ltr,
    )..layout();
    textPaint.paint(canvas, Offset(size.width - textPaint.width - 18, 18));
  }

  void _drawRibbon(Canvas canvas, Size size, Offset anchor, Color c1, Color c2, double t, int dir, double intensity, double tension, double release) {
    final points = <Offset>[];
    final count = 7;
    final seedLocal = seed * 0.013 + dir * 2.7;
    for (int i = 0; i < count; i++) {
      final rel = (i - (count - 1) / 2) / ((count - 1) / 2);
      final x = anchor.dx + rel * size.width * (0.11 + randomness * 0.05) + math.sin(t * (0.42 + randomness * 0.4) + i * 1.6 + seedLocal) * size.width * 0.045 * (0.5 + tension);
      final y = anchor.dy + math.sin(i * 0.92 + t * (0.65 + randomness * 0.4) + seedLocal) * size.height * (0.050 + tension * 0.025);
      points.add(Offset(x, y));
    }
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (int i = 1; i < points.length - 1; i++) {
      final mid = Offset.lerp(points[i], points[i + 1], 0.5)!;
      path.quadraticBezierTo(points[i].dx, points[i].dy, mid.dx, mid.dy);
    }
    path.lineTo(points.last.dx, points.last.dy);

    final w = (2.5 + ribbonWidth * 8.0) * (0.78 + intensity * 0.75 + release * 0.35);
    final shader = LinearGradient(colors: [c1.withOpacity(0.96), c2.withOpacity(0.96)]).createShader(Offset.zero & size);
    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..shader = shader
      ..strokeWidth = w * 4.8
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 1.7)
      ..color = Colors.white.withOpacity(0.36 + intensity * 0.22);
    canvas.drawPath(path, glow);

    final body = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..shader = shader
      ..strokeWidth = w * 1.45
      ..color = Colors.white.withOpacity(0.62 + intensity * 0.2);
    canvas.drawPath(path, body);

    final core = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = math.max(1.0, w * 0.18)
      ..color = Colors.white.withOpacity(0.78);
    canvas.drawPath(path, core);
  }

  _Phase _phase(double u) {
    const phases = [
      _Phase('吸引', 0.00, 0.30, 0.23, 0.10, 0.12),
      _Phase('靠近', 0.30, 0.38, 0.38, 0.34, 0.28),
      _Phase('同步', 0.38, 0.66, 0.56, 0.58, 0.48),
      _Phase('升高', 0.66, 0.90, 0.78, 0.76, 0.74),
      _Phase('临界', 0.90, 0.94, 0.95, 0.90, 1.00),
      _Phase('释放', 0.94, 0.965, 1.00, 1.00, 0.44),
      _Phase('余韵', 0.965, 1.00, 0.26, 0.54, 0.08),
    ];
    return phases.firstWhere((p) => u >= p.start && u < p.end, orElse: () => phases.last);
  }

  double _smooth(double x) {
    x = x.clamp(0.0, 1.0);
    return x * x * (3 - 2 * x);
  }

  @override
  bool shouldRepaint(covariant _MystifyPreviewPainter oldDelegate) => true;
}

class _Phase {
  const _Phase(this.name, this.start, this.end, this.intensity, this.closeness, this.tension);
  final String name;
  final double start;
  final double end;
  final double intensity;
  final double closeness;
  final double tension;
}
