package com.example.quote_app.wallpaper;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * 发现之旅/触摸：Mystify 亲密艺术动态壁纸。
 *
 * V3 重新按用户提供的 Windows Mystify 参考视频修正核心算法：
 * 1. 不是“事先画好一条完整曲线再移动”，而是每一帧随机活动的控制点即时画出一小段/一条当前线，
 *    由 framebuffer 残影负责留下轨迹；这才接近 Mystify 的“线条正在被画出来”的观感。
 * 2. 新线条从任意边缘、任意局部区域、任意角落随机出生，每次控制点数量、方向、速度、活动范围、颜色都不同。
 * 3. 画面保持黑场、大留白、少线条；多数时间处于吸引/同步/升高，临界/释放/余韵只短促出现。
 * 4. 性交理念只以两股生命轨迹的牵引、同步、张力升高、短促释放和回落来抽象表达，不出现任何具象身体或露骨画面。
 */
public class IntimacyMystifyWallpaperService extends WallpaperService {
    public static final String PREFS = "intimacy_mystify_wallpaper";

    @Override
    public Engine onCreateEngine() {
        return new MystifyEngine();
    }

    final class MystifyEngine extends Engine {
        private RenderThread renderThread;
        private boolean visible = false;

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            ensureThread(holder);
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            if (renderThread != null) renderThread.resize(width, height);
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            if (renderThread != null) renderThread.setVisible(visible);
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
        }

        @Override
        public void onDestroy() {
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
            super.onDestroy();
        }

        private void ensureThread(SurfaceHolder holder) {
            if (renderThread == null) {
                renderThread = new RenderThread(getApplicationContext(), holder);
                renderThread.setVisible(visible);
                renderThread.start();
            }
        }
    }

    static final class RenderThread extends Thread {
        private final Context context;
        private final SurfaceHolder holder;
        private final SharedPreferences prefs;
        private final Random random = new Random();

        private volatile boolean running = true;
        private volatile boolean visible = false;
        private int width = 1;
        private int height = 1;
        private Bitmap buffer;
        private Canvas bufferCanvas;

        private final ArrayList<Beam> beams = new ArrayList<>();

        private final Paint fadePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint corePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pulsePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bubblePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private Config cfg = new Config();
        private long lastConfigRead = 0L;
        private long startMs = SystemClock.elapsedRealtime();
        private float nextSpawnSec = 0f;
        private float nextHardClearSec = 0f;
        private float lastReleaseU = -1f;

        RenderThread(Context context, SurfaceHolder holder) {
            super("IntimacyMystifyWallpaperRendererV3");
            this.context = context.getApplicationContext();
            this.holder = holder;
            this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

            fadePaint.setStyle(Paint.Style.FILL);
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeCap(Paint.Cap.ROUND);
            glowPaint.setStrokeJoin(Paint.Join.ROUND);
            bodyPaint.setStyle(Paint.Style.STROKE);
            bodyPaint.setStrokeCap(Paint.Cap.ROUND);
            bodyPaint.setStrokeJoin(Paint.Join.ROUND);
            corePaint.setStyle(Paint.Style.STROKE);
            corePaint.setStrokeCap(Paint.Cap.ROUND);
            corePaint.setStrokeJoin(Paint.Join.ROUND);
            pulsePaint.setStyle(Paint.Style.FILL);
            bubblePaint.setStyle(Paint.Style.STROKE);

            readConfig(true);
        }

        void setVisible(boolean visible) { this.visible = visible; }
        void requestStop() { running = false; interrupt(); }

        synchronized void resize(int w, int h) {
            if (w <= 0 || h <= 0) return;
            width = w;
            height = h;
            if (buffer != null) buffer.recycle();
            buffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bufferCanvas = new Canvas(buffer);
            bufferCanvas.drawColor(Color.BLACK, PorterDuff.Mode.SRC);
            beams.clear();
            startMs = SystemClock.elapsedRealtime();
            nextSpawnSec = 0f;
            nextHardClearSec = 12f;
        }

        @Override
        public void run() {
            long lastFrame = SystemClock.elapsedRealtime();
            while (running) {
                if (!visible) {
                    sleepQuiet(140);
                    lastFrame = SystemClock.elapsedRealtime();
                    continue;
                }
                long now = SystemClock.elapsedRealtime();
                float dt = Math.min(0.052f, (now - lastFrame) / 1000f);
                lastFrame = now;
                if (now - lastConfigRead > 900L) readConfig(false);
                drawFrame(now, dt);
                sleepQuiet(cfg.powerSave ? 42 : 24);
            }
        }

        private void drawFrame(long nowMs, float dt) {
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;
                if (width <= 2 || height <= 2) resize(canvas.getWidth(), canvas.getHeight());
                if (buffer == null || bufferCanvas == null) resize(canvas.getWidth(), canvas.getHeight());

                float sec = (nowMs - startMs) / 1000f;
                float cycle = 96f;
                float u = (sec % cycle) / cycle;
                Phase phase = Phase.of(u);
                float local = smooth((u - phase.start) / Math.max(0.001f, phase.end - phase.start));
                float release = phase.name.equals("释放") ? (float)Math.sin(local * Math.PI) : 0f;
                float after = phase.name.equals("余韵") ? local : 0f;
                float intensity = clamp(phase.intensity * (0.76f + 0.46f * cfg.intimacy), 0f, 1.25f);
                float tension = clamp(phase.tension * (0.76f + 0.50f * cfg.intimacy), 0f, 1.30f);

                // Mystify 的关键是“黑底 + 残影衰减”。不要每帧清空，只用黑色半透明覆盖。
                int fadeAlpha = (int)lerp(30f, 72f, 1f - cfg.trail);
                if (cfg.powerSave) fadeAlpha += 8;
                // 参考视频会出现接近全黑的换场留白，但不是每次都硬切。
                if (sec > nextHardClearSec) {
                    fadeAlpha = 112 + random.nextInt(36);
                    nextHardClearSec = sec + 9f + random.nextFloat() * 13f;
                }
                fadePaint.setColor(Color.argb(clampInt(fadeAlpha, 0, 255), 0, 0, 0));
                bufferCanvas.drawRect(0, 0, width, height, fadePaint);

                if (sec >= nextSpawnSec) {
                    spawnAccordingToPhase(phase, sec);
                }

                updateAndDrawBeams(bufferCanvas, sec, dt, phase, intensity, tension, release, after);
                drawPhasePulse(bufferCanvas, phase, release, after, sec);

                canvas.drawColor(Color.BLACK, PorterDuff.Mode.SRC);
                canvas.drawBitmap(buffer, 0, 0, null);
            } catch (Throwable ignored) {
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas); } catch (Throwable ignored) {}
                }
            }
        }

        private void spawnAccordingToPhase(Phase phase, float sec) {
            int maxBeams = cfg.powerSave ? 2 : 4;
            while (beams.size() > maxBeams) beams.remove(0);

            float pairChance = phase.pairChance * (0.65f + cfg.intimacy * 0.45f);
            boolean pair = random.nextFloat() < pairChance && !phase.name.equals("吸引");
            boolean fan = random.nextFloat() < (phase.fanChance + cfg.randomness * 0.06f);

            if (pair) {
                RectF encounter = randomBounds(true);
                Beam a = createBeam(phase, encounter, -1, fan && random.nextBoolean());
                Beam b = createBeam(phase, encounter, 1, fan && !a.fan);
                a.partner = b;
                b.partner = a;
                beams.add(a);
                beams.add(b);
            } else {
                beams.add(createBeam(phase, randomBounds(false), 0, fan));
            }

            // 参考视频：有时很快出现下一笔，有时黑场等待更久；吸引/同步/升高出现更频繁。
            float base;
            if (phase.name.equals("吸引")) base = 1.8f + random.nextFloat() * 3.6f;
            else if (phase.name.equals("同步") || phase.name.equals("升高")) base = 1.1f + random.nextFloat() * 2.6f;
            else base = 1.6f + random.nextFloat() * 3.2f;
            nextSpawnSec = sec + base * lerp(1.15f, 0.72f, cfg.randomness);
        }

        private RectF randomBounds(boolean centralPossible) {
            float minSide = Math.min(width, height);
            float bw = width * (0.22f + random.nextFloat() * 0.52f);
            float bh = height * (0.16f + random.nextFloat() * 0.38f);
            if (random.nextFloat() < 0.30f) { // long sweep like Windows Mystify
                bw = width * (0.56f + random.nextFloat() * 0.40f);
                bh = height * (0.12f + random.nextFloat() * 0.22f);
            }
            if (centralPossible && random.nextFloat() < 0.45f) {
                float cx = width * (0.30f + random.nextFloat() * 0.40f);
                float cy = height * (0.26f + random.nextFloat() * 0.48f);
                return new RectF(cx - bw / 2f, cy - bh / 2f, cx + bw / 2f, cy + bh / 2f);
            }
            float left = random.nextFloat() * Math.max(1f, width - bw);
            float top = random.nextFloat() * Math.max(1f, height - bh);
            return new RectF(left, top, left + bw, top + bh);
        }

        private Beam createBeam(Phase phase, RectF bounds, int side, boolean fan) {
            Beam b = new Beam(3 + random.nextInt(4));
            b.bounds = bounds;
            b.life = 2.4f + random.nextFloat() * 5.4f;
            b.age = 0f;
            b.seed = random.nextFloat() * (float)Math.PI * 2f;
            b.baseWidth = 0.8f + random.nextFloat() * 2.2f;
            b.widthScale = 0.72f + random.nextFloat() * 1.18f;
            b.speed = Math.min(width, height) * (0.0016f + random.nextFloat() * (0.0046f + cfg.randomness * 0.0036f));
            b.turn = 0.14f + random.nextFloat() * (0.46f + cfg.randomness * 0.70f);
            b.relation = phase.relation;
            b.fan = fan;
            b.fanLines = fan ? 5 + random.nextInt(10) : 0;
            b.fanGap = Math.min(width, height) * (0.006f + random.nextFloat() * 0.014f);
            int[] colors = palette(cfg.style);
            b.colorA = pickColor(colors);
            b.colorB = pickColor(colors);
            if (random.nextFloat() < 0.22f) b.colorB = Color.WHITE;

            initBeamFromRandomPosition(b, side);
            return b;
        }

        private void initBeamFromRandomPosition(Beam b, int side) {
            // 关键：线条从任意位置“出生”，优先从边缘/角落切入，而不是画在中心再移动。
            int edge = random.nextInt(4);
            if (side < 0) edge = random.nextBoolean() ? 0 : 2;
            if (side > 0) edge = random.nextBoolean() ? 1 : 3;
            float x, y;
            switch (edge) {
                case 0: x = b.bounds.left - random.nextFloat() * width * 0.10f; y = lerp(b.bounds.top, b.bounds.bottom, random.nextFloat()); break;
                case 1: x = b.bounds.right + random.nextFloat() * width * 0.10f; y = lerp(b.bounds.top, b.bounds.bottom, random.nextFloat()); break;
                case 2: x = lerp(b.bounds.left, b.bounds.right, random.nextFloat()); y = b.bounds.top - random.nextFloat() * height * 0.08f; break;
                default: x = lerp(b.bounds.left, b.bounds.right, random.nextFloat()); y = b.bounds.bottom + random.nextFloat() * height * 0.08f; break;
            }
            float targetX = lerp(b.bounds.left, b.bounds.right, random.nextFloat());
            float targetY = lerp(b.bounds.top, b.bounds.bottom, random.nextFloat());
            float angle = (float)Math.atan2(targetY - y, targetX - x) + (random.nextFloat() - 0.5f) * 1.2f;
            float spread = Math.min(b.bounds.width(), b.bounds.height()) * (0.035f + random.nextFloat() * 0.12f);
            for (int i = 0; i < b.count; i++) {
                float rel = (i - (b.count - 1) * 0.5f) / Math.max(1f, (b.count - 1) * 0.5f);
                float curve = (float)Math.sin(i * 1.17f + b.seed) * spread;
                b.x[i] = x - (float)Math.cos(angle) * rel * spread + (float)Math.cos(angle + Math.PI / 2f) * curve;
                b.y[i] = y - (float)Math.sin(angle) * rel * spread + (float)Math.sin(angle + Math.PI / 2f) * curve;
                float v = b.speed * (0.75f + random.nextFloat() * 1.50f);
                b.vx[i] = (float)Math.cos(angle) * v + (random.nextFloat() - 0.5f) * v * 0.32f;
                b.vy[i] = (float)Math.sin(angle) * v + (random.nextFloat() - 0.5f) * v * 0.32f;
            }
        }

        private void updateAndDrawBeams(Canvas c, float sec, float dt, Phase phase, float intensity, float tension, float release, float after) {
            Iterator<Beam> it = beams.iterator();
            while (it.hasNext()) {
                Beam b = it.next();
                b.age += dt;
                if (b.age > b.life) {
                    it.remove();
                    continue;
                }
                updateBeam(b, dt, sec, phase, intensity, tension, release);
                drawCurrentBeam(c, b, phase, intensity, tension, release, after);
            }
        }

        private void updateBeam(Beam b, float dt, float sec, Phase phase, float intensity, float tension, float release) {
            float dt60 = dt * 60f;
            float cx = b.bounds.centerX();
            float cy = b.bounds.centerY();
            float relationPull = 0.0007f * b.relation * (0.4f + cfg.intimacy) * dt60;
            if (b.partner != null) {
                cx = (b.bounds.centerX() + b.partner.bounds.centerX()) * 0.5f;
                cy = (b.bounds.centerY() + b.partner.bounds.centerY()) * 0.5f;
            }
            for (int i = 0; i < b.count; i++) {
                float wobble = (float)Math.sin(sec * (0.55f + b.turn) + b.seed + i * 1.19f);
                float wobble2 = (float)Math.cos(sec * (0.42f + b.turn * 0.7f) + b.seed + i * 1.71f);
                b.vx[i] += wobble * b.speed * b.turn * (0.35f + cfg.randomness) * dt60;
                b.vy[i] += wobble2 * b.speed * b.turn * (0.35f + cfg.randomness) * dt60;

                // 同步/升高阶段的“亲密关系力”：只轻轻牵引，不把所有线都拉到正中心。
                b.vx[i] += (cx - b.x[i]) * relationPull;
                b.vy[i] += (cy - b.y[i]) * relationPull;

                if (release > 0f) {
                    b.vx[i] += (cx - b.x[i]) * release * 0.013f * dt60;
                    b.vy[i] += (cy - b.y[i]) * release * 0.013f * dt60;
                }

                b.x[i] += b.vx[i] * dt60;
                b.y[i] += b.vy[i] * dt60;
                b.vx[i] *= 0.970f;
                b.vy[i] *= 0.970f;

                // 控制点在随机活动范围内反弹，活动范围本身每次都不同。
                float pad = Math.max(8f, Math.min(width, height) * 0.018f);
                if (b.x[i] < b.bounds.left - pad) { b.x[i] = b.bounds.left - pad; b.vx[i] = Math.abs(b.vx[i]) * (0.82f + random.nextFloat()*0.20f); }
                if (b.x[i] > b.bounds.right + pad) { b.x[i] = b.bounds.right + pad; b.vx[i] = -Math.abs(b.vx[i]) * (0.82f + random.nextFloat()*0.20f); }
                if (b.y[i] < b.bounds.top - pad) { b.y[i] = b.bounds.top - pad; b.vy[i] = Math.abs(b.vy[i]) * (0.82f + random.nextFloat()*0.20f); }
                if (b.y[i] > b.bounds.bottom + pad) { b.y[i] = b.bounds.bottom + pad; b.vy[i] = -Math.abs(b.vy[i]) * (0.82f + random.nextFloat()*0.20f); }
            }
        }

        private void drawCurrentBeam(Canvas c, Beam b, Phase phase, float intensity, float tension, float release, float after) {
            float born = smooth(Math.min(1f, b.age / Math.max(0.001f, b.life * 0.22f)));
            float dying = smooth(Math.min(1f, (b.life - b.age) / Math.max(0.001f, b.life * 0.26f)));
            float alphaFactor = born * dying * (1f - after * 0.25f);
            if (alphaFactor <= 0.02f) return;

            Path path = b.path();
            Shader shader = new LinearGradient(b.x[0], b.y[0], b.x[b.count-1], b.y[b.count-1],
                    withAlpha(b.colorA, 245), withAlpha(b.colorB, 228), Shader.TileMode.CLAMP);
            float widthBase = lerp(0.9f, 5.8f, cfg.ribbonWidth) * b.widthScale * (0.64f + intensity * 0.72f + release * 0.58f);

            if (b.fan) {
                float nx = (float)Math.cos(b.seed + Math.PI / 2f);
                float ny = (float)Math.sin(b.seed + Math.PI / 2f);
                for (int i = b.fanLines; i >= 1; i--) {
                    c.save();
                    float offset = (i - b.fanLines * 0.5f) * b.fanGap * (0.65f + intensity);
                    c.translate(nx * offset, ny * offset);
                    bodyPaint.setShader(null);
                    bodyPaint.setColor(withAlpha(b.colorB, (int)((14 + intensity * 30) * alphaFactor * (1f - i / (b.fanLines + 2f)))));
                    bodyPaint.setStrokeWidth(Math.max(0.6f, widthBase * 0.24f));
                    bodyPaint.setMaskFilter(null);
                    c.drawPath(path, bodyPaint);
                    c.restore();
                }
            }

            glowPaint.setShader(shader);
            glowPaint.setStrokeWidth(widthBase * (4.8f + tension * 2.0f));
            glowPaint.setAlpha((int)((18 + intensity * 60 + release * 80) * alphaFactor));
            glowPaint.setMaskFilter(new BlurMaskFilter(Math.max(3.5f, widthBase * 1.85f), BlurMaskFilter.Blur.NORMAL));
            c.drawPath(path, glowPaint);

            bodyPaint.setShader(shader);
            bodyPaint.setStrokeWidth(widthBase * (1.15f + tension * 0.34f));
            bodyPaint.setAlpha((int)((72 + intensity * 112 + release * 42) * alphaFactor));
            bodyPaint.setMaskFilter(null);
            c.drawPath(path, bodyPaint);

            corePaint.setShader(null);
            corePaint.setColor(withAlpha(Color.WHITE, (int)((110 + intensity * 100 + release * 38) * alphaFactor)));
            corePaint.setStrokeWidth(Math.max(0.65f, widthBase * 0.18f));
            corePaint.setMaskFilter(null);
            c.drawPath(path, corePaint);

            glowPaint.setShader(null);
            bodyPaint.setShader(null);
        }

        private void drawPhasePulse(Canvas c, Phase phase, float release, float after, float sec) {
            if (release <= 0.001f && after <= 0.03f) return;
            float x = width * (0.18f + 0.64f * ((float)Math.sin(sec * 0.031f + 1.7f) * 0.5f + 0.5f));
            float y = height * (0.18f + 0.64f * ((float)Math.cos(sec * 0.027f + 2.4f) * 0.5f + 0.5f));
            int[] colors = palette(cfg.style);
            float r = Math.min(width, height) * (0.035f + release * 0.42f + after * 0.08f);
            int alpha = (int)(release * 168 + after * 22);
            pulsePaint.setShader(new RadialGradient(x, y, r,
                    new int[]{withAlpha(Color.WHITE, alpha), withAlpha(colors[3], alpha / 3), Color.TRANSPARENT},
                    null, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, r, pulsePaint);
            pulsePaint.setShader(null);

            if (cfg.bubbles && after > 0.08f) {
                bubblePaint.setStyle(Paint.Style.STROKE);
                bubblePaint.setStrokeWidth(0.9f + after * 0.9f);
                for (int i = 0; i < 3; i++) {
                    float a = sec * (0.05f + i * 0.012f) + i * 2.1f;
                    float rr = Math.min(width, height) * (0.05f + i * 0.028f + after * 0.08f);
                    bubblePaint.setColor(withAlpha(i % 2 == 0 ? colors[1] : colors[2], (int)(after * 18f * (1f - i * 0.18f))));
                    c.drawCircle(x + (float)Math.cos(a) * rr, y + (float)Math.sin(a * 1.2f) * rr, Math.min(width, height) * (0.010f + i * 0.002f), bubblePaint);
                }
            }
        }

        private int pickColor(int[] colors) {
            int i = random.nextInt(4);
            return colors[i];
        }

        private void readConfig(boolean force) {
            long now = SystemClock.elapsedRealtime();
            if (!force && now - lastConfigRead < 500L) return;
            lastConfigRead = now;
            cfg.style = prefs.getInt("style", 0);
            cfg.intimacy = prefs.getFloat("intimacy", 0.72f);
            cfg.randomness = prefs.getFloat("randomness", 0.55f);
            cfg.ribbonWidth = prefs.getFloat("ribbonWidth", 0.48f);
            cfg.trail = prefs.getFloat("trail", 0.64f);
            cfg.bubbles = prefs.getBoolean("bubbles", true);
            cfg.powerSave = prefs.getBoolean("powerSave", false);
            long savedSeed = prefs.getLong("seed", 0L);
            if (savedSeed != 0L && random.nextInt(1200) == 9) random.setSeed(savedSeed ^ now);
        }

        private int[] palette(int style) {
            switch (Math.floorMod(style, 5)) {
                case 1: return new int[]{0xFF34D399, 0xFF67E8F9, 0xFF93C5FD, 0xFFFDE68A, 0xFF020617};
                case 2: return new int[]{0xFFA78BFA, 0xFFD8B4FE, 0xFFF472B6, 0xFFFFFFFF, 0xFF050316};
                case 3: return new int[]{0xFFE5E7EB, 0xFFFFFFFF, 0xFF93C5FD, 0xFFD1D5DB, 0xFF000000};
                case 4: return new int[]{0xFFFDE68A, 0xFFFFF7ED, 0xFFFB7185, 0xFFF97316, 0xFF06030A};
                default: return new int[]{0xFF7DD3FC, 0xFFC4B5FD, 0xFFF472B6, 0xFFFDE68A, 0xFF030712};
            }
        }

        private static int withAlpha(int color, int alpha) {
            return (clampInt(alpha, 0, 255) << 24) | (color & 0x00FFFFFF);
        }
        private static int clampInt(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }
        private static float clamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }
        private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
        private static float smooth(float x) { x = clamp(x, 0f, 1f); return x * x * (3f - 2f * x); }
        private static void sleepQuiet(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }
    }

    static final class Beam {
        final int count;
        final float[] x;
        final float[] y;
        final float[] vx;
        final float[] vy;
        RectF bounds = new RectF(0,0,1,1);
        Beam partner;
        float age;
        float life;
        float seed;
        float baseWidth;
        float widthScale;
        float speed;
        float turn;
        float relation;
        int colorA;
        int colorB;
        boolean fan;
        int fanLines;
        float fanGap;

        Beam(int count) {
            this.count = count;
            x = new float[count]; y = new float[count]; vx = new float[count]; vy = new float[count];
        }

        Path path() {
            Path p = new Path();
            if (count <= 0) return p;
            p.moveTo(x[0], y[0]);
            if (count == 1) return p;
            for (int i = 1; i < count - 1; i++) {
                float mx = (x[i] + x[i + 1]) * 0.5f;
                float my = (y[i] + y[i + 1]) * 0.5f;
                p.quadTo(x[i], y[i], mx, my);
            }
            p.lineTo(x[count - 1], y[count - 1]);
            return p;
        }
    }

    static final class Config {
        int style = 0;
        float intimacy = 0.72f;
        float randomness = 0.55f;
        float ribbonWidth = 0.48f;
        float trail = 0.64f;
        boolean bubbles = true;
        boolean powerSave = false;
    }

    static final class Phase {
        final String name;
        final float start;
        final float end;
        final float intensity;
        final float closeness;
        final float tension;
        final float relation;
        final float pairChance;
        final float fanChance;

        Phase(String name, float start, float end, float intensity, float closeness, float tension, float relation, float pairChance, float fanChance) {
            this.name = name;
            this.start = start;
            this.end = end;
            this.intensity = intensity;
            this.closeness = closeness;
            this.tension = tension;
            this.relation = relation;
            this.pairChance = pairChance;
            this.fanChance = fanChance;
        }

        // 按用户要求：临界/释放/余韵极少，大部分处于吸引、同步、升高。
        static final Phase[] ALL = new Phase[]{
                new Phase("吸引", 0.000f, 0.360f, 0.22f, 0.08f, 0.10f, 0.08f, 0.05f, 0.08f),
                new Phase("靠近", 0.360f, 0.410f, 0.36f, 0.30f, 0.26f, 0.36f, 0.18f, 0.10f),
                new Phase("同步", 0.410f, 0.710f, 0.56f, 0.56f, 0.48f, 0.66f, 0.46f, 0.16f),
                new Phase("升高", 0.710f, 0.940f, 0.80f, 0.74f, 0.76f, 0.82f, 0.52f, 0.24f),
                new Phase("临界", 0.940f, 0.970f, 0.96f, 0.90f, 1.00f, 0.94f, 0.58f, 0.22f),
                new Phase("释放", 0.970f, 0.985f, 1.00f, 1.00f, 0.42f, 1.00f, 0.42f, 0.10f),
                new Phase("余韵", 0.985f, 1.000f, 0.24f, 0.54f, 0.08f, 0.20f, 0.08f, 0.05f),
        };

        static Phase of(float u) {
            for (Phase p : ALL) if (u >= p.start && u < p.end) return p;
            return ALL[ALL.length - 1];
        }
    }
}
