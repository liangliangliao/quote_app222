import 'dart:async';
import 'dart:io' show Platform;
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../platform/intimacy_wallpaper_bridge.dart';

class TouchMystifyWallpaperPage extends StatefulWidget {
  const TouchMystifyWallpaperPage({super.key});

  @override
  State<TouchMystifyWallpaperPage> createState() => _TouchMystifyWallpaperPageState();
}

class _TouchMystifyWallpaperPageState extends State<TouchMystifyWallpaperPage> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final Ticker _ticker;
  Duration _elapsed = Duration.zero;

  int _style = 0;
  double _intimacy = 0.72;
  double _randomness = 0.68;
  double _ribbonWidth = 0.48;
  double _trail = 0.84;
  double _fullScreenCoverage = 0.96;
  double _strokeDensity = 0.36;
  bool _previewAccelerated = false;
  double _previewCycleMinutes = 3.0;
  bool _debugLoopEnabled = false;
  double _debugCycleMinutes = 3.0;
  bool _bubbles = false;
  bool _powerSave = false;
  bool _randomCycle = true;
  double _cycleMinDays = 1.0;
  double _cycleMaxDays = 365.0;
  double _fixedCycleDays = 30.0;
  double _ratioSeparation = 0.46;
  double _ratioAttraction = 0.22;
  double _ratioSync = 0.22;
  double _ratioCritical = 0.06;
  double _ratioRelease = 0.02;
  double _ratioAfterglow = 0.02;
  double _criticalMinSec = 30.0;
  double _criticalMaxSec = 180.0;
  double _releaseMinSec = 8.0;
  double _releaseMaxSec = 24.0;
  double _afterglowMinSec = 20.0;
  double _afterglowMaxSec = 90.0;
  int _previewSeed = 7;
  bool _waitingForSystemApply = false;
  Timer? _configSyncDebounce;

  final List<String> _styles = const ['Mystify 经典黑底', '深海蓝绿光丝', '紫粉扇形光网', '银白冷光折刃', '金色余韵'];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _ticker = createTicker((elapsed) {
      setState(() => _elapsed = elapsed);
    })..start();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _configSyncDebounce?.cancel();
    _ticker.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _waitingForSystemApply) {
      _waitingForSystemApply = false;
      Future<void>.delayed(const Duration(milliseconds: 500), _checkWallpaperAppliedAfterReturn);
    }
  }

  Future<void> _checkWallpaperAppliedAfterReturn() async {
    final applied = await IntimacyWallpaperBridge.isLiveWallpaperApplied();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(applied
            ? '动态壁纸已成功应用。'
            : '动态壁纸尚未应用：必须在系统预览页点击“设置壁纸/应用”，仅返回本页不会生效。'),
      ),
    );
  }


  Future<void> _showWallpaperDiagnostic() async {
    final data = await IntimacyWallpaperBridge.getLiveWallpaperDiagnostic();
    if (!mounted) return;
    final lines = <String>[
      '动态壁纸服务注册：${data['registeredInLiveWallpaperList'] == true ? '已识别' : '未识别'}',
      '当前是否已应用：${data['applied'] == true ? '是' : '否'}',
      '启用状态：${data['enableState'] ?? '-'}',
      if (data['needsEnableGuide'] == true) '启用引导：${data['enableGuide'] ?? ''}',
      '系统动态壁纸服务数：${data['availableLiveWallpaperServices'] ?? '-'}',
      '指定预览入口目标数：${data['previewIntentTargets'] ?? '-'}',
      '动态壁纸列表入口目标数：${data['chooserIntentTargets'] ?? '-'}',
      '当前壁纸包：${data['currentWallpaperPackage'] ?? ''}',
      '当前壁纸服务：${data['currentWallpaperService'] ?? ''}',
      if (data['error'] != null) '错误：${data['error']}',
    ];
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('动态壁纸诊断'),
        content: SingleChildScrollView(child: SelectableText(lines.join('\n'))),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('关闭')),
        ],
      ),
    );
  }


  void _updateConfigPreview(VoidCallback update) {
    setState(update);
    _scheduleConfigSync();
  }

  void _scheduleConfigSync() {
    _configSyncDebounce?.cancel();
    _configSyncDebounce = Timer(const Duration(milliseconds: 650), () {
      _saveCurrentConfig(resetSeed: false, showSnack: false);
    });
  }

  Future<bool> _saveCurrentConfig({required bool resetSeed, bool showSnack = false}) async {
    final ok = await IntimacyWallpaperBridge.saveConfig(
      style: _style,
      intimacy: _intimacy,
      randomness: _randomness,
      ribbonWidth: _ribbonWidth,
      trail: _trail,
      fullScreenCoverage: _fullScreenCoverage,
      strokeDensity: _strokeDensity,
      previewAccelerated: _previewAccelerated,
      previewCycleMinutes: _previewCycleMinutes,
      debugLoopEnabled: _debugLoopEnabled,
      debugCycleMinutes: _debugCycleMinutes,
      bubbles: _bubbles,
      powerSave: _powerSave,
      randomCycle: _randomCycle,
      cycleMinDays: _cycleMinDays,
      cycleMaxDays: _cycleMaxDays,
      fixedCycleDays: _fixedCycleDays,
      ratioSeparation: _ratioSeparation,
      ratioAttraction: _ratioAttraction,
      ratioSync: _ratioSync,
      ratioCritical: _ratioCritical,
      ratioRelease: _ratioRelease,
      ratioAfterglow: _ratioAfterglow,
      criticalMinSec: _criticalMinSec,
      criticalMaxSec: _criticalMaxSec,
      releaseMinSec: _releaseMinSec,
      releaseMaxSec: _releaseMaxSec,
      afterglowMinSec: _afterglowMinSec,
      afterglowMaxSec: _afterglowMaxSec,
      resetSeed: resetSeed,
    );
    if (showSnack && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(ok ? '已保存壁纸参数，已安装的动态壁纸会自动读取新设置' : '当前平台不支持 Android 动态壁纸')),
      );
    }
    return ok;
  }

  Future<void> _saveAndOpen() async {
    final ok = await _saveCurrentConfig(resetSeed: true);
    if (!mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('当前平台不支持 Android 动态壁纸设置')),
      );
      return;
    }
    final diag = await IntimacyWallpaperBridge.getLiveWallpaperDiagnostic();
    if (!mounted) return;
    if (diag['registeredInLiveWallpaperList'] == false) {
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('需要开启/识别动态壁纸服务'),
          content: Text((diag['enableGuide'] as String?) ?? '系统尚未识别潮汐之间动态壁纸服务。请进入动态壁纸应用助手按步骤检查。'),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('继续打开助手')),
          ],
        ),
      );
      if (!mounted) return;
    }
    // Android 第三方应用不能稳定、静默地直接替换“动态壁纸”。
    // 正确且兼容的流程是打开系统 Live Wallpaper 预览页，由用户在系统页点击“设置壁纸/应用”。
    final opened = await IntimacyWallpaperBridge.openLiveWallpaper();
    if (!mounted) return;
    if (opened) {
      _waitingForSystemApply = true;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('已打开动态壁纸应用助手；若系统未自动跳转，请在助手页选择入口。')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('未能打开动态壁纸应用助手，请从手机系统“壁纸/动态壁纸”中选择“潮汐之间”。')),
      );
    }
  }

  Future<void> _saveOnly() async {
    await _saveCurrentConfig(resetSeed: true, showSnack: true);
  }

  void _randomizePreview() {
    setState(() {
      _previewSeed = math.Random().nextInt(999999);
      _randomness = (0.42 + math.Random().nextDouble() * 0.48).clamp(0.0, 1.0).toDouble();
    });
    _saveCurrentConfig(resetSeed: true);
  }

  @override
  Widget build(BuildContext context) {
    final seconds = _elapsed.inMilliseconds / 1000.0;
    return Scaffold(
      backgroundColor: const Color(0xFF050714),
      appBar: AppBar(
        title: const Text('触摸 · Mystify 亲密艺术壁纸'),
        backgroundColor: const Color(0xFF050714),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          _HeroPreview(
            seconds: seconds,
            style: _style,
            intimacy: _intimacy,
            randomness: _randomness,
            ribbonWidth: _ribbonWidth,
            trail: _trail,
            fullScreenCoverage: _fullScreenCoverage,
            bubbles: _bubbles,
            ratioSeparation: _ratioSeparation,
            ratioAttraction: _ratioAttraction,
            ratioSync: _ratioSync,
            ratioCritical: _ratioCritical,
            ratioRelease: _ratioRelease,
            ratioAfterglow: _ratioAfterglow,
            criticalMinSec: _criticalMinSec,
            criticalMaxSec: _criticalMaxSec,
            releaseMinSec: _releaseMinSec,
            releaseMaxSec: _releaseMaxSec,
            afterglowMinSec: _afterglowMinSec,
            afterglowMaxSec: _afterglowMaxSec,
            seed: _previewSeed,
          ),
          const SizedBox(height: 16),
          _IntroCard(),
          const SizedBox(height: 16),
          _SectionCard(
            title: '视觉风格',
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (int i = 0; i < _styles.length; i++)
                  ChoiceChip(
                    label: Text(_styles[i]),
                    selected: _style == i,
                    onSelected: (_) => _updateConfigPreview(() => _style = i),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: '表达参数',
            child: Column(
              children: [
                _SliderRow(
                  label: '亲密张力',
                  value: _intimacy,
                  description: '控制两条生命轨迹从吸引、同步、缠绕到释放的戏剧强度。',
                  onChanged: (v) => _updateConfigPreview(() => _intimacy = v),
                ),
                _SliderRow(
                  label: 'Mystify 随机性',
                  value: _randomness,
                  description: '控制轨迹变化莫测程度；越高越容易出现折叠、扇形光网、点线喷洒，但仍保持黑场留白。',
                  onChanged: (v) => _updateConfigPreview(() => _randomness = v),
                ),
                _SliderRow(
                  label: '光带宽度',
                  value: _ribbonWidth,
                  description: '控制主丝带的柔光厚度和高级感。',
                  onChanged: (v) => _updateConfigPreview(() => _ribbonWidth = v),
                ),
                _SliderRow(
                  label: '残影长度',
                  value: _trail,
                  description: '控制 Windows Mystify 式拖尾；越高越接近视频里“头部继续写出、尾部同步慢淡出”的光迹。',
                  onChanged: (v) => _updateConfigPreview(() => _trail = v),
                ),
                _SliderRow(
                  label: '全屏活动范围',
                  value: _fullScreenCoverage,
                  description: '控制随机运动点是否覆盖手机可见屏幕任意位置。默认接近全屏，避免线条只在中心或小区域活动。',
                  onChanged: (v) => _updateConfigPreview(() => _fullScreenCoverage = v),
                ),
                _SliderRow(
                  label: '线条出现密度',
                  value: _strokeDensity,
                  description: '控制随机即时线条发生器的出生频率。过低更像黑场留白，过高更容易杂乱。',
                  onChanged: (v) => _updateConfigPreview(() => _strokeDensity = v),
                ),
                SwitchListTile(
                  value: _bubbles,
                  onChanged: (v) => _updateConfigPreview(() => _bubbles = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('余韵气泡/光尘', style: TextStyle(color: Colors.white)),
                  subtitle: const Text('只在释放后的余韵阶段少量出现，避免画面杂乱。', style: TextStyle(color: Colors.white60)),
                ),
                SwitchListTile(
                  value: _powerSave,
                  onChanged: (v) => _updateConfigPreview(() => _powerSave = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('省电模式', style: TextStyle(color: Colors.white)),
                  subtitle: const Text('降低动态壁纸帧率，适合长期作为主屏/锁屏使用。', style: TextStyle(color: Colors.white60)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: '完整周期（以天为单位）',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SwitchListTile(
                  value: _randomCycle,
                  onChanged: (v) => _updateConfigPreview(() => _randomCycle = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('每轮随机生成周期', style: TextStyle(color: Colors.white)),
                  subtitle: Text(
                    _randomCycle
                        ? '当前范围：${_cycleMinDays.round()}～${_cycleMaxDays.round()} 天。每完成一轮后，会重新随机生成下一轮周期。'
                        : '关闭后使用固定周期：${_fixedCycleDays.round()} 天。',
                    style: const TextStyle(color: Colors.white60),
                  ),
                ),
                SwitchListTile(
                  value: _previewAccelerated,
                  onChanged: (v) => _updateConfigPreview(() => _previewAccelerated = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('壁纸单次加速演示模式', style: TextStyle(color: Colors.white)),
                  subtitle: Text(
                    _previewAccelerated
                        ? '已开启：仅系统预览页会把一个完整周期压缩到约 ${_previewCycleMinutes.toStringAsFixed(1)} 分钟；真正应用到桌面/锁屏后仍按真实 1～365 天周期运行。'
                        : '关闭后按真实天数推进完整周期。若你想快速检查一次完整过程，可以临时开启。',
                    style: const TextStyle(color: Colors.white60),
                  ),
                ),
                if (_previewAccelerated)
                  _MinuteSliderRow(
                    label: '单次演示周期',
                    value: _previewCycleMinutes,
                    min: 0.5,
                    max: 60.0,
                    onChanged: (v) => _updateConfigPreview(() => _previewCycleMinutes = v),
                  ),
                const Divider(color: Colors.white12, height: 24),
                SwitchListTile(
                  value: _debugLoopEnabled,
                  onChanged: (v) => _updateConfigPreview(() => _debugLoopEnabled = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('性交完整过程调试循环模式', style: TextStyle(color: Colors.white)),
                  subtitle: Text(
                    _debugLoopEnabled
                        ? '已开启：App 预览和真实桌面/锁屏动态壁纸都会按 ${_debugCycleMinutes.toStringAsFixed(1)} 分钟无限循环完整过程，用于快速调试阶段比例和短阶段持续时间。正式使用请关闭。'
                        : '关闭后，真实壁纸按 1～365 天周期运行；开启后会覆盖真实周期，并同步到已应用的动态壁纸。',
                    style: const TextStyle(color: Colors.white60),
                  ),
                ),
                if (_debugLoopEnabled)
                  _MinuteSliderRow(
                    label: '调试循环周期',
                    value: _debugCycleMinutes,
                    min: 1.0,
                    max: 60.0,
                    onChanged: (v) => _updateConfigPreview(() => _debugCycleMinutes = v),
                  ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: Text('随机范围：${_cycleMinDays.round()}～${_cycleMaxDays.round()} 天', style: const TextStyle(color: Colors.white70))),
                  ],
                ),
                RangeSlider(
                  values: RangeValues(_cycleMinDays, _cycleMaxDays),
                  min: 1.0,
                  max: 365.0,
                  divisions: 364,
                  labels: RangeLabels('${_cycleMinDays.round()}天', '${_cycleMaxDays.round()}天'),
                  onChanged: (values) {
                    _updateConfigPreview(() {
                      _cycleMinDays = values.start.clamp(1.0, 365.0).toDouble();
                      _cycleMaxDays = values.end.clamp(_cycleMinDays, 365.0).toDouble();
                      _fixedCycleDays = _fixedCycleDays.clamp(_cycleMinDays, _cycleMaxDays).toDouble();
                    });
                  },
                ),
                if (!_randomCycle)
                  _DaySliderRow(
                    label: '固定周期',
                    value: _fixedCycleDays,
                    min: _cycleMinDays,
                    max: _cycleMaxDays,
                    onChanged: (v) => _updateConfigPreview(() => _fixedCycleDays = v),
                  ),
                const Text(
                  '实际动态壁纸按真实天数推进；本页预览是单次周期演示，不会在几分钟内重复释放/余韵；真实壁纸仍以原生 OpenGL 渲染为准。',
                  style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.35),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: '阶段出现频率',
            child: Column(
              children: [
                _RatioSliderRow(label: '分离', value: _ratioSeparation, description: '默认最大比例：黑场、留白、低频单线，表达两个生命仍处于分离状态。', onChanged: (v) => _updateConfigPreview(() => _ratioSeparation = v)),
                _RatioSliderRow(label: '吸引', value: _ratioAttraction, description: '主要比例：线条从任意位置出现，彼此被牵引但尚未合一。', onChanged: (v) => _updateConfigPreview(() => _ratioAttraction = v)),
                _RatioSliderRow(label: '同步', value: _ratioSync, description: '主要比例：两条轨迹节奏趋同，张力持续升高。', onChanged: (v) => _updateConfigPreview(() => _ratioSync = v)),
                _RatioSliderRow(label: '临界', value: _ratioCritical, description: '小比例：短暂缠绕、压缩、接近峰值。', onChanged: (v) => _updateConfigPreview(() => _ratioCritical = v)),
                _RatioSliderRow(label: '释放', value: _ratioRelease, description: '最小比例：短促柔光脉冲，避免变成烟花式爆炸。', onChanged: (v) => _updateConfigPreview(() => _ratioRelease = v)),
                _RatioSliderRow(label: '余韵', value: _ratioAfterglow, description: '最小比例：残影、少量光尘、快速回到黑场。', onChanged: (v) => _updateConfigPreview(() => _ratioAfterglow = v)),
                _PhaseRatioSummary(
                  separation: _ratioSeparation,
                  attraction: _ratioAttraction,
                  sync: _ratioSync,
                  critical: _ratioCritical,
                  release: _ratioRelease,
                  afterglow: _ratioAfterglow,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: '短阶段持续时间（秒）',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SecondRangeRow(
                  label: '临界持续时间',
                  values: RangeValues(_criticalMinSec, _criticalMaxSec),
                  min: 5,
                  max: 7200,
                  description: '临界来自同步，位于释放之前；默认短暂出现，避免长时间停在峰值。',
                  onChanged: (v) => _updateConfigPreview(() {
                    _criticalMinSec = v.start;
                    _criticalMaxSec = math.max(v.end, _criticalMinSec);
                  }),
                ),
                _SecondRangeRow(
                  label: '释放持续时间',
                  values: RangeValues(_releaseMinSec, _releaseMaxSec),
                  min: 2,
                  max: 1200,
                  description: '每个完整周期内只出现一次释放；具体持续时长会在该范围内随机生成。',
                  onChanged: (v) => _updateConfigPreview(() {
                    _releaseMinSec = v.start;
                    _releaseMaxSec = math.max(v.end, _releaseMinSec);
                  }),
                ),
                _SecondRangeRow(
                  label: '余韵持续时间',
                  values: RangeValues(_afterglowMinSec, _afterglowMaxSec),
                  min: 3,
                  max: 3600,
                  description: '余韵必须紧跟释放，每周期只出现一次；具体持续时长也会随机生成。',
                  onChanged: (v) => _updateConfigPreview(() {
                    _afterglowMinSec = v.start;
                    _afterglowMaxSec = math.max(v.end, _afterglowMinSec);
                  }),
                ),
                const Text(
                  '新算法：先随机生成本轮周期天数，再随机确定本轮释放时刻；释放与余韵只出现一次，临界紧贴释放之前，分离/吸引/同步按占比填充前置过程，余韵结束后回到分离直到下一轮。',
                  style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.38),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _randomizePreview,
                  icon: const Icon(Icons.auto_awesome),
                  label: const Text('随机新构图'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _saveOnly,
                  icon: const Icon(Icons.save_alt),
                  label: const Text('保存参数'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 46,
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _showWallpaperDiagnostic,
              icon: const Icon(Icons.medical_information_outlined),
              label: const Text('诊断动态壁纸入口/注册状态'),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: _saveAndOpen,
              icon: const Icon(Icons.wallpaper),
              label: const Text('检查权限并打开动态壁纸助手'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            '说明：先检查系统是否识别并启用潮汐之间动态壁纸服务；若尚未启用，请在应用助手中进入系统动态壁纸页，选择“潮汐之间”，再点击“设置壁纸/应用”。',
            style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.45),
          ),
        ],
      ),
    );
  }
}

class _IntroCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withOpacity(0.08),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: const Text(
        '设计思想：参考 Windows Mystify / Ribbons 屏保视频，以极黑背景、加色光迹、FBO 式残影、纤维丝带、点线喷洒和扇形光网表达完整过程。每个周期只随机出现一次完整过程：分离 → 吸引 → 同步 → 临界 → 释放 → 余韵；释放和余韵只在周期中的某个随机时刻短暂发生。线条不是虫子式停留，而是像一笔荧光墨迹：从任意位置生成、折叠、拉伸、旋转，旧尾迹先失彩、再变细、最后被黑场吞没。',
        style: TextStyle(color: Colors.white70, height: 1.55),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withOpacity(0.06),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _SliderRow extends StatelessWidget {
  const _SliderRow({required this.label, required this.value, required this.description, required this.onChanged});
  final String label;
  final double value;
  final String description;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text('${(value * 100).round()}%', style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(value: value, onChanged: onChanged),
          Text(description, style: const TextStyle(color: Colors.white54, fontSize: 12, height: 1.35)),
        ],
      ),
    );
  }
}

class _DaySliderRow extends StatelessWidget {
  const _DaySliderRow({required this.label, required this.value, required this.min, required this.max, required this.onChanged});
  final String label;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    final safeMax = math.max(min, max);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text('${value.round()} 天', style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(
            value: value.clamp(min, safeMax).toDouble(),
            min: min,
            max: safeMax,
            divisions: math.max(1, (safeMax - min).round()),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}


class _MinuteSliderRow extends StatelessWidget {
  const _MinuteSliderRow({required this.label, required this.value, required this.min, required this.max, required this.onChanged});
  final String label;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text('${value.toStringAsFixed(1)} 分钟', style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(
            value: value.clamp(min, max).toDouble(),
            min: min,
            max: max,
            divisions: 119,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class _SecondRangeRow extends StatelessWidget {
  const _SecondRangeRow({required this.label, required this.values, required this.min, required this.max, required this.description, required this.onChanged});
  final String label;
  final RangeValues values;
  final double min;
  final double max;
  final String description;
  final ValueChanged<RangeValues> onChanged;

  @override
  Widget build(BuildContext context) {
    String fmt(double v) {
      if (v >= 3600) return '${(v / 3600).toStringAsFixed(1)}小时';
      if (v >= 60) return '${(v / 60).toStringAsFixed(1)}分';
      return '${v.round()}秒';
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text('${fmt(values.start)}～${fmt(values.end)}', style: const TextStyle(color: Colors.white60)),
            ],
          ),
          RangeSlider(
            values: RangeValues(values.start.clamp(min, max).toDouble(), values.end.clamp(min, max).toDouble()),
            min: min,
            max: max,
            divisions: 200,
            labels: RangeLabels(fmt(values.start), fmt(values.end)),
            onChanged: onChanged,
          ),
          Text(description, style: const TextStyle(color: Colors.white54, fontSize: 12, height: 1.35)),
        ],
      ),
    );
  }
}

class _RatioSliderRow extends StatelessWidget {
  const _RatioSliderRow({required this.label, required this.value, required this.description, required this.onChanged});
  final String label;
  final double value;
  final String description;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text(value.toStringAsFixed(3), style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(value: value.clamp(0.002, 0.70).toDouble(), min: 0.002, max: 0.70, onChanged: onChanged),
          Text(description, style: const TextStyle(color: Colors.white54, fontSize: 12, height: 1.35)),
        ],
      ),
    );
  }
}

class _PhaseRatioSummary extends StatelessWidget {
  const _PhaseRatioSummary({required this.separation, required this.attraction, required this.sync, required this.critical, required this.release, required this.afterglow});
  final double separation;
  final double attraction;
  final double sync;
  final double critical;
  final double release;
  final double afterglow;

  @override
  Widget build(BuildContext context) {
    final total = math.max(0.001, separation + attraction + sync + critical + release + afterglow);
    String pct(double v) => '${(v / total * 100).toStringAsFixed(1)}%';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: Colors.black.withOpacity(0.18),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Text(
        '归一化后：分离 ${pct(separation)} · 吸引 ${pct(attraction)} · 同步 ${pct(sync)} · 临界 ${pct(critical)} · 释放 ${pct(release)} · 余韵 ${pct(afterglow)}',
        style: const TextStyle(color: Colors.white60, fontSize: 12, height: 1.45),
      ),
    );
  }
}

class _HeroPreview extends StatelessWidget {
  const _HeroPreview({
    required this.seconds,
    required this.style,
    required this.intimacy,
    required this.randomness,
    required this.ribbonWidth,
    required this.trail,
    required this.fullScreenCoverage,
    required this.bubbles,
    required this.ratioSeparation,
    required this.ratioAttraction,
    required this.ratioSync,
    required this.ratioCritical,
    required this.ratioRelease,
    required this.ratioAfterglow,
    required this.criticalMinSec,
    required this.criticalMaxSec,
    required this.releaseMinSec,
    required this.releaseMaxSec,
    required this.afterglowMinSec,
    required this.afterglowMaxSec,
    required this.seed,
  });

  final double seconds;
  final int style;
  final double intimacy;
  final double randomness;
  final double ribbonWidth;
  final double trail;
  final double fullScreenCoverage;
  final bool bubbles;
  final double ratioSeparation;
  final double ratioAttraction;
  final double ratioSync;
  final double ratioCritical;
  final double ratioRelease;
  final double ratioAfterglow;
  final double criticalMinSec;
  final double criticalMaxSec;
  final double releaseMinSec;
  final double releaseMaxSec;
  final double afterglowMinSec;
  final double afterglowMaxSec;
  final int seed;

  @override
  Widget build(BuildContext context) {
    final useNativePreview = !kIsWeb && Platform.isAndroid;
    final preview = useNativePreview
        ? const AndroidView(
            viewType: 'com.example.quote_app/intimacy_mystify_preview',
            creationParams: <String, dynamic>{},
            creationParamsCodec: StandardMessageCodec(),
          )
        : CustomPaint(
            painter: _MystifyPreviewPainter(
              seconds: seconds,
              style: style,
              intimacy: intimacy,
              randomness: randomness,
              ribbonWidth: ribbonWidth,
              trail: trail,
              fullScreenCoverage: fullScreenCoverage,
              bubbles: bubbles,
              ratioSeparation: ratioSeparation,
              ratioAttraction: ratioAttraction,
              ratioSync: ratioSync,
              ratioCritical: ratioCritical,
              ratioRelease: ratioRelease,
              ratioAfterglow: ratioAfterglow,
              criticalMinSec: criticalMinSec,
              criticalMaxSec: criticalMaxSec,
              releaseMinSec: releaseMinSec,
              releaseMaxSec: releaseMaxSec,
              afterglowMinSec: afterglowMinSec,
              afterglowMaxSec: afterglowMaxSec,
              seed: seed,
            ),
          );

    return AspectRatio(
      aspectRatio: 9 / 13,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: Stack(
          fit: StackFit.expand,
          children: [
            preview,
            Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.24),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: Colors.white.withOpacity(0.12)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Text(
                      useNativePreview
                          ? '原生预览：与真实壁纸共用同一渲染器'
                          : '单次周期预览：头部显现，尾部同步慢淡出',
                      style: const TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class _MystifyPreviewPainter extends CustomPainter {
  _MystifyPreviewPainter({
    required this.seconds,
    required this.style,
    required this.intimacy,
    required this.randomness,
    required this.ribbonWidth,
    required this.trail,
    required this.fullScreenCoverage,
    required this.bubbles,
    required this.ratioSeparation,
    required this.ratioAttraction,
    required this.ratioSync,
    required this.ratioCritical,
    required this.ratioRelease,
    required this.ratioAfterglow,
    required this.criticalMinSec,
    required this.criticalMaxSec,
    required this.releaseMinSec,
    required this.releaseMaxSec,
    required this.afterglowMinSec,
    required this.afterglowMaxSec,
    required this.seed,
  });

  final double seconds;
  final int style;
  final double intimacy;
  final double randomness;
  final double ribbonWidth;
  final double trail;
  final double fullScreenCoverage;
  final bool bubbles;
  final double ratioSeparation;
  final double ratioAttraction;
  final double ratioSync;
  final double ratioCritical;
  final double ratioRelease;
  final double ratioAfterglow;
  final double criticalMinSec;
  final double criticalMaxSec;
  final double releaseMinSec;
  final double releaseMaxSec;
  final double afterglowMinSec;
  final double afterglowMaxSec;
  final int seed;

  static const List<List<Color>> palettes = [
    [Color(0xFF7DD3FC), Color(0xFFC4B5FD), Color(0xFFF472B6), Color(0xFFFDE68A), Color(0xFF030712)],
    [Color(0xFF67E8F9), Color(0xFF93C5FD), Color(0xFFC4B5FD), Color(0xFFFDE68A), Color(0xFF020617)],
    [Color(0xFFA78BFA), Color(0xFFD8B4FE), Color(0xFFF9A8D4), Color(0xFFFFF7ED), Color(0xFF050316)],
    [Color(0xFFE5E7EB), Color(0xFFFFFFFF), Color(0xFF93C5FD), Color(0xFFD1D5DB), Color(0xFF000000)],
    [Color(0xFFFDE68A), Color(0xFFFFF7ED), Color(0xFFFB7185), Color(0xFFFACC15), Color(0xFF06030A)],
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final palette = palettes[style % palettes.length];
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = palette[4]);

    // V14：设置页预览也不再用 seconds % cycle 循环。
    // 一个预览周期内只出现一次释放和余韵，之后停留在分离，避免几分钟内反复出现完整过程。
    final cycle = 360.0;
    final sec = math.min(seconds, cycle - 0.001);
    final plan = _previewPlan(cycle);
    final phase = _phaseAt(sec, cycle, plan);
    final local = _smooth((sec - phase.start) / math.max(0.001, phase.end - phase.start));
    final release = phase.name == '释放' ? math.sin(local * math.pi) : 0.0;
    final after = phase.name == '余韵' ? local : 0.0;
    final intensity = (phase.intensity * (0.76 + intimacy * 0.52)).clamp(0.0, 1.25).toDouble();
    final tension = (phase.tension * (0.74 + intimacy * 0.56)).clamp(0.0, 1.25).toDouble();

    // 这版预览不再画“两个固定曲线对象”。它模拟真实 Mystify：
    // 多个 StrokeEvent 从全屏任意位置出生，每帧即时画当前线段，旧事件只以残影形式短暂存在。
    final coverage = fullScreenCoverage.clamp(0.35, 1.0).toDouble();
    final safe = Rect.fromLTWH(
      size.width * (1 - coverage) * 0.5,
      size.height * (1 - coverage) * 0.5,
      size.width * coverage,
      size.height * coverage,
    );

    // 保持 Windows Mystify 式黑场和少量高质量线条：不要把屏幕填满。
    final densityByPhase = switch (phase.name) {
      '分离' => 0.18,
      '吸引' => 0.38,
      '同步' => 0.52,
      '临界' => 0.72,
      '释放' => 0.42,
      _ => 0.20,
    };
    final basePeriod = lerpDouble(14.0, 5.2, (randomness * 0.24 + densityByPhase * 0.48 + 0.12).clamp(0.0, 1.0))!;
    // V17：预览模拟真实 FBO 反馈。保留更多旧笔触层，形成“头部继续写出、尾部同步慢慢退场”。
    final activeBack = 7 + (trail * 12).round();
    final currentIndex = (seconds / basePeriod).floor();

    // Sparse soft field only, not decorative clutter.
    if (intensity > 0.15 || release > 0.0 || after > 0.0) {
      final fieldCenter = _eventPoint(currentIndex - 1, 91, safe, size);
      final field = Paint()
        ..shader = RadialGradient(
          colors: [
            palette[1].withOpacity(0.05 + intensity * 0.06 + release * 0.15),
            palette[2].withOpacity(0.025 + intensity * 0.035),
            Colors.transparent,
          ],
        ).createShader(Rect.fromCircle(center: fieldCenter, radius: size.shortestSide * (0.25 + intensity * 0.20 + release * 0.24)));
      canvas.drawCircle(fieldCenter, size.shortestSide * (0.25 + intensity * 0.20 + release * 0.24), field);
    }

    for (int event = currentIndex - activeBack; event <= currentIndex + 1; event++) {
      final start = event * basePeriod + _hash01(event, 19) * basePeriod * 0.35;
      final life = basePeriod * (0.95 + _hash01(event, 23) * 1.15 + trail * 0.78);
      final age = seconds - start;
      if (age < 0 || age > life) continue;
      final progress = (age / life).clamp(0.0, 1.0).toDouble();
      // V17：同一笔被切成多层时间切片；头部写出、尾部同步慢退，二者同时发生。
      final born = _smooth((progress / 0.08).clamp(0.0, 1.0).toDouble());
      final eventPhase = _phaseForEvent(phase.name, event);
      final alphaBase = (0.075 + born * (0.18 + intensity * 0.30)) * (eventPhase == '分离' ? 0.52 : 0.86);
      final trailSteps = 12 + (trail * 22).round();
      for (int step = trailSteps; step >= 0; step--) {
        final lag = step * 0.032 * (0.72 + trail * 0.55);
        final localAge = (age - lag).clamp(0.0, life).toDouble();
        final localProgress = (localAge / life).clamp(0.0, 1.0).toDouble();
        final tail = step / (trailSteps + 1);
        final lagAlpha = alphaBase * math.pow(1.0 - tail, 2.25) * (step == 0 ? 1.08 : 0.46);
        _drawStrokeEvent(
          canvas,
          size,
          safe,
          palette,
          event,
          localProgress,
          seconds - lag,
          lagAlpha,
          intensity,
          tension,
          release,
          eventPhase,
        );
      }
    }

    if (release > 0.0) {
      final center = _eventPoint(currentIndex, 777, safe, size);
      final pulse = Paint()
        ..shader = RadialGradient(
          colors: [Colors.white.withOpacity(0.62 * release), palette[3].withOpacity(0.20 * release), Colors.transparent],
        ).createShader(Rect.fromCircle(center: center, radius: size.shortestSide * (0.08 + release * 0.62)));
      canvas.drawCircle(center, size.shortestSide * (0.08 + release * 0.62), pulse);
    }

    if (bubbles && after > 0.02) {
      final bubblePaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withOpacity(0.07 * after);
      for (int i = 0; i < 6; i++) {
        final c = _eventPoint(currentIndex - i, 111 + i, safe, size);
        final r = size.shortestSide * (0.020 + _hash01(i + seed, 77) * 0.040 + after * 0.030);
        canvas.drawCircle(c, r, bubblePaint);
      }
    }

    final textPaint = TextPainter(
      text: TextSpan(text: phase.name, style: const TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.w600)),
      textDirection: TextDirection.ltr,
    )..layout();
    textPaint.paint(canvas, Offset(size.width - textPaint.width - 18, 18));
  }

  String _phaseForEvent(String mainPhase, int event) {
    if (mainPhase == '分离') {
      return _hash01(event, 401) < 0.78 ? '分离' : '吸引';
    }
    if (mainPhase == '吸引') {
      return _hash01(event, 402) < 0.66 ? '吸引' : '分离';
    }
    if (mainPhase == '同步') {
      return _hash01(event, 403) < 0.70 ? '同步' : '吸引';
    }
    if (mainPhase == '临界') {
      return _hash01(event, 404) < 0.68 ? '临界' : '同步';
    }
    if (mainPhase == '释放') return '释放';
    return _hash01(event, 405) < 0.72 ? '余韵' : '分离';
  }

  void _drawStrokeEvent(
    Canvas canvas,
    Size size,
    Rect safe,
    List<Color> palette,
    int event,
    double progress,
    double t,
    double alpha,
    double intensity,
    double tension,
    double release,
    String eventPhase,
  ) {
    if (alpha <= 0.002) return;
    final mode = (_hash01(event, 3) * 6).floor();
    final points = <Offset>[];
    final controlCount = 4 + (_hash01(event, 5) * 3).floor();
    for (int i = 0; i < controlCount; i++) {
      final base = _basePointForMode(event, i, mode, safe, size);
      final amp = size.shortestSide * (0.010 + randomness * 0.020 + tension * 0.018);
      final vx = math.sin(t * (0.42 + _hash01(event, 30 + i) * 0.72) + event * 0.37 + i * 1.9) * amp;
      final vy = math.cos(t * (0.36 + _hash01(event, 70 + i) * 0.66) + event * 0.29 + i * 1.4) * amp;
      var p = Offset(base.dx + vx, base.dy + vy);

      if (eventPhase == '吸引' || eventPhase == '同步' || eventPhase == '临界') {
        final attract = _eventPoint(event, 818, safe, size);
        final pull = eventPhase == '吸引' ? 0.05 : eventPhase == '同步' ? 0.10 : 0.16;
        p = Offset.lerp(p, attract, pull * intensity)!;
      }
      if (eventPhase == '释放') {
        final center = _eventPoint(event, 919, safe, size);
        p = Offset.lerp(p, center, release * 0.58)!;
      }
      points.add(p);
    }
    if (points.length < 2) return;

    // Mystify / Ribbons 的高级感来自“线条正在喷洒/飞掠”，不是一整条虫子懒洋洋地停在屏幕上。
    final sampled = _sampleCurve(points, 72);
    // V15：可见窗口沿曲线滑行：头部显现的同时，尾部正在逐渐离场。
    // 已离场的尾迹不由当前对象继续绘制，而由预览残影层和真实壁纸 FBO 慢慢淡去。
    // V18：不再允许出现短小残缺片段。可见窗口必须是一段完整光迹。
    final window = (0.30 + _hash01(event, 661) * 0.24).clamp(0.24, 0.58).toDouble();
    final lead = 0.06 + _hash01(event, 667) * 0.13;
    final eased = _smooth(progress);
    final head = lerpDouble(-lead, 1.0 + window + lead, eased)!;
    final tail = head - window;
    if (tail >= 1.0 || head <= 0.0) return;
    final startIndex = (sampled.length * tail.clamp(0.0, 1.0)).floor().clamp(0, sampled.length - 2);
    final endIndex = (sampled.length * head.clamp(0.0, 1.0)).ceil().clamp(startIndex + 2, sampled.length);
    final visiblePts = sampled.sublist(startIndex, endIndex);
    if (visiblePts.length < 2) return;
    if (_polylineLength(visiblePts) < size.shortestSide * 0.20) return;
    final path = Path()..moveTo(visiblePts.first.dx, visiblePts.first.dy);
    for (int i = 1; i < visiblePts.length; i++) {
      path.lineTo(visiblePts[i].dx, visiblePts[i].dy);
    }

    final colorA = palette[(event + 1) % 4];
    final colorB = palette[(event + 2) % 4];
    final baseWidth = (0.9 + ribbonWidth * 3.6) * (0.64 + intensity * 0.58 + release * 0.24);
    final shader = LinearGradient(colors: [colorA.withOpacity(0.90), colorB.withOpacity(0.90)]).createShader(Offset.zero & size);

    // V18：参考 Windows Mystify/Ribbons，不把画面理解成单根线，而是
    // 多条细纤维 + 半透明面 + 光尘共同组成的一笔光迹。
    _drawFiberVeil(canvas, visiblePts, palette, event, baseWidth, alpha, intensity, tension, release);
    // V27：同步/临界阶段增加“扇形光网/电子纱”肋纹，与真实壁纸的 OpenGL 渲染保持同一视觉语言。
    _drawFanLattice(canvas, visiblePts, palette, event, baseWidth, alpha, intensity, tension, release, eventPhase);

    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..shader = shader
      ..strokeWidth = baseWidth * (eventPhase == '分离' ? 1.6 : 2.4)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, baseWidth * 0.92)
      ..color = Colors.white.withOpacity(alpha * 0.42);
    canvas.drawPath(path, glow);

    _drawTaperedRibbon(
      canvas,
      visiblePts,
      baseWidth * (eventPhase == '分离' ? 0.58 : 0.86),
      Paint()
        ..shader = shader
        ..color = Colors.white.withOpacity(alpha * 0.86),
    );

    // V13: 点 + 短线 + 主丝带共同构成一笔，像墨/光喷洒在黑纸上。
    _drawPointLineSpray(canvas, visiblePts, palette, event, baseWidth, alpha, intensity, tension, release, eventPhase);

    final core = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = math.max(0.7, baseWidth * 0.12)
      ..color = Colors.white.withOpacity((alpha * 1.18).clamp(0.0, 0.78));
    canvas.drawPath(path, core);
  }


  double _polylineLength(List<Offset> pts) {
    var len = 0.0;
    for (var i = 1; i < pts.length; i++) {
      len += (pts[i] - pts[i - 1]).distance;
    }
    return len;
  }

  void _drawFanLattice(
    Canvas canvas,
    List<Offset> pts,
    List<Color> palette,
    int event,
    double baseWidth,
    double alpha,
    double intensity,
    double tension,
    double release,
    String eventPhase,
  ) {
    if (pts.length < 5 || alpha <= 0.003) return;
    final phaseAllows = eventPhase == '同步' || eventPhase == '临界' || eventPhase == '释放';
    final chance = 0.08 + randomness * 0.20 + tension * 0.18 + (eventPhase == '临界' ? 0.22 : 0.0);
    if (!phaseAllows && _hash01(event, 881) > 0.22) return;
    if (phaseAllows && _hash01(event, 883) > chance) return;

    final first = pts.first;
    final last = pts.last;
    final d = last - first;
    final len = d.distance == 0 ? 1.0 : d.distance;
    final tangent = Offset(d.dx / len, d.dy / len);
    final normal = Offset(-tangent.dy, tangent.dx);
    final colorA = palette[(event + 1) % 4];
    final colorB = palette[(event + 2) % 4];
    final ribs = (5 + randomness * 7 + tension * 4 + (eventPhase == '临界' ? 4 : 0)).round().clamp(4, 18).toInt();
    final spread = baseWidth * (5.6 + randomness * 4.6 + tension * 5.0 + release * 4.2);
    final growFromStart = _hash01(event, 885) < 0.5;

    for (var j = 0; j < ribs; j++) {
      final jj = ribs == 1 ? 0.0 : j / (ribs - 1);
      final centered = (jj - 0.5) * 2.0;
      final h = _hash01(event * 113 + j, 887);
      final h2 = _hash01(event * 113 + j, 889);
      final off = centered * spread * (0.55 + h * 0.55);
      final phaseShift = (h2 - 0.5) * baseWidth * (1.15 + tension);
      final rib = <Offset>[];
      for (var i = 0; i < pts.length; i++) {
        final u = i / math.max(1, pts.length - 1);
        final fanGrow = growFromStart ? _smooth(u) : _smooth(1.0 - u);
        final feather = math.sin(math.pi * u.clamp(0.0, 1.0));
        final shimmer = math.sin(u * math.pi * 2.0 + event * 0.37 + j * 0.41) * baseWidth * (0.35 + tension * 0.25) * feather;
        rib.add(pts[i] + normal * (off * fanGrow + shimmer) + tangent * phaseShift * feather);
      }
      final c = Color.lerp(colorA, colorB, h)!;
      _drawTaperedRibbon(
        canvas,
        rib,
        math.max(0.20, baseWidth * (0.035 + _hash01(event * 113 + j, 891) * 0.060)),
        Paint()..color = c.withOpacity((alpha * (0.018 + intensity * 0.028 + release * 0.030) * (0.55 + h * 0.72)).clamp(0.0, 0.20)),
      );
    }

    final cross = math.min(6, math.max(2, ribs ~/ 3)).toInt();
    for (var k = 1; k <= cross; k++) {
      final u = k / (cross + 1);
      final idx = (u * (pts.length - 1)).round().clamp(1, pts.length - 2).toInt();
      final p = pts[idx];
      final fanGrow = growFromStart ? _smooth(u) : _smooth(1.0 - u);
      final span = spread * (0.20 + 0.52 * fanGrow);
      final c = Color.lerp(colorA, colorB, u)!;
      _drawTaperedRibbon(
        canvas,
        [p - normal * span, p + normal * span],
        math.max(0.18, baseWidth * 0.026),
        Paint()..color = c.withOpacity((alpha * (0.007 + intensity * 0.014 + release * 0.012)).clamp(0.0, 0.12)),
      );
    }
  }

  void _drawFiberVeil(
    Canvas canvas,
    List<Offset> pts,
    List<Color> palette,
    int event,
    double baseWidth,
    double alpha,
    double intensity,
    double tension,
    double release,
  ) {
    if (pts.length < 4 || alpha <= 0.003) return;
    final first = pts.first;
    final last = pts.last;
    final d = last - first;
    final len = d.distance == 0 ? 1.0 : d.distance;
    final tangent = Offset(d.dx / len, d.dy / len);
    final normal = Offset(-tangent.dy, tangent.dx);
    final colorA = palette[(event + 1) % 4];
    final colorB = palette[(event + 2) % 4];
    final strands = 5 + (randomness * 5 + intensity * 4).round();
    final spread = baseWidth * (1.15 + tension * 1.75 + release * 1.60);
    for (var j = 0; j < strands; j++) {
      final h = _hash01(event * 97 + j, 701);
      final h2 = _hash01(event * 97 + j, 709);
      final side = (j - (strands - 1) * 0.5) / math.max(1, strands - 1);
      final off = side * spread * (0.55 + h * 0.90);
      final along = (h2 - 0.5) * baseWidth * (1.0 + tension);
      final strand = <Offset>[];
      for (var i = 0; i < pts.length; i++) {
        final u = i / math.max(1, pts.length - 1);
        final feather = math.sin(math.pi * u.clamp(0.0, 1.0));
        final wave = math.sin(u * math.pi * 2.0 + event * 0.71 + j * 0.77) * baseWidth * 0.28 * feather;
        strand.add(pts[i] + normal * (off + wave) + tangent * along * feather);
      }
      final c = Color.lerp(colorA, colorB, h)!;
      _drawTaperedRibbon(
        canvas,
        strand,
        math.max(0.25, baseWidth * (0.035 + _hash01(event * 97 + j, 719) * 0.075)),
        Paint()..color = c.withOpacity((alpha * (0.030 + intensity * 0.045 + release * 0.040) * (0.45 + h * 0.70)).clamp(0.0, 0.18)),
      );
    }
  }

  void _drawPointLineSpray(
    Canvas canvas,
    List<Offset> pts,
    List<Color> palette,
    int event,
    double baseWidth,
    double alpha,
    double intensity,
    double tension,
    double release,
    String eventPhase,
  ) {
    if (pts.length < 3 || alpha <= 0.002) return;
    final rndCount = eventPhase == '分离'
        ? 5
        : eventPhase == '吸引'
            ? 9
            : eventPhase == '同步'
                ? 12
                : eventPhase == '临界'
                    ? 18
                    : 11;
    final grains = (rndCount + randomness * 8 + release * 10).round();
    final colorA = palette[(event + 1) % 4];
    final colorB = palette[(event + 2) % 4];
    final spray = baseWidth * (1.35 + tension * 1.55);
    for (int i = 0; i < grains; i++) {
      final h1 = _hash01(event * 101 + i, 611);
      final h2 = _hash01(event * 101 + i, 617);
      final h3 = _hash01(event * 101 + i, 623);
      var u = h1 < 0.68 ? lerpDouble(0.55, 1.0, h2)! : h2;
      u = u.clamp(0.0, 1.0).toDouble();
      final idx = (u * (pts.length - 1)).round().clamp(1, pts.length - 2).toInt();
      final p = pts[idx];
      final prev = pts[idx - 1];
      final next = pts[idx + 1];
      final d = next - prev;
      final len = d.distance == 0 ? 1.0 : d.distance;
      final t = Offset(d.dx / len, d.dy / len);
      final n = Offset(-t.dy, t.dx);
      final along = (_hash01(event * 101 + i, 631) - 0.5) * spray * 0.9;
      final normal = (_hash01(event * 101 + i, 637) - 0.5) * spray * (eventPhase == '临界' ? 2.2 : eventPhase == '释放' ? 2.6 : 1.5);
      final q = p + t * along + n * normal;
      final radius = (0.28 + baseWidth * (0.026 + _hash01(event * 101 + i, 641) * 0.080)).clamp(0.22, 2.4).toDouble();
      final c = Color.lerp(colorA, colorB, _hash01(event * 101 + i, 643))!;
      final dotPaint = Paint()
        ..color = c.withOpacity((alpha * (0.018 + intensity * 0.070 + release * 0.055) * (0.40 + h3 * 0.55)).clamp(0.0, 0.32))
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, radius * 0.35);
      canvas.drawCircle(q, radius, dotPaint);

      if (_hash01(event * 101 + i, 647) < 0.48 + intensity * 0.18) {
        final seg = radius * (5.0 + _hash01(event * 101 + i, 653) * 9.0);
        final path = Path()
          ..moveTo(q.dx - t.dx * seg * 0.45, q.dy - t.dy * seg * 0.45)
          ..lineTo(q.dx + t.dx * seg * 0.55, q.dy + t.dy * seg * 0.55);
        final linePaint = Paint()
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeWidth = math.max(0.22, radius * 0.34)
          ..color = c.withOpacity((alpha * 0.070).clamp(0.0, 0.18));
        canvas.drawPath(path, linePaint);
      }
    }
  }

  void _drawTaperedRibbon(Canvas canvas, List<Offset> pts, double maxWidth, Paint paint) {
    if (pts.length < 2 || maxWidth <= 0) return;
    final left = <Offset>[];
    final right = <Offset>[];
    for (int i = 0; i < pts.length; i++) {
      final prev = pts[(i - 1).clamp(0, pts.length - 1).toInt()];
      final next = pts[(i + 1).clamp(0, pts.length - 1).toInt()];
      final d = next - prev;
      final len = d.distance == 0 ? 1.0 : d.distance;
      final n = Offset(-d.dy / len, d.dx / len);
      final u = i / math.max(1, pts.length - 1);
      final profile = math.pow(math.sin(math.pi * u).clamp(0.0, 1.0), 1.25).toDouble();
      final w = maxWidth * (0.004 + 0.996 * profile) * 0.5;
      left.add(pts[i] + n * w);
      right.add(pts[i] - n * w);
    }
    final path = Path()..moveTo(left.first.dx, left.first.dy);
    for (final p in left.skip(1)) {
      path.lineTo(p.dx, p.dy);
    }
    for (final p in right.reversed) {
      path.lineTo(p.dx, p.dy);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  List<Offset> _sampleCurve(List<Offset> controls, int samples) {
    final pts = <Offset>[];
    if (controls.length == 2) return [controls[0], controls[1]];
    for (int s = 0; s < samples; s++) {
      final u = s / (samples - 1);
      final scaled = u * (controls.length - 1);
      final i = scaled.floor().clamp(0, controls.length - 2);
      final local = scaled - i;
      final p0 = controls[(i - 1).clamp(0, controls.length - 1).toInt()];
      final p1 = controls[i];
      final p2 = controls[(i + 1).clamp(0, controls.length - 1).toInt()];
      final p3 = controls[(i + 2).clamp(0, controls.length - 1).toInt()];
      pts.add(_catmull(p0, p1, p2, p3, local));
    }
    return pts;
  }

  Offset _catmull(Offset p0, Offset p1, Offset p2, Offset p3, double t) {
    final t2 = t * t;
    final t3 = t2 * t;
    return Offset(
      0.5 * ((2 * p1.dx) + (-p0.dx + p2.dx) * t + (2*p0.dx - 5*p1.dx + 4*p2.dx - p3.dx) * t2 + (-p0.dx + 3*p1.dx - 3*p2.dx + p3.dx) * t3),
      0.5 * ((2 * p1.dy) + (-p0.dy + p2.dy) * t + (2*p0.dy - 5*p1.dy + 4*p2.dy - p3.dy) * t2 + (-p0.dy + 3*p1.dy - 3*p2.dy + p3.dy) * t3),
    );
  }

  Offset _basePointForMode(int event, int index, int mode, Rect safe, Size size) {
    final a = _hash01(event * 17 + index, 101);
    final b = _hash01(event * 17 + index, 102);
    switch (mode) {
      case 0: // left/right edge sweep
        return Offset(index == 0 ? safe.left : index == 1 ? safe.right : lerpDouble(safe.left, safe.right, a)!, lerpDouble(safe.top, safe.bottom, b)!);
      case 1: // top/bottom edge sweep
        return Offset(lerpDouble(safe.left, safe.right, a)!, index == 0 ? safe.top : index == 1 ? safe.bottom : lerpDouble(safe.top, safe.bottom, b)!);
      case 2: // diagonal full-screen trace
        final reverse = _hash01(event, 120) < 0.5;
        final s = (index / 4.0).clamp(0.0, 1.0);
        final x = reverse ? lerpDouble(safe.right, safe.left, s)! : lerpDouble(safe.left, safe.right, s)!;
        final y = _hash01(event, 121) < 0.5 ? lerpDouble(safe.top, safe.bottom, s)! : lerpDouble(safe.bottom, safe.top, s)!;
        return Offset(x, y);
      case 3: // arbitrary long line
        return _eventPoint(event + index * 37, 133, safe, size);
      case 4: // corner cut-in
        final corner = (_hash01(event, 140) * 4).floor();
        final cornerP = [safe.topLeft, safe.topRight, safe.bottomRight, safe.bottomLeft][corner];
        return Offset.lerp(cornerP, _eventPoint(event + index * 13, 141, safe, size), (index / 3.0).clamp(0.0, 1.0))!;
      default: // short local arc but still anywhere on screen
        final center = _eventPoint(event, 150, safe, size);
        final radius = math.min(safe.width, safe.height) * (0.10 + _hash01(event, 151) * 0.18);
        final angle = _hash01(event, 152) * math.pi * 2 + index * 0.75;
        return Offset(center.dx + math.cos(angle) * radius, center.dy + math.sin(angle) * radius * 0.72);
    }
  }

  Offset _eventPoint(int event, int salt, Rect safe, Size size) {
    return Offset(
      lerpDouble(safe.left, safe.right, _hash01(event, salt))!,
      lerpDouble(safe.top, safe.bottom, _hash01(event, salt + 1))!,
    );
  }

  double _hash01(int n, int salt) {
    var x = (n + seed * 1009 + salt * 9176) & 0x7fffffff;
    x = (x ^ 61) ^ (x >> 16);
    x = x + (x << 3);
    x = x ^ (x >> 4);
    x = x * 0x27d4eb2d;
    x = x ^ (x >> 15);
    return ((x & 0x7fffffff) / 0x7fffffff).clamp(0.0, 1.0).toDouble();
  }

  _PreviewPlan _previewPlan(double cycle) {
    double randBetween(double a, double b, int salt) => a + (b - a) * _hash01(seed, salt);
    final releaseRaw = randBetween(releaseMinSec, releaseMaxSec, 501) / 10.0;
    final afterRaw = randBetween(afterglowMinSec, afterglowMaxSec, 502) / 10.0;
    final criticalRaw = randBetween(criticalMinSec, criticalMaxSec, 503) / 10.0;
    final releaseDur = releaseRaw.clamp(0.8, math.max(0.9, cycle * 0.065)).toDouble();
    final afterDur = afterRaw.clamp(1.2, math.max(1.3, cycle * 0.110)).toDouble();
    final criticalDur = criticalRaw.clamp(1.8, math.max(1.9, cycle * 0.155)).toDouble();
    final latest = math.max(2.0, cycle - releaseDur - afterDur - 1.0);
    final earliest = math.min(latest, cycle * 0.32);
    final releaseStart = earliest + (latest - earliest) * _hash01(seed, 504);
    return _PreviewPlan(
      releaseStart: releaseStart,
      releaseEnd: releaseStart + releaseDur,
      afterEnd: releaseStart + releaseDur + afterDur,
      criticalStart: math.max(0.0, releaseStart - criticalDur),
    );
  }

  _Phase _phaseAt(double sec, double cycle, _PreviewPlan plan) {
    if (sec >= plan.releaseStart && sec < plan.releaseEnd) {
      return _Phase('释放', plan.releaseStart, plan.releaseEnd, 1.00, 1.00, 0.46);
    }
    if (sec >= plan.releaseEnd && sec < plan.afterEnd) {
      return _Phase('余韵', plan.releaseEnd, plan.afterEnd, 0.22, 0.54, 0.08);
    }
    if (sec >= plan.criticalStart && sec < plan.releaseStart) {
      return _Phase('临界', plan.criticalStart, plan.releaseStart, 0.98, 0.92, 1.00);
    }
    if (sec >= plan.afterEnd) {
      return _Phase('分离', plan.afterEnd, cycle, 0.06, 0.00, 0.04);
    }
    final total = math.max(0.001, ratioSeparation + ratioAttraction + ratioSync);
    final pre = math.max(0.001, plan.criticalStart);
    final sepEnd = pre * (ratioSeparation / total);
    final attrEnd = sepEnd + pre * (ratioAttraction / total);
    if (sec < sepEnd) return _Phase('分离', 0.0, sepEnd, 0.06, 0.00, 0.04);
    if (sec < attrEnd) return _Phase('吸引', sepEnd, attrEnd, 0.24, 0.16, 0.16);
    return _Phase('同步', attrEnd, plan.criticalStart, 0.58, 0.58, 0.52);
  }

  double _smooth(double x) {
    x = x.clamp(0.0, 1.0);
    return x * x * (3 - 2 * x);
  }

  @override
  bool shouldRepaint(covariant _MystifyPreviewPainter oldDelegate) => true;
}

class _PreviewPlan {
  const _PreviewPlan({required this.releaseStart, required this.releaseEnd, required this.afterEnd, required this.criticalStart});
  final double releaseStart;
  final double releaseEnd;
  final double afterEnd;
  final double criticalStart;
}

class _Phase {
  const _Phase(this.name, this.start, this.end, this.intensity, this.closeness, this.tension);
  final String name;
  final double start;
  final double end;
  final double intensity;
  final double closeness;
  final double tension;
}
