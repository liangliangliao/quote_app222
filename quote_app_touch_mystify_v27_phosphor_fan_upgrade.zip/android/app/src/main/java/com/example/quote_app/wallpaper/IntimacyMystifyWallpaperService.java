package com.example.quote_app.wallpaper;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.graphics.Color;
import android.graphics.RectF;
import android.opengl.GLES20;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;

/**
 * 发现之旅/触摸：Mystify 亲密艺术动态壁纸。
 *
 * V8 解决三个核心问题：
 * 1) 底层从 Canvas/Bitmap 升级为 OpenGL ES + FBO ping-pong 残影。
 *    真正采用“每帧即时绘制当前随机线条，上一帧只靠 FBO 残影衰减保留”的 Mystify 逻辑。
 * 2) 引入全屏 Stroke Event Generator：每条线从手机可见屏幕任意位置、任意边缘、任意角落、任意两点即时生成，
 *    并用热区采样器避免长期集中在一小块区域。
 * 3) 增加 phosphor decay、加色混合、扇形光网、纤维丝带、点线喷洒与棱镜余影，
 *    对齐参考视频里“黑场中彩色光迹生成、折叠、拖尾、淡出”的观感。
 * 4) 保留天级宏观周期：分离最大，吸引/同步主要，临界较少，释放/余韵最少；所有比例和 1～365 天周期可配置。
 *
 * 动画只以抽象线条关系表达分离、吸引、同步、临界、释放、余韵，不出现任何具象身体或露骨画面。
 */
public class IntimacyMystifyWallpaperService extends WallpaperService {
    public static final String PREFS = "intimacy_mystify_wallpaper";

    @Override
    public Engine onCreateEngine() {
        return new MystifyEngine();
    }

    final class MystifyEngine extends Engine {
        private GLRenderThread renderThread;
        private boolean visible = false;

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            ensureThread(holder);
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            if (renderThread != null) renderThread.resize(width, height);
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            if (renderThread != null) renderThread.setVisible(visible);
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
        }

        @Override
        public void onDestroy() {
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
            super.onDestroy();
        }

        private void ensureThread(SurfaceHolder holder) {
            if (renderThread == null) {
                renderThread = new GLRenderThread(getApplicationContext(), holder, isPreview());
                renderThread.setVisible(visible);
                renderThread.start();
            }
        }
    }

    static final class GLRenderThread extends Thread {
        private static final int EGL_CONTEXT_CLIENT_VERSION = 0x3098;
        private static final int EGL_OPENGL_ES2_BIT = 4;
        private static final int GRID_COLS = 6;
        private static final int GRID_ROWS = 10;

        private final Context context;
        private final SurfaceHolder holder;
        private final boolean enginePreview;
        private final SharedPreferences prefs;
        private final OnSharedPreferenceChangeListener prefListener;
        private volatile boolean configDirty = true;
        private String visualConfigSignature = "";
        private final Random random = new Random();
        private final ArrayList<StrokeEvent> strokes = new ArrayList<>();
        private final int[] spawnHeat = new int[GRID_COLS * GRID_ROWS];

        private volatile boolean running = true;
        private volatile boolean visible = false;
        private volatile int requestedWidth = 1;
        private volatile int requestedHeight = 1;
        private volatile boolean resizePending = true;

        private int width = 1;
        private int height = 1;
        private int spawnCounter = 0;

        private EGL10 egl;
        private EGLDisplay eglDisplay;
        private EGLConfig eglConfig;
        private EGLContext eglContext;
        private EGLSurface eglSurface;

        private int textureProgram = 0;
        private int colorProgram = 0;
        private int[] fbo = new int[]{0, 0};
        private int[] tex = new int[]{0, 0};
        private int readIndex = 0;
        private int writeIndex = 1;
        private boolean fboReady = false;

        private Config cfg = new Config();
        private long lastConfigRead = 0L;
        private long startMs = SystemClock.elapsedRealtime();
        private float nextSpawnSec = 0f;
        private float nextHardClearSec = 8f;
        private long cycleStartWallMs = 0L;
        private float cycleDurationSec = 86400f;
        private float cycleCriticalStartSec = 0f;
        private float cycleReleaseStartSec = 0f;
        private float cycleReleaseDurationSec = 12f;
        private float cycleAfterglowDurationSec = 24f;
        private float cycleCriticalDurationSec = 60f;
        private float lastVisualSec = -1f;
        private String cycleSignature = "";
        private float pulseX = 0.5f;
        private float pulseY = 0.5f;
        private boolean releasePulseArmed = true;

        GLRenderThread(Context context, SurfaceHolder holder, boolean enginePreview) {
            super("IntimacyMystifyGLRendererV27PhosphorFan");
            this.context = context.getApplicationContext();
            this.holder = holder;
            this.enginePreview = enginePreview;
            this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            this.prefListener = new OnSharedPreferenceChangeListener() {
                @Override public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                    configDirty = true;
                }
            };
            this.prefs.registerOnSharedPreferenceChangeListener(this.prefListener);
            readConfig(true);
        }

        void setVisible(boolean visible) { this.visible = visible; }
        void requestStop() { running = false; interrupt(); }
        void resize(int w, int h) {
            if (w > 0 && h > 0) {
                requestedWidth = w;
                requestedHeight = h;
                resizePending = true;
            }
        }

        @Override
        public void run() {
            if (!initEgl()) return;
            try {
                initGlObjects();
                long last = SystemClock.elapsedRealtime();
                while (running) {
                    if (!visible) {
                        sleepQuiet(120);
                        last = SystemClock.elapsedRealtime();
                        continue;
                    }
                    long now = SystemClock.elapsedRealtime();
                    float dt = clamp((now - last) / 1000f, 0.001f, 0.055f);
                    last = now;
                    if (configDirty || now - lastConfigRead > 3000L) readConfig(false);
                    if (resizePending || !fboReady) {
                        applyResize();
                    }
                    renderFrame(now, dt);
                    egl.eglSwapBuffers(eglDisplay, eglSurface);
                    sleepQuiet(cfg.powerSave ? 38 : 18);
                }
            } catch (Throwable ignored) {
            } finally {
                try { prefs.unregisterOnSharedPreferenceChangeListener(prefListener); } catch (Throwable ignored) {}
                releaseGl();
            }
        }

        private boolean initEgl() {
            try {
                egl = (EGL10) EGLContext.getEGL();
                eglDisplay = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
                if (eglDisplay == EGL10.EGL_NO_DISPLAY) return false;
                int[] version = new int[2];
                if (!egl.eglInitialize(eglDisplay, version)) return false;
                int[] configAttrs = new int[]{
                        EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
                        EGL10.EGL_RED_SIZE, 8,
                        EGL10.EGL_GREEN_SIZE, 8,
                        EGL10.EGL_BLUE_SIZE, 8,
                        EGL10.EGL_ALPHA_SIZE, 8,
                        EGL10.EGL_DEPTH_SIZE, 0,
                        EGL10.EGL_STENCIL_SIZE, 0,
                        EGL10.EGL_NONE
                };
                EGLConfig[] configs = new EGLConfig[1];
                int[] num = new int[1];
                if (!egl.eglChooseConfig(eglDisplay, configAttrs, configs, 1, num) || num[0] <= 0) return false;
                eglConfig = configs[0];
                int[] ctxAttrs = new int[]{EGL_CONTEXT_CLIENT_VERSION, 2, EGL10.EGL_NONE};
                eglContext = egl.eglCreateContext(eglDisplay, eglConfig, EGL10.EGL_NO_CONTEXT, ctxAttrs);
                if (eglContext == EGL10.EGL_NO_CONTEXT) return false;
                eglSurface = egl.eglCreateWindowSurface(eglDisplay, eglConfig, holder, null);
                if (eglSurface == null || eglSurface == EGL10.EGL_NO_SURFACE) return false;
                return egl.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext);
            } catch (Throwable ignored) {
                return false;
            }
        }

        private void initGlObjects() {
            textureProgram = createProgram(TEXTURE_VERTEX, TEXTURE_FRAGMENT);
            colorProgram = createProgram(COLOR_VERTEX, COLOR_FRAGMENT);
            GLES20.glDisable(GLES20.GL_DEPTH_TEST);
            GLES20.glDisable(GLES20.GL_CULL_FACE);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            applyResize();
        }

        private void applyResize() {
            resizePending = false;
            width = Math.max(2, requestedWidth);
            height = Math.max(2, requestedHeight);
            GLES20.glViewport(0, 0, width, height);
            recreateFbos(width, height);
            strokes.clear();
            resetSpawnHeat();
            nextSpawnSec = 0f;
            nextHardClearSec = 6f + random.nextFloat() * 12f;
            startMs = SystemClock.elapsedRealtime();
        }

        private void recreateFbos(int w, int h) {
            deleteFbos();
            GLES20.glGenTextures(2, tex, 0);
            GLES20.glGenFramebuffers(2, fbo, 0);
            for (int i = 0; i < 2; i++) {
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[i]);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
                GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null);
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[i]);
                GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, tex[i], 0);
                GLES20.glViewport(0, 0, w, h);
                GLES20.glClearColor(0f, 0f, 0f, 1f);
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            }
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
            readIndex = 0;
            writeIndex = 1;
            fboReady = true;
        }

        private void renderFrame(long nowMs, float dt) {
            if (!fboReady) return;
            ensureCycleState(false);

            // V25：新增“调试循环模式”。
            // debugLoopEnabled 会同时作用于 App 原生预览和真实桌面/锁屏动态壁纸，
            // 按分钟把一次完整过程无限循环，专门用于验证阶段比例和短阶段持续时间是否生效。
            // previewAccelerated 仍只作用于系统/应用预览，不影响正式壁纸。
            boolean useDebugLoop = cfg.debugLoopEnabled;
            boolean useAcceleratedPreview = !useDebugLoop && enginePreview && cfg.previewAccelerated;
            float durationSec = useDebugLoop
                    ? Math.max(60f, cfg.debugCycleMinutes * 60f)
                    : (useAcceleratedPreview ? Math.max(30f, cfg.previewCycleMinutes * 60f) : Math.max(1f, cycleDurationSec));

            float sec;
            if (useDebugLoop) {
                float raw = (SystemClock.elapsedRealtime() - startMs) / 1000f;
                sec = raw % durationSec;
            } else if (useAcceleratedPreview) {
                // 单次预览：只跑一次完整过程，不循环释放/余韵。
                float raw = (SystemClock.elapsedRealtime() - startMs) / 1000f;
                sec = Math.min(raw, Math.max(0.001f, durationSec - 0.001f));
            } else {
                sec = currentCycleElapsedSec();
                if (sec >= cycleDurationSec) {
                    beginNewCycle(System.currentTimeMillis());
                    sec = 0f;
                }
            }

            if (lastVisualSec >= 0f && sec + 0.20f < lastVisualSec) {
                // 只处理真实周期重置或配置变更造成的时间回退；演示模式不再循环。
                nextSpawnSec = 0f;
                nextHardClearSec = 6f + random.nextFloat() * 12f;
                strokes.clear();
                resetSpawnHeat();
                clearFbos();
                releasePulseArmed = true;
            }
            lastVisualSec = sec;
            CyclePlan plan = (useDebugLoop || useAcceleratedPreview) ? previewPlan(durationSec) : storedCyclePlan(durationSec);
            Phase phase = Phase.of(sec, durationSec, cfg, plan);
            float local = smooth((sec - phase.start) / Math.max(0.001f, phase.end - phase.start));
            float release = phase.name.equals("释放") ? (float)Math.sin(local * Math.PI) : 0f;
            float after = phase.name.equals("余韵") ? local : 0f;
            float intensity = clamp(phase.intensity * (0.74f + 0.52f * cfg.intimacy), 0f, 1.30f);
            float tension = clamp(phase.tension * (0.72f + 0.56f * cfg.intimacy), 0f, 1.35f);

            if (!phase.name.equals("释放")) releasePulseArmed = true;
            if (phase.name.equals("释放") && releasePulseArmed) {
                float[] p = pickLeastUsedPoint(false);
                pulseX = p[0] / Math.max(1f, width);
                pulseY = p[1] / Math.max(1f, height);
                releasePulseArmed = false;
            }

            if (sec >= nextSpawnSec) spawnAccordingToPhase(phase, sec);
            updateStrokes(sec, dt, phase, intensity, tension, release);

            // Windows Mystify 的“离开”不是突然清除，也不是对象死亡，而是上一帧缓慢被黑场吞没。
            // 因此这里不再定时 hard clear，只做 FBO 反馈衰减；trail 越高，背影越慢消失。
            // V17：Windows Mystify 的背影是“慢慢被黑场吞没”，不是快速衰亡。
            // 这里提高最低残留，让尾部能在头部继续游走时同步、缓慢、淡淡退场。
            float fade = lerp(0.958f, 0.9952f, cfg.trail);
            if (phase.name.equals("余韵")) fade = Math.max(fade, 0.990f);
            if (phase.name.equals("释放")) fade = Math.max(fade, 0.986f);
            if (cfg.powerSave) fade = Math.min(fade, 0.990f);

            // 1) FBO 残影：把上一帧纹理衰减写入新 FBO。
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[writeIndex]);
            GLES20.glViewport(0, 0, width, height);
            GLES20.glDisable(GLES20.GL_BLEND);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            drawTexture(tex[readIndex], fade);

            // 2) 即时绘制当前随机线条。旧线条历史不由对象保存，只由 FBO 残影留下。
            GLES20.glEnable(GLES20.GL_BLEND);
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE);
            drawAllStrokes(phase, intensity, tension, release, after);
            drawReleasePulse(release, after, phase);
            GLES20.glDisable(GLES20.GL_BLEND);

            // 3) 输出到真实壁纸 Surface。
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
            GLES20.glViewport(0, 0, width, height);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            drawTexture(tex[writeIndex], 1f);

            int tmp = readIndex;
            readIndex = writeIndex;
            writeIndex = tmp;
        }

        private void spawnAccordingToPhase(Phase phase, float sec) {
            // V26：性交意蕴不再只靠“单条光迹”隐喻，而是默认同时保留两个不同主体：
            // A：冷色、较细、较锋利，像主动追寻的轨迹；
            // B：暖色、较柔、点线喷洒更丰富，像被吸引并回应的轨迹。
            // 两者在“分离”阶段远离且互不牵引，在“吸引/同步”阶段逐渐同频，
            // 在“临界/释放”阶段短暂向共同能量场聚拢，余韵后再回到分离。
            int maxStrokes = cfg.powerSave ? 2 : 2;
            if (phase.name.equals("临界") && !cfg.powerSave && cfg.strokeDensity > 0.55f) maxStrokes = 4;
            while (strokes.size() > maxStrokes) strokes.remove(0);

            boolean fanA = random.nextFloat() < phase.fanChance * (0.08f + cfg.randomness * 0.16f);
            boolean fanB = random.nextFloat() < phase.fanChance * (0.18f + cfg.randomness * 0.32f);
            if (phase.name.equals("分离")) { fanA = false; fanB = false; }
            if (phase.name.equals("余韵")) { fanA = false; fanB = false; }

            StrokeEvent a = createStroke(phase, -1, fanA, 1);
            StrokeEvent b = createStroke(phase, 1, fanB, 2);
            tuneActorPairForPhase(a, b, phase);
            strokes.add(a);
            strokes.add(b);

            float base;
            // 两个主体始终可见，但出生间隔仍保持克制，避免画面变成杂乱线团。
            if (phase.name.equals("分离")) base = 14.0f + random.nextFloat() * 26.0f;
            else if (phase.name.equals("吸引")) base = 7.0f + random.nextFloat() * 14.0f;
            else if (phase.name.equals("同步")) base = 4.5f + random.nextFloat() * 10.0f;
            else if (phase.name.equals("临界")) base = 2.0f + random.nextFloat() * 3.8f;
            else if (phase.name.equals("释放")) base = 6.5f + random.nextFloat() * 10.0f;
            else base = 9.0f + random.nextFloat() * 18.0f;
            float densityScale = lerp(1.55f, 0.58f, cfg.strokeDensity);
            if (cfg.powerSave) densityScale *= 1.40f;
            nextSpawnSec = sec + base * lerp(1.08f, 0.68f, cfg.randomness) * densityScale;
        }

        private void tuneActorPairForPhase(StrokeEvent a, StrokeEvent b, Phase phase) {
            a.partner = b;
            b.partner = a;
            if (phase.name.equals("分离")) {
                a.relation = 0f;
                b.relation = 0f;
                a.attractX = width * (0.12f + random.nextFloat() * 0.20f);
                b.attractX = width * (0.68f + random.nextFloat() * 0.20f);
                a.attractY = height * (0.18f + random.nextFloat() * 0.64f);
                b.attractY = height * (0.18f + random.nextFloat() * 0.64f);
                return;
            }
            float commonX = width * (0.32f + random.nextFloat() * 0.36f);
            float commonY = height * (0.26f + random.nextFloat() * 0.48f);
            if (phase.name.equals("吸引")) {
                a.relation = 0.18f;
                b.relation = 0.18f;
                a.attractX = lerp(a.attractX, commonX, 0.42f);
                a.attractY = lerp(a.attractY, commonY, 0.42f);
                b.attractX = lerp(b.attractX, commonX, 0.42f);
                b.attractY = lerp(b.attractY, commonY, 0.42f);
            } else if (phase.name.equals("同步")) {
                a.relation = 0.58f;
                b.relation = 0.58f;
                b.seed = a.seed + 0.18f + random.nextFloat() * 0.26f;
                b.speed = lerp(b.speed, a.speed, 0.72f);
                a.attractX = b.attractX = commonX;
                a.attractY = b.attractY = commonY;
            } else if (phase.name.equals("临界") || phase.name.equals("释放")) {
                a.relation = 0.92f;
                b.relation = 0.92f;
                b.seed = a.seed + 0.06f + random.nextFloat() * 0.12f;
                b.speed = lerp(b.speed, a.speed, 0.86f);
                a.attractX = b.attractX = commonX;
                a.attractY = b.attractY = commonY;
                a.widthScale *= 1.10f;
                b.widthScale *= 1.16f;
            } else { // 余韵
                a.relation = 0.08f;
                b.relation = 0.08f;
                a.attractX = lerp(a.attractX, commonX, 0.18f);
                a.attractY = lerp(a.attractY, commonY, 0.18f);
                b.attractX = lerp(b.attractX, commonX, 0.18f);
                b.attractY = lerp(b.attractY, commonY, 0.18f);
            }
        }

        private StrokeEvent createStroke(Phase phase, int side, boolean fan, int actor) {
            int count = 4 + random.nextInt(3);
            StrokeEvent s = new StrokeEvent(count);
            s.actor = actor;
            // V15：生命周期表示“一笔光迹从起笔到尾部完全滑出”的飞行时间。
            // 不是整条线慢慢死亡；真正的尾部退场由移动窗口 + FBO 慢衰减共同完成。
            s.life = 2.8f + random.nextFloat() * (4.2f + cfg.randomness * 2.8f);
            if (phase.name.equals("分离")) s.life *= 1.25f;
            if (phase.name.equals("吸引")) s.life *= 1.10f;
            if (phase.name.equals("同步")) s.life *= 0.95f;
            if (phase.name.equals("临界")) s.life *= 0.72f;
            if (phase.name.equals("释放")) s.life *= 0.45f;
            // V18：不再允许出现截图中那种“残缺的短小点线”。
            // 一个笔触从可见开始就必须具备足够长度，像 Windows/Ribbons 那种完整的一笔光迹，
            // 而不是小虫子或短残片。
            s.visibleWindow = 0.32f + random.nextFloat() * 0.24f;
            if (phase.name.equals("分离")) s.visibleWindow *= 0.92f;
            if (phase.name.equals("同步")) s.visibleWindow *= 1.10f;
            if (phase.name.equals("临界")) s.visibleWindow *= 1.18f;
            if (phase.name.equals("释放")) s.visibleWindow *= 1.24f;
            s.headLead = 0.06f + random.nextFloat() * 0.13f;
            s.seed = random.nextFloat() * (float)Math.PI * 2f;
            s.widthScale = 0.54f + random.nextFloat() * 0.72f;
            s.speed = Math.min(width, height) * (0.82f + random.nextFloat() * (0.90f + cfg.randomness * 0.55f));
            s.turn = 0.06f + random.nextFloat() * (0.20f + cfg.randomness * 0.18f);
            s.relation = phase.relation;
            s.fan = fan;
            s.fanLines = fan ? 2 + random.nextInt(4) : 0;
            s.fanGapPx = Math.min(width, height) * (0.003f + random.nextFloat() * 0.007f);
            int[] colors = palette(cfg.style);
            if (actor == 1) {
                // 主动追寻者：冷色、锋利、较直、点线更克制。
                s.colorA = colors[0];
                s.colorB = random.nextFloat() < 0.62f ? colors[1] : Color.WHITE;
                s.widthScale *= 0.82f;
                s.turn *= 0.68f;
                s.visibleWindow *= 0.94f;
                s.fan = false;
                s.fanLines = 0;
            } else if (actor == 2) {
                // 回应者：暖色、柔和、点线喷洒更丰富。
                s.colorA = colors[2];
                s.colorB = random.nextFloat() < 0.58f ? colors[3] : Color.WHITE;
                s.widthScale *= 1.10f;
                s.turn *= 1.18f;
                s.visibleWindow *= 1.05f;
                if (!phase.name.equals("分离") && random.nextFloat() < 0.16f + cfg.randomness * 0.16f) {
                    s.fan = true;
                    s.fanLines = 2 + random.nextInt(3);
                }
            } else {
                s.colorA = pickColor(colors);
                s.colorB = random.nextFloat() < 0.20f ? Color.WHITE : pickColor(colors);
            }
            s.bounds = fullScreenBounds();
            initStrokeFromAnyVisiblePosition(s, side);
            return s;
        }

        private RectF fullScreenBounds() {
            float padX = width * lerp(0.08f, 0.22f, cfg.fullScreenCoverage);
            float padY = height * lerp(0.08f, 0.22f, cfg.fullScreenCoverage);
            return new RectF(-padX, -padY, width + padX, height + padY);
        }

        private void initStrokeFromAnyVisiblePosition(StrokeEvent s, int side) {
            // 这一步是 V8 的重点：控制点直接从全屏可见坐标系生成，而不是从中心曲线移动出来。
            // 热区采样保证长期覆盖整块手机屏幕。
            int mode = random.nextInt(100);
            float x0, y0, x1, y1;
            if (mode < 30) {
                float[] p0 = randomEdgePoint(side);
                float[] p1 = pickLeastUsedPoint(false);
                x0 = p0[0]; y0 = p0[1]; x1 = p1[0]; y1 = p1[1];
            } else if (mode < 72) {
                float[] p0 = pickLeastUsedPoint(false);
                float[] p1 = pickLeastUsedPoint(true);
                x0 = p0[0]; y0 = p0[1]; x1 = p1[0]; y1 = p1[1];
                float minDist = Math.min(width, height) * 0.36f;
                int guard = 0;
                while (distance(x0, y0, x1, y1) < minDist && guard++ < 10) {
                    p1 = pickLeastUsedPoint(true);
                    x1 = p1[0]; y1 = p1[1];
                }
            } else {
                float[] p0 = randomCornerOrDiagonalStart();
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                x0 = p0[0]; y0 = p0[1]; x1 = p1[0]; y1 = p1[1];
            }

            markSpawnHeat(x0, y0);
            markSpawnHeat(x1, y1);

            // 以“从某处喷洒/飞掠到另一处”的长势能曲线生成控制点。
            // 不再围绕一个小中心随意弯曲，避免像蚯蚓；每次都是一段有方向、有起笔、有收笔的 Mystify 光迹。
            float angle = (float)Math.atan2(y1 - y0, x1 - x0) + (random.nextFloat() - 0.5f) * (0.12f + cfg.randomness * 0.30f);
            float length = Math.max(Math.min(width, height) * 0.42f, distance(x0, y0, x1, y1));
            float perp = Math.min(width, height) * (0.045f + random.nextFloat() * (0.12f + cfg.randomness * 0.06f));
            float bendSign = random.nextBoolean() ? 1f : -1f;
            float phase = random.nextFloat() * (float)Math.PI * 2f;
            float coherentV = s.speed * (0.72f + random.nextFloat() * 0.70f);
            for (int i = 0; i < s.count; i++) {
                float u = i / Math.max(1f, (s.count - 1f));
                float baseX = lerp(x0, x1, u);
                float baseY = lerp(y0, y1, u);
                float broadArc = (float)Math.sin(u * Math.PI) * perp * bendSign;
                float fineArc = (float)Math.sin(u * Math.PI * 2f + phase) * perp * 0.22f;
                float curve = broadArc + fineArc;
                s.x[i] = baseX - (float)Math.sin(angle) * curve;
                s.y[i] = baseY + (float)Math.cos(angle) * curve;
                float sideDrift = (i - (s.count - 1) * 0.5f) / Math.max(1f, (s.count - 1f));
                s.vx[i] = (float)Math.cos(angle) * coherentV - (float)Math.sin(angle) * coherentV * sideDrift * 0.055f;
                s.vy[i] = (float)Math.sin(angle) * coherentV + (float)Math.cos(angle) * coherentV * sideDrift * 0.055f;
                markSpawnHeat(s.x[i], s.y[i]);
            }
            s.attractX = lerp(0f, width, random.nextFloat());
            s.attractY = lerp(0f, height, random.nextFloat());
        }

        private float[] randomEdgePoint(int side) {
            int edge = random.nextInt(4);
            if (side < 0) edge = random.nextBoolean() ? 0 : 2;
            if (side > 0) edge = random.nextBoolean() ? 1 : 3;
            float oX = width * (0.02f + random.nextFloat() * 0.18f);
            float oY = height * (0.02f + random.nextFloat() * 0.18f);
            switch (edge) {
                case 0: return new float[]{-oX, random.nextFloat() * height};
                case 1: return new float[]{width + oX, random.nextFloat() * height};
                case 2: return new float[]{random.nextFloat() * width, -oY};
                default: return new float[]{random.nextFloat() * width, height + oY};
            }
        }

        private float[] randomCornerOrDiagonalStart() {
            float oX = width * (0.04f + random.nextFloat() * 0.20f);
            float oY = height * (0.04f + random.nextFloat() * 0.20f);
            switch (random.nextInt(4)) {
                case 0: return new float[]{-oX, -oY};
                case 1: return new float[]{width + oX, -oY};
                case 2: return new float[]{width + oX, height + oY};
                default: return new float[]{-oX, height + oY};
            }
        }

        private float[] randomOppositeLongPoint(float x0, float y0) {
            float x = x0 < width * 0.5f ? width * (0.55f + random.nextFloat() * 0.65f) : -width * (0.05f + random.nextFloat() * 0.55f);
            float y = y0 < height * 0.5f ? height * (0.48f + random.nextFloat() * 0.72f) : -height * (0.04f + random.nextFloat() * 0.60f);
            return new float[]{x, y};
        }

        private float[] pickLeastUsedPoint(boolean farPreference) {
            int best = 0;
            int bestScore = Integer.MAX_VALUE;
            int samples = 10 + random.nextInt(12);
            for (int i = 0; i < samples; i++) {
                int idx = random.nextInt(GRID_COLS * GRID_ROWS);
                int score = spawnHeat[idx] + random.nextInt(4);
                if (score < bestScore) { bestScore = score; best = idx; }
            }
            int col = best % GRID_COLS;
            int row = best / GRID_COLS;
            float cw = width / (float)GRID_COLS;
            float ch = height / (float)GRID_ROWS;
            float x = col * cw + random.nextFloat() * cw;
            float y = row * ch + random.nextFloat() * ch;
            if (farPreference && random.nextFloat() < 0.35f) {
                x = width - x + (random.nextFloat() - 0.5f) * cw;
                y = height - y + (random.nextFloat() - 0.5f) * ch;
            }
            x = clamp(x, -width * 0.08f, width * 1.08f);
            y = clamp(y, -height * 0.08f, height * 1.08f);
            markSpawnHeat(x, y);
            return new float[]{x, y};
        }

        private void markSpawnHeat(float x, float y) {
            int col = clampInt((int)(clamp(x, 0f, Math.max(1, width - 1)) / Math.max(1f, width) * GRID_COLS), 0, GRID_COLS - 1);
            int row = clampInt((int)(clamp(y, 0f, Math.max(1, height - 1)) / Math.max(1f, height) * GRID_ROWS), 0, GRID_ROWS - 1);
            int idx = row * GRID_COLS + col;
            spawnHeat[idx] = Math.min(100000, spawnHeat[idx] + 4);
            spawnCounter++;
            if (spawnCounter % 36 == 0) {
                for (int i = 0; i < spawnHeat.length; i++) spawnHeat[i] = Math.max(0, spawnHeat[i] - 1);
            }
        }

        private void resetSpawnHeat() {
            for (int i = 0; i < spawnHeat.length; i++) spawnHeat[i] = 0;
            spawnCounter = 0;
        }

        private void updateStrokes(float sec, float dt, Phase phase, float intensity, float tension, float release) {
            Iterator<StrokeEvent> it = strokes.iterator();
            while (it.hasNext()) {
                StrokeEvent s = it.next();
                s.age += dt;
                if (s.age > s.life) {
                    it.remove();
                    continue;
                }
                updateStroke(s, sec, dt, phase, intensity, tension, release);
            }
        }

        private void updateStroke(StrokeEvent s, float sec, float dt, Phase phase, float intensity, float tension, float release) {
            float relationPull = s.relation * (0.00018f + 0.00036f * cfg.intimacy) * (0.5f + tension);
            if (phase.name.equals("分离")) relationPull = 0f;
            if (phase.name.equals("吸引")) relationPull *= 0.22f;
            if (phase.name.equals("临界")) relationPull *= 1.55f;

            s.attractX += Math.sin(sec * (0.024f + s.turn * 0.009f) + s.seed) * width * 0.012f * dt;
            s.attractY += Math.cos(sec * (0.021f + s.turn * 0.008f) + s.seed) * height * 0.012f * dt;
            s.attractX = clamp(s.attractX, -width * 0.14f, width * 1.14f);
            s.attractY = clamp(s.attractY, -height * 0.14f, height * 1.14f);

            for (int i = 0; i < s.count; i++) {
                float wobble = (float)Math.sin(sec * (0.8f + s.turn) + s.seed + i * 1.23f);
                float wobble2 = (float)Math.cos(sec * (0.72f + s.turn * 0.76f) + s.seed + i * 1.67f);
                // 只做轻微形变，保持“高级画家的一笔飞掠”，避免控制点各自乱跑变成虫子。
                s.vx[i] += wobble * s.speed * s.turn * (0.035f + cfg.randomness * 0.055f) * dt;
                s.vy[i] += wobble2 * s.speed * s.turn * (0.035f + cfg.randomness * 0.055f) * dt;
                s.vx[i] += (s.attractX - s.x[i]) * relationPull * 60f * dt;
                s.vy[i] += (s.attractY - s.y[i]) * relationPull * 60f * dt;
                if (release > 0f) {
                    s.vx[i] += (s.attractX - s.x[i]) * release * 0.016f;
                    s.vy[i] += (s.attractY - s.y[i]) * release * 0.016f;
                }
                s.x[i] += s.vx[i] * dt;
                s.y[i] += s.vy[i] * dt;
                s.vx[i] *= 0.998f;
                s.vy[i] *= 0.998f;
                bounce(s, i);
            }
        }

        private void bounce(StrokeEvent s, int i) {
            RectF b = s.bounds;
            if (s.x[i] < b.left) { s.x[i] = b.left; s.vx[i] = Math.abs(s.vx[i]) * (0.82f + random.nextFloat()*0.22f); }
            if (s.x[i] > b.right) { s.x[i] = b.right; s.vx[i] = -Math.abs(s.vx[i]) * (0.82f + random.nextFloat()*0.22f); }
            if (s.y[i] < b.top) { s.y[i] = b.top; s.vy[i] = Math.abs(s.vy[i]) * (0.82f + random.nextFloat()*0.22f); }
            if (s.y[i] > b.bottom) { s.y[i] = b.bottom; s.vy[i] = -Math.abs(s.vy[i]) * (0.82f + random.nextFloat()*0.22f); }
        }

        private void drawAllStrokes(Phase phase, float intensity, float tension, float release, float after) {
            for (int i = 0; i < strokes.size(); i++) {
                StrokeEvent s = strokes.get(i);
                drawStroke(s, phase, intensity, tension, release, after);
            }
        }

        private void drawStroke(StrokeEvent s, Phase phase, float intensity, float tension, float release, float after) {
            // V17：真正做“头部游走显现 + 尾部同步缓慢消失”。
            // 不再只画当前一段，也不让整条笔触整体衰老；而是把同一条光迹按时间切成多层。
            // 每层都是过去某个瞬间的可见窗口：越靠近头部越亮，越靠尾部越淡。
            // FBO 再继续保留更旧的尾迹，形成 Windows Mystify 那种“后会有期”的淡出背影。
            float progress = clamp(s.age / Math.max(0.001f, s.life), 0f, 1f);
            float born = smooth(Math.min(1f, s.age / Math.max(0.001f, s.life * 0.08f)));
            if (born <= 0.015f) return;

            ArrayList<float[]> all = sampleStroke(s);
            if (all.size() < 2) return;

            int ca = s.colorA;
            int cb = s.colorB;
            float baseWidth = lerp(0.52f, 3.20f, cfg.ribbonWidth) * s.widthScale * (0.64f + intensity * 0.58f + release * 0.32f);
            float[] c1 = color4(ca, 1f);
            float[] c2 = color4(cb, 1f);
            float[] mix = new float[]{(c1[0]+c2[0])*0.5f, (c1[1]+c2[1])*0.5f, (c1[2]+c2[2])*0.5f, 1f};

            // 过去的窗口层数。trail 越长，尾巴越柔和、越慢退场。
            int layers = cfg.powerSave ? 7 : (10 + (int)(cfg.trail * 18f));
            float step = lerp(0.018f, 0.010f, cfg.trail);
            for (int layer = layers; layer >= 0; layer--) {
                float p = progress - layer * step;
                if (p <= -0.08f || p >= 1.18f) continue;
                ArrayList<float[]> pts = visibleSegmentAt(all, s, p);
                if (pts.size() < 2) continue;

                float depth = layer / Math.max(1f, (float)layers);
                float layerAlpha = born * (float)Math.pow(1f - depth, 2.15f) * (1f - after * 0.18f);
                if (layer == 0) layerAlpha *= 1.14f;
                if (layerAlpha <= 0.006f) continue;

                drawStrokeLayer(s, pts, phase, baseWidth, mix, layerAlpha, intensity, tension, release, layer == 0);
            }
        }

        private void drawStrokeLayer(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                     float[] mix, float alpha, float intensity, float tension, float release, boolean headLayer) {
            if (pts.size() < 2 || alpha <= 0.004f) return;
            if (s.fan && headLayer) {
                float nx = (float)Math.cos(s.seed + Math.PI / 2f);
                float ny = (float)Math.sin(s.seed + Math.PI / 2f);
                for (int k = s.fanLines; k >= 1; k--) {
                    float off = (k - s.fanLines * 0.5f) * s.fanGapPx * (0.75f + intensity);
                    drawTaperedStrip(offsetPoints(pts, nx * off, ny * off), baseWidth * 0.22f, mix[0], mix[1], mix[2], alpha * (0.018f + intensity * 0.030f));
                }
            }

            // V18/V26：先画“点线面”的纤维束。两位主体的形状要有差异：
            // actor1 更像锋利的冷色轨迹，actor2 更像柔软的暖色喷洒。
            drawFiberVeil(s, pts, baseWidth, mix[0], mix[1], mix[2], alpha, intensity, tension, release, headLayer);
            // V27：当轨迹进入同步/临界，偶尔展开成参考视频中的“粉紫/蓝绿扇形光网”。
            // 它不是装饰性烟花，而是把同一条光迹沿法线复制成渐开肋纹，靠 FBO 残影慢慢吞回黑场。
            if (headLayer || s.fan) {
                drawMystifyFanLattice(s, pts, phase, baseWidth, mix[0], mix[1], mix[2], alpha, intensity, tension, release);
            }

            float actorFace = s.actor == 1 ? 0.86f : (s.actor == 2 ? 1.14f : 1.0f);
            float actorLine = s.actor == 1 ? 0.92f : (s.actor == 2 ? 1.08f : 1.0f);
            // 面：宽而极淡，构成参考图里“喷洒在黑纸上”的半透明羽化面。
            drawTaperedStrip(pts, baseWidth * actorFace * (7.8f + tension * 1.8f), mix[0], mix[1], mix[2], alpha * (0.010f + intensity * 0.019f + release * 0.030f));
            // 线：主光带，仍然克制，避免蚯蚓感。
            drawTaperedStrip(pts, baseWidth * actorLine * (2.3f + tension * 0.55f), mix[0], mix[1], mix[2], alpha * (0.045f + intensity * 0.055f + release * 0.040f));
            drawTaperedStrip(pts, baseWidth * actorLine * (0.78f + tension * 0.15f), mix[0], mix[1], mix[2], alpha * (0.20f + intensity * 0.15f + release * 0.075f));
            if (headLayer) drawActorHeadCluster(s, pts, baseWidth, mix[0], mix[1], mix[2], alpha, intensity, tension, release);

            // 点线喷洒只在较新的层出现，旧层交给 FBO 变成淡淡残影。
            if (headLayer || alpha > 0.075f) {
                drawPointLineSpray(s, pts, phase, baseWidth, mix[0], mix[1], mix[2], alpha, intensity, tension, release);
            }
            // 核心亮线：极细，模拟 Windows 屏保里锋利的亮边。
            drawTaperedStrip(pts, Math.max(0.32f, baseWidth * 0.085f), 1f, 1f, 1f, alpha * (0.38f + intensity * 0.20f));
        }

        private void drawMystifyFanLattice(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                        float r, float g, float b, float alpha, float intensity,
                                        float tension, float release) {
            if (pts.size() < 5 || alpha <= 0.004f) return;
            boolean phaseAllows = phase.name.equals("同步") || phase.name.equals("临界") || phase.name.equals("释放");
            float chance = (s.fan ? 1.0f : 0.10f + cfg.randomness * 0.18f + tension * 0.18f);
            if (!phaseAllows && !s.fan) return;
            if (!s.fan && strokeHash(s, 0, 881) > chance) return;

            float[] first = pts.get(0);
            float[] last = pts.get(pts.size() - 1);
            float dx = last[0] - first[0];
            float dy = last[1] - first[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) return;
            float tx = dx / len;
            float ty = dy / len;
            float nx = -ty;
            float ny = tx;

            int ribs = s.fan ? Math.max(5, s.fanLines + 4) : 5 + (int)(cfg.randomness * 7f + tension * 4f);
            if (phase.name.equals("临界")) ribs += 3;
            if (phase.name.equals("释放")) ribs += 1;
            ribs = Math.min(18, Math.max(4, ribs));
            float spread = baseWidth * (5.8f + cfg.randomness * 4.8f + tension * 5.2f + release * 4.2f);
            float originBias = strokeHash(s, 1, 883) < 0.5f ? 0f : 1f;
            for (int j = 0; j < ribs; j++) {
                float jj = ribs == 1 ? 0f : (j / (float)(ribs - 1));
                float centered = (jj - 0.5f) * 2f;
                float hash = strokeHash(s, j, 887);
                float off = centered * spread * (0.55f + hash * 0.55f);
                float phaseShift = (strokeHash(s, j, 889) - 0.5f) * baseWidth * (1.2f + tension);
                ArrayList<float[]> rib = new ArrayList<>(pts.size());
                for (int i = 0; i < pts.size(); i++) {
                    float u = i / Math.max(1f, pts.size() - 1f);
                    float fanGrow = originBias < 0.5f ? smooth(u) : smooth(1f - u);
                    float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                    float shimmer = (float)Math.sin(u * Math.PI * 2.0f + s.seed * 1.7f + j * 0.41f)
                            * baseWidth * (0.35f + tension * 0.25f) * feather;
                    float[] p = pts.get(i);
                    rib.add(new float[]{
                            p[0] + nx * (off * fanGrow + shimmer) + tx * phaseShift * feather,
                            p[1] + ny * (off * fanGrow + shimmer) + ty * phaseShift * feather
                    });
                }
                float ribWidth = Math.max(0.22f, baseWidth * (0.040f + strokeHash(s, j, 891) * 0.060f));
                float ribAlpha = alpha * (0.020f + intensity * 0.026f + release * 0.030f) * (0.55f + hash * 0.70f);
                drawTaperedStrip(rib, ribWidth, r, g, b, ribAlpha);
            }

            // 扇面内增加极淡的横向折线，形成“电子纱/贝壳肋纹”的网感。
            int cross = Math.min(6, Math.max(2, ribs / 3));
            for (int k = 1; k <= cross; k++) {
                float u = k / (float)(cross + 1);
                int idx = clampInt((int)(u * (pts.size() - 1)), 1, pts.size() - 2);
                float[] p = pts.get(idx);
                float span = spread * (0.22f + 0.52f * (originBias < 0.5f ? smooth(u) : smooth(1f - u)));
                ArrayList<float[]> crossPts = new ArrayList<>(2);
                crossPts.add(new float[]{p[0] - nx * span, p[1] - ny * span});
                crossPts.add(new float[]{p[0] + nx * span, p[1] + ny * span});
                drawTaperedStrip(crossPts, Math.max(0.18f, baseWidth * 0.025f), r, g, b,
                        alpha * (0.008f + intensity * 0.014f + release * 0.012f));
            }
        }

        private void drawFiberVeil(StrokeEvent s, ArrayList<float[]> pts, float baseWidth,
                                   float r, float g, float b, float alpha, float intensity,
                                   float tension, float release, boolean headLayer) {
            if (pts.size() < 4 || alpha <= 0.004f) return;
            float[] first = pts.get(0);
            float[] last = pts.get(pts.size() - 1);
            float dx = last[0] - first[0];
            float dy = last[1] - first[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) return;
            float nx = -dy / len;
            float ny = dx / len;

            int strands = 5 + (int)(cfg.randomness * 5f + intensity * 4f);
            if (s.actor == 1) strands = Math.max(3, strands - 2);
            if (s.actor == 2) strands += 2;
            if (!headLayer) strands = Math.max(3, strands / 2);
            float spread = baseWidth * (1.2f + tension * 1.9f + release * 1.7f) * (s.actor == 2 ? 1.20f : 0.92f);
            for (int j = 0; j < strands; j++) {
                float h = strokeHash(s, j, 701);
                float h2 = strokeHash(s, j, 709);
                float side = (j - (strands - 1) * 0.5f) / Math.max(1f, (strands - 1f));
                float off = side * spread * (0.55f + h * 0.90f);
                float along = (h2 - 0.5f) * baseWidth * (1.0f + tension);
                ArrayList<float[]> strand = new ArrayList<>(pts.size());
                for (int i = 0; i < pts.size(); i++) {
                    float u = i / Math.max(1f, pts.size() - 1f);
                    float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                    float wave = (float)Math.sin(u * Math.PI * 2.0f + s.seed + j * 0.77f) * baseWidth * 0.28f * feather;
                    float[] p = pts.get(i);
                    strand.add(new float[]{p[0] + nx * (off + wave) + dx / len * along * feather,
                                           p[1] + ny * (off + wave) + dy / len * along * feather});
                }
                float strandWidth = Math.max(0.24f, baseWidth * (0.030f + strokeHash(s, j, 719) * 0.070f));
                float strandAlpha = alpha * (0.025f + intensity * 0.035f + release * 0.035f) * (0.45f + h * 0.80f);
                drawTaperedStrip(strand, strandWidth, r, g, b, strandAlpha);
            }
        }

        private ArrayList<float[]> offsetPoints(ArrayList<float[]> src, float dx, float dy) {
            ArrayList<float[]> out = new ArrayList<>(src.size());
            for (int i = 0; i < src.size(); i++) {
                float[] p = src.get(i);
                out.add(new float[]{p[0] + dx, p[1] + dy});
            }
            return out;
        }


        private void drawActorHeadCluster(StrokeEvent s, ArrayList<float[]> pts, float baseWidth,
                                          float r, float g, float b, float alpha,
                                          float intensity, float tension, float release) {
            if (pts.size() < 3 || alpha <= 0.004f) return;
            float[] head = pts.get(pts.size() - 1);
            float[] prev = pts.get(Math.max(0, pts.size() - 4));
            float dx = head[0] - prev[0];
            float dy = head[1] - prev[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) len = 1f;
            float tx = dx / len;
            float ty = dy / len;
            float nx = -ty;
            float ny = tx;
            int dots = s.actor == 2 ? 5 : 3;
            float cluster = baseWidth * (s.actor == 2 ? 2.6f : 1.7f) * (0.80f + tension * 0.40f + release * 0.50f);
            for (int i = 0; i < dots; i++) {
                float h1 = strokeHash(s, i, 901);
                float h2 = strokeHash(s, i, 907);
                float along = (-0.18f + h1 * 0.36f) * cluster;
                float side = (h2 - 0.5f) * 2f * cluster * (s.actor == 2 ? 0.95f : 0.45f);
                float x = head[0] + tx * along + nx * side;
                float y = head[1] + ty * along + ny * side;
                float rr = Math.max(0.40f, baseWidth * (s.actor == 2 ? 0.20f : 0.13f) * (0.55f + h1));
                drawCircle(x, y, rr, r, g, b, alpha * (s.actor == 2 ? 0.050f : 0.034f) * (0.7f + intensity), 10);
            }
            if (s.actor == 2) {
                for (int k = -1; k <= 1; k += 2) {
                    ArrayList<float[]> ray = new ArrayList<>(2);
                    float side = k * cluster * 0.72f;
                    ray.add(new float[]{head[0] - tx * cluster * 0.20f, head[1] - ty * cluster * 0.20f});
                    ray.add(new float[]{head[0] + tx * cluster * 0.55f + nx * side, head[1] + ty * cluster * 0.55f + ny * side});
                    drawTaperedStrip(ray, Math.max(0.24f, baseWidth * 0.045f), r, g, b, alpha * 0.035f);
                }
            }
        }

        private void drawPointLineSpray(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                        float r, float g, float b, float alpha, float intensity, float tension, float release) {
            if (pts.size() < 3 || alpha <= 0.004f) return;
            int n = pts.size();
            float minDim = Math.min(width, height);
            float lifeProgress = clamp(s.age / Math.max(0.001f, s.life), 0f, 1f);
            float headBias = lifeProgress < 0.55f ? smooth(lifeProgress / 0.55f) : 1f;
            float grainBase = phase.name.equals("分离") ? 5f : phase.name.equals("吸引") ? 9f : phase.name.equals("同步") ? 12f : phase.name.equals("临界") ? 18f : 11f;
            if (s.actor == 1) grainBase *= 0.72f;
            if (s.actor == 2) grainBase *= 1.35f;
            int grains = (int)(grainBase + cfg.randomness * (s.actor == 2 ? 11f : 6f) + release * 10f);
            float spray = baseWidth * (1.35f + tension * 1.55f) * (s.actor == 2 ? 1.18f : 0.88f) + minDim * (0.0010f + cfg.randomness * 0.0035f);

            for (int i = 0; i < grains; i++) {
                float h1 = strokeHash(s, i, 11);
                float h2 = strokeHash(s, i, 17);
                float h3 = strokeHash(s, i, 23);
                // 大部分颗粒落在当前光迹前部，少部分散落在尾部，形成“喷洒”而非等宽线条。
                float u = h1 < 0.68f ? lerp(0.58f, 1.0f, h2) : h2;
                u = clamp(lerp(u, headBias, 0.18f * intensity), 0f, 1f);
                int idx = clampInt((int)(u * (n - 1)), 1, n - 2);
                float[] p = pts.get(idx);
                float[] prev = pts.get(idx - 1);
                float[] next = pts.get(idx + 1);
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float tx = dx / len;
                float ty = dy / len;
                float nx = -ty;
                float ny = tx;
                float side = (h2 - 0.5f) * 2f;
                float along = (strokeHash(s, i, 31) - 0.5f) * spray * 0.72f;
                float normal = side * spray * (0.35f + strokeHash(s, i, 37) * 1.25f);
                // 临界/释放更像飞溅；分离更淡、更远。
                float phaseBoost = phase.name.equals("临界") ? 1.30f : phase.name.equals("释放") ? 1.55f : phase.name.equals("分离") ? 0.72f : 1.0f;
                float x = p[0] + tx * along + nx * normal * phaseBoost;
                float y = p[1] + ty * along + ny * normal * phaseBoost;
                float radius = Math.max(0.32f, baseWidth * (0.018f + strokeHash(s, i, 41) * 0.070f) + minDim * 0.00028f);
                float dotAlpha = alpha * (0.014f + 0.060f * intensity + release * 0.055f) * (0.35f + h3 * 0.60f);
                if (phase.name.equals("分离")) dotAlpha *= 0.55f;
                if (s.actor == 1) dotAlpha *= 0.78f;
                if (s.actor == 2) dotAlpha *= 1.18f;
                drawCircle(x, y, radius, r, g, b, dotAlpha, 10);

                // 少量短促微线，形成“点线组成”的笔触纹理，而不是一根孤立线。
                if (strokeHash(s, i, 53) < 0.46f + intensity * 0.20f) {
                    float seg = radius * (5.0f + strokeHash(s, i, 59) * 9.0f);
                    ArrayList<float[]> mini = new ArrayList<>(2);
                    mini.add(new float[]{x - tx * seg * 0.45f, y - ty * seg * 0.45f});
                    mini.add(new float[]{x + tx * seg * 0.55f, y + ty * seg * 0.55f});
                    drawTaperedStrip(mini, Math.max(0.22f, radius * 0.50f), r, g, b, dotAlpha * 0.38f);
                }
            }
        }

        private float strokeHash(StrokeEvent s, int i, int salt) {
            double v = Math.sin(s.seed * 12.9898 + i * 78.233 + salt * 37.719) * 43758.5453;
            return (float)(v - Math.floor(v));
        }

        private ArrayList<float[]> sampleStroke(StrokeEvent s) {
            ArrayList<float[]> pts = new ArrayList<>();
            if (s.count == 2) {
                for (int i = 0; i <= 18; i++) {
                    float t = i / 18f;
                    pts.add(new float[]{lerp(s.x[0], s.x[1], t), lerp(s.y[0], s.y[1], t)});
                }
                return pts;
            }
            int samplesPerSegment = 12;
            for (int i = 0; i < s.count - 1; i++) {
                float x0 = s.x[Math.max(0, i - 1)], y0 = s.y[Math.max(0, i - 1)];
                float x1 = s.x[i], y1 = s.y[i];
                float x2 = s.x[i + 1], y2 = s.y[i + 1];
                float x3 = s.x[Math.min(s.count - 1, i + 2)], y3 = s.y[Math.min(s.count - 1, i + 2)];
                for (int k = 0; k < samplesPerSegment; k++) {
                    float t = k / (float)samplesPerSegment;
                    pts.add(new float[]{catmull(x0, x1, x2, x3, t), catmull(y0, y1, y2, y3, t)});
                }
            }
            pts.add(new float[]{s.x[s.count - 1], s.y[s.count - 1]});
            return pts;
        }

        private ArrayList<float[]> visibleSegment(ArrayList<float[]> all, StrokeEvent s) {
            return visibleSegmentAt(all, s, clamp(s.age / Math.max(0.001f, s.life), 0f, 1f));
        }

        private ArrayList<float[]> visibleSegmentAt(ArrayList<float[]> all, StrokeEvent s, float progress) {
            ArrayList<float[]> out = new ArrayList<>();
            if (all.size() < 2) return out;

            // V17：移动窗口。head 继续向前“写出”，tail 同步跟进；
            // 不再把整条线画出来再整体淡死。
            float eased = smooth(clamp(progress, 0f, 1f));
            float window = clamp(s.visibleWindow, 0.22f, 0.62f);
            float head = lerp(-s.headLead, 1.0f + window + s.headLead, eased);
            float tail = head - window;
            if (tail >= 1.0f || head <= 0.0f) return out;
            float startF = clamp(tail, 0f, 1f);
            float endF = clamp(head, 0f, 1f);
            int start = clampInt((int)(startF * (all.size() - 1)), 0, all.size() - 2);
            int end = clampInt((int)(endF * (all.size() - 1)), start + 1, all.size() - 1);
            for (int i = start; i <= end; i++) out.add(all.get(i));
            // V18：过滤过短可见片段。Mystify/Ribbons 的观感不是“短点线残片”，
            // 而是一笔有势能、有长度、有消失背影的光迹。
            // 开头和结尾如果窗口太短，直接不画，让旧 FBO 残影自然承担退场。
            float minLen = Math.min(width, height) * 0.18f;
            if (polylineLength(out) < minLen) out.clear();
            return out;
        }

        private float polylineLength(ArrayList<float[]> pts) {
            float len = 0f;
            for (int i = 1; i < pts.size(); i++) {
                float[] a = pts.get(i - 1);
                float[] b = pts.get(i);
                float dx = b[0] - a[0];
                float dy = b[1] - a[1];
                len += (float)Math.sqrt(dx * dx + dy * dy);
            }
            return len;
        }

        private void drawTaperedStrip(ArrayList<float[]> pts, float widthPx, float r, float g, float b, float a) {
            if (pts.size() < 2 || a <= 0.001f || widthPx <= 0.05f) return;
            int n = pts.size();
            float[] verts = new float[n * 2 * 2];
            int vi = 0;
            for (int i = 0; i < n; i++) {
                float u = i / Math.max(1f, (n - 1f));
                float profile = (float)Math.pow(Math.max(0.0, Math.sin(Math.PI * u)), 1.22);
                float half = widthPx * 0.5f * (0.004f + 0.996f * profile);
                float[] prev = pts.get(Math.max(0, i - 1));
                float[] next = pts.get(Math.min(n - 1, i + 1));
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float x = pts.get(i)[0];
                float y = pts.get(i)[1];
                putNdc(verts, vi, x + nx * half, y + ny * half); vi += 2;
                putNdc(verts, vi, x - nx * half, y - ny * half); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void drawStrip(ArrayList<float[]> pts, float widthPx, float r, float g, float b, float a) {
            if (pts.size() < 2 || a <= 0.001f || widthPx <= 0.05f) return;
            int n = pts.size();
            float[] verts = new float[n * 2 * 2];
            int vi = 0;
            float half = widthPx * 0.5f;
            for (int i = 0; i < n; i++) {
                float[] prev = pts.get(Math.max(0, i - 1));
                float[] next = pts.get(Math.min(n - 1, i + 1));
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float x = pts.get(i)[0];
                float y = pts.get(i)[1];
                putNdc(verts, vi, x + nx * half, y + ny * half); vi += 2;
                putNdc(verts, vi, x - nx * half, y - ny * half); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void drawReleasePulse(float release, float after, Phase phase) {
            if (release <= 0.001f && (!cfg.bubbles || after <= 0.04f)) return;
            float x = pulseX * width;
            float y = pulseY * height;
            int[] colors = palette(cfg.style);
            if (release > 0.001f) {
                float maxR = Math.min(width, height) * (0.10f + 0.58f * release);
                float[] c = color4(colors[3], 1f);
                drawCircle(x, y, maxR, c[0], c[1], c[2], release * 0.09f, 48);
                drawCircle(x, y, maxR * 0.55f, 1f, 1f, 1f, release * 0.13f, 48);
                drawRing(x, y, maxR * 0.86f, Math.max(1.2f, maxR * 0.020f), c[0], c[1], c[2], release * 0.32f, 64);
            }
            if (cfg.bubbles && after > 0.08f) {
                for (int i = 0; i < 3; i++) {
                    float ang = (SystemClock.elapsedRealtime() / 1000f) * (0.05f + i * 0.018f) + i * 2.1f;
                    float rr = Math.min(width, height) * (0.04f + i * 0.028f + after * 0.08f);
                    float bx = x + (float)Math.cos(ang) * rr;
                    float by = y + (float)Math.sin(ang * 1.2f) * rr;
                    float[] c = color4(i % 2 == 0 ? colors[1] : colors[2], 1f);
                    drawRing(bx, by, Math.min(width, height) * (0.009f + i * 0.003f), 1.2f, c[0], c[1], c[2], after * 0.055f * (1f - i * 0.20f), 32);
                }
            }
        }

        private void drawCircle(float cx, float cy, float radius, float r, float g, float b, float a, int segments) {
            if (a <= 0f || radius <= 0f) return;
            float[] verts = new float[(segments + 2) * 2];
            putNdc(verts, 0, cx, cy);
            int vi = 2;
            for (int i = 0; i <= segments; i++) {
                float ang = i / (float)segments * (float)Math.PI * 2f;
                putNdc(verts, vi, cx + (float)Math.cos(ang) * radius, cy + (float)Math.sin(ang) * radius);
                vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_FAN, r, g, b, a);
        }

        private void drawRing(float cx, float cy, float radius, float widthPx, float r, float g, float b, float a, int segments) {
            if (a <= 0f || radius <= 0f || widthPx <= 0f) return;
            float[] verts = new float[(segments + 1) * 2 * 2];
            int vi = 0;
            for (int i = 0; i <= segments; i++) {
                float ang = i / (float)segments * (float)Math.PI * 2f;
                float co = (float)Math.cos(ang);
                float si = (float)Math.sin(ang);
                putNdc(verts, vi, cx + co * (radius + widthPx), cy + si * (radius + widthPx)); vi += 2;
                putNdc(verts, vi, cx + co * Math.max(0f, radius - widthPx), cy + si * Math.max(0f, radius - widthPx)); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void putNdc(float[] verts, int idx, float x, float y) {
            verts[idx] = x / Math.max(1f, width) * 2f - 1f;
            verts[idx + 1] = 1f - y / Math.max(1f, height) * 2f;
        }

        private void drawColorVertices(float[] verts, int mode, float r, float g, float b, float a) {
            GLES20.glUseProgram(colorProgram);
            int aPos = GLES20.glGetAttribLocation(colorProgram, "aPosition");
            int uColor = GLES20.glGetUniformLocation(colorProgram, "uColor");
            FloatBuffer buf = makeFloatBuffer(verts);
            GLES20.glEnableVertexAttribArray(aPos);
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, buf);
            GLES20.glUniform4f(uColor, r, g, b, clamp(a, 0f, 1f));
            GLES20.glDrawArrays(mode, 0, verts.length / 2);
            GLES20.glDisableVertexAttribArray(aPos);
        }

        private void drawTexture(int textureId, float fade) {
            float[] verts = new float[]{
                    -1f, -1f, 0f, 0f,
                     1f, -1f, 1f, 0f,
                    -1f,  1f, 0f, 1f,
                     1f,  1f, 1f, 1f
            };
            GLES20.glUseProgram(textureProgram);
            int aPos = GLES20.glGetAttribLocation(textureProgram, "aPosition");
            int aTex = GLES20.glGetAttribLocation(textureProgram, "aTexCoord");
            int uTex = GLES20.glGetUniformLocation(textureProgram, "uTexture");
            int uFade = GLES20.glGetUniformLocation(textureProgram, "uFade");
            FloatBuffer buf = makeFloatBuffer(verts);
            buf.position(0);
            GLES20.glEnableVertexAttribArray(aPos);
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, buf);
            buf.position(2);
            GLES20.glEnableVertexAttribArray(aTex);
            GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, buf);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
            GLES20.glUniform1i(uTex, 0);
            GLES20.glUniform1f(uFade, fade);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            GLES20.glDisableVertexAttribArray(aPos);
            GLES20.glDisableVertexAttribArray(aTex);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
        }

        private int createProgram(String vs, String fs) {
            int v = compileShader(GLES20.GL_VERTEX_SHADER, vs);
            int f = compileShader(GLES20.GL_FRAGMENT_SHADER, fs);
            int p = GLES20.glCreateProgram();
            GLES20.glAttachShader(p, v);
            GLES20.glAttachShader(p, f);
            GLES20.glLinkProgram(p);
            int[] ok = new int[1];
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
            GLES20.glDeleteShader(v);
            GLES20.glDeleteShader(f);
            if (ok[0] == 0) {
                GLES20.glDeleteProgram(p);
                return 0;
            }
            return p;
        }

        private int compileShader(int type, String source) {
            int s = GLES20.glCreateShader(type);
            GLES20.glShaderSource(s, source);
            GLES20.glCompileShader(s);
            int[] ok = new int[1];
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
            if (ok[0] == 0) {
                GLES20.glDeleteShader(s);
                return 0;
            }
            return s;
        }

        private FloatBuffer makeFloatBuffer(float[] data) {
            ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 4);
            bb.order(ByteOrder.nativeOrder());
            FloatBuffer fb = bb.asFloatBuffer();
            fb.put(data);
            fb.position(0);
            return fb;
        }

        private void deleteFbos() {
            if (fbo[0] != 0 || fbo[1] != 0) GLES20.glDeleteFramebuffers(2, fbo, 0);
            if (tex[0] != 0 || tex[1] != 0) GLES20.glDeleteTextures(2, tex, 0);
            fbo[0] = fbo[1] = tex[0] = tex[1] = 0;
            fboReady = false;
        }

        private void releaseGl() {
            try {
                deleteFbos();
                if (textureProgram != 0) GLES20.glDeleteProgram(textureProgram);
                if (colorProgram != 0) GLES20.glDeleteProgram(colorProgram);
                if (egl != null && eglDisplay != null) {
                    egl.eglMakeCurrent(eglDisplay, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                    if (eglSurface != null && eglSurface != EGL10.EGL_NO_SURFACE) egl.eglDestroySurface(eglDisplay, eglSurface);
                    if (eglContext != null && eglContext != EGL10.EGL_NO_CONTEXT) egl.eglDestroyContext(eglDisplay, eglContext);
                    egl.eglTerminate(eglDisplay);
                }
            } catch (Throwable ignored) {}
        }

        private void ensureCycleState(boolean force) {
            long wallNow = System.currentTimeMillis();
            String sig = cycleConfigSignature();
            long savedStart = prefs.getLong("cycleStartWallMs", 0L);
            float savedDuration = prefs.getFloat("cycleDurationSec", 0f);
            String savedSig = prefs.getString("cycleConfigSignature", "");
            boolean missing = savedStart <= 0L || savedDuration <= 0f;
            boolean configChanged = !sig.equals(savedSig);
            boolean completed = !missing && wallNow - savedStart >= (long)(savedDuration * 1000f);
            if (force || missing || configChanged || completed) {
                beginNewCycle(wallNow);
            } else {
                cycleStartWallMs = savedStart;
                cycleDurationSec = savedDuration;
                cycleCriticalStartSec = prefs.getFloat("cycleCriticalStartSec", 0f);
                cycleReleaseStartSec = prefs.getFloat("cycleReleaseStartSec", Math.max(0f, savedDuration - 60f));
                cycleReleaseDurationSec = prefs.getFloat("cycleReleaseDurationSec", 12f);
                cycleAfterglowDurationSec = prefs.getFloat("cycleAfterglowDurationSec", 24f);
                cycleCriticalDurationSec = prefs.getFloat("cycleCriticalDurationSec", 60f);
                cycleSignature = savedSig;
            }
        }

        private void beginNewCycle(long wallNow) {
            cycleStartWallMs = wallNow;
            cycleDurationSec = chooseCycleDurationSec();
            cycleSignature = cycleConfigSignature();
            CyclePlan plan = randomPlanForDuration(cycleDurationSec);
            cycleCriticalStartSec = plan.criticalStartSec;
            cycleReleaseStartSec = plan.releaseStartSec;
            cycleReleaseDurationSec = plan.releaseDurationSec;
            cycleAfterglowDurationSec = plan.afterglowDurationSec;
            cycleCriticalDurationSec = plan.criticalDurationSec;
            prefs.edit()
                    .putLong("cycleStartWallMs", cycleStartWallMs)
                    .putFloat("cycleDurationSec", cycleDurationSec)
                    .putFloat("cycleCriticalStartSec", cycleCriticalStartSec)
                    .putFloat("cycleReleaseStartSec", cycleReleaseStartSec)
                    .putFloat("cycleReleaseDurationSec", cycleReleaseDurationSec)
                    .putFloat("cycleAfterglowDurationSec", cycleAfterglowDurationSec)
                    .putFloat("cycleCriticalDurationSec", cycleCriticalDurationSec)
                    .putString("cycleConfigSignature", cycleSignature)
                    .apply();
            startMs = SystemClock.elapsedRealtime();
            nextSpawnSec = 0f;
            nextHardClearSec = 6f + random.nextFloat() * 12f;
            lastVisualSec = -1f;
            releasePulseArmed = true;
            strokes.clear();
            resetSpawnHeat();
            clearFbos();
        }

        private void clearFbos() {
            if (!fboReady) return;
            for (int i = 0; i < 2; i++) {
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[i]);
                GLES20.glClearColor(0f, 0f, 0f, 1f);
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            }
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
        }

        private float currentCycleElapsedSec() {
            if (cycleStartWallMs <= 0L) return (SystemClock.elapsedRealtime() - startMs) / 1000f;
            return Math.max(0f, (System.currentTimeMillis() - cycleStartWallMs) / 1000f);
        }

        private CyclePlan storedCyclePlan(float durationSec) {
            CyclePlan p = new CyclePlan();
            p.durationSec = durationSec;
            p.criticalStartSec = cycleCriticalStartSec;
            p.releaseStartSec = cycleReleaseStartSec;
            p.releaseDurationSec = cycleReleaseDurationSec;
            p.afterglowDurationSec = cycleAfterglowDurationSec;
            p.criticalDurationSec = cycleCriticalDurationSec;
            return p.sanitized();
        }

        private CyclePlan previewPlan(float durationSec) {
            // 预览模式仍遵守“只出现一次释放/余韵”，但把真实天级周期压缩到几分钟。
            CyclePlan p = new CyclePlan();
            p.durationSec = durationSec;
            float seedLike = stable01("preview-release");
            p.releaseDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioRelease, cfg.releaseMinSec, cfg.releaseMaxSec, false);
            p.afterglowDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioAfterglow, cfg.afterglowMinSec, cfg.afterglowMaxSec, false);
            p.criticalDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioCritical, cfg.criticalMinSec, cfg.criticalMaxSec, false);
            float latest = Math.max(1f, durationSec - p.releaseDurationSec - p.afterglowDurationSec - 1f);
            float earliest = Math.min(latest, Math.max(1f, durationSec * 0.34f));
            p.releaseStartSec = earliest + (latest - earliest) * seedLike;
            p.criticalStartSec = Math.max(0f, p.releaseStartSec - p.criticalDurationSec);
            return p.sanitized();
        }

        private CyclePlan randomPlanForDuration(float durationSec) {
            CyclePlan p = new CyclePlan();
            p.durationSec = durationSec;
            p.releaseDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioRelease, cfg.releaseMinSec, cfg.releaseMaxSec, true);
            p.afterglowDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioAfterglow, cfg.afterglowMinSec, cfg.afterglowMaxSec, true);
            p.criticalDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioCritical, cfg.criticalMinSec, cfg.criticalMaxSec, true);
            float minPre = Math.max(60f, Math.min(3600f, durationSec * 0.035f));
            float latest = Math.max(minPre, durationSec - p.releaseDurationSec - p.afterglowDurationSec - 60f);
            p.releaseStartSec = minPre + random.nextFloat() * Math.max(0f, latest - minPre);
            p.criticalStartSec = Math.max(0f, p.releaseStartSec - p.criticalDurationSec);
            return p.sanitized();
        }

        private float durationFromRatioAndRange(float totalSec, float ratio, float minSec, float maxSec, boolean randomize) {
            float min = Math.min(minSec, maxSec);
            float max = Math.max(minSec, maxSec);
            // 阶段比例给出该阶段在本轮周期中的目标长度；用户设置的秒级范围是硬边界。
            // 如果目标超出范围，就被钳制到范围内，因此“短阶段持续时间范围”一定真实生效。
            // 若目标位于范围内，随机项只做轻微扰动，避免每轮完全机械一致。
            float target = clamp(totalSec * Math.max(0.0001f, ratio), min, max);
            float jitter = randomize ? randRange(min, max) : stableRange(min, max, "dur-" + Math.round(totalSec) + ":" + Math.round(ratio * 10000f));
            return clamp(lerp(target, jitter, 0.22f), min, max);
        }

        private float stableRange(float a, float b, String salt) {
            float min = Math.min(a, b);
            float max = Math.max(a, b);
            return min + stable01(salt) * Math.max(0f, max - min);
        }

        private float stable01(String salt) {
            int h = (cycleSignature + ":" + salt).hashCode();
            long v = h & 0x7fffffffL;
            return (v % 1000000L) / 1000000f;
        }

        private float randRange(float a, float b) {
            float min = Math.min(a, b);
            float max = Math.max(a, b);
            return min + random.nextFloat() * Math.max(0f, max - min);
        }

        private float chooseCycleDurationSec() {
            float minDays = clamp(cfg.cycleMinDays, 1f, 365f);
            float maxDays = clamp(cfg.cycleMaxDays, minDays, 365f);
            float days;
            if (cfg.randomCycle) days = minDays + random.nextFloat() * Math.max(0f, maxDays - minDays);
            else days = clamp(cfg.fixedCycleDays, minDays, maxDays);
            return Math.max(86400f, days * 86400f);
        }

        private String cycleConfigSignature() {
            return cfg.randomCycle + ":" + Math.round(cfg.cycleMinDays * 10f) + ":" + Math.round(cfg.cycleMaxDays * 10f)
                    + ":" + Math.round(cfg.fixedCycleDays * 10f) + ":" + Math.round(cfg.ratioSeparation * 1000f)
                    + ":" + Math.round(cfg.ratioAttraction * 1000f) + ":" + Math.round(cfg.ratioSync * 1000f)
                    + ":" + Math.round(cfg.ratioCritical * 1000f) + ":" + Math.round(cfg.ratioRelease * 1000f)
                    + ":" + Math.round(cfg.ratioAfterglow * 1000f) + ":" + Math.round(cfg.criticalMinSec) + ":" + Math.round(cfg.criticalMaxSec)
                    + ":" + Math.round(cfg.releaseMinSec) + ":" + Math.round(cfg.releaseMaxSec)
                    + ":" + Math.round(cfg.afterglowMinSec) + ":" + Math.round(cfg.afterglowMaxSec);
        }

        private void readConfig(boolean force) {
            long now = SystemClock.elapsedRealtime();
            if (!force && !configDirty && now - lastConfigRead < 500L) return;
            lastConfigRead = now;
            configDirty = false;
            String oldVisualSignature = visualConfigSignature;
            cfg.style = prefs.getInt("style", 0);
            cfg.intimacy = prefs.getFloat("intimacy", 0.72f);
            cfg.randomness = prefs.getFloat("randomness", 0.68f);
            cfg.ribbonWidth = prefs.getFloat("ribbonWidth", 0.48f);
            cfg.trail = prefs.getFloat("trail", 0.84f);
            cfg.fullScreenCoverage = prefs.getFloat("fullScreenCoverage", 0.96f);
            cfg.strokeDensity = prefs.getFloat("strokeDensity", 0.36f);
            cfg.previewAccelerated = prefs.getBoolean("previewAccelerated", false);
            cfg.previewCycleMinutes = clamp(prefs.getFloat("previewCycleMinutes", 3f), 0.5f, 60f);
            cfg.debugLoopEnabled = prefs.getBoolean("debugLoopEnabled", false);
            cfg.debugCycleMinutes = clamp(prefs.getFloat("debugCycleMinutes", 3f), 1f, 60f);
            cfg.bubbles = prefs.getBoolean("bubbles", false);
            cfg.powerSave = prefs.getBoolean("powerSave", false);
            cfg.cycleMinDays = clamp(prefs.getFloat("cycleMinDays", 1f), 1f, 365f);
            cfg.cycleMaxDays = clamp(prefs.getFloat("cycleMaxDays", 365f), cfg.cycleMinDays, 365f);
            cfg.fixedCycleDays = clamp(prefs.getFloat("fixedCycleDays", 30f), cfg.cycleMinDays, cfg.cycleMaxDays);
            cfg.randomCycle = prefs.getBoolean("randomCycle", true);
            cfg.ratioSeparation = prefs.getFloat("ratioSeparation", 0.46f);
            cfg.ratioAttraction = prefs.getFloat("ratioAttraction", 0.22f);
            cfg.ratioSync = prefs.getFloat("ratioSync", 0.22f);
            cfg.ratioCritical = prefs.getFloat("ratioCritical", 0.06f);
            cfg.ratioRelease = prefs.getFloat("ratioRelease", 0.02f);
            cfg.ratioAfterglow = prefs.getFloat("ratioAfterglow", 0.02f);
            cfg.criticalMinSec = clamp(prefs.getFloat("criticalMinSec", 30f), 5f, 3600f);
            cfg.criticalMaxSec = clamp(prefs.getFloat("criticalMaxSec", 180f), cfg.criticalMinSec, 7200f);
            cfg.releaseMinSec = clamp(prefs.getFloat("releaseMinSec", 8f), 2f, 600f);
            cfg.releaseMaxSec = clamp(prefs.getFloat("releaseMaxSec", 24f), cfg.releaseMinSec, 1200f);
            cfg.afterglowMinSec = clamp(prefs.getFloat("afterglowMinSec", 20f), 3f, 1800f);
            cfg.afterglowMaxSec = clamp(prefs.getFloat("afterglowMaxSec", 90f), cfg.afterglowMinSec, 3600f);
            normalizeRatios(cfg);
            visualConfigSignature = buildVisualConfigSignature();
            if (force || !visualConfigSignature.equals(oldVisualSignature)) {
                strokes.clear();
                resetSpawnHeat();
                nextSpawnSec = 0f;
                nextHardClearSec = 6f + random.nextFloat() * 12f;
                startMs = SystemClock.elapsedRealtime();
                lastVisualSec = -1f;
                releasePulseArmed = true;
                if (fboReady) clearFbos();
            }
            ensureCycleState(force);
        }

        private String buildVisualConfigSignature() {
            return cfg.style + ":" + Math.round(cfg.intimacy * 1000f)
                    + ":" + Math.round(cfg.randomness * 1000f)
                    + ":" + Math.round(cfg.ribbonWidth * 1000f)
                    + ":" + Math.round(cfg.trail * 1000f)
                    + ":" + Math.round(cfg.fullScreenCoverage * 1000f)
                    + ":" + Math.round(cfg.strokeDensity * 1000f)
                    + ":" + cfg.debugLoopEnabled + ":" + Math.round(cfg.debugCycleMinutes * 1000f)
                    + ":" + cfg.bubbles + ":" + cfg.powerSave;
        }

        private void normalizeRatios(Config c) {
            c.ratioSeparation = Math.max(0.01f, c.ratioSeparation);
            c.ratioAttraction = Math.max(0.01f, c.ratioAttraction);
            c.ratioSync = Math.max(0.01f, c.ratioSync);
            c.ratioCritical = Math.max(0.005f, c.ratioCritical);
            c.ratioRelease = Math.max(0.002f, c.ratioRelease);
            c.ratioAfterglow = Math.max(0.002f, c.ratioAfterglow);
            float sum = c.ratioSeparation + c.ratioAttraction + c.ratioSync + c.ratioCritical + c.ratioRelease + c.ratioAfterglow;
            if (sum <= 0f) {
                c.ratioSeparation = 0.46f; c.ratioAttraction = 0.22f; c.ratioSync = 0.22f;
                c.ratioCritical = 0.06f; c.ratioRelease = 0.02f; c.ratioAfterglow = 0.02f;
                return;
            }
            c.ratioSeparation /= sum;
            c.ratioAttraction /= sum;
            c.ratioSync /= sum;
            c.ratioCritical /= sum;
            c.ratioRelease /= sum;
            c.ratioAfterglow /= sum;
        }

        private int[] palette(int style) {
            switch (Math.floorMod(style, 5)) {
                case 1: return new int[]{0xFF34D399, 0xFF67E8F9, 0xFF93C5FD, 0xFFFDE68A, 0xFF020617};
                case 2: return new int[]{0xFFA78BFA, 0xFFD8B4FE, 0xFFF472B6, 0xFFFFFFFF, 0xFF050316};
                case 3: return new int[]{0xFFE5E7EB, 0xFFFFFFFF, 0xFF93C5FD, 0xFFD1D5DB, 0xFF000000};
                case 4: return new int[]{0xFFFDE68A, 0xFFFFF7ED, 0xFFFB7185, 0xFFF97316, 0xFF06030A};
                default: return new int[]{0xFF7DD3FC, 0xFFC4B5FD, 0xFFF472B6, 0xFFFDE68A, 0xFF030712};
            }
        }

        private int pickColor(int[] colors) { return colors[random.nextInt(4)]; }
        private static float catmull(float p0, float p1, float p2, float p3, float t) {
            float t2 = t * t;
            float t3 = t2 * t;
            return 0.5f * ((2f * p1) + (-p0 + p2) * t + (2f*p0 - 5f*p1 + 4f*p2 - p3) * t2 + (-p0 + 3f*p1 - 3f*p2 + p3) * t3);
        }
        private float distance(float x0, float y0, float x1, float y1) {
            float dx = x1 - x0, dy = y1 - y0;
            return (float)Math.sqrt(dx * dx + dy * dy);
        }
        private float[] color4(int color, float alpha) {
            return new float[]{Color.red(color)/255f, Color.green(color)/255f, Color.blue(color)/255f, clamp(alpha, 0f, 1f)};
        }
        private static int clampInt(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }
        private static float clamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }
        private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
        private static float smooth(float x) { x = clamp(x, 0f, 1f); return x * x * (3f - 2f * x); }
        private static void sleepQuiet(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }

        private static final String TEXTURE_VERTEX =
                "attribute vec2 aPosition;\n" +
                "attribute vec2 aTexCoord;\n" +
                "varying vec2 vTexCoord;\n" +
                "void main(){ gl_Position = vec4(aPosition, 0.0, 1.0); vTexCoord = aTexCoord; }";
        private static final String TEXTURE_FRAGMENT =
                "precision mediump float;\n" +
                "uniform sampler2D uTexture;\n" +
                "uniform float uFade;\n" +
                "varying vec2 vTexCoord;\n" +
                // V27 phosphor decay：不是简单乘 fade，而是每帧轻微扣黑，
                // 让尾迹像参考视频那样先失彩、再变细、最后被黑场吞没。
                "void main(){ vec4 c = texture2D(uTexture, vTexCoord); vec3 rgb = max(c.rgb * uFade - vec3(0.00135), vec3(0.0)); rgb = pow(rgb, vec3(1.006)); gl_FragColor = vec4(rgb, 1.0); }";
        private static final String COLOR_VERTEX =
                "attribute vec2 aPosition;\n" +
                "void main(){ gl_Position = vec4(aPosition, 0.0, 1.0); }";
        private static final String COLOR_FRAGMENT =
                "precision mediump float;\n" +
                "uniform vec4 uColor;\n" +
                "void main(){ gl_FragColor = uColor; }";
    }

    static final class StrokeEvent {
        final int count;
        final float[] x, y, vx, vy;
        RectF bounds = new RectF();
        StrokeEvent partner;
        float age = 0f;
        float life = 3f;
        float seed = 0f;
        float widthScale = 1f;
        float speed = 80f;
        float turn = 0.4f;
        float relation = 0f;
        float visibleWindow = 0.26f;
        float headLead = 0.10f;
        float attractX = 0f;
        float attractY = 0f;
        int colorA = Color.WHITE;
        int colorB = Color.WHITE;
        int actor = 0;
        boolean fan = false;
        int fanLines = 0;
        float fanGapPx = 3f;

        StrokeEvent(int count) {
            this.count = Math.max(2, count);
            x = new float[this.count]; y = new float[this.count];
            vx = new float[this.count]; vy = new float[this.count];
        }
    }

    static final class Config {
        int style = 0;
        float intimacy = 0.72f;
        float randomness = 0.68f;
        float ribbonWidth = 0.48f;
        float trail = 0.84f;
        float fullScreenCoverage = 0.96f;
        float strokeDensity = 0.36f;
        boolean previewAccelerated = false;
        float previewCycleMinutes = 3f;
        boolean debugLoopEnabled = false;
        float debugCycleMinutes = 3f;
        boolean bubbles = false;
        boolean powerSave = false;
        boolean randomCycle = true;
        float cycleMinDays = 1f;
        float cycleMaxDays = 365f;
        float fixedCycleDays = 30f;
        float ratioSeparation = 0.46f;
        float ratioAttraction = 0.22f;
        float ratioSync = 0.22f;
        float ratioCritical = 0.06f;
        float ratioRelease = 0.02f;
        float ratioAfterglow = 0.02f;
        float criticalMinSec = 30f;
        float criticalMaxSec = 180f;
        float releaseMinSec = 8f;
        float releaseMaxSec = 24f;
        float afterglowMinSec = 20f;
        float afterglowMaxSec = 90f;
    }

    static final class CyclePlan {
        float durationSec = 86400f;
        float criticalStartSec = 0f;
        float releaseStartSec = 3600f;
        float releaseDurationSec = 12f;
        float afterglowDurationSec = 24f;
        float criticalDurationSec = 60f;
        private static float cpClamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }
        CyclePlan sanitized() {
            durationSec = Math.max(30f, durationSec);
            releaseDurationSec = cpClamp(releaseDurationSec, 1f, Math.max(1f, durationSec * 0.20f));
            afterglowDurationSec = cpClamp(afterglowDurationSec, 1f, Math.max(1f, durationSec * 0.20f));
            criticalDurationSec = cpClamp(criticalDurationSec, 1f, Math.max(1f, durationSec * 0.35f));
            releaseStartSec = cpClamp(releaseStartSec, 1f, Math.max(1f, durationSec - releaseDurationSec - afterglowDurationSec));
            criticalStartSec = cpClamp(releaseStartSec - criticalDurationSec, 0f, releaseStartSec);
            return this;
        }
    }

    static final class Phase {
        final String name;
        final float start, end, intensity, closeness, tension, relation, pairChance, fanChance;
        Phase(String name, float start, float end, float intensity, float closeness, float tension, float relation, float pairChance, float fanChance) {
            this.name = name;
            this.start = start;
            this.end = end;
            this.intensity = intensity;
            this.closeness = closeness;
            this.tension = tension;
            this.relation = relation;
            this.pairChance = pairChance;
            this.fanChance = fanChance;
        }
        static Phase of(float sec, float durationSec, Config cfg, CyclePlan plan) {
            float releaseStart = plan.releaseStartSec;
            float releaseEnd = releaseStart + plan.releaseDurationSec;
            float afterEnd = releaseEnd + plan.afterglowDurationSec;
            float criticalStart = plan.criticalStartSec;

            if (sec >= releaseStart && sec < releaseEnd) {
                return new Phase("释放", releaseStart, releaseEnd, 1.00f, 1.00f, 0.46f, 1.00f, 0.04f, 0.006f);
            }
            if (sec >= releaseEnd && sec < afterEnd) {
                return new Phase("余韵", releaseEnd, afterEnd, 0.22f, 0.54f, 0.08f, 0.12f, 0.02f, 0.004f);
            }
            if (sec >= criticalStart && sec < releaseStart) {
                return new Phase("临界", criticalStart, releaseStart, 0.96f, 0.92f, 1.00f, 0.92f, 0.16f, 0.025f);
            }
            if (sec >= afterEnd) {
                return new Phase("分离", afterEnd, durationSec, 0.08f, 0.00f, 0.04f, 0.00f, 0.00f, 0.004f);
            }

            float pre = Math.max(1f, criticalStart);
            float sum = Math.max(0.001f, cfg.ratioSeparation + cfg.ratioAttraction + cfg.ratioSync);
            float sepDur = pre * (cfg.ratioSeparation / sum);
            float attrDur = pre * (cfg.ratioAttraction / sum);
            float syncDur = Math.max(0f, pre - sepDur - attrDur);
            float sepEnd = sepDur;
            float attrEnd = sepEnd + attrDur;
            float syncEnd = attrEnd + syncDur;
            if (sec < sepEnd) return new Phase("分离", 0f, sepEnd, 0.08f, 0.00f, 0.04f, 0.00f, 0.00f, 0.004f);
            if (sec < attrEnd) return new Phase("吸引", sepEnd, attrEnd, 0.24f, 0.16f, 0.16f, 0.06f, 0.010f, 0.004f);
            return new Phase("同步", attrEnd, Math.max(attrEnd + 0.001f, syncEnd), 0.56f, 0.58f, 0.52f, 0.58f, 0.11f, 0.010f);
        }
    }
}
