package com.example.quote_app

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.example.quote_app.wallpaper.IntimacyMystifyWallpaperService

/**
 * Reliable live-wallpaper apply helper.
 *
 * On some OEM ROMs ACTION_CHANGE_LIVE_WALLPAPER can be accepted by startActivity()
 * but not visibly show a new page. Therefore this Activity no longer immediately
 * finishes after launching one Intent. It presents a small native helper page and
 * exposes several system entry points. If the exact preview really opens, this
 * Activity is stopped and then finishes; if nothing opens, the user remains on a
 * visible helper page instead of seeing a false "opened" toast in Flutter.
 */
class WallpaperApplyActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var attemptedAutoLaunch = false
    private var launchedExternalUi = false

    private val wallpaperComponent: ComponentName by lazy {
        ComponentName(this, IntimacyMystifyWallpaperService::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        handler.postDelayed({
            attemptedAutoLaunch = true
            launchExactPreview(showToastOnFailure = false)
        }, 250L)
    }

    override fun onStop() {
        super.onStop()
        // If a real system wallpaper page was opened, close this helper so Back returns
        // to the Flutter settings page instead of this intermediate Activity.
        if (launchedExternalUi) {
            finish()
            overridePendingTransition(0, 0)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
            setBackgroundColor(Color.rgb(4, 7, 18))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        root.addView(text("动态壁纸应用助手", 24f, true, Color.WHITE))
        root.addView(text(
            "如果系统没有自动跳转，请依次点击下面入口。进入系统页后必须选择“潮汐之间”，再点击“设置壁纸 / 应用”。",
            15f,
            false,
            Color.rgb(205, 213, 230)
        ).apply { setPadding(0, dp(10), 0, dp(18)) })

        root.addView(statusCard())
        root.addView(button("1. 打开本动态壁纸预览页", true) { launchExactPreview(true) })
        root.addView(button("2. 打开动态壁纸列表", false) { launchLiveWallpaperChooser(true) })
        root.addView(button("3. 打开系统壁纸设置", false) { launchWallpaperSettings(true) })
        root.addView(button("4. 打开通用壁纸选择器", false) { launchGenericWallpaperPicker(true) })
        root.addView(button("5. 打开本应用系统设置", false) { launchAppDetails(true) })
        root.addView(button("返回应用", false) { finish() })
    }

    private fun statusCard(): View {
        val info = WallpaperManager.getInstance(applicationContext).wallpaperInfo
        val active = info != null && info.packageName == packageName &&
                info.serviceName == IntimacyMystifyWallpaperService::class.java.name
        val msg = if (active) {
            "当前状态：潮汐之间动态壁纸已应用。"
        } else {
            "当前状态：尚未检测到潮汐之间成为当前动态壁纸。"
        }
        return text(msg, 14f, false, if (active) Color.rgb(185, 255, 205) else Color.rgb(232, 232, 238)).apply {
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.argb(72, 255, 255, 255), Color.argb(42, 255, 255, 255), dp(18))
        }
    }

    private fun launchExactPreview(showToastOnFailure: Boolean) {
        val exact = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
            putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, wallpaperComponent)
        }
        if (tryStart(exact)) return

        val legacy = Intent("android.service.wallpaper.CHANGE_LIVE_WALLPAPER").apply {
            putExtra("android.service.wallpaper.extra.LIVE_WALLPAPER_COMPONENT", wallpaperComponent)
        }
        if (tryStart(legacy)) return

        if (showToastOnFailure) toast("本机未响应指定动态壁纸预览入口，请尝试动态壁纸列表。")
    }

    private fun launchLiveWallpaperChooser(showToastOnFailure: Boolean) {
        if (tryStart(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))) return
        if (tryStart(Intent("android.service.wallpaper.LIVE_WALLPAPER_CHOOSER"))) return
        if (showToastOnFailure) toast("本机未提供标准动态壁纸列表入口，请尝试系统壁纸设置。")
    }

    private fun launchWallpaperSettings(showToastOnFailure: Boolean) {
        // Keep strings instead of SDK constants so older compileSdk environments do not fail.
        if (tryStart(Intent("android.settings.WALLPAPER_SETTINGS"))) return
        if (tryStart(Intent("android.intent.action.SET_WALLPAPER"))) return
        if (showToastOnFailure) toast("无法打开系统壁纸设置，请从手机系统设置中手动进入“壁纸/动态壁纸”。")
    }

    private fun launchGenericWallpaperPicker(showToastOnFailure: Boolean) {
        if (tryStart(Intent(Intent.ACTION_SET_WALLPAPER))) return
        if (showToastOnFailure) toast("无法打开通用壁纸选择器。")
    }

    private fun launchAppDetails(showToastOnFailure: Boolean) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
        }
        if (tryStart(intent)) return
        if (showToastOnFailure) toast("无法打开应用设置。")
    }

    private fun tryStart(intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            launchedExternalUi = true
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun text(s: String, size: Float, bold: Boolean, color: Int): TextView {
        return TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            lineSpacing = 0f, 1.18f
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
    }

    private fun button(label: String, primary: Boolean, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(if (primary) Color.rgb(10, 15, 30) else Color.WHITE)
            background = rounded(
                if (primary) Color.rgb(224, 231, 255) else Color.argb(52, 255, 255, 255),
                Color.argb(72, 255, 255, 255),
                dp(22)
            )
            setPadding(dp(12), dp(8), dp(12), dp(8))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(52)
            ).apply { topMargin = dp(10) }
            layoutParams = lp
            gravity = Gravity.CENTER
            setOnClickListener { action() }
        }
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(fill)
            cornerRadius = radius.toFloat()
            setStroke(1, stroke)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
}
