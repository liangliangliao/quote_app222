import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../platform/intimacy_wallpaper_bridge.dart';

class TouchMystifyWallpaperPage extends StatefulWidget {
  const TouchMystifyWallpaperPage({super.key});

  @override
  State<TouchMystifyWallpaperPage> createState() => _TouchMystifyWallpaperPageState();
}

class _TouchMystifyWallpaperPageState extends State<TouchMystifyWallpaperPage> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  Duration _elapsed = Duration.zero;

  int _style = 0;
  double _intimacy = 0.72;
  double _randomness = 0.60;
  double _ribbonWidth = 0.55;
  double _trail = 0.62;
  double _fullScreenCoverage = 0.96;
  double _strokeDensity = 0.46;
  bool _previewAccelerated = false;
  double _previewCycleMinutes = 3.0;
  bool _bubbles = true;
  bool _powerSave = false;
  bool _randomCycle = true;
  double _cycleMinDays = 1.0;
  double _cycleMaxDays = 365.0;
  double _fixedCycleDays = 30.0;
  double _ratioSeparation = 0.46;
  double _ratioAttraction = 0.22;
  double _ratioSync = 0.22;
  double _ratioCritical = 0.06;
  double _ratioRelease = 0.02;
  double _ratioAfterglow = 0.02;
  int _previewSeed = 7;

  final List<String> _styles = const ['Mystify 经典黑底', '深海蓝黑', '紫粉梦境', '银白冷光', '金色余韵'];

  @override
  void initState() {
    super.initState();
    _ticker = createTicker((elapsed) {
      setState(() => _elapsed = elapsed);
    })..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  Future<void> _saveAndOpen() async {
    final ok = await IntimacyWallpaperBridge.saveConfig(
      style: _style,
      intimacy: _intimacy,
      randomness: _randomness,
      ribbonWidth: _ribbonWidth,
      trail: _trail,
      fullScreenCoverage: _fullScreenCoverage,
      strokeDensity: _strokeDensity,
      previewAccelerated: _previewAccelerated,
      previewCycleMinutes: _previewCycleMinutes,
      bubbles: _bubbles,
      powerSave: _powerSave,
      randomCycle: _randomCycle,
      cycleMinDays: _cycleMinDays,
      cycleMaxDays: _cycleMaxDays,
      fixedCycleDays: _fixedCycleDays,
      ratioSeparation: _ratioSeparation,
      ratioAttraction: _ratioAttraction,
      ratioSync: _ratioSync,
      ratioCritical: _ratioCritical,
      ratioRelease: _ratioRelease,
      ratioAfterglow: _ratioAfterglow,
    );
    if (!mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('当前平台不支持 Android 动态壁纸设置')),
      );
      return;
    }
    await IntimacyWallpaperBridge.openLiveWallpaper();
  }

  Future<void> _saveOnly() async {
    final ok = await IntimacyWallpaperBridge.saveConfig(
      style: _style,
      intimacy: _intimacy,
      randomness: _randomness,
      ribbonWidth: _ribbonWidth,
      trail: _trail,
      fullScreenCoverage: _fullScreenCoverage,
      strokeDensity: _strokeDensity,
      previewAccelerated: _previewAccelerated,
      previewCycleMinutes: _previewCycleMinutes,
      bubbles: _bubbles,
      powerSave: _powerSave,
      randomCycle: _randomCycle,
      cycleMinDays: _cycleMinDays,
      cycleMaxDays: _cycleMaxDays,
      fixedCycleDays: _fixedCycleDays,
      ratioSeparation: _ratioSeparation,
      ratioAttraction: _ratioAttraction,
      ratioSync: _ratioSync,
      ratioCritical: _ratioCritical,
      ratioRelease: _ratioRelease,
      ratioAfterglow: _ratioAfterglow,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(ok ? '已保存壁纸参数，已安装的动态壁纸会自动读取新设置' : '当前平台不支持 Android 动态壁纸')),
    );
  }

  void _randomizePreview() {
    setState(() {
      _previewSeed = math.Random().nextInt(999999);
      _randomness = (0.28 + math.Random().nextDouble() * 0.52).clamp(0.0, 1.0).toDouble();
    });
  }

  @override
  Widget build(BuildContext context) {
    final seconds = _elapsed.inMilliseconds / 1000.0;
    return Scaffold(
      backgroundColor: const Color(0xFF050714),
      appBar: AppBar(
        title: const Text('触摸 · Mystify 亲密艺术壁纸'),
        backgroundColor: const Color(0xFF050714),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          _HeroPreview(
            seconds: seconds,
            style: _style,
            intimacy: _intimacy,
            randomness: _randomness,
            ribbonWidth: _ribbonWidth,
            trail: _trail,
            fullScreenCoverage: _fullScreenCoverage,
            bubbles: _bubbles,
            ratioSeparation: _ratioSeparation,
            ratioAttraction: _ratioAttraction,
            ratioSync: _ratioSync,
            ratioCritical: _ratioCritical,
            ratioRelease: _ratioRelease,
            ratioAfterglow: _ratioAfterglow,
            seed: _previewSeed,
          ),
          const SizedBox(height: 16),
          _IntroCard(),
          const SizedBox(height: 16),
          _SectionCard(
            title: '视觉风格',
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (int i = 0; i < _styles.length; i++)
                  ChoiceChip(
                    label: Text(_styles[i]),
                    selected: _style == i,
                    onSelected: (_) => setState(() => _style = i),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: '表达参数',
            child: Column(
              children: [
                _SliderRow(
                  label: '亲密张力',
                  value: _intimacy,
                  description: '控制两条生命轨迹从吸引、同步、缠绕到释放的戏剧强度。',
                  onChanged: (v) => setState(() => _intimacy = v),
                ),
                _SliderRow(
                  label: 'Mystify 随机性',
                  value: _randomness,
                  description: '控制轨迹变化莫测程度；越高越像随机屏保，但仍保持主线克制。',
                  onChanged: (v) => setState(() => _randomness = v),
                ),
                _SliderRow(
                  label: '光带宽度',
                  value: _ribbonWidth,
                  description: '控制主丝带的柔光厚度和高级感。',
                  onChanged: (v) => setState(() => _ribbonWidth = v),
                ),
                _SliderRow(
                  label: '残影长度',
                  value: _trail,
                  description: '控制 Windows Mystify 式拖尾；越高余韵越长。',
                  onChanged: (v) => setState(() => _trail = v),
                ),
                _SliderRow(
                  label: '全屏活动范围',
                  value: _fullScreenCoverage,
                  description: '控制随机运动点是否覆盖手机可见屏幕任意位置。默认接近全屏，避免线条只在中心或小区域活动。',
                  onChanged: (v) => setState(() => _fullScreenCoverage = v),
                ),
                _SliderRow(
                  label: '线条出现密度',
                  value: _strokeDensity,
                  description: '控制随机即时线条发生器的出生频率。过低更像黑场留白，过高更容易杂乱。',
                  onChanged: (v) => setState(() => _strokeDensity = v),
                ),
                SwitchListTile(
                  value: _bubbles,
                  onChanged: (v) => setState(() => _bubbles = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('余韵气泡/光尘', style: TextStyle(color: Colors.white)),
                  subtitle: const Text('只在释放后的余韵阶段少量出现，避免画面杂乱。', style: TextStyle(color: Colors.white60)),
                ),
                SwitchListTile(
                  value: _powerSave,
                  onChanged: (v) => setState(() => _powerSave = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('省电模式', style: TextStyle(color: Colors.white)),
                  subtitle: const Text('降低动态壁纸帧率，适合长期作为主屏/锁屏使用。', style: TextStyle(color: Colors.white60)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: '完整周期（以天为单位）',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SwitchListTile(
                  value: _randomCycle,
                  onChanged: (v) => setState(() => _randomCycle = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('每轮随机生成周期', style: TextStyle(color: Colors.white)),
                  subtitle: Text(
                    _randomCycle
                        ? '当前范围：${_cycleMinDays.round()}～${_cycleMaxDays.round()} 天。每完成一轮后，会重新随机生成下一轮周期。'
                        : '关闭后使用固定周期：${_fixedCycleDays.round()} 天。',
                    style: const TextStyle(color: Colors.white60),
                  ),
                ),
                SwitchListTile(
                  value: _previewAccelerated,
                  onChanged: (v) => setState(() => _previewAccelerated = v),
                  contentPadding: EdgeInsets.zero,
                  title: const Text('壁纸加速演示模式', style: TextStyle(color: Colors.white)),
                  subtitle: Text(
                    _previewAccelerated
                        ? '已开启：动态壁纸会用约 ${_previewCycleMinutes.toStringAsFixed(1)} 分钟演示完整过程，便于调试观察。正式使用建议关闭。'
                        : '关闭后按真实天数推进完整周期。若你想快速检查临界、释放、余韵，可以临时开启。',
                    style: const TextStyle(color: Colors.white60),
                  ),
                ),
                if (_previewAccelerated)
                  _MinuteSliderRow(
                    label: '演示周期',
                    value: _previewCycleMinutes,
                    min: 0.5,
                    max: 60.0,
                    onChanged: (v) => setState(() => _previewCycleMinutes = v),
                  ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: Text('随机范围：${_cycleMinDays.round()}～${_cycleMaxDays.round()} 天', style: const TextStyle(color: Colors.white70))),
                  ],
                ),
                RangeSlider(
                  values: RangeValues(_cycleMinDays, _cycleMaxDays),
                  min: 1.0,
                  max: 365.0,
                  divisions: 364,
                  labels: RangeLabels('${_cycleMinDays.round()}天', '${_cycleMaxDays.round()}天'),
                  onChanged: (values) {
                    setState(() {
                      _cycleMinDays = values.start.clamp(1.0, 365.0).toDouble();
                      _cycleMaxDays = values.end.clamp(_cycleMinDays, 365.0).toDouble();
                      _fixedCycleDays = _fixedCycleDays.clamp(_cycleMinDays, _cycleMaxDays).toDouble();
                    });
                  },
                ),
                if (!_randomCycle)
                  _DaySliderRow(
                    label: '固定周期',
                    value: _fixedCycleDays,
                    min: _cycleMinDays,
                    max: _cycleMaxDays,
                    onChanged: (v) => setState(() => _fixedCycleDays = v),
                  ),
                const Text(
                  '实际动态壁纸按真实天数推进；本页预览为了方便观察会加速演示，不代表真实壁纸周期。',
                  style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.35),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: '阶段出现频率',
            child: Column(
              children: [
                _RatioSliderRow(label: '分离', value: _ratioSeparation, description: '默认最大比例：黑场、留白、低频单线，表达两个生命仍处于分离状态。', onChanged: (v) => setState(() => _ratioSeparation = v)),
                _RatioSliderRow(label: '吸引', value: _ratioAttraction, description: '主要比例：线条从任意位置出现，彼此被牵引但尚未合一。', onChanged: (v) => setState(() => _ratioAttraction = v)),
                _RatioSliderRow(label: '同步', value: _ratioSync, description: '主要比例：两条轨迹节奏趋同，张力持续升高。', onChanged: (v) => setState(() => _ratioSync = v)),
                _RatioSliderRow(label: '临界', value: _ratioCritical, description: '小比例：短暂缠绕、压缩、接近峰值。', onChanged: (v) => setState(() => _ratioCritical = v)),
                _RatioSliderRow(label: '释放', value: _ratioRelease, description: '最小比例：短促柔光脉冲，避免变成烟花式爆炸。', onChanged: (v) => setState(() => _ratioRelease = v)),
                _RatioSliderRow(label: '余韵', value: _ratioAfterglow, description: '最小比例：残影、少量光尘、快速回到黑场。', onChanged: (v) => setState(() => _ratioAfterglow = v)),
                _PhaseRatioSummary(
                  separation: _ratioSeparation,
                  attraction: _ratioAttraction,
                  sync: _ratioSync,
                  critical: _ratioCritical,
                  release: _ratioRelease,
                  afterglow: _ratioAfterglow,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _randomizePreview,
                  icon: const Icon(Icons.auto_awesome),
                  label: const Text('随机新构图'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _saveOnly,
                  icon: const Icon(Icons.save_alt),
                  label: const Text('保存参数'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: _saveAndOpen,
              icon: const Icon(Icons.wallpaper),
              label: const Text('设置为主屏幕/锁屏动态壁纸'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            '说明：Android 会打开系统动态壁纸预览页，能否单独设置锁屏取决于手机系统/厂商。已安装壁纸会从本页读取最新参数。',
            style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.45),
          ),
        ],
      ),
    );
  }
}

class _IntroCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withOpacity(0.08),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: const Text(
        '设计思想：参考 Windows Mystify 屏保视频，不做具象身体描绘；用少量随机发光轨迹表达两个人从分离、吸引、同步到短暂临界、释放、余韵的完整过程。默认分离占最大比例，吸引和同步占主要比例，临界较少，释放和余韵最少；随机运动点默认覆盖手机可见屏幕任意位置，而不是局限在一小块区域；完整周期默认在 1～365 天之间随机生成；如需检查完整效果，可临时开启加速演示模式。',
        style: TextStyle(color: Colors.white70, height: 1.55),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white.withOpacity(0.06),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _SliderRow extends StatelessWidget {
  const _SliderRow({required this.label, required this.value, required this.description, required this.onChanged});
  final String label;
  final double value;
  final String description;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text('${(value * 100).round()}%', style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(value: value, onChanged: onChanged),
          Text(description, style: const TextStyle(color: Colors.white54, fontSize: 12, height: 1.35)),
        ],
      ),
    );
  }
}

class _DaySliderRow extends StatelessWidget {
  const _DaySliderRow({required this.label, required this.value, required this.min, required this.max, required this.onChanged});
  final String label;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    final safeMax = math.max(min, max);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text('${value.round()} 天', style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(
            value: value.clamp(min, safeMax).toDouble(),
            min: min,
            max: safeMax,
            divisions: math.max(1, (safeMax - min).round()),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}


class _MinuteSliderRow extends StatelessWidget {
  const _MinuteSliderRow({required this.label, required this.value, required this.min, required this.max, required this.onChanged});
  final String label;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text('${value.toStringAsFixed(1)} 分钟', style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(
            value: value.clamp(min, max).toDouble(),
            min: min,
            max: max,
            divisions: 119,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class _RatioSliderRow extends StatelessWidget {
  const _RatioSliderRow({required this.label, required this.value, required this.description, required this.onChanged});
  final String label;
  final double value;
  final String description;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Text(value.toStringAsFixed(3), style: const TextStyle(color: Colors.white60)),
            ],
          ),
          Slider(value: value.clamp(0.002, 0.70).toDouble(), min: 0.002, max: 0.70, onChanged: onChanged),
          Text(description, style: const TextStyle(color: Colors.white54, fontSize: 12, height: 1.35)),
        ],
      ),
    );
  }
}

class _PhaseRatioSummary extends StatelessWidget {
  const _PhaseRatioSummary({required this.separation, required this.attraction, required this.sync, required this.critical, required this.release, required this.afterglow});
  final double separation;
  final double attraction;
  final double sync;
  final double critical;
  final double release;
  final double afterglow;

  @override
  Widget build(BuildContext context) {
    final total = math.max(0.001, separation + attraction + sync + critical + release + afterglow);
    String pct(double v) => '${(v / total * 100).toStringAsFixed(1)}%';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: Colors.black.withOpacity(0.18),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Text(
        '归一化后：分离 ${pct(separation)} · 吸引 ${pct(attraction)} · 同步 ${pct(sync)} · 临界 ${pct(critical)} · 释放 ${pct(release)} · 余韵 ${pct(afterglow)}',
        style: const TextStyle(color: Colors.white60, fontSize: 12, height: 1.45),
      ),
    );
  }
}

class _HeroPreview extends StatelessWidget {
  const _HeroPreview({
    required this.seconds,
    required this.style,
    required this.intimacy,
    required this.randomness,
    required this.ribbonWidth,
    required this.trail,
    required this.fullScreenCoverage,
    required this.bubbles,
    required this.ratioSeparation,
    required this.ratioAttraction,
    required this.ratioSync,
    required this.ratioCritical,
    required this.ratioRelease,
    required this.ratioAfterglow,
    required this.seed,
  });

  final double seconds;
  final int style;
  final double intimacy;
  final double randomness;
  final double ribbonWidth;
  final double trail;
  final double fullScreenCoverage;
  final bool bubbles;
  final double ratioSeparation;
  final double ratioAttraction;
  final double ratioSync;
  final double ratioCritical;
  final double ratioRelease;
  final double ratioAfterglow;
  final int seed;

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 9 / 13,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: CustomPaint(
          painter: _MystifyPreviewPainter(
            seconds: seconds,
            style: style,
            intimacy: intimacy,
            randomness: randomness,
            ribbonWidth: ribbonWidth,
            trail: trail,
            fullScreenCoverage: fullScreenCoverage,
            bubbles: bubbles,
            ratioSeparation: ratioSeparation,
            ratioAttraction: ratioAttraction,
            ratioSync: ratioSync,
            ratioCritical: ratioCritical,
            ratioRelease: ratioRelease,
            ratioAfterglow: ratioAfterglow,
            seed: seed,
          ),
          child: Container(
            alignment: Alignment.topLeft,
            padding: const EdgeInsets.all(18),
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.24),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: Colors.white.withOpacity(0.12)),
              ),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Text('预览：实际壁纸以原生 Mystify 渲染为准', style: TextStyle(color: Colors.white70, fontSize: 12)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MystifyPreviewPainter extends CustomPainter {
  _MystifyPreviewPainter({
    required this.seconds,
    required this.style,
    required this.intimacy,
    required this.randomness,
    required this.ribbonWidth,
    required this.trail,
    required this.fullScreenCoverage,
    required this.bubbles,
    required this.ratioSeparation,
    required this.ratioAttraction,
    required this.ratioSync,
    required this.ratioCritical,
    required this.ratioRelease,
    required this.ratioAfterglow,
    required this.seed,
  });

  final double seconds;
  final int style;
  final double intimacy;
  final double randomness;
  final double ribbonWidth;
  final double trail;
  final double fullScreenCoverage;
  final bool bubbles;
  final double ratioSeparation;
  final double ratioAttraction;
  final double ratioSync;
  final double ratioCritical;
  final double ratioRelease;
  final double ratioAfterglow;
  final int seed;

  static const List<List<Color>> palettes = [
    [Color(0xFF7DD3FC), Color(0xFFC4B5FD), Color(0xFFF472B6), Color(0xFFFDE68A), Color(0xFF030712)],
    [Color(0xFF67E8F9), Color(0xFF93C5FD), Color(0xFFC4B5FD), Color(0xFFFDE68A), Color(0xFF020617)],
    [Color(0xFFA78BFA), Color(0xFFD8B4FE), Color(0xFFF9A8D4), Color(0xFFFFF7ED), Color(0xFF050316)],
    [Color(0xFFE5E7EB), Color(0xFFFFFFFF), Color(0xFF93C5FD), Color(0xFFD1D5DB), Color(0xFF000000)],
    [Color(0xFFFDE68A), Color(0xFFFFF7ED), Color(0xFFFB7185), Color(0xFFFACC15), Color(0xFF06030A)],
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final p = palettes[style % palettes.length];
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = p[4]);

    final cycle = 30.0;
    final u = (seconds % cycle) / cycle;
    final phase = _phase(u);
    final local = _smooth((u - phase.start) / math.max(0.001, phase.end - phase.start));
    final intensity = (phase.intensity * (0.72 + 0.56 * intimacy)).clamp(0.0, 1.2).toDouble();
    final closeness = (phase.closeness + math.sin(local * math.pi) * 0.06).clamp(0.0, 1.0).toDouble();
    final tension = (phase.tension * (0.70 + 0.70 * intimacy)).clamp(0.0, 1.2).toDouble();
    final release = phase.name == '释放' ? math.sin(local * math.pi) : 0.0;
    final after = phase.name == '余韵' ? local : 0.0;

    final cx = size.width * 0.5 + math.sin(seconds * 0.13 + seed) * size.width * 0.02;
    final cy = size.height * 0.52 + math.cos(seconds * 0.11 + seed) * size.height * 0.02;
    final center = Offset(cx, cy);

    final bg = Paint()
      ..shader = RadialGradient(
        colors: [p[1].withOpacity(0.24 + intensity * 0.14), p[2].withOpacity(0.08), Colors.transparent],
      ).createShader(Rect.fromCircle(center: center, radius: size.shortestSide * (0.34 + intensity * 0.25)));
    canvas.drawCircle(center, size.shortestSide * (0.34 + intensity * 0.25), bg);

    final dist = lerpDouble(size.shortestSide * 0.34, size.shortestSide * 0.05, closeness)!;
    final orbit = seconds * (0.45 + intensity * 0.45) + seed * 0.01;
    var a = center - Offset(math.cos(orbit) * dist, math.sin(orbit * 1.17) * dist * 0.66);
    var b = center + Offset(math.cos(orbit) * dist, math.sin(orbit * 1.17) * dist * 0.66);
    if (release > 0) {
      a = Offset.lerp(a, center, release * 0.94)!;
      b = Offset.lerp(b, center, release * 0.94)!;
    }

    for (int i = 0; i < 2; i++) {
      final rp = (seconds * (0.028 + intensity * 0.018) + i / 2) % 1.0;
      final rx = size.shortestSide * (0.10 + rp * 0.50);
      final ringPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0 + intensity * 2
        ..color = Colors.white.withOpacity((1 - rp) * (0.015 + intensity * 0.04));
      canvas.save();
      canvas.translate(cx, cy);
      canvas.rotate(seconds * 0.04 + i * 0.18);
      canvas.drawOval(Rect.fromCenter(center: Offset.zero, width: rx * 2, height: rx * (0.74 + intensity * 0.12)), ringPaint);
      canvas.restore();
    }

    _drawRibbon(canvas, size, a, p[0], p[1], seconds, -1, intensity, tension, release);
    _drawRibbon(canvas, size, b, p[2], p[3], seconds, 1, intensity, tension, release);

    if (release > 0 || after > 0) {
      final r = size.shortestSide * (0.05 + release * 0.72 + after * 0.14);
      final pulse = Paint()
        ..shader = RadialGradient(
          colors: [Colors.white.withOpacity(0.75 * release + 0.12 * after), p[3].withOpacity(0.28 * release), Colors.transparent],
        ).createShader(Rect.fromCircle(center: center, radius: r));
      canvas.drawCircle(center, r, pulse);
    }

    if (bubbles && after > 0.02) {
      final bubblePaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withOpacity(0.12 * after);
      for (int i = 0; i < 7; i++) {
        final ang = i / 7 * math.pi * 2 + seconds * 0.16;
        final rr = size.shortestSide * (0.12 + i * 0.028 + after * 0.18);
        canvas.drawCircle(center + Offset(math.cos(ang) * rr, math.sin(ang * 1.23) * rr * 0.66), size.shortestSide * (0.018 + i * 0.002), bubblePaint);
      }
    }

    final textPaint = TextPainter(
      text: TextSpan(text: phase.name, style: const TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.w600)),
      textDirection: TextDirection.ltr,
    )..layout();
    textPaint.paint(canvas, Offset(size.width - textPaint.width - 18, 18));
  }

  void _drawRibbon(Canvas canvas, Size size, Offset anchor, Color c1, Color c2, double t, int dir, double intensity, double tension, double release) {
    final points = <Offset>[];
    final count = 7;
    final seedLocal = seed * 0.013 + dir * 2.7;
    for (int i = 0; i < count; i++) {
      final rel = (i - (count - 1) / 2) / ((count - 1) / 2);
      final x = anchor.dx + rel * size.width * (0.11 + randomness * 0.05) + math.sin(t * (0.46 + randomness * 0.4) + i * 1.6 + seedLocal) * size.width * 0.045 * (0.5 + tension);
      final y = anchor.dy + math.sin(i * 0.92 + t * (0.65 + randomness * 0.4) + seedLocal) * size.height * (0.050 + tension * 0.02);
      points.add(Offset(x, y));
    }
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (int i = 1; i < points.length - 1; i++) {
      final mid = Offset.lerp(points[i], points[i + 1], 0.5)!;
      path.quadraticBezierTo(points[i].dx, points[i].dy, mid.dx, mid.dy);
    }
    path.lineTo(points.last.dx, points.last.dy);

    final w = (2.5 + ribbonWidth * 8.0) * (0.78 + intensity * 0.75 + release * 0.35);
    final shader = LinearGradient(colors: [c1.withOpacity(0.96), c2.withOpacity(0.96)]).createShader(Offset.zero & size);
    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..shader = shader
      ..strokeWidth = w * 4.8
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 1.7)
      ..color = Colors.white.withOpacity(0.36 + intensity * 0.22);
    canvas.drawPath(path, glow);

    final body = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..shader = shader
      ..strokeWidth = w * 1.45
      ..color = Colors.white.withOpacity(0.62 + intensity * 0.2);
    canvas.drawPath(path, body);

    final core = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = math.max(1.0, w * 0.18)
      ..color = Colors.white.withOpacity(0.78);
    canvas.drawPath(path, core);
  }

  _Phase _phase(double u) {
    final total = math.max(0.001, ratioSeparation + ratioAttraction + ratioSync + ratioCritical + ratioRelease + ratioAfterglow);
    final r0 = ratioSeparation / total;
    final r1 = ratioAttraction / total;
    final r2 = ratioSync / total;
    final r3 = ratioCritical / total;
    final r4 = ratioRelease / total;
    final s1 = r0;
    final s2 = s1 + r1;
    final s3 = s2 + r2;
    final s4 = s3 + r3;
    final s5 = s4 + r4;
    if (u < s1) return _Phase('分离', 0.0, s1, 0.06, 0.00, 0.04);
    if (u < s2) return _Phase('吸引', s1, s2, 0.20, 0.10, 0.12);
    if (u < s3) return _Phase('同步', s2, s3, 0.56, 0.58, 0.50);
    if (u < s4) return _Phase('临界', s3, s4, 0.96, 0.92, 1.00);
    if (u < s5) return _Phase('释放', s4, s5, 1.00, 1.00, 0.46);
    return _Phase('余韵', s5, 1.0, 0.22, 0.54, 0.08);
  }

  double _smooth(double x) {
    x = x.clamp(0.0, 1.0);
    return x * x * (3 - 2 * x);
  }

  @override
  bool shouldRepaint(covariant _MystifyPreviewPainter oldDelegate) => true;
}

class _Phase {
  const _Phase(this.name, this.start, this.end, this.intensity, this.closeness, this.tension);
  final String name;
  final double start;
  final double end;
  final double intensity;
  final double closeness;
  final double tension;
}
