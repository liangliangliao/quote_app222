package com.example.quote_app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import org.json.JSONObject

/**
 * 行为观察桌面小组件。
 *
 * Android AppWidget 不能承载复杂输入表单，因此这里采用低摩擦方案：
 * 1) 桌面小组件常驻显示 7 个观察层面入口；
 * 2) 点击层面后不打开完整 App，而是弹出一条可直接输入的通知；
 * 3) 用户在通知内输入一句话即可由 BehaviorObservationQuickRecordReceiver 原生落库。
 *
 * 如果通知权限未开启，则回退到打开对应层面的轻量表单页，避免点击无反馈。
 */
class BehaviorObservationWidgetProvider : AppWidgetProvider() {
  override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
    for (id in appWidgetIds) updateWidget(context, appWidgetManager, id)
  }

  override fun onReceive(context: Context, intent: Intent?) {
    super.onReceive(context, intent)
    if (intent?.action == ACTION_QUICK_LAYER) {
      val layer = intent.getStringExtra(EXTRA_LAYER) ?: "行为层面"
      val ok = NotifyHelper.sendBehaviorObservationWidgetQuickReply(context.applicationContext, layer)
      if (!ok) openLayerForm(context.applicationContext, layer)
    } else if (intent?.action == ACTION_REFRESH_WIDGET) {
      refreshAll(context.applicationContext)
    }
  }

  companion object {
    private const val ACTION_QUICK_LAYER = "com.example.quote_app.behavior_observation_widget.QUICK_LAYER"
    private const val ACTION_REFRESH_WIDGET = "com.example.quote_app.behavior_observation_widget.REFRESH"
    private const val EXTRA_LAYER = "layer"

    @JvmStatic
    fun refreshAll(context: Context) {
      val mgr = AppWidgetManager.getInstance(context)
      val cn = ComponentName(context, BehaviorObservationWidgetProvider::class.java)
      val ids = mgr.getAppWidgetIds(cn)
      for (id in ids) updateWidget(context, mgr, id)
    }

    @JvmStatic
    fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
      val views = RemoteViews(context.packageName, R.layout.behavior_observation_widget)
      bindLayer(context, views, appWidgetId, R.id.widget_btn_behavior, "行为层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_time, "时间层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_emotion, "情绪层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_cognition, "认知层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_result, "结果层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_environment, "环境层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_body, "身体状态层面")
      appWidgetManager.updateAppWidget(appWidgetId, views)
    }

    private fun bindLayer(context: Context, views: RemoteViews, appWidgetId: Int, viewId: Int, layer: String) {
      val intent = Intent(context, BehaviorObservationWidgetProvider::class.java).apply {
        action = ACTION_QUICK_LAYER
        putExtra(EXTRA_LAYER, layer)
        putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
      }
      val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      val requestCode = appWidgetId * 100 + (layer.hashCode() and 0x7fffffff) % 97
      val pi = PendingIntent.getBroadcast(context, requestCode, intent, flags)
      views.setOnClickPendingIntent(viewId, pi)
    }

    private fun openLayerForm(context: Context, layer: String) {
      val payload = JSONObject().apply {
        put("module", "behavior_tracking")
        put("route", "/behavior_tracking")
        put("templateKey", "notification_layer_select")
        put("entryMode", "desktop_widget_fallback")
        put("primaryLayer", layer)
        put("source", "desktop_widget")
      }.toString()
      val intent = Intent(context, MainActivity::class.java).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        putExtra("from_notification", true)
        putExtra("notif_type", "behavior_tracking")
        putExtra("payload", payload)
      }
      try { context.startActivity(intent) } catch (_: Throwable) {}
    }
  }
}
