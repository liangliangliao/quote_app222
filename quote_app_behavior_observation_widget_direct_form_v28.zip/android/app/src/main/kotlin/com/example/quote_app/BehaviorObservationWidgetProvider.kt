package com.example.quote_app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONObject

/**
 * 行为观察桌面小组件。
 *
 * V28 调整：小组件按钮不再弹出“可输入通知”。
 * 用户点击某个观察层面后，直接打开行为观察的轻量表单页，
 * 表单会预选对应层面，并只显示该层字段。
 *
 * 这样比“先弹通知、再输入一句话”更符合用户对桌面小组件的预期：
 * 点哪个层面，就进入哪个层面的结构化表单。
 */
class BehaviorObservationWidgetProvider : AppWidgetProvider() {
  override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
    for (id in appWidgetIds) updateWidget(context, appWidgetManager, id)
  }

  override fun onReceive(context: Context, intent: Intent?) {
    super.onReceive(context, intent)
    if (intent?.action == ACTION_REFRESH_WIDGET) {
      refreshAll(context.applicationContext)
    }
  }

  companion object {
    private const val ACTION_REFRESH_WIDGET = "com.example.quote_app.behavior_observation_widget.REFRESH"

    @JvmStatic
    fun refreshAll(context: Context) {
      val mgr = AppWidgetManager.getInstance(context)
      val cn = ComponentName(context, BehaviorObservationWidgetProvider::class.java)
      val ids = mgr.getAppWidgetIds(cn)
      for (id in ids) updateWidget(context, mgr, id)
    }

    @JvmStatic
    fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
      val views = RemoteViews(context.packageName, R.layout.behavior_observation_widget)
      bindLayer(context, views, appWidgetId, R.id.widget_btn_behavior, "行为层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_time, "时间层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_emotion, "情绪层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_cognition, "认知层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_result, "结果层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_environment, "环境层面")
      bindLayer(context, views, appWidgetId, R.id.widget_btn_body, "身体状态层面")
      appWidgetManager.updateAppWidget(appWidgetId, views)
    }

    private fun bindLayer(context: Context, views: RemoteViews, appWidgetId: Int, viewId: Int, layer: String) {
      val payload = JSONObject().apply {
        put("module", "behavior_tracking")
        put("route", "/behavior_tracking")
        put("templateKey", "notification_layer_select")
        put("entryMode", "desktop_widget_direct_form")
        put("primaryLayer", layer)
        put("source", "desktop_widget")
      }.toString()
      val intent = Intent(context, MainActivity::class.java).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        putExtra("from_notification", true)
        putExtra("notif_type", "behavior_tracking")
        putExtra("payload", payload)
        putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
      }
      val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      val requestCode = appWidgetId * 100 + (layer.hashCode() and 0x7fffffff) % 997
      val pi = PendingIntent.getActivity(context, requestCode, intent, flags)
      views.setOnClickPendingIntent(viewId, pi)
    }
  }
}
