package com.example.quote_app

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import com.example.quote_app.wallpaper.IntimacyMystifyWallpaperService

object IntimacyWallpaperChannel {
    private const val CHANNEL = "com.example.quote_app/intimacy_wallpaper"
    private const val PREFS = "intimacy_mystify_wallpaper"

    fun register(activity: Activity, engine: FlutterEngine) {
        MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
            try {
                when (call.method) {
                    "saveConfig" -> {
                        val prefs = activity.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        val editor = prefs.edit()
                        editor.putInt("style", numberArg(call, "style", 0.0).toInt())
                        editor.putFloat("intimacy", numberArg(call, "intimacy", 0.72).toFloat().coerceIn(0f, 1f))
                        editor.putFloat("randomness", numberArg(call, "randomness", 0.48).toFloat().coerceIn(0f, 1f))
                        editor.putFloat("ribbonWidth", numberArg(call, "ribbonWidth", 0.55).toFloat().coerceIn(0f, 1f))
                        editor.putFloat("trail", numberArg(call, "trail", 0.62).toFloat().coerceIn(0f, 1f))
                        editor.putBoolean("bubbles", call.argument<Boolean>("bubbles") ?: true)
                        editor.putBoolean("powerSave", call.argument<Boolean>("powerSave") ?: false)
                        editor.putBoolean("randomCycle", call.argument<Boolean>("randomCycle") ?: true)
                        editor.putFloat("cycleMinDays", numberArg(call, "cycleMinDays", 1.0).toFloat().coerceIn(1f, 365f))
                        editor.putFloat("cycleMaxDays", numberArg(call, "cycleMaxDays", 365.0).toFloat().coerceIn(1f, 365f))
                        editor.putFloat("fixedCycleDays", numberArg(call, "fixedCycleDays", 30.0).toFloat().coerceIn(1f, 365f))
                        editor.putFloat("ratioSeparation", numberArg(call, "ratioSeparation", 0.42).toFloat().coerceIn(0.001f, 1f))
                        editor.putFloat("ratioAttraction", numberArg(call, "ratioAttraction", 0.22).toFloat().coerceIn(0.001f, 1f))
                        editor.putFloat("ratioSync", numberArg(call, "ratioSync", 0.23).toFloat().coerceIn(0.001f, 1f))
                        editor.putFloat("ratioCritical", numberArg(call, "ratioCritical", 0.07).toFloat().coerceIn(0.001f, 1f))
                        editor.putFloat("ratioRelease", numberArg(call, "ratioRelease", 0.025).toFloat().coerceIn(0.001f, 1f))
                        editor.putFloat("ratioAfterglow", numberArg(call, "ratioAfterglow", 0.035).toFloat().coerceIn(0.001f, 1f))
                        editor.putLong("seed", System.currentTimeMillis() + (Math.random() * 1000000000.0).toLong())
                        editor.apply()
                        result.success(true)
                    }
                    "openLiveWallpaper" -> {
                        val component = ComponentName(activity, IntimacyMystifyWallpaperService::class.java)
                        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                            putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
                        }
                        try {
                            activity.startActivity(intent)
                        } catch (_: Throwable) {
                            activity.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                        }
                        result.success(true)
                    }
                    "isSupported" -> result.success(true)
                    else -> result.notImplemented()
                }
            } catch (t: Throwable) {
                result.error("INTIMACY_WALLPAPER", t.message ?: t.javaClass.simpleName, null)
            }
        }
    }

    private fun numberArg(call: MethodCall, name: String, fallback: Double): Double {
        val v = call.argument<Any>(name) ?: return fallback
        return when (v) {
            is Int -> v.toDouble()
            is Long -> v.toDouble()
            is Float -> v.toDouble()
            is Double -> v
            is Number -> v.toDouble()
            else -> fallback
        }
    }
}
