package com.example.quote_app

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import com.example.quote_app.wallpaper.IntimacyMystifyWallpaperService

object IntimacyWallpaperChannel {
    private const val CHANNEL = "com.example.quote_app/intimacy_wallpaper"
    private const val PREFS = "intimacy_mystify_wallpaper"

    fun register(activity: Activity, engine: FlutterEngine) {
        MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
            try {
                when (call.method) {
                    "saveConfig" -> {
                        val prefs = activity.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        val editor = prefs.edit()
                        editor.putInt("style", numberArg(call, "style", 0.0).toInt())
                        editor.putFloat("intimacy", numberArg(call, "intimacy", 0.72).toFloat().coerceIn(0f, 1f))
                        editor.putFloat("randomness", numberArg(call, "randomness", 0.48).toFloat().coerceIn(0f, 1f))
                        editor.putFloat("ribbonWidth", numberArg(call, "ribbonWidth", 0.42).toFloat().coerceIn(0f, 1f))
                        editor.putFloat("trail", numberArg(call, "trail", 0.72).toFloat().coerceIn(0f, 1f))
                        editor.putFloat("fullScreenCoverage", numberArg(call, "fullScreenCoverage", 0.92).toFloat().coerceIn(0f, 1f))
                        editor.putFloat("strokeDensity", numberArg(call, "strokeDensity", 0.28).toFloat().coerceIn(0f, 1f))
                        editor.putBoolean("previewAccelerated", call.argument<Boolean>("previewAccelerated") ?: false)
                        editor.putFloat("previewCycleMinutes", numberArg(call, "previewCycleMinutes", 3.0).toFloat().coerceIn(0.5f, 60f))
                        editor.putBoolean("bubbles", call.argument<Boolean>("bubbles") ?: false)
                        editor.putBoolean("powerSave", call.argument<Boolean>("powerSave") ?: false)
                        editor.putBoolean("randomCycle", call.argument<Boolean>("randomCycle") ?: true)
                        editor.putFloat("cycleMinDays", numberArg(call, "cycleMinDays", 1.0).toFloat().coerceIn(1f, 365f))
                        editor.putFloat("cycleMaxDays", numberArg(call, "cycleMaxDays", 365.0).toFloat().coerceIn(1f, 365f))
                        editor.putFloat("fixedCycleDays", numberArg(call, "fixedCycleDays", 30.0).toFloat().coerceIn(1f, 365f))
                        editor.putFloat("ratioSeparation", numberArg(call, "ratioSeparation", 0.46).toFloat().coerceIn(0.001f, 1f))
                        editor.putFloat("ratioAttraction", numberArg(call, "ratioAttraction", 0.22).toFloat().coerceIn(0.001f, 1f))
                        editor.putFloat("ratioSync", numberArg(call, "ratioSync", 0.22).toFloat().coerceIn(0.001f, 1f))
                        editor.putFloat("ratioCritical", numberArg(call, "ratioCritical", 0.06).toFloat().coerceIn(0.001f, 1f))
                        editor.putFloat("ratioRelease", numberArg(call, "ratioRelease", 0.02).toFloat().coerceIn(0.001f, 1f))
                        editor.putFloat("ratioAfterglow", numberArg(call, "ratioAfterglow", 0.02).toFloat().coerceIn(0.001f, 1f))
                        editor.putFloat("criticalMinSec", numberArg(call, "criticalMinSec", 30.0).toFloat().coerceIn(5f, 3600f))
                        editor.putFloat("criticalMaxSec", numberArg(call, "criticalMaxSec", 180.0).toFloat().coerceIn(5f, 7200f))
                        editor.putFloat("releaseMinSec", numberArg(call, "releaseMinSec", 8.0).toFloat().coerceIn(2f, 600f))
                        editor.putFloat("releaseMaxSec", numberArg(call, "releaseMaxSec", 24.0).toFloat().coerceIn(2f, 1200f))
                        editor.putFloat("afterglowMinSec", numberArg(call, "afterglowMinSec", 20.0).toFloat().coerceIn(3f, 1800f))
                        editor.putFloat("afterglowMaxSec", numberArg(call, "afterglowMaxSec", 90.0).toFloat().coerceIn(3f, 3600f))
                        editor.putLong("seed", System.currentTimeMillis() + (Math.random() * 1000000000.0).toLong())
                        editor.apply()
                        result.success(true)
                    }
                    "setLiveWallpaperDirect" -> {
                        val component = ComponentName(activity, IntimacyMystifyWallpaperService::class.java)
                        try {
                            // setWallpaperComponent is not available in the public SDK on all
                            // compileSdk / vendor combinations. Calling it directly breaks
                            // Kotlin compilation in those environments, so use reflection.
                            // If the platform blocks or does not expose it, return false and
                            // let Dart fall back to ACTION_CHANGE_LIVE_WALLPAPER preview.
                            val wm = WallpaperManager.getInstance(activity.applicationContext)
                            val method = WallpaperManager::class.java.getMethod(
                                "setWallpaperComponent",
                                ComponentName::class.java
                            )
                            method.invoke(wm, component)
                            result.success(true)
                        } catch (_: Throwable) {
                            result.success(false)
                        }
                    }
                    "openLiveWallpaper" -> {
                        val component = ComponentName(activity, IntimacyMystifyWallpaperService::class.java)
                        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                            putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
                        }
                        try {
                            activity.startActivity(intent)
                        } catch (_: Throwable) {
                            try {
                                activity.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                            } catch (_: Throwable) {
                                activity.startActivity(Intent(Intent.ACTION_SET_WALLPAPER))
                            }
                        }
                        result.success(true)
                    }
                    "isSupported" -> result.success(true)
                    else -> result.notImplemented()
                }
            } catch (t: Throwable) {
                result.error("INTIMACY_WALLPAPER", t.message ?: t.javaClass.simpleName, null)
            }
        }
    }

    private fun numberArg(call: MethodCall, name: String, fallback: Double): Double {
        val v = call.argument<Any>(name) ?: return fallback
        return when (v) {
            is Int -> v.toDouble()
            is Long -> v.toDouble()
            is Float -> v.toDouble()
            is Double -> v
            is Number -> v.toDouble()
            else -> fallback
        }
    }
}
