package com.example.quote_app

import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast

class BehaviorPresetRingtonePickActivity : Activity() {
  companion object { private const val REQ_PICK = 51042 }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    try {
      val current = BehaviorPresetAlarmSettings.getSoundUri(this).takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
      val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "选择预设行为闹钟铃声")
        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
        putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, current)
      }
      startActivityForResult(intent, REQ_PICK)
    } catch (t: Throwable) {
      Toast.makeText(this, "无法打开系统铃声选择器", Toast.LENGTH_SHORT).show()
      finish()
    }
  }

  @Deprecated("Deprecated in Android framework; suitable for this small picker proxy activity.")
  override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    super.onActivityResult(requestCode, resultCode, data)
    if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
      val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
        data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
      } else {
        @Suppress("DEPRECATION")
        data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
      }
      if (uri != null) {
        val title = BehaviorPresetAlarmSettings.titleForUri(this, uri.toString())
        BehaviorPresetAlarmSettings.set(this, uri.toString(), title, null, null)
        Toast.makeText(this, "已选择：$title", Toast.LENGTH_SHORT).show()
      }
    }
    finish()
  }
}
