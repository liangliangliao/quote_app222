package com.example.quote_app

import android.content.Context
import android.media.RingtoneManager
import android.net.Uri

object BehaviorPresetAlarmSettings {
  private const val PREFS = "behavior_preset_alarm_settings"
  private const val KEY_SOUND_URI = "sound_uri"
  private const val KEY_SOUND_TITLE = "sound_title"
  private const val KEY_VOLUME = "volume"
  private const val KEY_VIBRATE = "vibrate"

  @JvmStatic
  fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

  @JvmStatic
  fun defaultSoundUri(ctx: Context): String {
    return try {
      val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
      uri?.toString() ?: ""
    } catch (_: Throwable) { "" }
  }

  @JvmStatic
  fun getSoundUri(ctx: Context): String {
    val p = prefs(ctx)
    val saved = p.getString(KEY_SOUND_URI, null)
    return if (!saved.isNullOrBlank()) saved else defaultSoundUri(ctx)
  }

  @JvmStatic
  fun getSoundTitle(ctx: Context): String {
    val p = prefs(ctx)
    val saved = p.getString(KEY_SOUND_TITLE, null)
    if (!saved.isNullOrBlank()) return saved
    return titleForUri(ctx, getSoundUri(ctx)).ifBlank { "系统默认闹钟铃声" }
  }

  @JvmStatic
  fun getVolume(ctx: Context): Float {
    return prefs(ctx).getFloat(KEY_VOLUME, 1.0f).coerceIn(0.0f, 1.0f)
  }

  @JvmStatic
  fun isVibrateEnabled(ctx: Context): Boolean {
    return prefs(ctx).getBoolean(KEY_VIBRATE, true)
  }

  @JvmStatic
  fun set(ctx: Context, soundUri: String?, soundTitle: String?, volume: Float?, vibrate: Boolean?) {
    val editor = prefs(ctx).edit()
    if (soundUri != null) editor.putString(KEY_SOUND_URI, soundUri)
    if (soundTitle != null) editor.putString(KEY_SOUND_TITLE, soundTitle)
    if (volume != null) editor.putFloat(KEY_VOLUME, volume.coerceIn(0.0f, 1.0f))
    if (vibrate != null) editor.putBoolean(KEY_VIBRATE, vibrate)
    editor.apply()
  }

  @JvmStatic
  fun asMap(ctx: Context): HashMap<String, Any?> {
    return hashMapOf(
      "soundUri" to getSoundUri(ctx),
      "soundTitle" to getSoundTitle(ctx),
      "volume" to getVolume(ctx).toDouble(),
      "vibrate" to isVibrateEnabled(ctx)
    )
  }

  @JvmStatic
  fun titleForUri(ctx: Context, uriText: String?): String {
    if (uriText.isNullOrBlank()) return "系统默认闹钟铃声"
    return try {
      val ringtone = RingtoneManager.getRingtone(ctx.applicationContext, Uri.parse(uriText))
      ringtone?.getTitle(ctx.applicationContext) ?: "系统默认闹钟铃声"
    } catch (_: Throwable) { "系统默认闹钟铃声" }
  }
}
