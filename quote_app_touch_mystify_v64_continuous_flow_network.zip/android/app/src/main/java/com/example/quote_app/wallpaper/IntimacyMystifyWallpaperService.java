package com.example.quote_app.wallpaper;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.graphics.Color;
import android.graphics.RectF;
import android.opengl.GLES20;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;

/**
 * 发现之旅/触摸：Mystify 亲密艺术动态壁纸。
 *
 * V8 解决三个核心问题：
 * 1) 底层从 Canvas/Bitmap 升级为 OpenGL ES + FBO ping-pong 残影。
 *    真正采用“每帧即时绘制当前随机线条，上一帧只靠 FBO 残影衰减保留”的 Mystify 逻辑。
 * 2) 引入全屏 Stroke Event Generator：每条线从手机可见屏幕任意位置、任意边缘、任意角落、任意两点即时生成，
 *    并用热区采样器避免长期集中在一小块区域。
 * 3) 增加 phosphor decay、加色混合、扇形光网、纤维丝带、点线喷洒与棱镜余影，
 *    对齐参考视频里“黑场中彩色光迹生成、折叠、拖尾、淡出”的观感。
 * 5) V28 新增艺术导演：花瓣钩弧、叶片藤蔓、电子纱扇、银白折刃、菱形框片、长弓光桥等母型轮换，
 *    避免所有点线组成近似同一形状，也减少无组织散乱感。
 * 6) V29 新增“反重复生命系统”：母型冷却记忆、低差异黄金采样、非周期相位、深层变体、
 *    水母触须/星云涡旋/折纸光片/星座碎链，让长期播放更难出现雷同画面。
 * 7) V30 从“点线网状”升级为“雕塑形态”：液态光泡、羽翼、花冠、丝绸幕、能量环、晶体光片。
 * 8) V31 把余韵阶段升级为深蓝水域气泡；V32 去除大圆盘和旧小残泡，改为中心爆散的透明彩膜气泡。
 * 9) V33 进一步把气泡做成水晶薄膜：蓝色水域背景、透明折射感、随机爆散；同时在余韵/新周期做 FBO 清洁，避免旧线条留下脏痕。
 * 10) V34 把“释放”阶段从普通圆形脉冲升级为抽象能量爆发：白金光心、粗大放射光束、暖金/橙红辉光、
 *     高速碎光粒子洪流与短暂满屏白化；只借鉴爆发节奏与光效层次，不复制参考视频中的角色、武器或道具。
 * 11) V35 继续强化释放阶段的“突然颤抖 + 强刺激爆光 + 扫屏光柱 + 碎光洪流”：
 *     通过高频错位重影、短促白化、宽幅冲击楔面、斜切扫光和更密的抽象碎片，增强视频中先抖动再爆发的冲击。
 * 12) V36 把释放开头改为更短、更快、更剧烈的硬震颤；同时余韵气泡改为无 FBO 拖尾的逐帧水晶泡，
 *     避免移动时出现筒状重影/残影，只保留透明膜边、白色高光与轻微折射。
 * 13) V37 把释放震颤升级为“硬震屏错位”：按真实秒数驱动 0.5 秒可见强震窗口，加入全屏白闪、
 *     斜向撕裂光带、核心多重错帧和大幅跳变偏移，让肉眼明确看到先剧烈颤动再爆发。
 * 14) V38 把释放开头改为“冲击环同步硬震”：整组释放光效以更大幅度做高频跳变；
 *     震动持续到白金大圆冲击环扩张至最大半径，并在到达最大的一刻自动停止，后续只保留爆光、扫屏光柱和碎光外冲。
 * 15) V39 把震动频率从过高的微颤改为“低频硬切大位移”：冲击环未到最大前，每 70ms 左右整组释放光效跳到
 *     明显不同的位置，并绘制错位冲击环/屏幕撕裂光带；到最大半径后位移和错帧层立即归零，确保肉眼能看出震动。
 * 16) V40 把普通短笔触升级为“长形体生命旅程”：单个元素的连续变化时长可配置；形体会显形、游走、起伏、牵引、渐隐，
 *     而不是一闪而过。
 * 17) V41 把默认旅程时间收敛到 6～60 秒，并削弱大面积白色光幕：白色只做窄边高光，主体改用低透明蓝紫/金橙膜。
 *    大形体优先，细线只做边缘高光，不再让画面主要由细网格/点阵构成.
 * 18) V46 引入 Shape DNA：family/bodySdf/pathType/flowField/relationRole/lifeScript 成为一等基因，
 *     每个元素都以“出生→试探→牵引→纠缠→变形→离别”的生命路径演出。
 * 19) V46 引入隐式形体近似层：metaball 双泡、光膜胚胎、花冠、水母伞盖、晶体薄片、halo 和液态融合，
 *     让主元素从随机线条升级为有轮廓、有膜纹、有边缘高光的生命体。
 * 20) V46 引入 curl-like 生命运动场、Boids 释放碎光、Poisson 余韵泡分布与膜纹/脉络纹理，
 *     控制群体同频、避免局部扎堆和反复刷同一种形状。
 * 21) V47 引入“阶段呼吸式主体调度”：主形体出生间隔不再固定，而是根据性爱阶段、阶段进度、
 *     当前画面负载、形体寿命、亲密强度和随机呼吸共同决定；避免一阵过密，也避免跨阶段等待过久。
 * 22) V48 引入“非释放阶段白区限幅/去重影”：分离、吸引、同步、临界阶段的高亮宽带被限制在约 2～3mm，
 *     同时降低非释放阶段 FBO 残留和历史窗口叠加；释放与余韵阶段保持原有表现不变。
 * 23) V54 纠偏：V53 线束过暗、出生过疏、FBO 衰减过快导致真实桌面近乎全黑；
 *     本版切回“Windows Mystify 可见光迹”优先级：更高残影保留、更亮细线、更短空场补位、更多稳定主体。
 * 24) V55：根据用户上传的 Mystify 视频重新建模：改为“运动控制点 + 历史轨迹缓冲 + 延迟线束重绘”的经典屏保逻辑；
 *     形体来自多条延迟 Bezier 曲线和末端相位扇形，而不是单个随机对象或厚面形状。
 * 25) V56：按视频2再次校准：压低大面积厚光带，禁用旧 ShapeDNA 厚面主角，改为小舞台游走、细线束、历史丝网、
 *     端点扇形和黑场留白，避免视频1那种居中、巨幅、重复 S 形的发光幕布。
 * 26) V57：纠正 V56 过度局部化：恢复全屏控制点运动；引入“主体生命段落”——每个主体入场、变形、退场、清场、
 *     重生；并把分离、吸引、同步、临界、释放、余韵重新绑定到阶段递进，而不是让一个主体从头漂到尾。
 * 4) 保留天级宏观周期：分离最大，吸引/同步主要，临界较少，释放/余韵最少；所有比例和 1～365 天周期可配置.
 *
 * 动画只以抽象线条关系表达分离、吸引、同步、临界、释放、余韵，不出现任何具象身体或露骨画面。
 */
public class IntimacyMystifyWallpaperService extends WallpaperService {
    public static final String PREFS = "intimacy_mystify_wallpaper";

    @Override
    public Engine onCreateEngine() {
        return new MystifyEngine();
    }

    final class MystifyEngine extends Engine {
        private GLRenderThread renderThread;
        private boolean visible = false;

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            ensureThread(holder);
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            if (renderThread != null) renderThread.resize(width, height);
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            if (renderThread != null) renderThread.setVisible(visible);
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
        }

        @Override
        public void onDestroy() {
            if (renderThread != null) {
                renderThread.requestStop();
                renderThread = null;
            }
            super.onDestroy();
        }

        private void ensureThread(SurfaceHolder holder) {
            if (renderThread == null) {
                renderThread = new GLRenderThread(getApplicationContext(), holder, isPreview());
                renderThread.setVisible(visible);
                renderThread.start();
            }
        }
    }

    static final class GLRenderThread extends Thread {
        private static final int EGL_CONTEXT_CLIENT_VERSION = 0x3098;
        private static final int EGL_OPENGL_ES2_BIT = 4;
        private static final int GRID_COLS = 6;
        private static final int GRID_ROWS = 10;

        private final Context context;
        private final SurfaceHolder holder;
        private final boolean enginePreview;
        private final SharedPreferences prefs;
        private final OnSharedPreferenceChangeListener prefListener;
        private volatile boolean configDirty = true;
        private String visualConfigSignature = "";
        private static final int MOTIF_COUNT = 18;
        private static final int SCENE_PROGRAM_COUNT = 6;
        private static final int COLOR_MOOD_COUNT = 5;
        // V46 Shape DNA：family/bodySdf/pathType/flowField/relationRole/lifeScript
        // 不再只靠 motif 编号决定元素长相，而是先生成“生命基因”，再由基因导演运动与形体。
        private static final int FAMILY_MEMBRANE = 0;
        private static final int FAMILY_BLOSSOM = 1;
        private static final int FAMILY_JELLYFISH = 2;
        private static final int FAMILY_CRYSTAL = 3;
        private static final int FAMILY_LIQUID = 4;
        private static final int FAMILY_HALO = 5;
        private static final int FAMILY_TWIN_ORBIT = 6;
        private static final int SHAPE_FAMILY_COUNT = 7;
        private static final int SDF_ELLIPSE = 0;
        private static final int SDF_PETAL = 1;
        private static final int SDF_CAPSULE = 2;
        private static final int SDF_RING = 3;
        private static final int SDF_IMPLICIT_MERGE = 4;
        private static final int SDF_UMBRELLA = 5;
        private static final int SDF_SHARD = 6;
        private static final int BODY_SDF_COUNT = 7;
        private static final int PATH_DRIFT = 0;
        private static final int PATH_SPIRAL = 1;
        private static final int PATH_ATTRACT = 2;
        private static final int PATH_ORBIT = 3;
        private static final int PATH_BURST = 4;
        private static final int PATH_FAREWELL = 5;
        private static final int PATH_TYPE_COUNT = 6;
        private static final int FLOW_CURL_A = 0;
        private static final int FLOW_CURL_B = 1;
        private static final int FLOW_SHARED = 2;
        private static final int FLOW_EXPAND = 3;
        private static final int FLOW_FIELD_COUNT = 4;
        // V51 Master Contour Templates：明确的母体轮廓库，让形体先“有谱”，再做变奏。
        private static final int TEMPLATE_MEMBRANE_BREATH = 0;
        private static final int TEMPLATE_TWIN_LEAF = 1;
        private static final int TEMPLATE_BLOSSOM_CROWN = 2;
        private static final int TEMPLATE_JELLY_UMBRELLA = 3;
        private static final int TEMPLATE_CRYSTAL_SHARD = 4;
        private static final int TEMPLATE_LIQUID_LACE = 5;
        private static final int MASTER_TEMPLATE_COUNT = 6;

        // V49 Artist DNA：让主体不只是“能动”，而是更像艺术家组织出来的生命形体。
        private static final int ART_MEMBRANE_POETRY = 0;
        private static final int ART_BLOSSOM_RESONANCE = 1;
        private static final int ART_LIQUID_EMBRACE = 2;
        private static final int ART_CRYSTAL_GRACE = 3;
        private static final int ART_STYLE_COUNT = 4;
        private static final int SILHOUETTE_SIMPLE = 0;
        private static final int SILHOUETTE_TAPERED = 1;
        private static final int SILHOUETTE_ASYMMETRIC = 2;
        private static final int SILHOUETTE_TWIN_BALANCED = 3;
        private static final int DETAIL_SPARSE = 0;
        private static final int DETAIL_MEDIUM = 1;
        private static final int DETAIL_RICH = 2;
        private static final int EDGE_SOFT_GLOW = 0;
        private static final int EDGE_IRIDESCENT = 1;
        private static final int EDGE_WET_FILM = 2;
        private static final int EDGE_REFRACT = 3;
        private static final int TEXTURE_NONE = 0;
        private static final int TEXTURE_MEMBRANE = 1;
        private static final int TEXTURE_VEIN = 2;
        private static final int TEXTURE_RIPPLE = 3;
        private static final int TEXTURE_CRYSTAL = 4;
        private static final int RHYTHM_STILL = 0;
        private static final int RHYTHM_BREATHING = 1;
        private static final int RHYTHM_PULSING = 2;
        private static final int RHYTHM_BLOOMING = 3;
        private static final int COMPOSITION_HERO = 0;
        private static final int COMPOSITION_SUPPORT = 1;
        private static final int COMPOSITION_ECHO = 2;
        private static final int RESTRAINT_HIGH = 0;
        private static final int RESTRAINT_MEDIUM = 1;
        private static final int RESTRAINT_EXPRESSIVE = 2;
        private final Random random = new Random();
        private final ArrayList<StrokeEvent> strokes = new ArrayList<>();
        private final int[] spawnHeat = new int[GRID_COLS * GRID_ROWS];
        // V29：短期形态记忆。不是禁止重复，而是让最近出现过的母型降权，避免几分钟内
        // 反复看到同一种“线条整体轮廓”。
        private final int[] motifCooldown = new int[MOTIF_COUNT];
        // V44：章节级 Scene DNA。除了母型记忆，还记录最近的构图程序与色彩情绪，
        // 避免长期观看时总在重复同一类布局与同一套颜色关系。
        private final int[] sceneCooldown = new int[SCENE_PROGRAM_COUNT];
        private final int[] colorMoodCooldown = new int[COLOR_MOOD_COUNT];
        private final int[] shapeFamilyCooldown = new int[SHAPE_FAMILY_COUNT];
        private final int[] bodySdfCooldown = new int[BODY_SDF_COUNT];
        private final int[] pathTypeCooldown = new int[PATH_TYPE_COUNT];
        private final int[] masterTemplateCooldown = new int[MASTER_TEMPLATE_COUNT];
        private final int[] artStyleCooldown = new int[ART_STYLE_COUNT];
        private int artSpawnIndex = 0;

        // V55 Classic Mystify：从视频观察到的核心不是“出生/死亡的图形对象”，而是
        // 少量运动控制点在黑场中连续移动，系统反复重绘历史轨迹，形成延迟线束、扇形和丝滑拖尾。
        private static final int CLASSIC_CP = 28;
        private static final int CLASSIC_HISTORY = 1;
        private final float[] classicX = new float[CLASSIC_CP];
        private final float[] classicY = new float[CLASSIC_CP];
        private final float[] classicVX = new float[CLASSIC_CP];
        private final float[] classicVY = new float[CLASSIC_CP];
        private final float[] classicPrevX = new float[CLASSIC_CP];
        private final float[] classicPrevY = new float[CLASSIC_CP];
        private final float[] classicSeedA = new float[CLASSIC_CP];
        private final float[] classicSeedB = new float[CLASSIC_CP];
        private final float[] classicEdgeWeight = new float[CLASSIC_CP * CLASSIC_CP];
        private final float[] classicEdgePhase = new float[CLASSIC_CP * CLASSIC_CP];
        private final float[][] classicHistory = new float[CLASSIC_HISTORY][CLASSIC_CP * 2];
        private int classicHead = 0;
        private int classicFilled = 0;
        private float classicHue = random.nextFloat();
        private float classicSeed = random.nextFloat() * 1000f;
        private float classicShapeAge = 0f;
        // V57 full-screen subject cycle：不再把控制点锁进小舞台。
        // “像视频2”的部分只保留为细线束、历史丝网、端点扇形和黑场克制；
        // 运动范围恢复全屏，并通过主体寿命控制“生成—变形—退场—清场—重生”。
        private float classicRegionAge = 999f;
        private float classicRegionLife = 24f;
        private float classicCx = 0f;
        private float classicCy = 0f;
        private float classicRx = 1f;
        private float classicRy = 1f;
        private float classicSubjectLife = 12f;
        private float classicSubjectIntro = 0.90f;
        private float classicSubjectExit = 1.85f;
        private float classicNextMorphSec = 2.8f;
        private int classicSubjectOrdinal = 0;
        private int classicPatternMode = 0;
        private int classicTopologyMode = 0;
        private final float[] classicTargetX = new float[CLASSIC_CP];
        private final float[] classicTargetY = new float[CLASSIC_CP];
        private float classicGeneAngle = 0f;
        private float classicGeneSpan = 0.5f;
        private float classicGeneLift = 0.5f;
        private float classicGeneCurl = 1.0f;
        private float classicGeneSkew = 0f;
        private float classicGeneFold = 1.0f;
        private float classicGeneNoiseA = 1.0f;
        private float classicGeneNoiseB = 1.0f;
        private float classicGeneOrbit = 0.5f;
        private float classicGeneDrift = 0.5f;
        private float classicGeneTwist = 0.5f;
        private float classicGeneSplit = 0.5f;
        private float classicGenePhaseA = 0f;
        private float classicGenePhaseB = 0f;
        private float classicGenePhaseC = 0f;
        private float classicSoftMorphSec = 0.9f;
        private int classicGeneFamily = 0;
        private boolean classicReady = false;

        private volatile boolean running = true;
        private volatile boolean visible = false;
        private volatile int requestedWidth = 1;
        private volatile int requestedHeight = 1;
        private volatile boolean resizePending = true;

        private int width = 1;
        private int height = 1;
        private int spawnCounter = 0;

        private EGL10 egl;
        private EGLDisplay eglDisplay;
        private EGLConfig eglConfig;
        private EGLContext eglContext;
        private EGLSurface eglSurface;

        private int textureProgram = 0;
        private int colorProgram = 0;
        private int[] fbo = new int[]{0, 0};
        private int[] tex = new int[]{0, 0};
        private int readIndex = 0;
        private int writeIndex = 1;
        private boolean fboReady = false;

        private Config cfg = new Config();
        private long lastConfigRead = 0L;
        private long startMs = SystemClock.elapsedRealtime();
        private float nextSpawnSec = 0f;
        // V47：主体出生节奏不再是固定 delay，而是“阶段呼吸 + 画面负载反压 + 随机自然抖动”。
        private float spawnBreathPhase = random.nextFloat() * (float)Math.PI * 2f;
        private float spawnTempoMemory = 1f;
        private float lastMainSpawnSec = -9999f;
        private int phaseSpawnOrdinal = 0;
        private float nextHardClearSec = 8f;
        private long cycleStartWallMs = 0L;
        private float cycleDurationSec = 86400f;
        private float cycleCriticalStartSec = 0f;
        private float cycleReleaseStartSec = 0f;
        private float cycleReleaseDurationSec = 12f;
        private float cycleAfterglowDurationSec = 24f;
        private float cycleCriticalDurationSec = 60f;
        private float lastVisualSec = -1f;
        private String cycleSignature = "";
        private float pulseX = 0.5f;
        private float pulseY = 0.5f;
        private boolean releasePulseArmed = true;
        // V33：余韵气泡每一轮都使用新的随机种子；阶段切换时清理 FBO，避免上一阶段线条在桌面上留下灰黑痕迹。
        private int afterglowSeed = random.nextInt();
        private int releaseSeed = random.nextInt();
        private String lastPhaseName = "";

        GLRenderThread(Context context, SurfaceHolder holder, boolean enginePreview) {
            super("IntimacyMystifyGLRendererV57FullScreenPhaseCycle");
            this.context = context.getApplicationContext();
            this.holder = holder;
            this.enginePreview = enginePreview;
            this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            this.prefListener = new OnSharedPreferenceChangeListener() {
                @Override public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                    configDirty = true;
                }
            };
            this.prefs.registerOnSharedPreferenceChangeListener(this.prefListener);
            readConfig(true);
        }

        void setVisible(boolean visible) { this.visible = visible; }
        void requestStop() { running = false; interrupt(); }
        void resize(int w, int h) {
            if (w > 0 && h > 0) {
                requestedWidth = w;
                requestedHeight = h;
                resizePending = true;
            }
        }

        @Override
        public void run() {
            if (!initEgl()) return;
            try {
                initGlObjects();
                long last = SystemClock.elapsedRealtime();
                while (running) {
                    if (!visible) {
                        sleepQuiet(120);
                        last = SystemClock.elapsedRealtime();
                        continue;
                    }
                    long now = SystemClock.elapsedRealtime();
                    float dt = clamp((now - last) / 1000f, 0.001f, 0.055f);
                    last = now;
                    if (configDirty || now - lastConfigRead > 3000L) readConfig(false);
                    if (resizePending || !fboReady) {
                        applyResize();
                    }
                    renderFrame(now, dt);
                    egl.eglSwapBuffers(eglDisplay, eglSurface);
                    sleepQuiet(cfg.powerSave ? 38 : 18);
                }
            } catch (Throwable ignored) {
            } finally {
                try { prefs.unregisterOnSharedPreferenceChangeListener(prefListener); } catch (Throwable ignored) {}
                releaseGl();
            }
        }

        private boolean initEgl() {
            try {
                egl = (EGL10) EGLContext.getEGL();
                eglDisplay = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
                if (eglDisplay == EGL10.EGL_NO_DISPLAY) return false;
                int[] version = new int[2];
                if (!egl.eglInitialize(eglDisplay, version)) return false;
                int[] configAttrs = new int[]{
                        EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
                        EGL10.EGL_RED_SIZE, 8,
                        EGL10.EGL_GREEN_SIZE, 8,
                        EGL10.EGL_BLUE_SIZE, 8,
                        EGL10.EGL_ALPHA_SIZE, 8,
                        EGL10.EGL_DEPTH_SIZE, 0,
                        EGL10.EGL_STENCIL_SIZE, 0,
                        EGL10.EGL_NONE
                };
                EGLConfig[] configs = new EGLConfig[1];
                int[] num = new int[1];
                if (!egl.eglChooseConfig(eglDisplay, configAttrs, configs, 1, num) || num[0] <= 0) return false;
                eglConfig = configs[0];
                int[] ctxAttrs = new int[]{EGL_CONTEXT_CLIENT_VERSION, 2, EGL10.EGL_NONE};
                eglContext = egl.eglCreateContext(eglDisplay, eglConfig, EGL10.EGL_NO_CONTEXT, ctxAttrs);
                if (eglContext == EGL10.EGL_NO_CONTEXT) return false;
                eglSurface = egl.eglCreateWindowSurface(eglDisplay, eglConfig, holder, null);
                if (eglSurface == null || eglSurface == EGL10.EGL_NO_SURFACE) return false;
                return egl.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext);
            } catch (Throwable ignored) {
                return false;
            }
        }

        private void initGlObjects() {
            textureProgram = createProgram(TEXTURE_VERTEX, TEXTURE_FRAGMENT);
            colorProgram = createProgram(COLOR_VERTEX, COLOR_FRAGMENT);
            GLES20.glDisable(GLES20.GL_DEPTH_TEST);
            GLES20.glDisable(GLES20.GL_CULL_FACE);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            applyResize();
        }

        private void applyResize() {
            resizePending = false;
            width = Math.max(2, requestedWidth);
            height = Math.max(2, requestedHeight);
            GLES20.glViewport(0, 0, width, height);
            recreateFbos(width, height);
            strokes.clear();
            resetSpawnHeat();
            nextSpawnSec = 0f;
            spawnBreathPhase = random.nextFloat() * (float)Math.PI * 2f;
            spawnTempoMemory = 1f;
            lastMainSpawnSec = -9999f;
            phaseSpawnOrdinal = 0;
            nextHardClearSec = 6f + random.nextFloat() * 12f;
            afterglowSeed = random.nextInt();
            lastPhaseName = "";
            classicReady = false;
            classicFilled = 0;
            classicHead = 0;
            classicShapeAge = 0f;
            classicSubjectOrdinal = 0;
            classicTopologyMode = 0;
            classicNextMorphSec = 2.0f;
            classicSoftMorphSec = 0.9f;
            classicRegionAge = 999f;
            startMs = SystemClock.elapsedRealtime();
        }

        private void recreateFbos(int w, int h) {
            deleteFbos();
            GLES20.glGenTextures(2, tex, 0);
            GLES20.glGenFramebuffers(2, fbo, 0);
            for (int i = 0; i < 2; i++) {
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[i]);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
                GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null);
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[i]);
                GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, tex[i], 0);
                GLES20.glViewport(0, 0, w, h);
                GLES20.glClearColor(0f, 0f, 0f, 1f);
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            }
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
            readIndex = 0;
            writeIndex = 1;
            fboReady = true;
        }

        private void renderFrame(long nowMs, float dt) {
            if (!fboReady) return;
            ensureCycleState(false);

            // V25：新增“调试循环模式”。
            // debugLoopEnabled 会同时作用于 App 原生预览和真实桌面/锁屏动态壁纸，
            // 按分钟把一次完整过程无限循环，专门用于验证阶段比例和短阶段持续时间是否生效。
            // previewAccelerated 仍只作用于系统/应用预览，不影响正式壁纸。
            boolean useDebugLoop = cfg.debugLoopEnabled;
            boolean useAcceleratedPreview = !useDebugLoop && enginePreview && cfg.previewAccelerated;
            float durationSec = useDebugLoop
                    ? Math.max(60f, cfg.debugCycleMinutes * 60f)
                    : (useAcceleratedPreview ? Math.max(30f, cfg.previewCycleMinutes * 60f) : Math.max(1f, cycleDurationSec));

            float sec;
            if (useDebugLoop) {
                float raw = (SystemClock.elapsedRealtime() - startMs) / 1000f;
                sec = raw % durationSec;
            } else if (useAcceleratedPreview) {
                // 单次预览：只跑一次完整过程，不循环释放/余韵。
                float raw = (SystemClock.elapsedRealtime() - startMs) / 1000f;
                sec = Math.min(raw, Math.max(0.001f, durationSec - 0.001f));
            } else {
                sec = currentCycleElapsedSec();
                if (sec >= cycleDurationSec) {
                    beginNewCycle(System.currentTimeMillis());
                    sec = 0f;
                }
            }

            if (lastVisualSec >= 0f && sec + 0.20f < lastVisualSec) {
                // 只处理真实周期重置或配置变更造成的时间回退；演示模式不再循环。
                nextSpawnSec = 0f;
                spawnBreathPhase = random.nextFloat() * (float)Math.PI * 2f;
                spawnTempoMemory = 1f;
                lastMainSpawnSec = -9999f;
                phaseSpawnOrdinal = 0;
                nextHardClearSec = 6f + random.nextFloat() * 12f;
                strokes.clear();
                resetSpawnHeat();
                clearFbos();
                releasePulseArmed = true;
                afterglowSeed = random.nextInt();
                releaseSeed = random.nextInt();
                lastPhaseName = "";
                classicReady = false;
                classicFilled = 0;
                classicHead = 0;
                classicShapeAge = 0f;
            }
            lastVisualSec = sec;
            CyclePlan plan = (useDebugLoop || useAcceleratedPreview) ? previewPlan(durationSec) : storedCyclePlan(durationSec);
            Phase phase = Phase.of(sec, durationSec, cfg, plan);
            if (!phase.name.equals(lastPhaseName)) {
                String previousPhase = lastPhaseName;
                // V62：阶段切换不再 hard clear / 重置 classic。
                // hard clear 会让真实壁纸看起来像“一张张幻灯片”；现在只让阶段力连续改变运动场，旧痕迹交给 FBO 自然衰减。
                if (previousPhase != null && previousPhase.length() > 0) {
                    resetSpawnHeat();
                }
                // V34：进入释放时重置释放特效种子，并洗掉前段过多线条，让释放画面像一次干净、强烈的能量爆发。
                if (phase.name.equals("释放")) {
                    releaseSeed = random.nextInt();
                    resetSpawnHeat();
                    // V62：释放阶段也不硬清屏，避免阶段切换像幻灯片切页。
                }
                // 进入余韵时立即清空释放阶段的大形体残影，让气泡层从干净黑/蓝水域中出现。
                if (phase.name.equals("余韵") && cfg.bubbles) {
                    strokes.clear();
                    resetSpawnHeat();
                    afterglowSeed = random.nextInt();
                    nextSpawnSec = sec + 9999f;
                }
                // 余韵结束后也清一次，避免透明泡泡/旧光迹在桌面上留下截图里那种灰黑网状痕迹。
                if (phase.name.equals("分离") && "余韵".equals(previousPhase)) {
                    strokes.clear();
                    resetSpawnHeat();
                    nextSpawnSec = sec + 0.10f;
                }
                // V47：阶段切换时重置“呼吸节拍”，并把上一阶段留下的过长等待截短。
                // 例如分离阶段刚安排了很久以后再出生，进入吸引/同步后不能继续傻等；
                // 释放阶段也应有短促起手，而不是继承同步阶段的长间隔。
                phaseSpawnOrdinal = 0;
                spawnBreathPhase = random.nextFloat() * (float)Math.PI * 2f;
                if (!(phase.name.equals("余韵") && cfg.bubbles)) {
                    nextSpawnSec = Math.min(nextSpawnSec, sec + adaptivePhaseIntroDelay(phase, sec));
                }
                lastPhaseName = phase.name;
            }
            float rawLocal = clamp((sec - phase.start) / Math.max(0.001f, phase.end - phase.start), 0f, 1f);
            float local = smooth(rawLocal);
            float release = phase.name.equals("释放") ? (float)Math.sin(local * Math.PI) : 0f;
            float after = phase.name.equals("余韵") ? local : 0f;
            float intensity = clamp(phase.intensity * (0.74f + 0.52f * cfg.intimacy), 0f, 1.30f);
            float tension = clamp(phase.tension * (0.72f + 0.56f * cfg.intimacy), 0f, 1.35f);

            if (!phase.name.equals("释放")) releasePulseArmed = true;
            if (phase.name.equals("释放") && releasePulseArmed) {
                float[] p = pickLeastUsedPoint(false);
                pulseX = p[0] / Math.max(1f, width);
                pulseY = p[1] / Math.max(1f, height);
                releaseSeed = random.nextInt();
                releasePulseArmed = false;
            }

            // V64：彻底停用旧 StrokeEvent 出生/死亡系统。
            // 旧系统会按生命周期“生成主体、播放主体、删除主体”，这正是幻灯片感的根源。
            // 现在画面只由 continuous classic flow field + FBO 残影产生。
            if (!strokes.isEmpty()) strokes.clear();
            nextSpawnSec = sec + 9999f;
            updateClassicMystify(sec, dt, phase, intensity, tension, release);

            // Windows Mystify 的“离开”不是突然清除，也不是对象死亡，而是上一帧缓慢被黑场吞没。
            // 因此这里不再定时 hard clear，只做 FBO 反馈衰减；trail 越高，背影越慢消失。
            // V17：Windows Mystify 的背影是“慢慢被黑场吞没”，不是快速衰亡。
            // 这里提高最低残留，让尾部能在头部继续游走时同步、缓慢、淡淡退场。
            float fade = lerp(0.944f, 0.980f, cfg.trail);
            if (phase.name.equals("余韵") && cfg.bubbles) {
                // V36：气泡不是依靠 FBO 拖尾移动。每帧先清空旧帧，再绘制当前透明泡，
                // 彻底避免截图中那种随运动拉成长筒的重影/残影。
                fade = 0.0f;
            } else if (phase.name.equals("余韵")) {
                fade = Math.min(fade, 0.955f);
            }
            if (phase.name.equals("释放")) fade = Math.min(fade, lerp(0.780f, 0.900f, cfg.trail));
            // V48：只约束分离/吸引/同步/临界。释放与余韵不动。
            // 截图中的大面积白块通常来自宽面 + FBO 长残留 + 多历史窗口叠加，
            // 所以这里把非释放阶段的残影寿命压短，让旧白面快速被黑场吞没。
            if (!isReleaseOrAfterglowPhase(phase)) fade = Math.min(fade, lerp(0.948f, 0.972f, cfg.trail));
            if (cfg.powerSave) fade = Math.min(fade, 0.946f);

            // 1) FBO 残影：把上一帧纹理衰减写入新 FBO。
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[writeIndex]);
            GLES20.glViewport(0, 0, width, height);
            GLES20.glDisable(GLES20.GL_BLEND);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            drawTexture(tex[readIndex], fade);

            // 2) 即时绘制当前随机线条。旧线条历史不由对象保存，只由 FBO 残影留下。
            GLES20.glEnable(GLES20.GL_BLEND);
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE);
            // V64：只绘制连续流场网络。主体不是对象，不出生、不死亡、不播放。
            drawClassicMystifyField(sec, phase, intensity, tension, release);
            // V64：禁用旧释放/余韵对象层。那些层会额外生成可识别主体，容易再次产生“幻灯片/换主体”错觉。
            // 释放、余韵改由 classic 连续流场的力学参数表达。
            GLES20.glDisable(GLES20.GL_BLEND);

            // 3) 输出到真实壁纸 Surface。
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
            GLES20.glViewport(0, 0, width, height);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            drawTexture(tex[writeIndex], 1f);

            int tmp = readIndex;
            readIndex = writeIndex;
            writeIndex = tmp;
        }

        private void initClassicMystify(Phase phase) {
            retargetClassicRegion(true);
            reseedClassicSubject(phase, false);
        }

        private void retargetClassicRegion(boolean force) {
            if (width <= 2 || height <= 2) return;
            float minDim = Math.max(1f, Math.min(width, height));
            classicRegionAge = 0f;
            classicRegionLife = 9999f;
            // V57：恢复全屏运动 envelope。这里不再是“小舞台”，只作为全屏中心/半径的数学参考。
            classicCx = width * 0.5f;
            classicCy = height * 0.5f;
            classicRx = width * 0.5f + minDim * 0.10f;
            classicRy = height * 0.5f + minDim * 0.10f;
        }

        private void reseedClassicSubject(Phase phase, boolean clearTrail) {
            if (width <= 2 || height <= 2) return;
            float minDim = Math.max(1f, Math.min(width, height));
            classicSubjectOrdinal++;
            classicPatternMode = chooseClassicPatternMode(phase);
            classicTopologyMode = chooseClassicTopologyMode(phase);
            randomizeClassicGenes(phase, true);
            // V61：classic 不再有“主体生命”。阶段内只存在持续运动的角点系统。
            classicSubjectLife = 999999f;
            classicSubjectIntro = 0.20f;
            classicSubjectExit = 0.60f;
            classicNextMorphSec = 0.80f + random.nextFloat() * 1.60f;
            classicSoftMorphSec = 0.20f + random.nextFloat() * 0.70f;
            classicHue = fract(classicHue + 0.13f + random.nextFloat() * 0.39f);
            classicSeed = random.nextFloat() * 1000f + classicSubjectOrdinal * 17.17f;
            classicShapeAge = 0f;
            fillClassicControlPointsFullScreen(phase, minDim);
            classicHead = 0;
            classicFilled = 0;
            for (int h = 0; h < CLASSIC_HISTORY; h++) {
                for (int i = 0; i < CLASSIC_CP; i++) {
                    classicHistory[h][i * 2] = classicX[i];
                    classicHistory[h][i * 2 + 1] = classicY[i];
                }
            }
            if (clearTrail && fboReady) clearFbos();
            classicReady = true;
        }

        private int chooseClassicPatternMode(Phase phase) {
            int mode = random.nextInt(7);
            if (phase.name.equals("分离")) mode = random.nextBoolean() ? 5 : mode;
            else if (phase.name.equals("吸引")) mode = random.nextBoolean() ? 0 : mode;
            else if (phase.name.equals("同步")) mode = random.nextBoolean() ? 2 : mode;
            else if (phase.name.equals("临界")) mode = random.nextBoolean() ? 3 : mode;
            else if (phase.name.equals("释放")) mode = random.nextBoolean() ? 6 : mode;
            if (mode == classicPatternMode && random.nextFloat() < 0.72f) mode = (mode + 1 + random.nextInt(6)) % 7;
            return mode;
        }

        private int chooseClassicTopologyMode(Phase phase) {
            int mode = random.nextInt(6);
            if (phase.name.equals("分离") && random.nextFloat() < 0.38f) mode = 4;
            if (phase.name.equals("同步") && random.nextFloat() < 0.32f) mode = 2;
            if (phase.name.equals("临界") && random.nextFloat() < 0.36f) mode = 3;
            if (phase.name.equals("释放") && random.nextFloat() < 0.42f) mode = 5;
            if (mode == classicTopologyMode && random.nextFloat() < 0.65f) mode = (mode + 1 + random.nextInt(5)) % 6;
            return mode;
        }

        private float chooseClassicSubjectLife(Phase phase) {
            float span = Math.max(2.5f, phase.end - phase.start);
            float lo = 4.8f, hi = 9.2f;
            if (phase.name.equals("分离")) { lo = 5.4f; hi = 10.8f; }
            else if (phase.name.equals("吸引")) { lo = 4.6f; hi = 8.8f; }
            else if (phase.name.equals("同步")) { lo = 4.0f; hi = 7.8f; }
            else if (phase.name.equals("临界")) { lo = 3.0f; hi = 5.6f; }
            else if (phase.name.equals("释放")) { lo = 1.8f; hi = 3.6f; }
            else if (phase.name.equals("余韵")) { lo = 5.0f; hi = 9.8f; }
            float life = lo + random.nextFloat() * Math.max(0.1f, hi - lo);
            // 让单个主体更像视频2：存活更短、变形和换代更快，不会一条线霸屏太久。
            life = Math.min(life, Math.max(1.9f, span * 0.48f));
            return Math.max(1.8f, life);
        }

        private void fillClassicControlPointsFullScreen(Phase phase, float minDim) {
            // V64：初始化的是“流场采样粒子”，不是主体轮廓。
            // 后续形状只来自这些点在连续向量场中的运动与边权的渐变连接。
            float margin = minDim * 0.08f;
            for (int i = 0; i < CLASSIC_CP; i++) {
                float x = width * (0.06f + 0.88f * random.nextFloat());
                float y = height * (0.10f + 0.80f * random.nextFloat());
                if (phase.name.equals("分离")) {
                    x = (i % 2 == 0) ? width * (0.05f + 0.30f * random.nextFloat()) : width * (0.65f + 0.30f * random.nextFloat());
                }
                classicX[i] = clamp(x, -margin, width + margin);
                classicY[i] = clamp(y, -margin, height + margin);
                classicPrevX[i] = classicX[i];
                classicPrevY[i] = classicY[i];
                classicSeedA[i] = random.nextFloat() * 1000f + i * 17.31f;
                classicSeedB[i] = random.nextFloat() * 1000f + i * 29.73f;
                float a = (float)(random.nextFloat() * Math.PI * 2.0);
                float spd = minDim * (0.018f + random.nextFloat() * 0.046f) * phaseSpeedSeed(phase);
                classicVX[i] = (float)Math.cos(a) * spd;
                classicVY[i] = (float)Math.sin(a) * spd;
            }
            for (int i = 0; i < CLASSIC_CP; i++) {
                for (int j = 0; j < CLASSIC_CP; j++) {
                    int idx = edgeIndex(i, j);
                    classicEdgeWeight[idx] = 0f;
                    classicEdgePhase[idx] = random.nextFloat() * (float)Math.PI * 2f + (i * 0.91f - j * 0.67f);
                }
            }
        }

        private void randomizeClassicGenes(Phase phase, boolean hard) {
            if (hard || random.nextFloat() < 0.60f) classicGeneFamily = random.nextInt(9);
            if (phase.name.equals("分离") && random.nextFloat() < 0.42f) classicGeneFamily = 8;
            if (phase.name.equals("同步") && random.nextFloat() < 0.36f) classicGeneFamily = 5;
            if (phase.name.equals("释放") && random.nextFloat() < 0.40f) classicGeneFamily = 4 + random.nextInt(3);
            classicGeneAngle = random.nextFloat() * (float)Math.PI * 2f;
            classicGeneSpan = 0.22f + random.nextFloat() * 0.76f;
            classicGeneLift = 0.12f + random.nextFloat() * 0.82f;
            classicGeneCurl = 0.55f + random.nextFloat() * 2.80f;
            classicGeneSkew = -1f + random.nextFloat() * 2f;
            classicGeneFold = 0.35f + random.nextFloat() * 2.60f;
            classicGeneNoiseA = 0.55f + random.nextFloat() * 3.20f;
            classicGeneNoiseB = 0.55f + random.nextFloat() * 3.20f;
            classicGeneOrbit = random.nextFloat();
            classicGeneDrift = random.nextFloat();
            classicGeneTwist = random.nextFloat();
            classicGeneSplit = random.nextFloat();
            classicGenePhaseA = random.nextFloat() * (float)Math.PI * 2f;
            classicGenePhaseB = random.nextFloat() * (float)Math.PI * 2f;
            classicGenePhaseC = random.nextFloat() * (float)Math.PI * 2f;
        }

        private void mutateClassicGenes(Phase phase, float amount) {
            float a = clamp(amount, 0f, 1.35f);
            if (random.nextFloat() < 0.12f + 0.40f * a) classicGeneFamily = random.nextInt(9);
            classicGeneAngle += (random.nextFloat() - 0.5f) * 1.90f * a;
            classicGeneSpan = clamp(classicGeneSpan + (random.nextFloat() - 0.5f) * 0.60f * a, 0.16f, 1.02f);
            classicGeneLift = clamp(classicGeneLift + (random.nextFloat() - 0.5f) * 0.55f * a, 0.08f, 1.05f);
            classicGeneCurl = clamp(classicGeneCurl + (random.nextFloat() - 0.5f) * 2.40f * a, 0.25f, 3.80f);
            classicGeneSkew = clamp(classicGeneSkew + (random.nextFloat() - 0.5f) * 1.60f * a, -1.25f, 1.25f);
            classicGeneFold = clamp(classicGeneFold + (random.nextFloat() - 0.5f) * 1.90f * a, 0.15f, 3.40f);
            classicGeneNoiseA = clamp(classicGeneNoiseA + (random.nextFloat() - 0.5f) * 2.10f * a, 0.30f, 4.20f);
            classicGeneNoiseB = clamp(classicGeneNoiseB + (random.nextFloat() - 0.5f) * 2.10f * a, 0.30f, 4.20f);
            classicGeneOrbit = clamp(classicGeneOrbit + (random.nextFloat() - 0.5f) * 0.95f * a, 0f, 1.1f);
            classicGeneDrift = clamp(classicGeneDrift + (random.nextFloat() - 0.5f) * 0.95f * a, 0f, 1.1f);
            classicGeneTwist = clamp(classicGeneTwist + (random.nextFloat() - 0.5f) * 0.95f * a, 0f, 1.1f);
            classicGeneSplit = clamp(classicGeneSplit + (random.nextFloat() - 0.5f) * 0.95f * a, 0f, 1.1f);
            classicGenePhaseA += (random.nextFloat() - 0.5f) * (float)Math.PI * a;
            classicGenePhaseB += (random.nextFloat() - 0.5f) * (float)Math.PI * a;
            classicGenePhaseC += (random.nextFloat() - 0.5f) * (float)Math.PI * a;
            if (phase.name.equals("释放")) classicGeneTwist = Math.min(1.15f, classicGeneTwist + 0.12f * a);
        }

        private void updateClassicTargetShape(float sec, Phase phase, boolean hard) {
            float minDim = Math.max(1f, Math.min(width, height));
            float margin = minDim * 0.14f;
            float orbitAmp = 0.16f + 0.18f * classicGeneOrbit;
            float driftAmp = 0.12f + 0.16f * classicGeneDrift;
            float cx = width * (0.50f + orbitAmp * (float)Math.sin(sec * (0.021f + 0.018f * classicGeneOrbit) + classicSeed * 0.013f + classicGenePhaseA));
            float cy = height * (0.50f + driftAmp * (float)Math.cos(sec * (0.019f + 0.016f * classicGeneDrift) + classicSeed * 0.011f + classicGenePhaseB));
            float ang = classicGeneAngle
                    + sec * (0.05f + 0.10f * classicGeneOrbit)
                    + (float)Math.sin(sec * 0.17f + classicGenePhaseA) * (0.25f + 0.85f * classicGeneTwist)
                    + (phase.name.equals("同步") ? 0.25f * (float)Math.sin(sec * 0.10f + classicGenePhaseC) : 0f);
            if (classicGeneFamily == 7) ang += (float)Math.PI * 0.5f;
            float tx = (float)Math.cos(ang);
            float ty = (float)Math.sin(ang);
            float nx = -ty;
            float ny = tx;
            float spanMain = minDim * (0.14f + 0.34f * classicGeneSpan);
            float spanCross = minDim * (0.06f + 0.24f * classicGeneLift);
            for (int i = 0; i < CLASSIC_CP; i++) {
                float u = i / (float)Math.max(1, CLASSIC_CP - 1);
                float s = (u - 0.5f) * 2f;
                float phase1 = classicGenePhaseA + sec * (0.06f + 0.08f * classicGeneTwist);
                float phase2 = classicGenePhaseB + sec * (0.08f + 0.10f * classicGeneDrift);
                float phase3 = classicGenePhaseC + sec * (0.09f + 0.12f * classicGeneOrbit);
                float spine = s * spanMain * (0.85f + 0.32f * (float)Math.sin(phase1 + u * 2.1f));
                spine += (float)Math.sin((u * (1.0f + classicGeneCurl) + phase1) * (float)Math.PI) * spanMain * 0.26f * classicGeneSkew;
                spine += (float)Math.sin((u * (2.0f + classicGeneNoiseA) + phase2) * (float)Math.PI) * spanMain * 0.12f * (0.25f + classicGeneTwist);
                float cross = (float)Math.sin((u * (1.0f + classicGeneFold) + phase2) * (float)Math.PI) * spanCross * (0.55f + 0.65f * classicGeneLift);
                cross += (float)Math.cos((u * (1.5f + classicGeneNoiseB) + phase3) * (float)Math.PI) * spanCross * 0.34f * (0.35f + classicGeneTwist);
                cross += s * spanCross * 0.55f * classicGeneSkew;
                switch (classicGeneFamily) {
                    case 0: // arc bloom
                        cross += (float)Math.sin(u * (float)Math.PI) * spanCross * 0.85f;
                        break;
                    case 1: // hook / claw
                        cross += Math.signum(s) * (float)Math.pow(Math.abs(s), 0.55f) * spanCross * (0.45f + 0.85f * classicGeneSplit);
                        spine += (float)Math.sin((u * 2.0f + phase1) * (float)Math.PI) * spanMain * 0.12f;
                        break;
                    case 2: // ribbon weave
                        spine += (float)Math.sin((u * 2.4f + phase2) * (float)Math.PI) * spanMain * 0.18f;
                        cross += (float)Math.cos((u * 2.2f + phase3) * (float)Math.PI) * spanCross * 0.62f;
                        break;
                    case 3: // loop-ish fold
                        cross += (float)Math.sin((u * 2.8f + phase1) * (float)Math.PI) * spanCross * 1.10f;
                        spine += (float)Math.cos((u * 1.4f + phase3) * (float)Math.PI) * spanMain * 0.18f;
                        break;
                    case 4: // shard sweep
                        cross *= 0.52f;
                        spine += Math.signum(s) * (float)Math.pow(Math.abs(s), 1.35f) * spanMain * 0.55f;
                        break;
                    case 5: // broad S fold
                        cross += (float)Math.sin((u - 0.5f) * (float)Math.PI * 1.8f + phase2) * spanCross * 0.92f;
                        spine += (float)Math.sin((u * 1.7f + phase3) * (float)Math.PI) * spanMain * 0.16f;
                        break;
                    case 6: // vertical flutter / flame
                        spine *= 0.42f;
                        cross += (float)Math.sin((u * 1.9f + phase1) * (float)Math.PI) * spanCross * 1.30f;
                        break;
                    case 7: // horizontal wing
                        spine += (float)Math.sin((u * 1.3f + phase1) * (float)Math.PI) * spanMain * 0.10f;
                        cross += (float)Math.cos((u * 3.0f + phase2) * (float)Math.PI) * spanCross * 0.55f;
                        break;
                    default: // split asymmetry
                        cross += (i < CLASSIC_CP / 2 ? -1f : 1f) * spanCross * (0.30f + 0.55f * classicGeneSplit);
                        spine += (i % 2 == 0 ? -1f : 1f) * spanMain * 0.10f * classicGeneSkew;
                        break;
                }
                if (phase.name.equals("分离")) {
                    spine += (i < CLASSIC_CP / 2 ? -1f : 1f) * spanMain * 0.16f;
                } else if (phase.name.equals("吸引")) {
                    cross *= 0.88f;
                } else if (phase.name.equals("同步")) {
                    cross *= 0.72f;
                } else if (phase.name.equals("临界")) {
                    cross *= 0.78f;
                    spine *= 0.92f;
                } else if (phase.name.equals("释放")) {
                    spine *= 1.12f;
                    cross *= 1.06f;
                }
                float jitter = hard ? minDim * 0.010f : minDim * (0.004f + 0.008f * cfg.randomness);
                float x = cx + tx * spine + nx * cross
                        + (float)Math.sin(sec * (0.33f + i * 0.08f) + classicSeed * 0.0043f + i * 0.9f) * jitter;
                float y = cy + ty * spine + ny * cross
                        + (float)Math.cos(sec * (0.31f + i * 0.07f) + classicSeed * 0.0037f - i * 0.8f) * jitter;
                classicTargetX[i] = clamp(x, -margin, width + margin);
                classicTargetY[i] = clamp(y, -margin, height + margin);
            }
        }

        private float phaseSpeedSeed(Phase phase) {
            if (phase.name.equals("分离")) return 0.82f;
            if (phase.name.equals("吸引")) return 0.94f;
            if (phase.name.equals("同步")) return 0.86f;
            if (phase.name.equals("临界")) return 1.16f;
            if (phase.name.equals("释放")) return 1.34f;
            if (phase.name.equals("余韵")) return 0.66f;
            return 1f;
        }

        private void morphClassicSubject(Phase phase) {
            classicHue = fract(classicHue + 0.07f + random.nextFloat() * 0.19f);
            classicSeed += 13.0f + random.nextFloat() * 47.0f;
            mutateClassicGenes(phase, 0.78f + random.nextFloat() * 0.70f);
            if (random.nextFloat() < 0.62f + 0.34f * cfg.randomness) {
                classicPatternMode = chooseClassicPatternMode(phase);
            }
            if (random.nextFloat() < 0.38f + 0.34f * cfg.randomness) {
                classicTopologyMode = chooseClassicTopologyMode(phase);
            }
            float minDim = Math.max(1f, Math.min(width, height));
            float kick = minDim * (0.018f + 0.040f * cfg.randomness) * phaseSpeedSeed(phase);
            float warp = minDim * (0.028f + 0.090f * cfg.randomness);
            for (int i = 0; i < CLASSIC_CP; i++) {
                float ang = (float)(random.nextFloat() * Math.PI * 2.0);
                classicVX[i] += (float)Math.cos(ang) * kick * (0.50f + random.nextFloat());
                classicVY[i] += (float)Math.sin(ang) * kick * (0.50f + random.nextFloat());
                classicX[i] += (float)Math.cos(ang * 1.7f + i * 0.9f) * warp * (0.20f + random.nextFloat() * 0.95f);
                classicY[i] += (float)Math.sin(ang * 1.3f - i * 0.8f) * warp * (0.20f + random.nextFloat() * 0.95f);
            }
            if (random.nextFloat() < 0.30f) {
                int i = 1 + random.nextInt(Math.max(1, CLASSIC_CP - 2));
                int j = 1 + random.nextInt(Math.max(1, CLASSIC_CP - 2));
                float tx = classicX[i]; classicX[i] = classicX[j]; classicX[j] = tx;
                float ty = classicY[i]; classicY[i] = classicY[j]; classicY[j] = ty;
            }
            float margin = minDim * 0.12f;
            for (int i = 0; i < CLASSIC_CP; i++) {
                classicX[i] = clamp(classicX[i], -margin, width + margin);
                classicY[i] = clamp(classicY[i], -margin, height + margin);
            }
            float gap = 0.85f + random.nextFloat() * 2.15f;
            if (phase.name.equals("临界")) gap *= 0.66f;
            if (phase.name.equals("释放")) gap *= 0.48f;
            if (phase.name.equals("余韵")) gap *= 1.18f;
            classicNextMorphSec += gap;
            classicSoftMorphSec = Math.min(classicSoftMorphSec, classicShapeAge + 0.35f + random.nextFloat() * 0.55f);
        }

        private float classicSubjectVisibility(float sec, Phase phase) {
            return classicReady ? 1f : 0f;
        }

        private void updateClassicMystify(float sec, float dt, Phase phase, float intensity, float tension, float release) {
            if (!classicReady || width <= 2 || height <= 2) initClassicMystify(phase);
            classicShapeAge += dt;
            classicRegionAge += dt;
            float minDim = Math.max(1f, Math.min(width, height));
            float margin = minDim * 0.085f;
            float safeDt = clamp(dt, 0.001f, 0.050f);

            for (int i = 0; i < CLASSIC_CP; i++) {
                classicPrevX[i] = classicX[i];
                classicPrevY[i] = classicY[i];
            }

            int subSteps = cfg.powerSave ? 2 : Math.max(3, Math.min(7, (int)Math.ceil(safeDt / 0.010f)));
            float stepDt = safeDt / Math.max(1, subSteps);
            for (int step = 0; step < subSteps; step++) {
                float tSec = sec - safeDt + stepDt * (step + 1);
                stepClassicFlowParticles(tSec, stepDt, phase, intensity, tension, release, minDim, margin);
            }
            updateClassicEdgeWeights(sec, safeDt, phase, intensity, tension, release, minDim);
            classicHue = fract(classicHue + safeDt * (0.020f + 0.018f * intensity + 0.022f * release));
        }

        private void stepClassicFlowParticles(float sec, float dt, Phase phase, float intensity, float tension, float release, float minDim, float margin) {
            float centerX = width * (0.50f + 0.11f * (float)Math.sin(sec * 0.031f + classicSeed * 0.017f));
            float centerY = height * (0.50f + 0.10f * (float)Math.cos(sec * 0.027f + classicSeed * 0.013f));
            float axMean = 0f, ayMean = 0f;
            for (int i = 0; i < CLASSIC_CP; i++) { axMean += classicVX[i]; ayMean += classicVY[i]; }
            axMean /= CLASSIC_CP; ayMean /= CLASSIC_CP;

            float speedMul = 0.86f + 0.34f * cfg.intimacy;
            if (phase.name.equals("临界")) speedMul *= 1.16f;
            if (phase.name.equals("释放")) speedMul *= 1.30f;
            if (phase.name.equals("余韵")) speedMul *= 0.74f;

            for (int i = 0; i < CLASSIC_CP; i++) {
                float px = classicX[i] / Math.max(1f, width);
                float py = classicY[i] / Math.max(1f, height);
                float seedA = classicSeedA[i];
                float seedB = classicSeedB[i];

                // 连续流场：多频正弦 + domain warp。没有“下一张图”的离散随机。
                float warpX = (float)Math.sin(py * 7.1f + sec * 0.19f + seedA * 0.013f)
                        + 0.45f * (float)Math.sin((px + py) * 13.7f - sec * 0.31f + seedB * 0.017f);
                float warpY = (float)Math.cos(px * 6.6f - sec * 0.17f + seedB * 0.011f)
                        + 0.42f * (float)Math.sin((px - py) * 12.4f + sec * 0.27f + seedA * 0.019f);
                float angle = classicSeed * 0.009f + seedA * 0.004f
                        + warpX * 1.25f + warpY * 1.05f
                        + sec * (0.18f + 0.035f * (i % 5));
                float ax = (float)Math.cos(angle) * minDim * 0.016f * speedMul;
                float ay = (float)Math.sin(angle) * minDim * 0.016f * speedMul;

                // 两个慢速游走的隐形吸引/旋转中心，让形态持续重构，但不会突然换主体。
                float a1x = width * (0.50f + 0.31f * (float)Math.sin(sec * 0.023f + classicSeed * 0.021f));
                float a1y = height * (0.50f + 0.28f * (float)Math.cos(sec * 0.021f + classicSeed * 0.018f));
                float a2x = width * (0.50f + 0.34f * (float)Math.sin(sec * 0.017f + classicSeed * 0.037f + 2.1f));
                float a2y = height * (0.50f + 0.31f * (float)Math.cos(sec * 0.019f + classicSeed * 0.029f - 1.4f));
                float dx1 = classicX[i] - a1x, dy1 = classicY[i] - a1y;
                float dx2 = classicX[i] - a2x, dy2 = classicY[i] - a2y;
                float d1 = (float)Math.sqrt(dx1 * dx1 + dy1 * dy1) + 1f;
                float d2 = (float)Math.sqrt(dx2 * dx2 + dy2 * dy2) + 1f;
                ax += -dy1 / d1 * minDim * (0.010f + 0.006f * tension);
                ay +=  dx1 / d1 * minDim * (0.010f + 0.006f * tension);
                ax +=  dy2 / d2 * minDim * (0.006f + 0.006f * cfg.randomness);
                ay += -dx2 / d2 * minDim * (0.006f + 0.006f * cfg.randomness);
                ax += (centerX - classicX[i]) * 0.00070f;
                ay += (centerY - classicY[i]) * 0.00070f;

                // 粒子间柔性排斥/弱凝聚，只维持涌现系统的密度，不形成固定拓扑。
                for (int j = 0; j < CLASSIC_CP; j++) {
                    if (j == i) continue;
                    float dx = classicX[i] - classicX[j];
                    float dy = classicY[i] - classicY[j];
                    float d2p = dx * dx + dy * dy + 0.001f;
                    float d = (float)Math.sqrt(d2p);
                    if (d < minDim * 0.105f) {
                        float push = (minDim * 0.105f - d) * 0.0025f;
                        ax += dx / d * push;
                        ay += dy / d * push;
                    } else if (d > minDim * 0.46f && d < minDim * 0.82f) {
                        float pull = (d - minDim * 0.46f) * 0.000055f;
                        ax += -dx / d * pull;
                        ay += -dy / d * pull;
                    }
                }

                // 阶段逻辑只改变连续力场，不切页、不换主体。
                if (phase.name.equals("分离")) {
                    float side = ((seedA + i * 13.0f) % 2f < 1f) ? -1f : 1f;
                    ax += side * minDim * 0.0022f;
                } else if (phase.name.equals("吸引")) {
                    ax += (centerX - classicX[i]) * 0.0011f;
                    ay += (centerY - classicY[i]) * 0.0011f;
                } else if (phase.name.equals("同步")) {
                    ax += (axMean - classicVX[i]) * 0.015f;
                    ay += (ayMean - classicVY[i]) * 0.015f;
                    ax += -(classicY[i] - centerY) * 0.00052f;
                    ay +=  (classicX[i] - centerX) * 0.00052f;
                } else if (phase.name.equals("临界")) {
                    ax += (centerX - classicX[i]) * 0.0024f - (classicY[i] - centerY) * 0.0014f * (0.9f + tension);
                    ay += (centerY - classicY[i]) * 0.0024f + (classicX[i] - centerX) * 0.0014f * (0.9f + tension);
                } else if (phase.name.equals("释放")) {
                    float dx = classicX[i] - centerX, dy = classicY[i] - centerY;
                    float inv = 1f / Math.max(28f, (float)Math.sqrt(dx * dx + dy * dy));
                    ax += dx * inv * minDim * (0.034f + 0.046f * release);
                    ay += dy * inv * minDim * (0.034f + 0.046f * release);
                } else if (phase.name.equals("余韵")) {
                    ax += (centerX - classicX[i]) * 0.00045f;
                    ay += (centerY - classicY[i]) * 0.00045f - minDim * 0.00045f;
                }

                classicVX[i] += ax * dt;
                classicVY[i] += ay * dt;
                classicVX[i] *= (float)Math.pow(0.990f, dt * 60f);
                classicVY[i] *= (float)Math.pow(0.990f, dt * 60f);
                float maxSpd = minDim * (0.060f + 0.030f * intensity + 0.040f * release) * speedMul;
                float spd = (float)Math.sqrt(classicVX[i] * classicVX[i] + classicVY[i] * classicVY[i]);
                if (spd > maxSpd) {
                    float sc = maxSpd / Math.max(0.001f, spd);
                    classicVX[i] *= sc; classicVY[i] *= sc;
                }
                classicX[i] += classicVX[i] * dt;
                classicY[i] += classicVY[i] * dt;

                if (classicX[i] < -margin) { classicX[i] = -margin; classicVX[i] = Math.abs(classicVX[i]) * (0.74f + 0.28f * wave01(sec + seedA)); classicVY[i] *= 0.82f + 0.24f * wave01(sec * 1.31f + seedB); }
                if (classicX[i] > width + margin) { classicX[i] = width + margin; classicVX[i] = -Math.abs(classicVX[i]) * (0.74f + 0.28f * wave01(sec + seedA)); classicVY[i] *= 0.82f + 0.24f * wave01(sec * 1.31f + seedB); }
                if (classicY[i] < -margin) { classicY[i] = -margin; classicVY[i] = Math.abs(classicVY[i]) * (0.74f + 0.28f * wave01(sec + seedB)); classicVX[i] *= 0.82f + 0.24f * wave01(sec * 1.17f + seedA); }
                if (classicY[i] > height + margin) { classicY[i] = height + margin; classicVY[i] = -Math.abs(classicVY[i]) * (0.74f + 0.28f * wave01(sec + seedB)); classicVX[i] *= 0.82f + 0.24f * wave01(sec * 1.17f + seedA); }
            }
        }

        private void updateClassicEdgeWeights(float sec, float dt, Phase phase, float intensity, float tension, float release, float minDim) {
            float radius = minDim * (0.18f + 0.15f * cfg.randomness + 0.07f * tension + 0.11f * release);
            if (phase.name.equals("分离")) radius *= 0.88f;
            if (phase.name.equals("同步")) radius *= 1.08f;
            if (phase.name.equals("释放")) radius *= 1.22f;
            float rate = 1f - (float)Math.exp(-(1.35f + 2.20f * cfg.randomness + 0.75f * intensity) * dt);
            for (int i = 0; i < CLASSIC_CP; i++) {
                for (int j = i + 1; j < CLASSIC_CP; j++) {
                    int idx = edgeIndex(i, j);
                    float dx = classicX[j] - classicX[i];
                    float dy = classicY[j] - classicY[i];
                    float d = (float)Math.sqrt(dx * dx + dy * dy);
                    float distGate = 1f - smooth(clamp((d - radius * 0.30f) / Math.max(1f, radius * 0.85f), 0f, 1f));
                    float vx = classicVX[i] - classicVX[j];
                    float vy = classicVY[i] - classicVY[j];
                    float kinetic = clamp((float)Math.sqrt(vx * vx + vy * vy) / Math.max(1f, minDim * 0.080f), 0f, 1f);
                    float wave = 0.5f + 0.5f * (float)Math.sin(sec * (0.34f + 0.018f * ((i + j) % 7)) + classicEdgePhase[idx] + classicSeed * 0.010f);
                    float target = clamp(distGate * (0.72f + 0.18f * wave) + kinetic * 0.14f - 0.11f, 0f, 1f);
                    if (d > radius * 1.34f) target = 0f;
                    classicEdgeWeight[idx] += (target - classicEdgeWeight[idx]) * rate;
                    classicEdgeWeight[edgeIndex(j, i)] = classicEdgeWeight[idx];
                }
            }
        }

        private int edgeIndex(int i, int j) {
            return i * CLASSIC_CP + j;
        }

        private float wave01(float x) {
            return 0.5f + 0.5f * (float)Math.sin(x);
        }

        private void drawClassicMystifyField(float sec, Phase phase, float intensity, float tension, float release) {
            if (!classicReady) return;
            if (phase.name.equals("余韵") && cfg.bubbles) return;
            // V64：没有 subjectVis、intro、exit。可见性来自边权、速度、FBO 残影连续累积。
            float phaseMul = phase.name.equals("释放") ? 0.78f : phase.name.equals("余韵") ? 0.46f : 1.0f;
            drawClassicSwarmConnections(sec, phaseMul, intensity, tension, release);
            drawClassicPointTrajectories(sec, phaseMul, intensity, tension, release);
        }

        private void drawClassicSwarmConnections(float sec, float phaseMul, float intensity, float tension, float release) {
            float minDim = Math.max(1f, Math.min(width, height));
            float[] rgb = classicRgb(fract(classicHue + sec * 0.0035f));
            float baseWidth = Math.max(0.10f, minDim * (0.00012f + 0.00018f * cfg.ribbonWidth));
            int subSteps = cfg.powerSave ? 2 : 5;
            for (int step = 1; step <= subSteps; step++) {
                float t = step / (float)subSteps;
                for (int i = 0; i < CLASSIC_CP; i++) {
                    for (int j = i + 1; j < CLASSIC_CP; j++) {
                        float w = classicEdgeWeight[edgeIndex(i, j)];
                        if (w <= 0.018f) continue;
                        float x1 = lerp(classicPrevX[i], classicX[i], t);
                        float y1 = lerp(classicPrevY[i], classicY[i], t);
                        float x2 = lerp(classicPrevX[j], classicX[j], t);
                        float y2 = lerp(classicPrevY[j], classicY[j], t);
                        float a = phaseMul * w * (0.026f + 0.044f * intensity + 0.030f * release) * (0.50f + 0.50f * t);
                        if (a <= 0.002f) continue;
                        float hueShift = 0.035f * (float)Math.sin(classicEdgePhase[edgeIndex(i, j)] + sec * 0.12f);
                        float[] ergb = classicRgb(fract(classicHue + hueShift + 0.08f * w));
                        drawClassicDynamicEdge(sec, x1, y1, x2, y2, ergb[0], ergb[1], ergb[2], a, baseWidth * (0.75f + 1.10f * w), w, i, j);
                    }
                }
            }
        }

        private void drawClassicPointTrajectories(float sec, float phaseMul, float intensity, float tension, float release) {
            float minDim = Math.max(1f, Math.min(width, height));
            float[] rgb = classicRgb(fract(classicHue + 0.10f + sec * 0.004f));
            float widthPx = Math.max(0.08f, minDim * 0.00012f);
            for (int i = 0; i < CLASSIC_CP; i++) {
                float dx = classicX[i] - classicPrevX[i];
                float dy = classicY[i] - classicPrevY[i];
                if (dx * dx + dy * dy < 0.25f) continue;
                ArrayList<float[]> pts = new ArrayList<>(4);
                pts.add(new float[]{classicPrevX[i], classicPrevY[i]});
                pts.add(new float[]{lerp(classicPrevX[i], classicX[i], 0.45f), lerp(classicPrevY[i], classicY[i], 0.45f)});
                pts.add(new float[]{classicX[i], classicY[i]});
                drawTaperedStrip(pts, widthPx, rgb[0], rgb[1], rgb[2], phaseMul * (0.034f + 0.030f * intensity + 0.030f * release));
            }
        }

        private void drawClassicDynamicEdge(float sec, float x1, float y1, float x2, float y2, float r, float g, float b, float alpha, float widthPx, float gate, int i, int j) {
            if (alpha <= 0.002f) return;
            float dx = x2 - x1, dy = y2 - y1;
            float d = (float)Math.sqrt(dx * dx + dy * dy);
            if (d < 2f) return;
            float nx = -dy / Math.max(0.001f, d);
            float ny =  dx / Math.max(0.001f, d);
            float minDim = Math.max(1f, Math.min(width, height));
            float bend = minDim * (0.002f + 0.010f * gate) * (0.5f + cfg.randomness);
            float ph = sec * (0.48f + 0.013f * (i + j)) + i * 1.21f - j * 0.93f + classicSeed * 0.006f;
            ArrayList<float[]> pts = new ArrayList<>(9);
            for (int k = 0; k <= 8; k++) {
                float u = k / 8f;
                float env = (float)Math.sin(u * Math.PI);
                float wob = (float)Math.sin(ph + u * Math.PI * (1.0f + gate)) * bend * env;
                pts.add(new float[]{lerp(x1, x2, u) + nx * wob, lerp(y1, y2, u) + ny * wob});
            }
            drawTaperedStrip(pts, widthPx, r, g, b, alpha);
        }

        private void drawClassicTemporalMesh(float sec, int maxAge, float phaseMul, float intensity, float tension) {
            if (maxAge < 14) return;
            float minDim = Math.max(1f, Math.min(width, height));
            int historyLines = cfg.powerSave ? 10 : 22;
            int sampleLines = cfg.powerSave ? 9 : 18;
            int ageStep = Math.max(2, maxAge / Math.max(1, historyLines));
            ArrayList<ArrayList<float[]>> curves = new ArrayList<>(historyLines + 1);
            for (int k = 0; k <= historyLines; k++) {
                int a = Math.min(maxAge - 1, k * ageStep);
                int idx = (classicHead - 1 - a + CLASSIC_HISTORY * 4) % CLASSIC_HISTORY;
                curves.add(sampleClassicSpline(classicHistory[idx], 58));
            }
            float[] rgb = classicRgb(fract(classicHue + sec * 0.006f + 0.08f));
            for (int sIdx = 1; sIdx < sampleLines; sIdx++) {
                float u = sIdx / (float)sampleLines;
                if (u < 0.04f || u > 0.97f) continue;
                ArrayList<float[]> rib = new ArrayList<>(curves.size());
                for (ArrayList<float[]> c : curves) {
                    if (c.size() < 2) continue;
                    int pi = clampInt(Math.round(u * (c.size() - 1)), 0, c.size() - 1);
                    rib.add(c.get(pi));
                }
                if (rib.size() < 2) continue;
                float gate = (float)Math.sin((u * 7.0f + sec * 0.040f + classicSeed * 0.0013f) * Math.PI);
                float a = phaseMul * (0.016f + 0.036f * Math.max(0f, gate)) * (0.68f + 0.32f * intensity);
                drawTaperedStrip(rib, Math.max(0.14f, minDim * 0.00016f), rgb[0], rgb[1], rgb[2], a);
            }
            // diagonal history ribs create the Windows-like moire/fan instead of a single glowing arc.
            int diagStep = cfg.powerSave ? 4 : 3;
            for (int d = 0; d < sampleLines - 2; d += diagStep) {
                ArrayList<float[]> diag = new ArrayList<>(curves.size());
                for (int k = 0; k < curves.size(); k++) {
                    ArrayList<float[]> c = curves.get(k);
                    if (c.size() < 2) continue;
                    float u = clamp((d + 1 + k * 0.35f) / (float)sampleLines, 0.05f, 0.95f);
                    int pi = clampInt(Math.round(u * (c.size() - 1)), 0, c.size() - 1);
                    diag.add(c.get(pi));
                }
                if (diag.size() > 3) {
                    drawTaperedStrip(diag, Math.max(0.12f, minDim * 0.00013f), rgb[0], rgb[1], rgb[2], phaseMul * 0.018f);
                }
            }
        }

        private ArrayList<float[]> sampleClassicSpline(float[] cp, int samples) {
            ArrayList<float[]> pts = new ArrayList<>(samples + 1);
            if (cp == null || cp.length < 4) return pts;
            int count = Math.max(2, cp.length / 2);
            int[] order = new int[count];
            for (int i = 0; i < count; i++) order[i] = classicOrderedIndex(i, count);
            int segments = Math.max(1, count - 1);
            for (int i = 0; i <= samples; i++) {
                float tt = i / (float)Math.max(1, samples);
                float ft = tt * segments;
                int seg = clampInt((int)Math.floor(ft), 0, segments - 1);
                float t = ft - seg;
                int i0 = order[clampInt(seg - 1, 0, count - 1)];
                int i1 = order[clampInt(seg, 0, count - 1)];
                int i2 = order[clampInt(seg + 1, 0, count - 1)];
                int i3 = order[clampInt(seg + 2, 0, count - 1)];
                float p0x = cp[i0 * 2], p0y = cp[i0 * 2 + 1];
                float p1x = cp[i1 * 2], p1y = cp[i1 * 2 + 1];
                float p2x = cp[i2 * 2], p2y = cp[i2 * 2 + 1];
                float p3x = cp[i3 * 2], p3y = cp[i3 * 2 + 1];
                float t2 = t * t;
                float t3 = t2 * t;
                float x = 0.5f * ((2f * p1x) + (-p0x + p2x) * t + (2f * p0x - 5f * p1x + 4f * p2x - p3x) * t2 + (-p0x + 3f * p1x - 3f * p2x + p3x) * t3);
                float y = 0.5f * ((2f * p1y) + (-p0y + p2y) * t + (2f * p0y - 5f * p1y + 4f * p2y - p3y) * t2 + (-p0y + 3f * p1y - 3f * p2y + p3y) * t3);
                pts.add(new float[]{x, y});
            }
            return pts;
        }

        private int classicOrderedIndex(int i, int count) {
            switch (classicTopologyMode % 6) {
                case 1: return count - 1 - i;
                case 2: return (i % 2 == 0) ? i / 2 : count - 1 - i / 2;
                case 3: return (i * 2 + i / Math.max(1, (count + 1) / 2)) % count;
                case 4: return (i < count / 2) ? i * 2 : (i - count / 2) * 2 + 1 < count ? (i - count / 2) * 2 + 1 : count - 1;
                case 5: return (i + classicSubjectOrdinal) % count;
                default: return i;
            }
        }

        private ArrayList<float[]> sampleClassicBezier(float[] cp, int samples) {
            // Kept for backward compatibility; V60 classic rendering uses sampleClassicSpline().
            return sampleClassicSpline(cp, samples);
        }

        private void drawClassicWireSurface(float sec, ArrayList<float[]> curve, float r, float g, float b, float alpha, float spread, int wires) {
            if (curve == null || curve.size() < 4 || alpha <= 0.002f) return;
            float minDim = Math.max(1f, Math.min(width, height));
            int n = Math.max(3, wires);
            for (int w = 0; w < n; w++) {
                float u = n == 1 ? 0.5f : w / (float)(n - 1);
                float centered = (u - 0.5f) * 2f;
                float falloff = 1f - Math.abs(centered) * 0.62f;
                ArrayList<float[]> off = new ArrayList<>(curve.size());
                for (int i = 0; i < curve.size(); i++) {
                    float q = i / (float)Math.max(1, curve.size() - 1);
                    float[] basis = tangentNormalAt(curve, i);
                    float fan = (float)Math.sin(q * Math.PI);
                    float wave = (float)Math.sin(q * Math.PI * (1.0f + 1.2f * classicGeneFold) + centered * 1.7f + sec * 0.035f + classicSeed * 0.001f);
                    float localSpread = centered * spread * (0.22f + 0.78f * fan) + wave * spread * 0.10f * (1f - Math.abs(centered));
                    // Tiny tangential drift prevents the wires from looking like one fixed pre-made band.
                    float tangentSlip = centered * spread * 0.10f * (float)Math.sin(q * Math.PI * 2.0f + classicGenePhaseC + sec * 0.025f);
                    off.add(new float[]{curve.get(i)[0] + basis[2] * localSpread + basis[0] * tangentSlip,
                            curve.get(i)[1] + basis[3] * localSpread + basis[1] * tangentSlip});
                }
                float a = alpha * Math.max(0.08f, falloff) * (0.55f + 0.45f * (float)Math.sin(u * Math.PI));
                drawTaperedStrip(off, Math.max(0.12f, minDim * 0.00015f), r, g, b, a);
            }
        }

        private void drawClassicMatrixRibs(float sec, ArrayList<float[]> curve, float r, float g, float b, float alpha) {
            if (curve == null || curve.size() < 8 || alpha <= 0.002f) return;
            float minDim = Math.max(1f, Math.min(width, height));
            int ribs = cfg.powerSave ? 6 : 14;
            float spread = minDim * (0.018f + 0.030f * classicGeneLift + 0.020f * classicGeneTwist);
            for (int k = 1; k < ribs; k++) {
                float q = k / (float)ribs;
                int idx = clampInt(Math.round(q * (curve.size() - 1)), 1, curve.size() - 2);
                float[] p = curve.get(idx);
                float[] basis = tangentNormalAt(curve, idx);
                float phase = (float)Math.sin(sec * 0.05f + q * Math.PI * 4f + classicSeed * 0.002f);
                float len = spread * (0.35f + 0.65f * (float)Math.sin(q * Math.PI)) * (0.70f + 0.30f * phase);
                ArrayList<float[]> rib = new ArrayList<>(5);
                rib.add(new float[]{p[0] - basis[2] * len, p[1] - basis[3] * len});
                rib.add(new float[]{p[0] - basis[2] * len * 0.35f + basis[0] * len * 0.10f * phase, p[1] - basis[3] * len * 0.35f + basis[1] * len * 0.10f * phase});
                rib.add(new float[]{p[0] + basis[2] * len * 0.35f - basis[0] * len * 0.10f * phase, p[1] + basis[3] * len * 0.35f - basis[1] * len * 0.10f * phase});
                rib.add(new float[]{p[0] + basis[2] * len, p[1] + basis[3] * len});
                drawTaperedStrip(rib, Math.max(0.11f, minDim * 0.00013f), r, g, b, alpha * (0.20f + 0.45f * (float)Math.sin(q * Math.PI)));
            }
        }

        private void drawClassicOffsetBundle(ArrayList<float[]> curve, float spread, float widthPx,
                                             float r, float g, float b, float alpha, int lines) {
            if (curve == null || curve.size() < 3 || alpha <= 0.002f) return;
            int n = Math.max(1, lines);
            for (int i = 0; i < n; i++) {
                float u = n == 1 ? 0.5f : i / (float)(n - 1);
                float centered = (u - 0.5f) * 2f;
                float falloff = 1f - Math.abs(centered) * 0.68f;
                ArrayList<float[]> off = offsetClassicByNormals(curve, centered * spread * (0.22f + 0.78f * (float)Math.sin(u * Math.PI)));
                drawTaperedStrip(off, widthPx * (0.68f + falloff * 0.34f), r, g, b, alpha * Math.max(0.08f, falloff));
            }
        }

        private ArrayList<float[]> offsetClassicByNormals(ArrayList<float[]> curve, float offset) {
            ArrayList<float[]> out = new ArrayList<>(curve.size());
            for (int i = 0; i < curve.size(); i++) {
                float[] n = tangentNormalAt(curve, i);
                out.add(new float[]{curve.get(i)[0] + n[2] * offset, curve.get(i)[1] + n[3] * offset});
            }
            return out;
        }

        private void drawClassicCurvatureLines(ArrayList<float[]> curve, float r, float g, float b, float alpha) {
            if (curve == null || curve.size() < 8 || alpha <= 0.002f) return;
            float minDim = Math.max(1f, Math.min(width, height));
            for (int i = 6; i < curve.size() - 6; i += 5) {
                float k = curvatureAt(curve, i);
                if (k < 0.010f) continue;
                float[] p = curve.get(i);
                float[] basis = tangentNormalAt(curve, i);
                float len = minDim * (0.010f + Math.min(0.030f, k * 0.85f));
                ArrayList<float[]> rib = new ArrayList<>(2);
                rib.add(new float[]{p[0] - basis[2] * len, p[1] - basis[3] * len});
                rib.add(new float[]{p[0] + basis[2] * len, p[1] + basis[3] * len});
                drawTaperedStrip(rib, Math.max(0.42f, minDim * 0.00048f), r, g, b, alpha * Math.min(1f, k * 24f));
            }
        }

        private void drawClassicTerminalFan(ArrayList<float[]> curve, float r, float g, float b, float alpha) {
            if (curve == null || curve.size() < 8 || alpha <= 0.002f) return;
            float minDim = Math.max(1f, Math.min(width, height));
            int end = curve.size() - 1;
            float[] p = curve.get(end);
            float[] basis = tangentNormalAt(curve, end - 2);
            float tx = basis[0], ty = basis[1], nx = basis[2], ny = basis[3];
            int lines = cfg.powerSave ? 5 : 9;
            for (int i = 0; i < lines; i++) {
                float u = i / (float)Math.max(1, lines - 1);
                float centered = (u - 0.5f) * 2f;
                float len = minDim * (0.020f + 0.038f * u);
                float curl = minDim * (0.010f + 0.026f * (1f - Math.abs(centered)));
                ArrayList<float[]> fan = new ArrayList<>(18);
                for (int q = 0; q < 18; q++) {
                    float t = q / 17f;
                    float bend = (float)Math.sin(t * Math.PI) * curl * centered;
                    float x = p[0] - tx * len * t + nx * (centered * len * 0.45f + bend);
                    float y = p[1] - ty * len * t + ny * (centered * len * 0.45f + bend);
                    fan.add(new float[]{x, y});
                }
                float a = alpha * (0.06f + 0.18f * (1f - Math.abs(centered)));
                drawTaperedStrip(fan, Math.max(0.22f, minDim * 0.00030f), r, g, b, a);
            }
        }

        private void drawClassicPointLattice(ArrayList<float[]> curve, float r, float g, float b, float alpha) {
            if (curve == null || curve.size() < 3 || alpha <= 0.002f) return;
            float minDim = Math.max(1f, Math.min(width, height));
            int step = cfg.powerSave ? 10 : 7;
            for (int i = 0; i < curve.size(); i += step) {
                float k = curvatureAt(curve, i);
                if (k < 0.006f && i < curve.size() - 10) continue;
                float[] p = curve.get(i);
                float rr = Math.max(0.24f, minDim * (0.00022f + Math.min(0.00045f, k * 0.004f)));
                drawCircle(p[0], p[1], rr, r, g, b, alpha * (0.14f + Math.min(0.42f, k * 12f)), 8);
            }
        }


        private void drawClassicHistoryEchoes(float sec, int maxAge, float phaseMul, float intensity, float tension) {
            if (maxAge < 8) return;
            float minDim = Math.max(1f, Math.min(width, height));
            int echoes = cfg.powerSave ? 2 : 3;
            for (int e = 0; e < echoes; e++) {
                int a = Math.min(maxAge - 1, (cfg.powerSave ? 10 : 8) + e * (cfg.powerSave ? 12 : 10));
                int idx = (classicHead - 1 - a + CLASSIC_HISTORY * 4) % CLASSIC_HISTORY;
                ArrayList<float[]> curve = sampleClassicSpline(classicHistory[idx], 68);
                if (curve.size() < 4) continue;
                float[] rgb = classicRgb(fract(classicHue + 0.05f * e + sec * 0.005f));
                float spread = minDim * (0.010f + 0.006f * e + 0.008f * tension);
                float alpha = phaseMul * (0.060f - e * 0.012f) * (0.86f + 0.20f * intensity);
                drawClassicOffsetBundle(curve, spread, Math.max(0.24f, minDim * 0.00028f), rgb[0], rgb[1], rgb[2], alpha, cfg.powerSave ? 3 : 5);
            }
        }

        private void drawClassicTravelRibs(float sec, ArrayList<float[]> curve, float r, float g, float b, float alpha) {
            if (curve == null || curve.size() < 8 || alpha <= 0.002f) return;
            float minDim = Math.max(1f, Math.min(width, height));
            int start = 6;
            int end = curve.size() - 6;
            int step = cfg.powerSave ? 9 : 5;
            for (int i = start; i < end; i += step) {
                float gate = 0.5f + 0.5f * (float)Math.sin(sec * 0.060f + i * 0.41f + classicSeed * 0.0011f);
                if (gate < 0.22f) continue;
                float[] p = curve.get(i);
                float[] basis = tangentNormalAt(curve, i);
                float tx = basis[0], ty = basis[1], nx = basis[2], ny = basis[3];
                float len = minDim * (0.014f + 0.022f * gate);
                float side = ((i / step) % 2 == 0 ? 1f : -1f);
                ArrayList<float[]> rib = new ArrayList<>(6);
                rib.add(new float[]{p[0], p[1]});
                rib.add(new float[]{p[0] - tx * len * 0.35f + nx * len * 0.35f * side, p[1] - ty * len * 0.35f + ny * len * 0.35f * side});
                rib.add(new float[]{p[0] - tx * len * 0.68f + nx * len * 0.55f * side, p[1] - ty * len * 0.68f + ny * len * 0.55f * side});
                rib.add(new float[]{p[0] - tx * len * 0.92f + nx * len * 0.32f * side, p[1] - ty * len * 0.92f + ny * len * 0.32f * side});
                drawTaperedStrip(rib, Math.max(0.18f, minDim * 0.00020f), r, g, b, alpha * gate * 0.85f);
            }
        }

        private float[] classicRgb(float h) {
            h = fract(h);
            float x = h * 6f;
            int sector = (int)Math.floor(x);
            float f = x - sector;
            float q = 1f - f;
            switch (sector % 6) {
                case 0: return new float[]{1f, f, 0.12f};
                case 1: return new float[]{q, 1f, 0.12f};
                case 2: return new float[]{0.12f, 1f, f};
                case 3: return new float[]{0.12f, q, 1f};
                case 4: return new float[]{f, 0.12f, 1f};
                default: return new float[]{1f, 0.12f, q};
            }
        }

        private void spawnAccordingToPhase(Phase phase, float sec) {
            decayArtMemory();
            artSpawnIndex++;
            // V26：性交意蕴不再只靠“单条光迹”隐喻，而是默认同时保留两个不同主体：
            // A：冷色、较细、较锋利，像主动追寻的轨迹；
            // B：暖色、较柔、点线喷洒更丰富，像被吸引并回应的轨迹。
            // 两者在“分离”阶段远离且互不牵引，在“吸引/同步”阶段逐渐同频，
            // 在“临界/释放”阶段短暂向共同能量场聚拢，余韵后再回到分离。
            // V42：单个形体的生命时长保留，但主形体出生频率显著放慢。
            // 让“分离→吸引→同步→临界→释放→余韵”更像章节式表演，而不是密集特效覆盖。
            int maxStrokes;
            if (phase.name.equals("分离")) maxStrokes = cfg.powerSave ? 3 : 4;
            else if (phase.name.equals("吸引")) maxStrokes = cfg.powerSave ? 3 : 5;
            else if (phase.name.equals("同步")) maxStrokes = cfg.powerSave ? 3 : 5;
            else if (phase.name.equals("临界")) maxStrokes = cfg.powerSave ? 3 : 5;
            else if (phase.name.equals("释放")) maxStrokes = 2;
            else maxStrokes = 1;
            while (strokes.size() > maxStrokes) strokes.remove(0);

            float chapter = clamp(cfg.journeyMinSec * 0.72f, 4.2f, 24f);
            if (strokes.size() >= maxStrokes) {
                // V54：只在真正达到上限时才反压；V53 在 maxStrokes-1 就停止，桌面容易只剩一条暗线。
                scheduleNextMainSpawn(phase, sec, maxStrokes, true);
                return;
            }

            // V30：扇面网格只作为少数回声出现，不再让整屏偏“细线网状”。
            boolean fanA = random.nextFloat() < phase.fanChance * (0.018f + cfg.randomness * 0.030f);
            boolean fanB = random.nextFloat() < phase.fanChance * (0.030f + cfg.randomness * 0.045f);
            if (phase.name.equals("分离")) { fanA = false; fanB = false; }
            if (phase.name.equals("余韵") || phase.name.equals("释放")) { fanA = false; fanB = false; }

            int sceneProgram = chooseSceneProgram(phase);
            int colorMood = chooseColorMood(phase);
            int[] colors = palette(cfg.style);
            StrokeEvent a = createStroke(phase, -1, fanA, 1, sceneProgram, colorMood);
            StrokeEvent b = createStroke(phase, 1, fanB, 2, sceneProgram, colorMood);
            applyColorMood(a, colorMood, colors);
            applyColorMood(b, colorMood, colors);
            tuneActorPairForPhase(a, b, phase, sceneProgram);
            strokes.add(a);
            if (maxStrokes >= 2) strokes.add(b);

            lastMainSpawnSec = sec;
            phaseSpawnOrdinal++;
            scheduleNextMainSpawn(phase, sec, maxStrokes, false);
        }

        private void scheduleNextMainSpawn(Phase phase, float sec, int maxStrokes, boolean capacityBackoff) {
            nextSpawnSec = sec + adaptiveMainSpawnInterval(phase, sec, maxStrokes, capacityBackoff);
        }

        private float adaptivePhaseIntroDelay(Phase phase, float sec) {
            // 阶段开场不是立即刷屏，而是像呼吸进入：释放最快，分离/余韵最慢。
            float span = Math.max(1f, phase.end - phase.start);
            float local = clamp((sec - phase.start) / span, 0f, 1f);
            float jitter = random.nextFloat();
            float delay;
            if (phase.name.equals("释放")) delay = 0.12f + jitter * 0.55f;
            else if (phase.name.equals("临界")) delay = 0.45f + jitter * 1.65f;
            else if (phase.name.equals("同步")) delay = 0.80f + jitter * 2.80f;
            else if (phase.name.equals("吸引")) delay = 1.10f + jitter * 3.60f;
            else if (phase.name.equals("余韵")) delay = 4.00f + jitter * 8.00f;
            else delay = 0.28f + jitter * 1.20f;
            return Math.min(delay, Math.max(0.20f, span * (0.08f + 0.06f * local)));
        }

        private float adaptiveEmptySceneDelay(Phase phase, float sec) {
            // 旧形体已经结束时，避免空场；但延迟仍按阶段有差异，避免“没了就立刻补一个”的机械感。
            float jitter = random.nextFloat();
            if (phase.name.equals("释放")) return 0.05f + jitter * 0.30f;
            if (phase.name.equals("临界")) return 0.35f + jitter * 0.90f;
            if (phase.name.equals("同步")) return 0.28f + jitter * 0.70f;
            if (phase.name.equals("吸引")) return 0.32f + jitter * 0.85f;
            if (phase.name.equals("余韵")) return 3.00f + jitter * 5.00f;
            return 0.32f + jitter * 0.90f;
        }

        private float adaptiveMainSpawnInterval(Phase phase, float sec, int maxStrokes, boolean capacityBackoff) {
            float phaseSpan = Math.max(1f, phase.end - phase.start);
            float local = clamp((sec - phase.start) / phaseSpan, 0f, 1f);
            float easedLocal = smooth(local);
            float lifeMin = clamp(Math.min(cfg.journeyMinSec, cfg.journeyMaxSec), 6f, 60f);
            float lifeMax = clamp(Math.max(cfg.journeyMinSec, cfg.journeyMaxSec), lifeMin, 60f);
            // 主体出生节奏跟“单个形体生命时长”松耦合：寿命越长，上场越慢；但不会机械等到寿命结束。
            float lifeRef = clamp(lerp(lifeMin, lifeMax, 0.18f + 0.10f * cfg.strokeDensity), 6f, 28f);

            float minMul;
            float maxMul;
            float phaseTempo = 1f;
            float minSec;
            float maxSec;

            if (phase.name.equals("分离")) {
                minMul = 1.18f; maxMul = 3.40f;
                phaseTempo = lerp(1.18f, 0.92f, easedLocal);      // 越接近吸引，越愿意再次出现。
                minSec = 2.2f; maxSec = 14.0f;
            } else if (phase.name.equals("吸引")) {
                minMul = 0.86f; maxMul = 2.18f;
                phaseTempo = lerp(1.08f, 0.78f, easedLocal);      // 越靠近相遇，间隔自然缩短。
                minSec = 1.8f; maxSec = 12.0f;
            } else if (phase.name.equals("同步")) {
                minMul = 0.74f; maxMul = 1.62f;
                phaseTempo = 1.0f + 0.16f * (float)Math.sin(spawnBreathPhase + easedLocal * Math.PI * 6.0f);
                minSec = 1.6f; maxSec = 10.0f;
            } else if (phase.name.equals("临界")) {
                minMul = 0.58f; maxMul = 1.28f;
                phaseTempo = 1.06f - 0.28f * (float)Math.sin(easedLocal * Math.PI); // 中段压缩，前后稍慢。
                minSec = 1.2f; maxSec = 8.0f;
            } else if (phase.name.equals("释放")) {
                minMul = phaseSpawnOrdinal <= 0 ? 0.72f : 1.55f;
                maxMul = phaseSpawnOrdinal <= 0 ? 1.45f : 3.20f;
                phaseTempo = 0.88f + 0.40f * easedLocal;          // 爆发后不再频繁叠加主体。
                minSec = 12.0f; maxSec = 72.0f;
            } else {
                minMul = 1.35f; maxMul = 3.65f;
                phaseTempo = 1.18f + 0.22f * easedLocal;          // 余韵越往后越稀。
                minSec = 16.0f; maxSec = 90.0f;
            }

            // 三角分布比均匀随机更自然：多数间隔在中间，偶尔短一点或长一点。
            float tri = (random.nextFloat() + random.nextFloat()) * 0.5f;
            float randomnessCurve = lerp(1.65f, 0.74f, cfg.randomness);
            float naturalPick = (float)Math.pow(tri, randomnessCurve);
            float interval = lifeRef * lerp(minMul, maxMul, naturalPick);

            // 画面负载反压：当前已有主体越多，下一次越晚；避免截图中那种主形体叠加成大白幕。
            float activeLoad = clamp(strokes.size() / (float)Math.max(1, maxStrokes), 0f, 1f);
            float loadBackPressure = 1f + activeLoad * activeLoad * 0.82f;
            if (capacityBackoff) loadBackPressure += 0.58f + random.nextFloat() * 0.62f;

            // 配置仍然生效：密度越高间隔越短，但保持阶段最低保护，不会变成急促连刷。
            float densityScale = lerp(1.55f, 0.86f, cfg.strokeDensity);
            float intimacyScale = lerp(1.08f, 0.88f, cfg.intimacy);
            float randomWobble = lerp(0.88f, 1.16f, random.nextFloat());
            float wobbleAmount = lerp(0.42f, 1.0f, cfg.randomness);
            randomWobble = lerp(1f, randomWobble, wobbleAmount);
            float breath = 1f + 0.14f * (float)Math.sin(spawnBreathPhase + phaseSpawnOrdinal * 1.37f + local * Math.PI * 4.0f);

            interval *= phaseTempo * loadBackPressure * densityScale * intimacyScale * randomWobble * breath;
            if (cfg.powerSave) interval *= 1.22f;

            // 避免一轮随机极端值造成“太短/太长”：用轻微惯性平滑，但保留随机生命感。
            float normalized = interval / Math.max(1f, lifeRef);
            spawnTempoMemory = lerp(spawnTempoMemory, normalized, 0.34f);
            interval = lerp(interval, spawnTempoMemory * lifeRef, 0.18f);

            // 如果主体全部离场太久，则允许提前，避免桌面长时间没有生命主体。
            if (strokes.isEmpty() && sec - lastMainSpawnSec > maxSec * 0.70f) {
                interval = Math.min(interval, minSec + random.nextFloat() * minSec * 0.65f);
            }
            return clamp(interval, minSec, maxSec);
        }

        private void tuneActorPairForPhase(StrokeEvent a, StrokeEvent b, Phase phase, int sceneProgram) {
            a.partner = b;
            b.partner = a;
            float leftX = width * (0.14f + random.nextFloat() * 0.18f);
            float rightX = width * (0.68f + random.nextFloat() * 0.18f);
            float topY = height * (0.18f + random.nextFloat() * 0.20f);
            float midY = height * (0.34f + random.nextFloat() * 0.28f);
            float lowY = height * (0.64f + random.nextFloat() * 0.18f);
            float commonX = width * (0.32f + random.nextFloat() * 0.36f);
            float commonY = height * (0.26f + random.nextFloat() * 0.48f);

            switch (sceneProgram) {
                case 0: // 遥远双生
                    a.attractX = leftX;  b.attractX = rightX;
                    a.attractY = b.attractY = midY;
                    break;
                case 1: // 对角追逐
                    a.attractX = leftX;  a.attractY = lowY;
                    b.attractX = rightX; b.attractY = topY;
                    commonX = width * 0.50f; commonY = height * 0.48f;
                    break;
                case 2: // 纵向绽放
                    a.attractX = commonX - width * 0.08f;
                    b.attractX = commonX + width * 0.08f;
                    a.attractY = lowY; b.attractY = topY;
                    commonY = height * 0.50f;
                    break;
                case 3: // 水域漂移
                    a.attractX = width * 0.28f; b.attractX = width * 0.72f;
                    a.attractY = height * 0.58f; b.attractY = height * 0.42f;
                    commonY = height * 0.52f;
                    break;
                case 4: // 螺旋互缠
                    a.attractX = commonX - width * 0.05f;
                    b.attractX = commonX + width * 0.05f;
                    a.attractY = commonY - height * 0.06f;
                    b.attractY = commonY + height * 0.06f;
                    break;
                default: // 中央汇环
                    a.attractX = b.attractX = commonX;
                    a.attractY = commonY - height * 0.08f;
                    b.attractY = commonY + height * 0.08f;
                    break;
            }

            if (phase.name.equals("分离")) {
                a.relation = 0f;
                b.relation = 0f;
                if (sceneProgram == 5) {
                    a.attractX = leftX;
                    b.attractX = rightX;
                }
                return;
            }
            if (phase.name.equals("吸引")) {
                a.relation = 0.18f;
                b.relation = 0.18f;
                a.attractX = lerp(a.attractX, commonX, 0.42f);
                a.attractY = lerp(a.attractY, commonY, 0.42f);
                b.attractX = lerp(b.attractX, commonX, 0.42f);
                b.attractY = lerp(b.attractY, commonY, 0.42f);
            } else if (phase.name.equals("同步")) {
                a.relation = 0.58f;
                b.relation = 0.58f;
                b.seed = a.seed + 0.18f + random.nextFloat() * 0.26f;
                b.speed = lerp(b.speed, a.speed, 0.72f);
                a.attractX = lerp(a.attractX, commonX, 0.72f);
                b.attractX = lerp(b.attractX, commonX, 0.72f);
                a.attractY = lerp(a.attractY, commonY, 0.72f);
                b.attractY = lerp(b.attractY, commonY, 0.72f);
            } else if (phase.name.equals("临界") || phase.name.equals("释放")) {
                a.relation = 0.92f;
                b.relation = 0.92f;
                b.seed = a.seed + 0.06f + random.nextFloat() * 0.12f;
                b.speed = lerp(b.speed, a.speed, 0.86f);
                a.attractX = b.attractX = commonX;
                a.attractY = b.attractY = commonY;
                a.widthScale *= 1.10f;
                b.widthScale *= 1.16f;
            } else { // 余韵
                a.relation = 0.08f;
                b.relation = 0.08f;
                a.attractX = lerp(a.attractX, commonX, 0.18f);
                a.attractY = lerp(a.attractY, commonY, 0.18f);
                b.attractX = lerp(b.attractX, commonX, 0.18f);
                b.attractY = lerp(b.attractY, commonY, 0.18f);
            }
        }


        private void decayArtMemory() {
            for (int i = 0; i < motifCooldown.length; i++) {
                motifCooldown[i] = Math.max(0, motifCooldown[i] - 1);
            }
            for (int i = 0; i < sceneCooldown.length; i++) {
                sceneCooldown[i] = Math.max(0, sceneCooldown[i] - 1);
            }
            for (int i = 0; i < colorMoodCooldown.length; i++) {
                colorMoodCooldown[i] = Math.max(0, colorMoodCooldown[i] - 1);
            }
            for (int i = 0; i < shapeFamilyCooldown.length; i++) {
                shapeFamilyCooldown[i] = Math.max(0, shapeFamilyCooldown[i] - 1);
            }
            for (int i = 0; i < bodySdfCooldown.length; i++) {
                bodySdfCooldown[i] = Math.max(0, bodySdfCooldown[i] - 1);
            }
            for (int i = 0; i < pathTypeCooldown.length; i++) {
                pathTypeCooldown[i] = Math.max(0, pathTypeCooldown[i] - 1);
            }
            for (int i = 0; i < masterTemplateCooldown.length; i++) {
                masterTemplateCooldown[i] = Math.max(0, masterTemplateCooldown[i] - 1);
            }
            for (int i = 0; i < artStyleCooldown.length; i++) {
                artStyleCooldown[i] = Math.max(0, artStyleCooldown[i] - 1);
            }
        }

        private void rememberMotif(int motif) {
            if (motif < 0 || motif >= motifCooldown.length) return;
            motifCooldown[motif] = Math.max(motifCooldown[motif], 4);
            int neighborA = Math.max(0, motif - 1);
            int neighborB = Math.min(motifCooldown.length - 1, motif + 1);
            motifCooldown[neighborA] = Math.max(motifCooldown[neighborA], 1);
            motifCooldown[neighborB] = Math.max(motifCooldown[neighborB], 1);
        }

        private void rememberSceneProgram(int sceneProgram) {
            if (sceneProgram < 0 || sceneProgram >= sceneCooldown.length) return;
            sceneCooldown[sceneProgram] = Math.max(sceneCooldown[sceneProgram], 4);
        }

        private void rememberColorMood(int colorMood) {
            if (colorMood < 0 || colorMood >= colorMoodCooldown.length) return;
            colorMoodCooldown[colorMood] = Math.max(colorMoodCooldown[colorMood], 3);
        }

        private int chooseSceneProgram(Phase phase) {
            float[] w;
            if (phase.name.equals("分离")) {
                w = new float[]{1.40f, 1.18f, 0.72f, 1.12f, 0.48f, 0.66f};
            } else if (phase.name.equals("吸引")) {
                w = new float[]{0.68f, 1.18f, 0.94f, 0.86f, 1.24f, 0.72f};
            } else if (phase.name.equals("同步")) {
                w = new float[]{0.34f, 0.72f, 0.82f, 0.76f, 1.42f, 1.10f};
            } else if (phase.name.equals("临界")) {
                w = new float[]{0.18f, 0.46f, 0.62f, 0.42f, 1.08f, 1.56f};
            } else if (phase.name.equals("释放")) {
                w = new float[]{0.08f, 0.22f, 0.34f, 0.18f, 0.92f, 1.68f};
            } else {
                w = new float[]{0.86f, 0.34f, 0.92f, 1.28f, 0.24f, 0.46f};
            }
            float drift = 0.5f + 0.5f * (float)Math.sin((SystemClock.elapsedRealtime() - startMs) / 1000f * 0.013f + artSpawnIndex * 0.73f);
            w[0] *= 0.78f + drift * 0.52f;
            w[3] *= 0.82f + (1f - drift) * 0.58f;
            w[4] *= 0.76f + drift * 0.70f;
            w[5] *= 0.72f + (1f - drift) * 0.86f;
            for (int i = 0; i < w.length; i++) {
                w[i] *= 1f / (1f + sceneCooldown[i] * 0.95f);
            }
            int picked = weightedMotif(w);
            rememberSceneProgram(picked);
            return picked;
        }

        private int chooseColorMood(Phase phase) {
            float[] w;
            if (phase.name.equals("分离")) {
                w = new float[]{1.36f, 0.74f, 0.42f, 0.34f, 0.56f};
            } else if (phase.name.equals("吸引")) {
                w = new float[]{0.82f, 1.22f, 0.74f, 0.68f, 0.92f};
            } else if (phase.name.equals("同步")) {
                w = new float[]{0.54f, 0.92f, 1.18f, 0.74f, 1.02f};
            } else if (phase.name.equals("临界")) {
                w = new float[]{0.32f, 0.62f, 0.96f, 1.26f, 0.92f};
            } else if (phase.name.equals("释放")) {
                w = new float[]{0.10f, 0.22f, 0.68f, 1.66f, 0.72f};
            } else {
                w = new float[]{0.88f, 0.56f, 0.54f, 0.28f, 1.62f};
            }
            for (int i = 0; i < w.length; i++) {
                w[i] *= 1f / (1f + colorMoodCooldown[i] * 1.10f);
            }
            int picked = weightedMotif(w);
            rememberColorMood(picked);
            return picked;
        }

        private void applyColorMood(StrokeEvent s, int colorMood, int[] colors) {
            int c0 = colors[0], c1 = colors[1], c2 = colors[2], c3 = colors[3];
            switch (colorMood) {
                case 0: // 冷澈
                    s.colorA = s.actor == 1 ? c0 : c1;
                    s.colorB = Color.WHITE;
                    break;
                case 1: // 柔粉
                    s.colorA = s.actor == 1 ? c1 : c2;
                    s.colorB = c0;
                    break;
                case 2: // 虹彩
                    s.colorA = s.actor == 1 ? c0 : c2;
                    s.colorB = s.actor == 1 ? c1 : c3;
                    break;
                case 3: // 炽热释放
                    s.colorA = s.actor == 1 ? c3 : c2;
                    s.colorB = Color.WHITE;
                    break;
                default: // 余韵水域
                    s.colorA = s.actor == 1 ? c1 : c0;
                    s.colorB = s.actor == 1 ? c0 : Color.WHITE;
                    break;
            }
        }

        private ShapeDNA chooseShapeDNA(Phase phase, int actor, int motif, int sceneProgram, int colorMood) {
            ShapeDNA dna = new ShapeDNA();
            dna.family = chooseShapeFamily(phase, actor, motif, sceneProgram);
            dna.bodySdf = chooseBodySdf(phase, dna.family, motif);
            dna.pathType = choosePathType(phase, dna.family, sceneProgram);
            dna.flowField = chooseFlowField(phase, actor, sceneProgram);
            dna.colorMood = colorMood;
            dna.relationRole = actor == 1 ? 0 : (actor == 2 ? 1 : 2); // seeker / responder / shared
            dna.lifeScript = lifeScriptForPhase(phase.name);
            dna.masterTemplate = chooseMasterTemplate(phase, dna.family, dna.bodySdf, dna.pathType, actor, sceneProgram);
            dna.templateVariant = random.nextInt(10000);
            dna.seed = random.nextFloat() * (float)Math.PI * 2f;
            dna.aspect = 0.58f + random.nextFloat() * 1.28f;
            dna.softness = 0.52f + random.nextFloat() * 0.76f;
            dna.textureSeed = random.nextInt();
            rememberShapeDNA(dna);
            return dna;
        }

        private int chooseShapeFamily(Phase phase, int actor, int motif, int sceneProgram) {
            float[] w;
            if (phase.name.equals("分离")) {
                w = new float[]{1.45f, 0.42f, 0.62f, 1.20f, 0.70f, 0.76f, 0.46f};
            } else if (phase.name.equals("吸引")) {
                w = new float[]{1.10f, 1.06f, 0.84f, 0.48f, 1.38f, 0.72f, 1.20f};
            } else if (phase.name.equals("同步")) {
                w = new float[]{0.88f, 1.18f, 0.76f, 0.68f, 1.08f, 1.22f, 1.36f};
            } else if (phase.name.equals("临界")) {
                w = new float[]{0.62f, 0.82f, 0.54f, 0.90f, 1.46f, 1.30f, 1.52f};
            } else if (phase.name.equals("释放")) {
                w = new float[]{0.32f, 0.46f, 0.24f, 1.30f, 1.18f, 1.64f, 0.82f};
            } else {
                w = new float[]{1.34f, 0.62f, 1.28f, 0.58f, 0.94f, 0.82f, 0.46f};
            }
            // motif 仍作为“审美倾向”，但不再等同于最终形体。
            if (motif == 12) { w[FAMILY_MEMBRANE] *= 1.28f; w[FAMILY_LIQUID] *= 1.34f; }
            if (motif == 13) { w[FAMILY_MEMBRANE] *= 1.18f; w[FAMILY_BLOSSOM] *= 1.14f; }
            if (motif == 14) { w[FAMILY_BLOSSOM] *= 1.55f; }
            if (motif == 15) { w[FAMILY_MEMBRANE] *= 1.18f; w[FAMILY_JELLYFISH] *= 1.10f; }
            if (motif == 16) { w[FAMILY_HALO] *= 1.55f; w[FAMILY_TWIN_ORBIT] *= 1.18f; }
            if (motif == 17 || motif == 3 || motif == 5) { w[FAMILY_CRYSTAL] *= 1.42f; }
            if (sceneProgram == 4 || sceneProgram == 5) w[FAMILY_TWIN_ORBIT] *= 1.28f;
            if (sceneProgram == 3) { w[FAMILY_JELLYFISH] *= 1.24f; w[FAMILY_MEMBRANE] *= 1.16f; }
            if (actor == 1) { w[FAMILY_CRYSTAL] *= 1.16f; w[FAMILY_HALO] *= 1.08f; }
            if (actor == 2) { w[FAMILY_BLOSSOM] *= 1.22f; w[FAMILY_LIQUID] *= 1.18f; }
            for (int i = 0; i < w.length; i++) {
                w[i] *= 1f / (1f + shapeFamilyCooldown[i] * 0.86f);
            }
            return weightedMotif(w);
        }

        private int chooseBodySdf(Phase phase, int family, int motif) {
            float[] w = new float[]{1f, 0.84f, 0.78f, 0.72f, 0.74f, 0.62f, 0.64f};
            switch (family) {
                case FAMILY_MEMBRANE:
                    w[SDF_ELLIPSE] *= 1.75f; w[SDF_IMPLICIT_MERGE] *= 1.18f; w[SDF_CAPSULE] *= 0.96f; break;
                case FAMILY_BLOSSOM:
                    w[SDF_PETAL] *= 2.10f; w[SDF_ELLIPSE] *= 1.20f; break;
                case FAMILY_JELLYFISH:
                    w[SDF_UMBRELLA] *= 2.20f; w[SDF_CAPSULE] *= 1.22f; break;
                case FAMILY_CRYSTAL:
                    w[SDF_SHARD] *= 2.30f; w[SDF_CAPSULE] *= 0.62f; break;
                case FAMILY_LIQUID:
                    w[SDF_IMPLICIT_MERGE] *= 2.25f; w[SDF_ELLIPSE] *= 1.36f; break;
                case FAMILY_HALO:
                    w[SDF_RING] *= 2.35f; w[SDF_ELLIPSE] *= 0.72f; break;
                default:
                    w[SDF_RING] *= 1.34f; w[SDF_IMPLICIT_MERGE] *= 1.52f; break;
            }
            if (motif == 14) w[SDF_PETAL] *= 1.30f;
            if (motif == 16) w[SDF_RING] *= 1.45f;
            if (motif == 17) w[SDF_SHARD] *= 1.50f;
            if (phase.name.equals("临界")) w[SDF_IMPLICIT_MERGE] *= 1.26f;
            if (phase.name.equals("余韵")) { w[SDF_ELLIPSE] *= 1.36f; w[SDF_UMBRELLA] *= 1.22f; }
            for (int i = 0; i < w.length; i++) w[i] *= 1f / (1f + bodySdfCooldown[i] * 0.72f);
            return weightedMotif(w);
        }

        private int choosePathType(Phase phase, int family, int sceneProgram) {
            float[] w;
            if (phase.name.equals("分离")) w = new float[]{1.45f, 0.42f, 0.12f, 0.38f, 0.06f, 1.18f};
            else if (phase.name.equals("吸引")) w = new float[]{0.68f, 0.72f, 1.55f, 0.88f, 0.12f, 0.28f};
            else if (phase.name.equals("同步")) w = new float[]{0.46f, 1.06f, 0.96f, 1.48f, 0.18f, 0.34f};
            else if (phase.name.equals("临界")) w = new float[]{0.20f, 1.45f, 1.20f, 0.90f, 0.36f, 0.18f};
            else if (phase.name.equals("释放")) w = new float[]{0.08f, 0.36f, 0.22f, 0.42f, 2.20f, 0.12f};
            else w = new float[]{1.08f, 0.42f, 0.20f, 0.44f, 0.06f, 1.36f};
            if (family == FAMILY_HALO || family == FAMILY_TWIN_ORBIT) w[PATH_ORBIT] *= 1.38f;
            if (family == FAMILY_LIQUID) w[PATH_ATTRACT] *= 1.24f;
            if (family == FAMILY_JELLYFISH) w[PATH_DRIFT] *= 1.22f;
            if (sceneProgram == 4) w[PATH_SPIRAL] *= 1.36f;
            if (sceneProgram == 5) w[PATH_ATTRACT] *= 1.24f;
            for (int i = 0; i < w.length; i++) w[i] *= 1f / (1f + pathTypeCooldown[i] * 0.68f);
            return weightedMotif(w);
        }

        private int chooseFlowField(Phase phase, int actor, int sceneProgram) {
            if (phase.name.equals("释放")) return FLOW_EXPAND;
            if (phase.name.equals("同步") || sceneProgram == 4 || sceneProgram == 5) return FLOW_SHARED;
            if (actor == 1) return FLOW_CURL_A;
            if (actor == 2) return FLOW_CURL_B;
            return random.nextBoolean() ? FLOW_CURL_A : FLOW_CURL_B;
        }

        private int chooseMasterTemplate(Phase phase, int family, int bodySdf, int pathType, int actor, int sceneProgram) {
            float[] w = new float[]{0.86f, 0.82f, 0.76f, 0.72f, 0.62f, 0.74f};
            switch (family) {
                case FAMILY_MEMBRANE:
                    w[TEMPLATE_MEMBRANE_BREATH] *= 2.20f; w[TEMPLATE_LIQUID_LACE] *= 1.12f; break;
                case FAMILY_BLOSSOM:
                    w[TEMPLATE_BLOSSOM_CROWN] *= 2.35f; w[TEMPLATE_TWIN_LEAF] *= 1.10f; break;
                case FAMILY_JELLYFISH:
                    w[TEMPLATE_JELLY_UMBRELLA] *= 2.50f; w[TEMPLATE_MEMBRANE_BREATH] *= 1.12f; break;
                case FAMILY_CRYSTAL:
                    w[TEMPLATE_CRYSTAL_SHARD] *= 2.60f; break;
                case FAMILY_LIQUID:
                    w[TEMPLATE_LIQUID_LACE] *= 2.30f; w[TEMPLATE_TWIN_LEAF] *= 1.12f; break;
                case FAMILY_HALO:
                    w[TEMPLATE_BLOSSOM_CROWN] *= 1.18f; w[TEMPLATE_TWIN_LEAF] *= 1.18f; break;
                default:
                    w[TEMPLATE_TWIN_LEAF] *= 2.15f; w[TEMPLATE_LIQUID_LACE] *= 1.10f; break;
            }
            if (phase.name.equals("分离")) { w[TEMPLATE_MEMBRANE_BREATH] *= 1.28f; w[TEMPLATE_JELLY_UMBRELLA] *= 1.22f; w[TEMPLATE_CRYSTAL_SHARD] *= 1.08f; }
            if (phase.name.equals("吸引")) { w[TEMPLATE_TWIN_LEAF] *= 1.42f; w[TEMPLATE_LIQUID_LACE] *= 1.30f; }
            if (phase.name.equals("同步")) { w[TEMPLATE_BLOSSOM_CROWN] *= 1.48f; w[TEMPLATE_TWIN_LEAF] *= 1.34f; }
            if (phase.name.equals("临界")) { w[TEMPLATE_LIQUID_LACE] *= 1.52f; w[TEMPLATE_CRYSTAL_SHARD] *= 1.26f; }
            if (phase.name.equals("余韵")) { w[TEMPLATE_MEMBRANE_BREATH] *= 1.36f; w[TEMPLATE_JELLY_UMBRELLA] *= 1.20f; }
            if (bodySdf == SDF_SHARD) w[TEMPLATE_CRYSTAL_SHARD] *= 1.22f;
            if (bodySdf == SDF_PETAL) w[TEMPLATE_BLOSSOM_CROWN] *= 1.22f;
            if (bodySdf == SDF_UMBRELLA) w[TEMPLATE_JELLY_UMBRELLA] *= 1.22f;
            if (bodySdf == SDF_IMPLICIT_MERGE) w[TEMPLATE_LIQUID_LACE] *= 1.24f;
            if (pathType == PATH_ORBIT) w[TEMPLATE_TWIN_LEAF] *= 1.20f;
            if (pathType == PATH_ATTRACT) w[TEMPLATE_LIQUID_LACE] *= 1.14f;
            if (sceneProgram == 4 || sceneProgram == 5) w[TEMPLATE_TWIN_LEAF] *= 1.12f;
            if (actor == 2) w[TEMPLATE_BLOSSOM_CROWN] *= 1.08f;
            for (int i = 0; i < w.length; i++) w[i] *= 1f / (1f + masterTemplateCooldown[i] * 0.72f);
            return weightedMotif(w);
        }

        private int lifeScriptForPhase(String phaseName) {
            if (phaseName.equals("分离")) return 0;   // birth -> explore -> farewell
            if (phaseName.equals("吸引")) return 1;   // birth -> seek -> encounter
            if (phaseName.equals("同步")) return 2;   // shared breath
            if (phaseName.equals("临界")) return 3;   // compress -> transform
            if (phaseName.equals("释放")) return 4;   // burst
            return 5;                                  // afterglow
        }

        private void rememberShapeDNA(ShapeDNA dna) {
            if (dna == null) return;
            if (dna.family >= 0 && dna.family < shapeFamilyCooldown.length) shapeFamilyCooldown[dna.family] = Math.max(shapeFamilyCooldown[dna.family], 4);
            if (dna.bodySdf >= 0 && dna.bodySdf < bodySdfCooldown.length) bodySdfCooldown[dna.bodySdf] = Math.max(bodySdfCooldown[dna.bodySdf], 3);
            if (dna.pathType >= 0 && dna.pathType < pathTypeCooldown.length) pathTypeCooldown[dna.pathType] = Math.max(pathTypeCooldown[dna.pathType], 2);
            if (dna.masterTemplate >= 0 && dna.masterTemplate < masterTemplateCooldown.length) masterTemplateCooldown[dna.masterTemplate] = Math.max(masterTemplateCooldown[dna.masterTemplate], 3);
        }

        private ArtistDNA chooseArtistDNA(Phase phase, int actor, int sceneProgram, ShapeDNA dna) {
            ArtistDNA art = new ArtistDNA();
            art.styleFamily = chooseArtistStyle(phase, actor, sceneProgram, dna);
            art.silhouetteLaw = chooseSilhouetteLaw(phase, art.styleFamily, dna);
            art.detailDensity = chooseDetailDensity(phase, art.styleFamily);
            art.edgeTreatment = chooseEdgeTreatment(art.styleFamily, dna);
            art.innerTexture = chooseInnerTexture(phase, art.styleFamily, dna);
            art.rhythmStyle = chooseRhythmStyle(phase, art.styleFamily);
            art.compositionRole = chooseCompositionRole(actor, phase, art.styleFamily);
            art.restraintLevel = chooseRestraintLevel(phase, art.styleFamily);
            art.beautyScore = scoreArtistDNA(phase, dna, art);
            rememberArtistDNA(art);
            return art;
        }

        private int chooseArtistStyle(Phase phase, int actor, int sceneProgram, ShapeDNA dna) {
            float[] w;
            if (phase.name.equals("分离")) {
                w = new float[]{1.52f, 0.48f, 0.76f, 1.04f};
            } else if (phase.name.equals("吸引")) {
                w = new float[]{1.08f, 0.92f, 1.26f, 0.72f};
            } else if (phase.name.equals("同步")) {
                w = new float[]{0.86f, 1.36f, 0.94f, 0.64f};
            } else if (phase.name.equals("临界")) {
                w = new float[]{0.62f, 1.06f, 1.34f, 0.94f};
            } else if (phase.name.equals("释放")) {
                w = new float[]{0.32f, 1.20f, 1.18f, 1.06f};
            } else {
                w = new float[]{1.42f, 0.72f, 0.82f, 0.54f};
            }
            if (dna != null) {
                if (dna.family == FAMILY_MEMBRANE || dna.family == FAMILY_JELLYFISH) w[ART_MEMBRANE_POETRY] *= 1.28f;
                if (dna.family == FAMILY_BLOSSOM || dna.family == FAMILY_HALO) w[ART_BLOSSOM_RESONANCE] *= 1.22f;
                if (dna.family == FAMILY_LIQUID || dna.bodySdf == SDF_IMPLICIT_MERGE) w[ART_LIQUID_EMBRACE] *= 1.32f;
                if (dna.family == FAMILY_CRYSTAL) w[ART_CRYSTAL_GRACE] *= 1.50f;
            }
            if (sceneProgram == 2) w[ART_BLOSSOM_RESONANCE] *= 1.26f;
            if (sceneProgram == 3) w[ART_MEMBRANE_POETRY] *= 1.22f;
            if (sceneProgram == 4) { w[ART_LIQUID_EMBRACE] *= 1.12f; w[ART_BLOSSOM_RESONANCE] *= 1.10f; }
            if (actor == 1) w[ART_CRYSTAL_GRACE] *= 1.14f;
            if (actor == 2) { w[ART_BLOSSOM_RESONANCE] *= 1.10f; w[ART_LIQUID_EMBRACE] *= 1.08f; }
            for (int i = 0; i < w.length; i++) w[i] *= 1f / (1f + artStyleCooldown[i] * 0.68f);
            return weightedMotif(w);
        }

        private int chooseSilhouetteLaw(Phase phase, int styleFamily, ShapeDNA dna) {
            if (styleFamily == ART_MEMBRANE_POETRY) return random.nextFloat() < 0.62f ? SILHOUETTE_SIMPLE : SILHOUETTE_ASYMMETRIC;
            if (styleFamily == ART_BLOSSOM_RESONANCE) return phase.name.equals("同步") ? SILHOUETTE_TWIN_BALANCED : SILHOUETTE_TAPERED;
            if (styleFamily == ART_LIQUID_EMBRACE) return random.nextFloat() < 0.60f ? SILHOUETTE_ASYMMETRIC : SILHOUETTE_TWIN_BALANCED;
            return random.nextFloat() < 0.55f ? SILHOUETTE_TAPERED : SILHOUETTE_SIMPLE;
        }

        private int chooseDetailDensity(Phase phase, int styleFamily) {
            if (phase.name.equals("分离") || phase.name.equals("余韵")) return random.nextFloat() < 0.70f ? DETAIL_SPARSE : DETAIL_MEDIUM;
            if (phase.name.equals("释放")) return random.nextFloat() < 0.50f ? DETAIL_MEDIUM : DETAIL_RICH;
            if (styleFamily == ART_BLOSSOM_RESONANCE) return random.nextFloat() < 0.48f ? DETAIL_MEDIUM : DETAIL_RICH;
            return random.nextFloat() < 0.62f ? DETAIL_MEDIUM : DETAIL_SPARSE;
        }

        private int chooseEdgeTreatment(int styleFamily, ShapeDNA dna) {
            if (styleFamily == ART_CRYSTAL_GRACE) return EDGE_REFRACT;
            if (styleFamily == ART_LIQUID_EMBRACE) return EDGE_WET_FILM;
            if (styleFamily == ART_BLOSSOM_RESONANCE) return EDGE_IRIDESCENT;
            if (dna != null && dna.family == FAMILY_HALO) return EDGE_IRIDESCENT;
            return EDGE_SOFT_GLOW;
        }

        private int chooseInnerTexture(Phase phase, int styleFamily, ShapeDNA dna) {
            if (styleFamily == ART_CRYSTAL_GRACE) return TEXTURE_CRYSTAL;
            if (styleFamily == ART_BLOSSOM_RESONANCE) return TEXTURE_VEIN;
            if (styleFamily == ART_LIQUID_EMBRACE) return phase.name.equals("余韵") ? TEXTURE_MEMBRANE : TEXTURE_RIPPLE;
            if (dna != null && dna.family == FAMILY_JELLYFISH) return TEXTURE_RIPPLE;
            return phase.name.equals("分离") ? TEXTURE_NONE : TEXTURE_MEMBRANE;
        }

        private int chooseRhythmStyle(Phase phase, int styleFamily) {
            if (phase.name.equals("分离")) return RHYTHM_STILL;
            if (phase.name.equals("吸引") || phase.name.equals("同步")) return RHYTHM_BREATHING;
            if (phase.name.equals("临界")) return RHYTHM_PULSING;
            if (phase.name.equals("释放")) return RHYTHM_BLOOMING;
            return styleFamily == ART_BLOSSOM_RESONANCE ? RHYTHM_BREATHING : RHYTHM_STILL;
        }

        private int chooseCompositionRole(int actor, Phase phase, int styleFamily) {
            if (phase.name.equals("释放")) return actor == 0 ? COMPOSITION_ECHO : COMPOSITION_HERO;
            if (actor == 1 || actor == 2) return phase.name.equals("分离") ? (actor == 1 ? COMPOSITION_HERO : COMPOSITION_SUPPORT) : (actor == 1 ? COMPOSITION_SUPPORT : COMPOSITION_HERO);
            return styleFamily == ART_MEMBRANE_POETRY ? COMPOSITION_ECHO : COMPOSITION_SUPPORT;
        }

        private int chooseRestraintLevel(Phase phase, int styleFamily) {
            if (phase.name.equals("分离") || phase.name.equals("余韵")) return RESTRAINT_HIGH;
            if (phase.name.equals("释放")) return RESTRAINT_EXPRESSIVE;
            if (styleFamily == ART_CRYSTAL_GRACE) return RESTRAINT_MEDIUM;
            return random.nextFloat() < 0.56f ? RESTRAINT_HIGH : RESTRAINT_MEDIUM;
        }

        private float scoreArtistDNA(Phase phase, ShapeDNA dna, ArtistDNA art) {
            float score = 0.58f;
            if (art.compositionRole == COMPOSITION_HERO) score += 0.08f;
            if (art.restraintLevel == RESTRAINT_HIGH) score += (phase.name.equals("分离") || phase.name.equals("余韵")) ? 0.10f : 0.03f;
            if (art.detailDensity == DETAIL_MEDIUM) score += 0.08f;
            if (art.detailDensity == DETAIL_RICH && (phase.name.equals("同步") || phase.name.equals("释放"))) score += 0.06f;
            if (art.silhouetteLaw == SILHOUETTE_ASYMMETRIC) score += 0.06f;
            if (art.silhouetteLaw == SILHOUETTE_TWIN_BALANCED && (phase.name.equals("同步") || phase.name.equals("吸引"))) score += 0.05f;
            if (dna != null) {
                if (art.styleFamily == ART_MEMBRANE_POETRY && (dna.family == FAMILY_MEMBRANE || dna.family == FAMILY_JELLYFISH)) score += 0.10f;
                if (art.styleFamily == ART_BLOSSOM_RESONANCE && (dna.family == FAMILY_BLOSSOM || dna.family == FAMILY_HALO)) score += 0.10f;
                if (art.styleFamily == ART_LIQUID_EMBRACE && dna.family == FAMILY_LIQUID) score += 0.12f;
                if (art.styleFamily == ART_CRYSTAL_GRACE && dna.family == FAMILY_CRYSTAL) score += 0.12f;
            }
            if (art.innerTexture == TEXTURE_NONE && art.detailDensity == DETAIL_RICH) score -= 0.08f;
            if (art.restraintLevel == RESTRAINT_EXPRESSIVE && (phase.name.equals("分离") || phase.name.equals("余韵"))) score -= 0.10f;
            return clamp(score, 0f, 1f);
        }

        private void rememberArtistDNA(ArtistDNA art) {
            if (art == null) return;
            if (art.styleFamily >= 0 && art.styleFamily < artStyleCooldown.length) artStyleCooldown[art.styleFamily] = Math.max(artStyleCooldown[art.styleFamily], 3);
        }

        private void applyArtistDnaToStroke(StrokeEvent s, Phase phase) {
            if (s.artist == null) return;
            if (s.artist.compositionRole == COMPOSITION_HERO) {
                s.widthScale *= 1.12f;
                s.visibleWindow *= 1.08f;
            } else if (s.artist.compositionRole == COMPOSITION_SUPPORT) {
                s.widthScale *= 0.92f;
                s.visibleWindow *= 0.96f;
            } else {
                s.widthScale *= 0.76f;
                s.visibleWindow *= 0.84f;
                s.speed *= 0.92f;
            }
            if (s.artist.silhouetteLaw == SILHOUETTE_SIMPLE) { s.turn *= 0.84f; s.asymmetry *= 0.45f; }
            if (s.artist.silhouetteLaw == SILHOUETTE_TAPERED) { s.widthScale *= 0.98f; s.headLead *= 0.94f; }
            if (s.artist.silhouetteLaw == SILHOUETTE_ASYMMETRIC) { s.asymmetry = clamp(s.asymmetry * 1.35f, -1.2f, 1.2f); s.turn *= 1.08f; }
            if (s.artist.silhouetteLaw == SILHOUETTE_TWIN_BALANCED) { s.relation += 0.05f; s.turn *= 0.92f; }
            if (s.artist.rhythmStyle == RHYTHM_STILL) { s.speed *= 0.92f; s.turn *= 0.88f; }
            if (s.artist.rhythmStyle == RHYTHM_BREATHING) { s.visibleWindow *= 1.05f; }
            if (s.artist.rhythmStyle == RHYTHM_PULSING) { s.speed *= 1.05f; }
            if (s.artist.rhythmStyle == RHYTHM_BLOOMING) { s.widthScale *= 1.10f; }
            if (s.artist.restraintLevel == RESTRAINT_HIGH) { s.widthScale *= 0.92f; s.fan = false; s.fanLines = 0; }
            if (s.artist.restraintLevel == RESTRAINT_EXPRESSIVE && phase.name.equals("释放")) s.widthScale *= 1.08f;
        }

        private void applyAestheticRescue(StrokeEvent s, Phase phase) {
            if (s == null || s.artist == null) return;
            if (s.artist.beautyScore >= 0.70f) return;
            s.fan = false;
            s.fanLines = 0;
            s.widthScale *= 0.90f;
            s.turn *= 0.90f;
            s.visibleWindow *= 0.96f;
            s.artist.restraintLevel = phase.name.equals("释放") ? RESTRAINT_MEDIUM : RESTRAINT_HIGH;
            s.artist.detailDensity = DETAIL_SPARSE;
            s.artist.beautyScore = clamp(s.artist.beautyScore + 0.12f, 0f, 1f);
        }

        private void applyArtistPaletteDiscipline(StrokeEvent s) {
            if (s == null || s.artist == null) return;
            if (s.artist.styleFamily == ART_MEMBRANE_POETRY) {
                s.colorB = mixColor(s.colorA, Color.WHITE, 0.32f);
            } else if (s.artist.styleFamily == ART_BLOSSOM_RESONANCE) {
                s.colorB = mixColor(s.colorB, Color.WHITE, 0.18f);
            } else if (s.artist.styleFamily == ART_LIQUID_EMBRACE) {
                s.colorA = mixColor(s.colorA, s.colorB, 0.18f);
            } else if (s.artist.styleFamily == ART_CRYSTAL_GRACE) {
                s.colorB = mixColor(s.colorA, Color.WHITE, 0.52f);
            }
        }

        private int mixColor(int a, int b, float t) {
            t = clamp(t, 0f, 1f);
            int ar = Color.red(a), ag = Color.green(a), ab = Color.blue(a);
            int br = Color.red(b), bg = Color.green(b), bb = Color.blue(b);
            int rr = clampInt((int)lerp(ar, br, t), 0, 255);
            int gg = clampInt((int)lerp(ag, bg, t), 0, 255);
            int bb2 = clampInt((int)lerp(ab, bb, t), 0, 255);
            return 0xFF000000 | (rr << 16) | (gg << 8) | bb2;
        }

        private void applyShapeDnaToStroke(StrokeEvent s, Phase phase) {
            if (s.dna == null) return;
            switch (s.dna.family) {
                case FAMILY_MEMBRANE:
                    s.widthScale *= 1.20f; s.turn *= 0.82f; s.visibleWindow *= 1.15f; break;
                case FAMILY_BLOSSOM:
                    s.widthScale *= 1.16f; s.turn *= 0.96f; s.visibleWindow *= 1.08f; break;
                case FAMILY_JELLYFISH:
                    s.widthScale *= 1.05f; s.turn *= 1.18f; s.speed *= 0.90f; break;
                case FAMILY_CRYSTAL:
                    s.widthScale *= 0.94f; s.turn *= 0.54f; s.visibleWindow *= 0.98f; break;
                case FAMILY_LIQUID:
                    s.widthScale *= 1.32f; s.turn *= 0.78f; s.visibleWindow *= 1.18f; break;
                case FAMILY_HALO:
                    s.widthScale *= 1.18f; s.turn *= 0.72f; s.visibleWindow *= 1.10f; break;
                case FAMILY_TWIN_ORBIT:
                    s.widthScale *= 1.26f; s.turn *= 0.86f; s.visibleWindow *= 1.18f; break;
            }
            if (s.dna.pathType == PATH_DRIFT) { s.speed *= 0.88f; s.turn *= 1.05f; }
            if (s.dna.pathType == PATH_SPIRAL) { s.turn *= 1.36f; }
            if (s.dna.pathType == PATH_ATTRACT) { s.relation = Math.max(s.relation, phase.relation + 0.12f); }
            if (s.dna.pathType == PATH_ORBIT) { s.turn *= 1.18f; s.visibleWindow *= 1.06f; }
            if (s.dna.pathType == PATH_BURST) { s.speed *= 1.22f; s.visibleWindow *= 0.92f; }
            if (s.dna.pathType == PATH_FAREWELL) { s.speed *= 0.80f; s.visibleWindow *= 1.22f; }
        }

        private int chooseArtMotif(Phase phase, int actor, int sceneProgram) {
            float[] w = motifWeightsForPhase(phase.name);
            // V30：优先选择有完整轮廓的大形体，降低“电子纱扇/星座碎链”这类细网比例。
            // 12 liquid pod, 13 wing, 14 blossom, 15 silk sheet, 16 orbit halo, 17 crystal shard.
            if (actor == 1) {
                w[3] *= 1.15f;   // silver blade
                w[10] *= 0.92f;  // origami sheet
                w[13] *= 1.35f;  // wing
                w[15] *= 1.22f;  // silk sheet
                w[17] *= 1.32f;  // crystal shard
                w[2] *= 0.42f;   // less fan lattice
                w[11] *= 0.34f;  // less dot chain
            } else if (actor == 2) {
                w[4] *= 1.05f;   // petal hook
                w[6] *= 0.95f;   // vine
                w[12] *= 1.45f;  // liquid pod
                w[14] *= 1.58f;  // blossom
                w[16] *= 1.26f;  // orbit halo
                w[2] *= 0.35f;
                w[11] *= 0.28f;
            }

            // V44：章节级构图程序。不同阶段会优先走不同的“构图叙事”，
            // 让每次不是只换位置，而是真正换一种生命形体组合语言。
            switch (sceneProgram) {
                case 0: // 遥远双生 / distant orbit
                    w[3] *= 1.16f;
                    w[7] *= 1.28f;
                    w[13] *= 1.22f;
                    w[16] *= 0.84f;
                    break;
                case 1: // 对角追逐 / diagonal chase
                    w[6] *= 1.24f;
                    w[12] *= 1.08f;
                    w[15] *= 1.12f;
                    w[17] *= 1.10f;
                    break;
                case 2: // 纵向绽放 / vertical bloom
                    w[4] *= 1.18f;
                    w[12] *= 1.14f;
                    w[14] *= 1.30f;
                    w[15] *= 1.10f;
                    break;
                case 3: // 水域漂移 / aquatic drift
                    w[8] *= 1.14f;
                    w[9] *= 1.22f;
                    w[12] *= 1.26f;
                    w[15] *= 1.16f;
                    break;
                case 4: // 螺旋互缠 / helix weave
                    w[9] *= 1.26f;
                    w[13] *= 1.10f;
                    w[16] *= 1.32f;
                    w[17] *= 1.08f;
                    break;
                default: // 中央汇环 / centered halo
                    w[5] *= 1.14f;
                    w[10] *= 1.08f;
                    w[14] *= 1.06f;
                    w[16] *= 1.36f;
                    break;
            }

            // V29/V30：非周期“天气”。不同天气推动不同雕塑形态，而不是反复刷同一种曲线。
            float t = (SystemClock.elapsedRealtime() - startMs) / 1000f;
            float weatherA = 0.5f + 0.5f * (float)Math.sin(t * 0.0173f + artSpawnIndex * 0.618f);
            float weatherB = 0.5f + 0.5f * (float)Math.sin(t * 0.0117f + artSpawnIndex * 1.4142f + 2.1f);
            float weatherC = 0.5f + 0.5f * (float)Math.sin(t * 0.0079f + artSpawnIndex * 1.7320f + 4.7f);
            w[8] *= 0.66f + weatherB * 0.78f;
            w[9] *= 0.62f + weatherC * 0.92f;
            w[12] *= 0.70f + weatherA * 1.35f;
            w[13] *= 0.72f + weatherB * 1.22f;
            w[14] *= 0.68f + weatherC * 1.38f;
            w[15] *= 0.74f + (1f - weatherA) * 1.20f;
            w[16] *= 0.72f + (1f - weatherB) * 1.26f;
            w[17] *= 0.76f + (1f - weatherC) * 1.18f;
            w[2] *= 0.25f + weatherA * 0.18f;
            w[11] *= 0.20f + weatherB * 0.16f;
            // V41：进一步把主体从“线条事件”推向“有轮廓的生命形体”，并限制白色大面积面片。
            // 细线只作为边缘高光或运动脉络，液态泡、羽翼、花冠、丝绸幕、能量环、晶片成为主舞台。
            for (int i = 0; i < 12; i++) w[i] *= 0.62f;
            for (int i = 12; i <= 17; i++) w[i] *= 1.70f;

            // 反重复冷却：最近出现过的母型降权。雕塑类也参与冷却，防止连续看到同一类大形体。
            for (int i = 0; i < w.length; i++) {
                w[i] *= 1f / (1f + motifCooldown[i] * (isSculpturalMotif(i) ? 0.72f : 0.58f));
                if (cfg.powerSave && (i == 8 || i == 9 || i == 11 || i == 14 || i == 16)) w[i] *= 0.68f;
            }

            int motif = weightedMotif(w);
            rememberMotif(motif);
            return motif;
        }

        private float[] motifWeightsForPhase(String phaseName) {
            // 0 comet arc, 1 veil ribbon, 2 electronic fan, 3 silver blade,
            // 4 petal hook, 5 prism polygon, 6 falling leaf, 7 long bridge,
            // 8 jellyfish tendril, 9 nebula coil, 10 origami sheet, 11 constellation chain,
            // 12 liquid pod, 13 luminous wing, 14 blossom crown, 15 silk banner,
            // 16 orbit halo, 17 crystal shard.
            if (phaseName.equals("分离")) {
                return new float[]{1.08f, 0.74f, 0.06f, 0.98f, 0.20f, 0.34f, 0.82f, 1.02f, 0.38f, 0.30f, 0.52f, 0.18f, 0.62f, 1.05f, 0.28f, 0.96f, 0.52f, 0.92f};
            }
            if (phaseName.equals("吸引")) {
                return new float[]{0.60f, 0.95f, 0.12f, 0.38f, 0.86f, 0.46f, 0.92f, 0.42f, 0.74f, 0.54f, 0.46f, 0.12f, 1.24f, 1.12f, 1.42f, 1.05f, 0.78f, 0.52f};
            }
            if (phaseName.equals("同步")) {
                return new float[]{0.34f, 0.86f, 0.30f, 0.48f, 0.72f, 0.58f, 0.44f, 0.32f, 0.50f, 0.64f, 0.72f, 0.16f, 1.06f, 1.30f, 1.20f, 1.34f, 1.18f, 0.76f};
            }
            if (phaseName.equals("临界")) {
                return new float[]{0.22f, 0.56f, 0.28f, 1.02f, 0.56f, 0.62f, 0.24f, 0.48f, 0.42f, 0.76f, 0.92f, 0.20f, 1.22f, 1.18f, 1.06f, 1.28f, 1.46f, 1.32f};
            }
            if (phaseName.equals("释放")) {
                return new float[]{0.24f, 0.40f, 0.22f, 1.14f, 0.32f, 0.46f, 0.22f, 0.94f, 0.34f, 0.72f, 0.88f, 0.22f, 1.48f, 1.06f, 0.86f, 0.92f, 1.70f, 1.46f};
            }
            return new float[]{0.86f, 0.62f, 0.08f, 0.74f, 0.28f, 0.26f, 0.92f, 0.68f, 0.42f, 0.28f, 0.38f, 0.14f, 0.94f, 0.72f, 0.74f, 0.86f, 0.78f, 0.66f};
        }

        private boolean isSculpturalMotif(int motif) {
            return motif >= 12 && motif <= 17;
        }

        private int weightedMotif(float[] w) {
            float total = 0f;
            for (float v : w) total += Math.max(0f, v);
            if (total <= 0.0001f) return random.nextInt(Math.max(1, w.length));
            float r = random.nextFloat() * total;
            for (int i = 0; i < w.length; i++) {
                r -= Math.max(0f, w[i]);
                if (r <= 0f) return i;
            }
            return w.length - 1;
        }

        private int motifControlCount(int motif) {
            switch (motif) {
                case 2: return 6 + random.nextInt(3);   // fan shell
                case 3: return 3 + random.nextInt(2);   // blade shard
                case 4: return 5 + random.nextInt(2);   // petal hook
                case 5: return 5;                       // prism polygon
                case 6: return 5 + random.nextInt(2);   // leaf/vine
                case 7: return 4 + random.nextInt(2);   // long bridge
                case 8: return 6 + random.nextInt(3);   // jellyfish tendril
                case 9: return 6 + random.nextInt(3);   // nebula coil
                case 10: return 5 + random.nextInt(2);  // origami sheet
                case 11: return 4 + random.nextInt(4);  // constellation chain
                case 12: return 5 + random.nextInt(3);  // liquid pod
                case 13: return 5 + random.nextInt(3);  // luminous wing
                case 14: return 6 + random.nextInt(3);  // blossom crown
                case 15: return 5 + random.nextInt(3);  // silk banner
                case 16: return 5 + random.nextInt(3);  // orbit halo
                case 17: return 4 + random.nextInt(3);  // crystal shard
                default: return 4 + random.nextInt(3);
            }
        }

        private StrokeEvent createStroke(Phase phase, int side, boolean fan, int actor, int sceneProgram, int colorMood) {
            int motif = chooseArtMotif(phase, actor, sceneProgram);
            int count = motifControlCount(motif);
            StrokeEvent s = new StrokeEvent(count);
            s.actor = actor;
            s.motif = motif;
            s.sceneProgram = sceneProgram;
            s.colorMood = colorMood;
            s.motifStrength = 0.72f + random.nextFloat() * 0.70f;
            s.variant = random.nextInt(100000);
            s.flowA = 0.65f + random.nextFloat() * 1.70f;
            s.flowB = 0.35f + random.nextFloat() * 1.45f;
            s.flowC = random.nextBoolean() ? 1f : -1f;
            s.asymmetry = -1f + random.nextFloat() * 2f;
            s.dna = chooseShapeDNA(phase, actor, motif, sceneProgram, colorMood);
            s.artist = chooseArtistDNA(phase, actor, sceneProgram, s.dna);
            // V41：生命周期不再一闪而过，但默认限制为 6～60 秒。
            // 每个形体会先显形，再沿着随机轨迹起伏、变形、互相牵引，最后渐隐离场。
            float journeyMin = clamp(Math.min(cfg.journeyMinSec, cfg.journeyMaxSec), 6f, 60f);
            float journeyMax = clamp(Math.max(cfg.journeyMinSec, cfg.journeyMaxSec), journeyMin, 60f);
            s.life = journeyMin + random.nextFloat() * Math.max(0.1f, journeyMax - journeyMin);
            if (phase.name.equals("分离")) s.life *= 1.00f;
            if (phase.name.equals("吸引")) s.life *= 0.98f;
            if (phase.name.equals("同步")) s.life *= 0.96f;
            if (phase.name.equals("临界")) s.life *= 0.84f;
            if (phase.name.equals("释放")) s.life *= 0.62f;
            s.life = clamp(s.life, 4.8f, 60f);
            // V18：不再允许出现截图中那种“残缺的短小点线”。
            // 一个笔触从可见开始就必须具备足够长度，像 Windows/Ribbons 那种完整的一笔光迹，
            // 而不是小虫子或短残片。
            s.visibleWindow = 0.32f + random.nextFloat() * 0.24f;
            if (phase.name.equals("分离")) s.visibleWindow *= 0.92f;
            if (phase.name.equals("同步")) s.visibleWindow *= 1.10f;
            if (phase.name.equals("临界")) s.visibleWindow *= 1.18f;
            if (phase.name.equals("释放")) s.visibleWindow *= 1.24f;
            s.headLead = 0.06f + random.nextFloat() * 0.13f;
            s.seed = random.nextFloat() * (float)Math.PI * 2f;
            s.widthScale = 0.54f + random.nextFloat() * 0.72f;
            s.speed = Math.min(width, height) * (0.82f + random.nextFloat() * (0.90f + cfg.randomness * 0.55f));
            s.turn = 0.06f + random.nextFloat() * (0.20f + cfg.randomness * 0.18f);
            s.relation = phase.relation;
            s.fan = fan || motif == 2;
            s.fanLines = s.fan ? 4 + random.nextInt(8) : 0;
            s.fanGapPx = Math.min(width, height) * (0.003f + random.nextFloat() * 0.009f);
            int[] colors = palette(cfg.style);
            if (actor == 1) {
                // 主动追寻者：冷色、锋利、较直、点线更克制。
                s.colorA = colors[0];
                s.colorB = random.nextFloat() < 0.62f ? colors[1] : Color.WHITE;
                s.widthScale *= 0.82f;
                s.turn *= 0.68f;
                s.visibleWindow *= 0.94f;
                s.fan = false;
                s.fanLines = 0;
            } else if (actor == 2) {
                // 回应者：暖色、柔和、点线喷洒更丰富。
                s.colorA = colors[2];
                s.colorB = random.nextFloat() < 0.58f ? colors[3] : Color.WHITE;
                s.widthScale *= 1.10f;
                s.turn *= 1.18f;
                s.visibleWindow *= 1.05f;
                if (!phase.name.equals("分离") && random.nextFloat() < 0.035f + cfg.randomness * 0.055f) {
                    s.fan = true;
                    s.fanLines = 2 + random.nextInt(2);
                }
            } else {
                s.colorA = pickColor(colors);
                s.colorB = random.nextFloat() < 0.20f ? Color.WHITE : pickColor(colors);
            }
            // V44：不同 Scene DNA 会给同一母型附加不同的“生命剧本”。
            switch (sceneProgram) {
                case 0: // 遥远双生
                    s.life *= 1.10f;
                    s.turn *= 0.86f;
                    s.speed *= 0.94f;
                    break;
                case 1: // 对角追逐
                    s.life *= 0.96f;
                    s.turn *= 1.08f;
                    s.speed *= 1.05f;
                    break;
                case 2: // 纵向绽放
                    s.widthScale *= 1.06f;
                    s.turn *= 0.92f;
                    break;
                case 3: // 水域漂移
                    s.life *= 1.06f;
                    s.speed *= 0.92f;
                    s.turn *= 1.04f;
                    break;
                case 4: // 螺旋互缠
                    s.turn *= 1.18f;
                    s.visibleWindow *= 1.08f;
                    break;
                default: // 中央汇环
                    s.widthScale *= 1.10f;
                    s.visibleWindow *= 1.06f;
                    break;
            }
            // V46：Shape DNA 先于 motif 微调整体生命气质；motif 只继续承担局部纹理/口音。
            applyShapeDnaToStroke(s, phase);
            // V49：Artist DNA 决定主次、克制、轮廓和材质倾向，让主体更像被“导演”出来。
            applyArtistDnaToStroke(s, phase);

            // V28：不同母型有不同的运动气质，避免“所有线条长得一样”。
            if (s.motif == 2) { // electronic fan / shell
                s.fan = true;
                s.fanLines = Math.max(s.fanLines, 7 + random.nextInt(8));
                s.visibleWindow *= 1.18f;
                s.widthScale *= 0.92f;
                s.turn *= 0.78f;
            } else if (s.motif == 3) { // silver blade
                s.widthScale *= 0.72f;
                s.turn *= 0.48f;
                s.visibleWindow *= 0.92f;
                s.colorA = Color.WHITE;
            } else if (s.motif == 4) { // petal hook
                s.widthScale *= 1.12f;
                s.turn *= 1.35f;
                s.visibleWindow *= 1.10f;
            } else if (s.motif == 5) { // prism polygon
                s.widthScale *= 0.86f;
                s.turn *= 0.58f;
                s.visibleWindow *= 0.96f;
            } else if (s.motif == 6) { // falling leaf / vine
                s.widthScale *= 1.04f;
                s.turn *= 1.16f;
            } else if (s.motif == 7) { // long bridge arc
                s.visibleWindow *= 1.22f;
                s.turn *= 0.62f;
            } else if (s.motif == 8) { // jellyfish tendril / water grass
                s.widthScale *= 0.94f;
                s.turn *= 1.42f;
                s.visibleWindow *= 1.18f;
            } else if (s.motif == 9) { // nebula coil / smoke spiral
                s.widthScale *= 1.06f;
                s.turn *= 1.08f;
                s.visibleWindow *= 1.12f;
            } else if (s.motif == 10) { // origami light sheet
                s.widthScale *= 0.92f;
                s.turn *= 0.74f;
                s.visibleWindow *= 1.08f;
                if (random.nextFloat() < 0.42f) { s.fan = true; s.fanLines = Math.max(s.fanLines, 5 + random.nextInt(5)); }
            } else if (s.motif == 11) { // constellation broken chain
                s.widthScale *= 0.56f;
                s.turn *= 0.86f;
                s.visibleWindow *= 0.86f;
            } else if (s.motif == 12) { // liquid light pod: rounded glowing body
                s.widthScale *= 1.32f;
                s.turn *= 0.62f;
                s.visibleWindow *= 1.22f;
                s.fan = false;
                s.fanLines = 0;
            } else if (s.motif == 13) { // luminous wing: broad two-sided lobe
                s.widthScale *= 1.22f;
                s.turn *= 0.58f;
                s.visibleWindow *= 1.26f;
                s.fan = false;
                s.fanLines = 0;
            } else if (s.motif == 14) { // blossom crown: petal cluster
                s.widthScale *= 1.28f;
                s.turn *= 0.84f;
                s.visibleWindow *= 1.20f;
                s.fan = false;
                s.fanLines = 0;
            } else if (s.motif == 15) { // silk banner: wide translucent sheet
                s.widthScale *= 1.22f;
                s.turn *= 0.70f;
                s.visibleWindow *= 1.08f;
                s.fan = false;
                s.fanLines = 0;
            } else if (s.motif == 16) { // orbit halo: luminous ring / crescent
                s.widthScale *= 1.34f;
                s.turn *= 0.66f;
                s.visibleWindow *= 1.12f;
                s.fan = false;
                s.fanLines = 0;
            } else if (s.motif == 17) { // crystal shard: hard angular luminous plate
                s.widthScale *= 1.18f;
                s.turn *= 0.42f;
                s.visibleWindow *= 1.04f;
                s.fan = false;
                s.fanLines = 0;
            }

            applyArtistPaletteDiscipline(s);
            applyAestheticRescue(s, phase);
            s.motionSmoothness = chooseMotionSmoothness(s, phase);
            s.closureTendency = chooseClosureTendency(s, phase);
            s.bundleLineCount = chooseBundleLineCount(s, phase);
            s.bundleSpread = chooseBundleSpread(s, phase);
            s.terminalFan = chooseTerminalFan(s, phase);
            s.bounds = fullScreenBounds();
            initStrokeFromAnyVisiblePosition(s, side);
            s.attractTargetX = s.attractX;
            s.attractTargetY = s.attractY;
            return s;
        }

        private float chooseMotionSmoothness(StrokeEvent s, Phase phase) {
            float m = 0.68f;
            if (s == null) return m;
            if (s.artist != null) {
                if (s.artist.restraintLevel == RESTRAINT_HIGH) m += 0.08f;
                if (s.artist.styleFamily == ART_MEMBRANE_POETRY) m += 0.05f;
                if (s.artist.styleFamily == ART_LIQUID_EMBRACE) m += 0.08f;
                if (s.artist.styleFamily == ART_CRYSTAL_GRACE) m -= 0.04f;
            }
            if (s.dna != null) {
                if (s.dna.masterTemplate == TEMPLATE_MEMBRANE_BREATH || s.dna.masterTemplate == TEMPLATE_JELLY_UMBRELLA) m += 0.10f;
                if (s.dna.masterTemplate == TEMPLATE_LIQUID_LACE) m += 0.12f;
                if (s.dna.masterTemplate == TEMPLATE_CRYSTAL_SHARD) m -= 0.08f;
            }
            if (phase.name.equals("同步") || phase.name.equals("余韵")) m += 0.08f;
            if (phase.name.equals("临界")) m -= 0.06f;
            if (phase.name.equals("释放")) m -= 0.10f;
            return clamp(m, 0.35f, 0.96f);
        }

        private float chooseClosureTendency(StrokeEvent s, Phase phase) {
            float c = 0.16f;
            if (s == null || s.dna == null) return c;
            switch (s.dna.masterTemplate) {
                case TEMPLATE_MEMBRANE_BREATH: c = 0.34f; break;
                case TEMPLATE_TWIN_LEAF: c = 0.46f; break;
                case TEMPLATE_BLOSSOM_CROWN: c = 0.54f; break;
                case TEMPLATE_JELLY_UMBRELLA: c = 0.22f; break;
                case TEMPLATE_CRYSTAL_SHARD: c = 0.12f; break;
                case TEMPLATE_LIQUID_LACE: c = 0.38f; break;
            }
            if (s.dna.family == FAMILY_HALO) c += 0.16f;
            if (phase.name.equals("分离")) c *= 0.72f;
            if (phase.name.equals("同步")) c *= 1.18f;
            if (phase.name.equals("释放") || phase.name.equals("余韵")) c *= 0.48f;
            return clamp(c, 0f, 0.80f);
        }

        private int chooseBundleLineCount(StrokeEvent s, Phase phase) {
            int count = cfg.powerSave ? 4 : 6;
            if (s != null && s.dna != null) {
                switch (s.dna.masterTemplate) {
                    case TEMPLATE_BLOSSOM_CROWN: count += 2; break;
                    case TEMPLATE_TWIN_LEAF: count += 1; break;
                    case TEMPLATE_LIQUID_LACE: count += 2; break;
                    case TEMPLATE_JELLY_UMBRELLA: count += 1; break;
                    case TEMPLATE_CRYSTAL_SHARD: count -= 1; break;
                }
            }
            if (s != null && s.artist != null) {
                if (s.artist.detailDensity == DETAIL_RICH) count += 2;
                if (s.artist.detailDensity == DETAIL_SPARSE) count -= 1;
                if (s.artist.compositionRole == COMPOSITION_HERO) count += 1;
                if (s.artist.compositionRole == COMPOSITION_ECHO) count -= 1;
            }
            if (phase.name.equals("同步") || phase.name.equals("临界")) count += 1;
            if (phase.name.equals("分离")) count -= 1;
            return clampInt(count, cfg.powerSave ? 3 : 4, cfg.powerSave ? 7 : 11);
        }

        private float chooseBundleSpread(StrokeEvent s, Phase phase) {
            float spread = 1.0f;
            if (s != null && s.dna != null) {
                if (s.dna.masterTemplate == TEMPLATE_LIQUID_LACE) spread *= 1.18f;
                if (s.dna.masterTemplate == TEMPLATE_BLOSSOM_CROWN) spread *= 1.10f;
                if (s.dna.masterTemplate == TEMPLATE_CRYSTAL_SHARD) spread *= 0.78f;
                if (s.dna.masterTemplate == TEMPLATE_JELLY_UMBRELLA) spread *= 1.05f;
            }
            if (phase.name.equals("临界")) spread *= 0.86f;
            if (phase.name.equals("同步")) spread *= 1.08f;
            if (phase.name.equals("分离")) spread *= 0.88f;
            return clamp(spread, 0.55f, 1.45f);
        }

        private float chooseTerminalFan(StrokeEvent s, Phase phase) {
            float fan = 0.42f;
            if (s != null && s.dna != null) {
                if (s.dna.masterTemplate == TEMPLATE_BLOSSOM_CROWN) fan += 0.20f;
                if (s.dna.masterTemplate == TEMPLATE_TWIN_LEAF) fan += 0.16f;
                if (s.dna.masterTemplate == TEMPLATE_JELLY_UMBRELLA) fan += 0.22f;
                if (s.dna.masterTemplate == TEMPLATE_LIQUID_LACE) fan += 0.12f;
                if (s.dna.masterTemplate == TEMPLATE_CRYSTAL_SHARD) fan -= 0.16f;
            }
            if (phase.name.equals("同步")) fan += 0.10f;
            if (phase.name.equals("临界")) fan += 0.16f;
            if (phase.name.equals("分离")) fan -= 0.10f;
            if (phase.name.equals("释放") || phase.name.equals("余韵")) fan *= 0.45f;
            return clamp(fan, 0.05f, 0.86f);
        }

        private RectF fullScreenBounds() {
            float padX = width * lerp(0.08f, 0.22f, cfg.fullScreenCoverage);
            float padY = height * lerp(0.08f, 0.22f, cfg.fullScreenCoverage);
            return new RectF(-padX, -padY, width + padX, height + padY);
        }

        private void initStrokeFromAnyVisiblePosition(StrokeEvent s, int side) {
            if (initStrokeByShapeDNA(s, side)) return;
            if (initStrokeByArtMotif(s, side)) return;
            // 这一步是 V8 的重点：控制点直接从全屏可见坐标系生成，而不是从中心曲线移动出来。
            // 热区采样保证长期覆盖整块手机屏幕。
            int mode = random.nextInt(100);
            float x0, y0, x1, y1;
            if (mode < 30) {
                float[] p0 = randomEdgePoint(side);
                float[] p1 = pickLeastUsedPoint(false);
                x0 = p0[0]; y0 = p0[1]; x1 = p1[0]; y1 = p1[1];
            } else if (mode < 72) {
                float[] p0 = pickLeastUsedPoint(false);
                float[] p1 = pickLeastUsedPoint(true);
                x0 = p0[0]; y0 = p0[1]; x1 = p1[0]; y1 = p1[1];
                float minDist = Math.min(width, height) * 0.36f;
                int guard = 0;
                while (distance(x0, y0, x1, y1) < minDist && guard++ < 10) {
                    p1 = pickLeastUsedPoint(true);
                    x1 = p1[0]; y1 = p1[1];
                }
            } else {
                float[] p0 = randomCornerOrDiagonalStart();
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                x0 = p0[0]; y0 = p0[1]; x1 = p1[0]; y1 = p1[1];
            }

            markSpawnHeat(x0, y0);
            markSpawnHeat(x1, y1);

            // 以“从某处喷洒/飞掠到另一处”的长势能曲线生成控制点。
            // 不再围绕一个小中心随意弯曲，避免像蚯蚓；每次都是一段有方向、有起笔、有收笔的 Mystify 光迹。
            float angle = (float)Math.atan2(y1 - y0, x1 - x0) + (random.nextFloat() - 0.5f) * (0.12f + cfg.randomness * 0.30f);
            float length = Math.max(Math.min(width, height) * 0.42f, distance(x0, y0, x1, y1));
            float perp = Math.min(width, height) * (0.045f + random.nextFloat() * (0.12f + cfg.randomness * 0.06f));
            float bendSign = random.nextBoolean() ? 1f : -1f;
            float phase = random.nextFloat() * (float)Math.PI * 2f;
            float coherentV = s.speed * (0.72f + random.nextFloat() * 0.70f);
            for (int i = 0; i < s.count; i++) {
                float u = i / Math.max(1f, (s.count - 1f));
                float baseX = lerp(x0, x1, u);
                float baseY = lerp(y0, y1, u);
                float broadArc = (float)Math.sin(u * Math.PI) * perp * bendSign;
                float fineArc = (float)Math.sin(u * Math.PI * 2f + phase) * perp * 0.22f;
                float curve = broadArc + fineArc;
                s.x[i] = baseX - (float)Math.sin(angle) * curve;
                s.y[i] = baseY + (float)Math.cos(angle) * curve;
                float sideDrift = (i - (s.count - 1) * 0.5f) / Math.max(1f, (s.count - 1f));
                s.vx[i] = (float)Math.cos(angle) * coherentV - (float)Math.sin(angle) * coherentV * sideDrift * 0.055f;
                s.vy[i] = (float)Math.sin(angle) * coherentV + (float)Math.cos(angle) * coherentV * sideDrift * 0.055f;
                markSpawnHeat(s.x[i], s.y[i]);
            }
            s.attractX = lerp(0f, width, random.nextFloat());
            s.attractY = lerp(0f, height, random.nextFloat());
            s.attractTargetX = s.attractX;
            s.attractTargetY = s.attractY;
        }


        private boolean initStrokeByShapeDNA(StrokeEvent s, int side) {
            if (s.dna == null) return false;
            float minDim = Math.max(1f, Math.min(width, height));
            float[] birth = dnaBirthPoint(s, side);
            float[] farewell = dnaFarewellPoint(s, birth[0], birth[1]);
            float commonX = clamp(s.attractX == 0f ? width * (0.38f + random.nextFloat() * 0.24f) : s.attractX, -width * 0.10f, width * 1.10f);
            float commonY = clamp(s.attractY == 0f ? height * (0.28f + random.nextFloat() * 0.44f) : s.attractY, -height * 0.10f, height * 1.10f);
            float dx = farewell[0] - birth[0];
            float dy = farewell[1] - birth[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 1f) len = 1f;
            float tx = dx / len;
            float ty = dy / len;
            float nx = -ty;
            float ny = tx;
            float sideSign = s.actor == 1 ? -1f : (s.actor == 2 ? 1f : (random.nextBoolean() ? 1f : -1f));
            float arc = minDim * (0.10f + 0.16f * s.dna.softness + 0.06f * cfg.randomness) * sideSign;
            if (s.dna.pathType == PATH_SPIRAL || s.dna.pathType == PATH_ORBIT) arc *= 1.45f;
            if (s.dna.pathType == PATH_FAREWELL) arc *= 0.76f;
            if (s.artist != null) {
                if (s.artist.silhouetteLaw == SILHOUETTE_SIMPLE) arc *= 0.82f;
                if (s.artist.silhouetteLaw == SILHOUETTE_TAPERED) arc *= 0.92f;
                if (s.artist.silhouetteLaw == SILHOUETTE_ASYMMETRIC) arc *= 1.18f;
                if (s.artist.silhouetteLaw == SILHOUETTE_TWIN_BALANCED) arc *= 0.90f;
            }

            float[][] anchors = new float[6][2];
            anchors[0][0] = birth[0];
            anchors[0][1] = birth[1];
            anchors[1][0] = lerp(birth[0], commonX, 0.25f) + nx * arc * 0.55f;
            anchors[1][1] = lerp(birth[1], commonY, 0.25f) + ny * arc * 0.55f;
            anchors[2][0] = lerp(birth[0], commonX, 0.58f) - nx * arc * 0.38f;
            anchors[2][1] = lerp(birth[1], commonY, 0.58f) - ny * arc * 0.38f;
            anchors[3][0] = commonX + nx * arc * 0.22f * (s.dna.pathType == PATH_ATTRACT ? 0.38f : 1f);
            anchors[3][1] = commonY + ny * arc * 0.22f * (s.dna.pathType == PATH_ATTRACT ? 0.38f : 1f);
            anchors[4][0] = lerp(commonX, farewell[0], 0.52f) + nx * arc * (s.dna.pathType == PATH_ORBIT ? 0.88f : -0.18f);
            anchors[4][1] = lerp(commonY, farewell[1], 0.52f) + ny * arc * (s.dna.pathType == PATH_ORBIT ? 0.88f : -0.18f);
            anchors[5][0] = farewell[0];
            anchors[5][1] = farewell[1];

            if (s.dna.pathType == PATH_SPIRAL || s.dna.pathType == PATH_ORBIT) {
                for (int a = 1; a < 5; a++) {
                    float u = a / 5f;
                    float spin = s.seed + u * (float)Math.PI * (1.15f + 0.70f * s.dna.aspect) * s.flowC;
                    float rr = minDim * (0.05f + 0.09f * (float)Math.sin(u * Math.PI));
                    anchors[a][0] += (float)Math.cos(spin) * rr;
                    anchors[a][1] += (float)Math.sin(spin) * rr;
                }
            }
            if (s.dna.pathType == PATH_BURST) {
                for (int a = 1; a < 5; a++) {
                    float fromCenterX = anchors[a][0] - commonX;
                    float fromCenterY = anchors[a][1] - commonY;
                    anchors[a][0] = commonX + fromCenterX * 0.42f;
                    anchors[a][1] = commonY + fromCenterY * 0.42f;
                }
            }

            if (s.artist != null && s.artist.silhouetteLaw == SILHOUETTE_ASYMMETRIC) {
                for (int a = 1; a < 5; a++) {
                    float skew = ((a % 2 == 0) ? 1f : -1f) * minDim * 0.018f * s.asymmetry;
                    anchors[a][0] += nx * skew;
                    anchors[a][1] += ny * skew * 0.68f;
                }
            }
            if (s.artist != null && s.artist.silhouetteLaw == SILHOUETTE_TWIN_BALANCED) {
                anchors[1][0] = lerp(anchors[1][0], birth[0] + dx * 0.20f, 0.22f);
                anchors[4][0] = lerp(anchors[4][0], farewell[0] - dx * 0.18f, 0.22f);
            }

            applyMasterContourTemplate(s, anchors, birth, farewell, commonX, commonY, tx, ty, nx, ny, dx, dy, minDim);

            float prevX = birth[0];
            float prevY = birth[1];
            for (int i = 0; i < s.count; i++) {
                float u = i / Math.max(1f, s.count - 1f);
                float segF = u * (anchors.length - 1);
                int seg = clampInt((int)Math.floor(segF), 0, anchors.length - 2);
                float t = smooth(segF - seg);
                float x0 = anchors[Math.max(0, seg - 1)][0], y0 = anchors[Math.max(0, seg - 1)][1];
                float x1 = anchors[seg][0], y1 = anchors[seg][1];
                float x2 = anchors[seg + 1][0], y2 = anchors[seg + 1][1];
                float x3 = anchors[Math.min(anchors.length - 1, seg + 2)][0], y3 = anchors[Math.min(anchors.length - 1, seg + 2)][1];
                float px = catmull(x0, x1, x2, x3, t);
                float py = catmull(y0, y1, y2, y3, t);
                float body = (float)Math.sin(u * Math.PI);
                float ripple = (float)Math.sin(u * Math.PI * (2.0f + s.dna.aspect) + s.dna.seed) * minDim * 0.018f * body;
                if (s.dna.family == FAMILY_BLOSSOM) ripple *= 1.50f;
                if (s.dna.family == FAMILY_CRYSTAL) ripple *= 0.45f;
                ripple *= templateRippleScale(s, u);
                s.x[i] = px + nx * ripple;
                s.y[i] = py + ny * ripple;
                if (i > 0) {
                    float vdx = s.x[i] - prevX;
                    float vdy = s.y[i] - prevY;
                    float vlen = (float)Math.sqrt(vdx * vdx + vdy * vdy);
                    if (vlen < 1f) vlen = 1f;
                    s.vx[i] = vdx / vlen * s.speed * (0.32f + 0.26f * u);
                    s.vy[i] = vdy / vlen * s.speed * (0.32f + 0.26f * u);
                } else {
                    s.vx[i] = tx * s.speed * 0.32f;
                    s.vy[i] = ty * s.speed * 0.32f;
                }
                prevX = s.x[i];
                prevY = s.y[i];
                markSpawnHeat(s.x[i], s.y[i]);
            }
            s.attractX = commonX;
            s.attractY = commonY;
            s.attractTargetX = commonX;
            s.attractTargetY = commonY;
            return true;
        }

        private void applyMasterContourTemplate(StrokeEvent s, float[][] anchors, float[] birth, float[] farewell,
                                                float commonX, float commonY, float tx, float ty, float nx, float ny,
                                                float dx, float dy, float minDim) {
            if (s == null || s.dna == null || anchors == null || anchors.length < 6) return;
            float seedA = fract((s.dna.templateVariant * 0.6180339f) % 1f);
            float seedB = fract((s.dna.templateVariant * 0.381966f) % 1f);
            float span = minDim * (0.06f + 0.10f * s.dna.softness);
            switch (s.dna.masterTemplate) {
                case TEMPLATE_MEMBRANE_BREATH:
                    anchors[1][0] += nx * span * 0.42f;
                    anchors[1][1] += ny * span * 0.42f;
                    anchors[2][0] -= nx * span * 0.22f;
                    anchors[2][1] -= ny * span * 0.22f;
                    anchors[3][0] += nx * span * 0.18f;
                    anchors[3][1] += ny * span * 0.18f;
                    anchors[4][0] -= nx * span * 0.12f;
                    anchors[4][1] -= ny * span * 0.12f;
                    break;
                case TEMPLATE_TWIN_LEAF:
                    anchors[1][0] += nx * span * 0.62f;
                    anchors[1][1] += ny * span * 0.62f;
                    anchors[2][0] -= nx * span * (0.40f + 0.12f * seedA);
                    anchors[2][1] -= ny * span * (0.40f + 0.12f * seedA);
                    anchors[3][0] += nx * span * (0.34f + 0.08f * seedB);
                    anchors[3][1] += ny * span * (0.34f + 0.08f * seedB);
                    anchors[4][0] -= nx * span * 0.58f;
                    anchors[4][1] -= ny * span * 0.58f;
                    break;
                case TEMPLATE_BLOSSOM_CROWN:
                    anchors[1][0] += nx * span * 0.35f - tx * span * 0.12f;
                    anchors[1][1] += ny * span * 0.35f - ty * span * 0.12f;
                    anchors[2][0] -= nx * span * 0.35f + tx * span * 0.08f;
                    anchors[2][1] -= ny * span * 0.35f + ty * span * 0.08f;
                    anchors[3][0] += nx * span * 0.48f;
                    anchors[3][1] += ny * span * 0.48f;
                    anchors[4][0] -= nx * span * 0.28f - tx * span * 0.10f;
                    anchors[4][1] -= ny * span * 0.28f - ty * span * 0.10f;
                    break;
                case TEMPLATE_JELLY_UMBRELLA:
                    anchors[1][1] -= span * 0.32f;
                    anchors[2][0] += nx * span * 0.20f;
                    anchors[2][1] += ny * span * 0.20f;
                    anchors[3][0] -= nx * span * 0.12f;
                    anchors[3][1] -= ny * span * 0.12f;
                    anchors[4][1] += span * 0.16f;
                    break;
                case TEMPLATE_CRYSTAL_SHARD:
                    anchors[1][0] += nx * span * 0.28f + tx * span * 0.18f;
                    anchors[1][1] += ny * span * 0.28f + ty * span * 0.18f;
                    anchors[2][0] -= nx * span * 0.08f;
                    anchors[2][1] -= ny * span * 0.08f;
                    anchors[3][0] += nx * span * 0.52f;
                    anchors[3][1] += ny * span * 0.52f;
                    anchors[4][0] -= nx * span * 0.14f - tx * span * 0.20f;
                    anchors[4][1] -= ny * span * 0.14f - ty * span * 0.20f;
                    break;
                case TEMPLATE_LIQUID_LACE:
                    anchors[1][0] += nx * span * 0.50f;
                    anchors[1][1] += ny * span * 0.50f;
                    anchors[2][0] -= nx * span * 0.54f;
                    anchors[2][1] -= ny * span * 0.54f;
                    anchors[3][0] += nx * span * 0.42f;
                    anchors[3][1] += ny * span * 0.42f;
                    anchors[4][0] -= nx * span * 0.46f;
                    anchors[4][1] -= ny * span * 0.46f;
                    break;
            }
        }

        private float templateRippleScale(StrokeEvent s, float u) {
            if (s == null || s.dna == null) return 1f;
            switch (s.dna.masterTemplate) {
                case TEMPLATE_MEMBRANE_BREATH:
                    return 0.70f + 0.34f * (float)Math.sin(u * (float)Math.PI);
                case TEMPLATE_TWIN_LEAF:
                    return 0.92f + 0.30f * (float)Math.sin(u * (float)Math.PI * 2f + s.seed * 0.6f);
                case TEMPLATE_BLOSSOM_CROWN:
                    return 1.04f + 0.42f * (float)Math.sin(u * (float)Math.PI * 3f + s.seed);
                case TEMPLATE_JELLY_UMBRELLA:
                    return 0.62f + 0.24f * (1f - u) + 0.12f * (float)Math.sin(u * (float)Math.PI * 4f);
                case TEMPLATE_CRYSTAL_SHARD:
                    return 0.36f + 0.22f * (u < 0.35f ? 1f : 0.55f);
                case TEMPLATE_LIQUID_LACE:
                    return 1.00f + 0.52f * (float)Math.sin(u * (float)Math.PI * 2.5f + s.seed * 1.2f);
            }
            return 1f;
        }

        private float[] dnaBirthPoint(StrokeEvent s, int side) {
            if (s.dna != null && s.dna.pathType == PATH_ATTRACT && s.actor > 0) {
                float x = s.actor == 1 ? width * (0.08f + random.nextFloat() * 0.18f) : width * (0.74f + random.nextFloat() * 0.18f);
                float y = height * (0.20f + random.nextFloat() * 0.58f);
                return new float[]{x, y};
            }
            if (s.dna != null && s.dna.pathType == PATH_ORBIT) {
                float cx = width * (0.36f + random.nextFloat() * 0.28f);
                float cy = height * (0.28f + random.nextFloat() * 0.40f);
                float ang = random.nextFloat() * (float)Math.PI * 2f;
                float rr = Math.min(width, height) * (0.18f + random.nextFloat() * 0.22f);
                return new float[]{cx + (float)Math.cos(ang) * rr, cy + (float)Math.sin(ang) * rr};
            }
            return pickLeastUsedPoint(false);
        }

        private float[] dnaFarewellPoint(StrokeEvent s, float bx, float by) {
            if (s.dna != null && (s.dna.pathType == PATH_FAREWELL || s.dna.pathType == PATH_BURST)) {
                float cx = width * 0.5f;
                float cy = height * 0.5f;
                float dx = bx - cx;
                float dy = by - cy;
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) { dx = random.nextBoolean() ? 1f : -1f; dy = random.nextBoolean() ? 0.5f : -0.5f; len = (float)Math.sqrt(dx * dx + dy * dy); }
                float scale = Math.min(width, height) * (0.42f + random.nextFloat() * 0.28f) / len;
                return new float[]{clamp(cx + dx * scale, -width * 0.12f, width * 1.12f), clamp(cy + dy * scale, -height * 0.12f, height * 1.12f)};
            }
            return randomOppositeLongPoint(bx, by);
        }

        private boolean initStrokeByArtMotif(StrokeEvent s, int side) {
            float minDim = Math.max(1f, Math.min(width, height));
            int motif = s.motif;
            if (motif == 1 || motif == 0) return false;

            if (motif == 2) { // electronic fan / shell: hidden pivot + gradually opening ribs
                float[] pivot = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float sweep = (0.75f + random.nextFloat() * 1.35f) * (random.nextBoolean() ? 1f : -1f);
                float squash = 0.62f + random.nextFloat() * 0.34f;
                float speed = s.speed * (0.36f + random.nextFloat() * 0.35f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float su = smooth(u);
                    float rr = minDim * (0.038f + 0.36f * su) * s.motifStrength;
                    float ang = base + sweep * su;
                    s.x[i] = pivot[0] + (float)Math.cos(ang) * rr;
                    s.y[i] = pivot[1] + (float)Math.sin(ang) * rr * squash;
                    float tangent = ang + (sweep >= 0f ? 1f : -1f) * (float)Math.PI * 0.5f;
                    s.vx[i] = (float)Math.cos(tangent) * speed * (0.45f + u);
                    s.vy[i] = (float)Math.sin(tangent) * speed * squash * (0.45f + u);
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = pivot[0];
                s.attractY = pivot[1];
                return true;
            }

            if (motif == 3) { // silver blade: straight diagonal energy with one sharp crease
                float[] p0 = randomEdgePoint(side);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float crease = (random.nextFloat() - 0.5f) * minDim * (0.16f + cfg.randomness * 0.16f);
                float speed = s.speed * (0.82f + random.nextFloat() * 0.45f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float blade = (float)Math.sin(Math.PI * u) * crease;
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * blade;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * blade;
                    s.vx[i] = dx / len * speed + nx * (i - (s.count - 1) * 0.5f) * speed * 0.035f;
                    s.vy[i] = dy / len * speed + ny * (i - (s.count - 1) * 0.5f) * speed * 0.035f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.55f);
                s.attractY = lerp(p0[1], p1[1], 0.55f);
                return true;
            }

            if (motif == 4) { // petal hook: vertical stem curling into a flower-like head
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float sweep = (1.18f + random.nextFloat() * 1.64f) * (random.nextBoolean() ? 1f : -1f);
                float speed = s.speed * (0.42f + random.nextFloat() * 0.35f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float rr = minDim * (0.045f + 0.22f * (float)Math.pow(u, 0.72f)) * s.motifStrength;
                    float ang = base + sweep * u * u;
                    float stem = minDim * 0.11f * (0.5f - u);
                    float sx = (float)Math.cos(base + Math.PI * 0.5f) * stem;
                    float sy = (float)Math.sin(base + Math.PI * 0.5f) * stem;
                    s.x[i] = c[0] + sx + (float)Math.cos(ang) * rr;
                    s.y[i] = c[1] + sy + (float)Math.sin(ang) * rr * (0.58f + random.nextFloat() * 0.24f);
                    float tangent = ang + (sweep >= 0f ? 1f : -1f) * (float)Math.PI * 0.5f;
                    s.vx[i] = (float)Math.cos(tangent) * speed * (0.54f + u * 0.35f);
                    s.vy[i] = (float)Math.sin(tangent) * speed * (0.54f + u * 0.35f);
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 5) { // prism polygon: diamond/square frame briefly turning in darkness
                float[] c = pickLeastUsedPoint(false);
                float radius = minDim * (0.10f + random.nextFloat() * 0.22f) * s.motifStrength;
                float rot = random.nextFloat() * (float)Math.PI * 2f;
                float[][] corners = new float[][]{
                        {(float)Math.cos(rot) * radius, (float)Math.sin(rot) * radius * 0.72f},
                        {(float)Math.cos(rot + Math.PI * 0.5f) * radius * 0.72f, (float)Math.sin(rot + Math.PI * 0.5f) * radius},
                        {(float)Math.cos(rot + Math.PI) * radius, (float)Math.sin(rot + Math.PI) * radius * 0.72f},
                        {(float)Math.cos(rot + Math.PI * 1.5f) * radius * 0.72f, (float)Math.sin(rot + Math.PI * 1.5f) * radius},
                        {(float)Math.cos(rot) * radius, (float)Math.sin(rot) * radius * 0.72f}
                };
                float drift = s.speed * (0.28f + random.nextFloat() * 0.26f);
                float moveAng = rot + (random.nextBoolean() ? 1f : -1f) * (float)Math.PI * 0.35f;
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    int seg = Math.min(3, (int)(u * 4f));
                    float local = u * 4f - seg;
                    s.x[i] = c[0] + lerp(corners[seg][0], corners[seg + 1][0], local);
                    s.y[i] = c[1] + lerp(corners[seg][1], corners[seg + 1][1], local);
                    s.vx[i] = (float)Math.cos(moveAng) * drift + (float)Math.cos(rot + i) * drift * 0.08f;
                    s.vy[i] = (float)Math.sin(moveAng) * drift + (float)Math.sin(rot + i) * drift * 0.08f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 6) { // falling leaf / vine: slender soft S curve
                float[] p0 = pickLeastUsedPoint(false);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float amp = minDim * (0.055f + random.nextFloat() * 0.11f) * s.motifStrength;
                float speed = s.speed * (0.46f + random.nextFloat() * 0.32f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float leaf = (float)Math.sin(Math.PI * u) * amp + (float)Math.sin(Math.PI * 2f * u) * amp * 0.28f;
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * leaf;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * leaf;
                    s.vx[i] = dx / len * speed + nx * speed * (0.10f - u * 0.06f);
                    s.vy[i] = dy / len * speed + ny * speed * (0.06f + u * 0.05f);
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.60f);
                s.attractY = lerp(p0[1], p1[1], 0.60f);
                return true;
            }

            if (motif == 7) { // long bridge arc: wide magenta/green bow spanning the black field
                float[] p0 = randomCornerOrDiagonalStart();
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float amp = minDim * (0.09f + random.nextFloat() * 0.20f) * (random.nextBoolean() ? 1f : -1f);
                float speed = s.speed * (0.58f + random.nextFloat() * 0.40f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float arc = (float)Math.sin(Math.PI * u) * amp;
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * arc;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * arc;
                    s.vx[i] = dx / len * speed;
                    s.vy[i] = dy / len * speed;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.50f);
                s.attractY = lerp(p0[1], p1[1], 0.50f);
                return true;
            }

            if (motif == 8) { // jellyfish tendril: many-control soft hanging curve with a drifting head
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float sweep = (0.55f + random.nextFloat() * 0.85f) * (random.nextBoolean() ? 1f : -1f);
                float len = minDim * (0.22f + random.nextFloat() * 0.28f) * s.motifStrength;
                float speed = s.speed * (0.34f + random.nextFloat() * 0.26f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float droop = len * (u - 0.5f);
                    float wave = (float)Math.sin(u * Math.PI * 1.7f + s.seed) * minDim * (0.045f + random.nextFloat() * 0.030f);
                    float ang = base + sweep * u;
                    float tx = (float)Math.cos(base) * droop + (float)Math.cos(ang + Math.PI * 0.5f) * wave;
                    float ty = (float)Math.sin(base) * droop + (float)Math.sin(ang + Math.PI * 0.5f) * wave;
                    s.x[i] = c[0] + tx;
                    s.y[i] = c[1] + ty;
                    s.vx[i] = (float)Math.cos(base + 0.22f * s.flowC) * speed + (float)Math.cos(ang) * speed * 0.12f;
                    s.vy[i] = (float)Math.sin(base + 0.22f * s.flowC) * speed + (float)Math.sin(ang) * speed * 0.12f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 9) { // nebula coil: open spiral, not a closed circle
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float handed = random.nextBoolean() ? 1f : -1f;
                float radius = minDim * (0.035f + random.nextFloat() * 0.075f);
                float grow = minDim * (0.16f + random.nextFloat() * 0.23f) * s.motifStrength;
                float drift = s.speed * (0.28f + random.nextFloat() * 0.26f);
                float move = base + handed * (float)Math.PI * 0.35f;
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float rr = radius + grow * smooth(u);
                    float a = base + handed * (0.75f + 2.15f * u + 0.30f * (float)Math.sin(u * Math.PI));
                    s.x[i] = c[0] + (float)Math.cos(a) * rr;
                    s.y[i] = c[1] + (float)Math.sin(a) * rr * (0.62f + random.nextFloat() * 0.18f);
                    s.vx[i] = (float)Math.cos(move) * drift + (float)Math.cos(a + Math.PI * 0.5f) * drift * 0.18f;
                    s.vy[i] = (float)Math.sin(move) * drift + (float)Math.sin(a + Math.PI * 0.5f) * drift * 0.18f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 10) { // origami sheet: folded luminous paper, two creases
                float[] p0 = randomEdgePoint(side);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float fold = minDim * (0.060f + random.nextFloat() * 0.16f) * (random.nextBoolean() ? 1f : -1f);
                float speed = s.speed * (0.52f + random.nextFloat() * 0.34f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float kink = ((u < 0.48f ? u / 0.48f : (1f - u) / 0.52f));
                    float zig = (i % 2 == 0 ? -0.45f : 0.45f) * fold * (0.25f + 0.75f * (float)Math.sin(Math.PI * u));
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * (fold * kink + zig);
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * (fold * kink + zig);
                    s.vx[i] = dx / len * speed + nx * speed * (i - (s.count - 1) * 0.5f) * 0.025f;
                    s.vy[i] = dy / len * speed + ny * speed * (i - (s.count - 1) * 0.5f) * 0.025f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.52f);
                s.attractY = lerp(p0[1], p1[1], 0.52f);
                return true;
            }

            if (motif == 12) { // liquid pod: slow oval body with inner drift, not a point cloud
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float rx = minDim * (0.11f + random.nextFloat() * 0.18f) * s.motifStrength;
                float ry = rx * (0.52f + random.nextFloat() * 0.36f);
                float drift = s.speed * (0.24f + random.nextFloat() * 0.22f);
                float move = base + (random.nextBoolean() ? 1f : -1f) * (float)Math.PI * 0.28f;
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float a = base + (u - 0.5f) * (1.45f + random.nextFloat() * 1.05f);
                    float breathe = 0.82f + 0.18f * (float)Math.sin(u * Math.PI);
                    s.x[i] = c[0] + (float)Math.cos(a) * rx * breathe;
                    s.y[i] = c[1] + (float)Math.sin(a) * ry * breathe;
                    s.vx[i] = (float)Math.cos(move) * drift + (float)Math.cos(a + Math.PI * 0.5f) * drift * 0.10f;
                    s.vy[i] = (float)Math.sin(move) * drift + (float)Math.sin(a + Math.PI * 0.5f) * drift * 0.10f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 13) { // luminous wing: broad asymmetric wing crossing the black field
                float[] p0 = randomEdgePoint(side);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float amp = minDim * (0.12f + random.nextFloat() * 0.22f) * (random.nextBoolean() ? 1f : -1f);
                float speed = s.speed * (0.42f + random.nextFloat() * 0.30f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float lift = (float)Math.sin(Math.PI * u) * amp;
                    float secondary = (float)Math.sin(Math.PI * 2f * u + s.seed) * amp * 0.16f;
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * (lift + secondary);
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * (lift + secondary);
                    s.vx[i] = dx / len * speed + nx * speed * (0.06f - u * 0.04f);
                    s.vy[i] = dy / len * speed + ny * speed * (0.05f + u * 0.03f);
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.48f);
                s.attractY = lerp(p0[1], p1[1], 0.48f);
                return true;
            }

            if (motif == 14) { // blossom crown: looped petal arc around a soft center
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float radius = minDim * (0.08f + random.nextFloat() * 0.15f) * s.motifStrength;
                float petals = 3f + random.nextInt(4);
                float drift = s.speed * (0.25f + random.nextFloat() * 0.24f);
                float move = base + (float)Math.PI * 0.42f;
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float a = base + u * (float)Math.PI * 1.65f;
                    float flower = radius * (0.66f + 0.34f * (float)Math.sin(petals * a));
                    s.x[i] = c[0] + (float)Math.cos(a) * flower;
                    s.y[i] = c[1] + (float)Math.sin(a) * flower * (0.70f + random.nextFloat() * 0.18f);
                    s.vx[i] = (float)Math.cos(move) * drift + (float)Math.cos(a + Math.PI * 0.5f) * drift * 0.12f;
                    s.vy[i] = (float)Math.sin(move) * drift + (float)Math.sin(a + Math.PI * 0.5f) * drift * 0.12f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 15) { // silk banner: broad flowing sheet, intentionally not a mesh
                float[] p0 = randomCornerOrDiagonalStart();
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float amp = minDim * (0.035f + random.nextFloat() * 0.065f) * (random.nextBoolean() ? 1f : -1f);
                float speed = s.speed * (0.34f + random.nextFloat() * 0.28f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float wave = (float)Math.sin(Math.PI * u) * amp + (float)Math.sin(Math.PI * 3f * u + s.seed) * amp * 0.20f;
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * wave;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * wave;
                    s.vx[i] = dx / len * speed + nx * speed * 0.035f * (0.5f - u);
                    s.vy[i] = dy / len * speed + ny * speed * 0.035f * (0.5f - u);
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.52f);
                s.attractY = lerp(p0[1], p1[1], 0.52f);
                return true;
            }

            if (motif == 16) { // orbit halo: crescent/ring body, not random dots
                float[] c = pickLeastUsedPoint(false);
                float base = random.nextFloat() * (float)Math.PI * 2f;
                float sweep = (1.55f + random.nextFloat() * 1.25f) * (random.nextBoolean() ? 1f : -1f);
                float rx = minDim * (0.13f + random.nextFloat() * 0.20f) * s.motifStrength;
                float ry = rx * (0.48f + random.nextFloat() * 0.38f);
                float drift = s.speed * (0.22f + random.nextFloat() * 0.20f);
                float move = base + (random.nextBoolean() ? 1f : -1f) * (float)Math.PI * 0.30f;
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float a = base + sweep * u;
                    s.x[i] = c[0] + (float)Math.cos(a) * rx;
                    s.y[i] = c[1] + (float)Math.sin(a) * ry;
                    s.vx[i] = (float)Math.cos(move) * drift + (float)Math.cos(a + Math.PI * 0.5f) * drift * 0.08f;
                    s.vy[i] = (float)Math.sin(move) * drift + (float)Math.sin(a + Math.PI * 0.5f) * drift * 0.08f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = c[0];
                s.attractY = c[1];
                return true;
            }

            if (motif == 17) { // crystal shard: moving faceted luminous plate
                float[] p0 = randomEdgePoint(side);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float speed = s.speed * (0.58f + random.nextFloat() * 0.34f);
                float shard = minDim * (0.09f + random.nextFloat() * 0.16f) * (random.nextBoolean() ? 1f : -1f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float angular = (i % 2 == 0 ? -0.55f : 0.70f) * shard * (0.35f + 0.65f * (float)Math.sin(Math.PI * u));
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * angular;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * angular;
                    s.vx[i] = dx / len * speed + nx * speed * (i - (s.count - 1) * 0.5f) * 0.030f;
                    s.vy[i] = dy / len * speed + ny * speed * (i - (s.count - 1) * 0.5f) * 0.030f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.50f);
                s.attractY = lerp(p0[1], p1[1], 0.50f);
                return true;
            }

            if (motif == 11) { // constellation chain: sparse angular path with glowing nodes
                float[] p0 = pickLeastUsedPoint(false);
                float[] p1 = randomOppositeLongPoint(p0[0], p0[1]);
                float dx = p1[0] - p0[0];
                float dy = p1[1] - p0[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 1f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float speed = s.speed * (0.45f + random.nextFloat() * 0.34f);
                for (int i = 0; i < s.count; i++) {
                    float u = i / Math.max(1f, s.count - 1f);
                    float step = (random.nextFloat() - 0.5f) * minDim * (0.07f + cfg.randomness * 0.06f);
                    s.x[i] = lerp(p0[0], p1[0], u) + nx * step;
                    s.y[i] = lerp(p0[1], p1[1], u) + ny * step;
                    s.vx[i] = dx / len * speed + nx * speed * (random.nextFloat() - 0.5f) * 0.08f;
                    s.vy[i] = dy / len * speed + ny * speed * (random.nextFloat() - 0.5f) * 0.08f;
                    markSpawnHeat(s.x[i], s.y[i]);
                }
                s.attractX = lerp(p0[0], p1[0], 0.50f);
                s.attractY = lerp(p0[1], p1[1], 0.50f);
                return true;
            }
            return false;
        }

        private float[] randomEdgePoint(int side) {
            int edge = random.nextInt(4);
            if (side < 0) edge = random.nextBoolean() ? 0 : 2;
            if (side > 0) edge = random.nextBoolean() ? 1 : 3;
            float oX = width * (0.02f + random.nextFloat() * 0.18f);
            float oY = height * (0.02f + random.nextFloat() * 0.18f);
            switch (edge) {
                case 0: return new float[]{-oX, random.nextFloat() * height};
                case 1: return new float[]{width + oX, random.nextFloat() * height};
                case 2: return new float[]{random.nextFloat() * width, -oY};
                default: return new float[]{random.nextFloat() * width, height + oY};
            }
        }

        private float[] randomCornerOrDiagonalStart() {
            float oX = width * (0.04f + random.nextFloat() * 0.20f);
            float oY = height * (0.04f + random.nextFloat() * 0.20f);
            switch (random.nextInt(4)) {
                case 0: return new float[]{-oX, -oY};
                case 1: return new float[]{width + oX, -oY};
                case 2: return new float[]{width + oX, height + oY};
                default: return new float[]{-oX, height + oY};
            }
        }

        private float[] randomOppositeLongPoint(float x0, float y0) {
            float x = x0 < width * 0.5f ? width * (0.55f + random.nextFloat() * 0.65f) : -width * (0.05f + random.nextFloat() * 0.55f);
            float y = y0 < height * 0.5f ? height * (0.48f + random.nextFloat() * 0.72f) : -height * (0.04f + random.nextFloat() * 0.60f);
            return new float[]{x, y};
        }

        private float[] pickLeastUsedPoint(boolean farPreference) {
            // V29：热区采样 + 黄金比例低差异采样混合。热区避免局部重复，黄金序列避免
            // 伪随机长期形成可见簇团，使出生点更像“永远换位置的星图”。
            int best = 0;
            int bestScore = Integer.MAX_VALUE;
            int samples = 10 + random.nextInt(12);
            for (int i = 0; i < samples; i++) {
                int idx = random.nextInt(GRID_COLS * GRID_ROWS);
                int score = spawnHeat[idx] + random.nextInt(4);
                if (score < bestScore) { bestScore = score; best = idx; }
            }
            int col = best % GRID_COLS;
            int row = best / GRID_COLS;
            float cw = width / (float)GRID_COLS;
            float ch = height / (float)GRID_ROWS;
            float heatX = col * cw + random.nextFloat() * cw;
            float heatY = row * ch + random.nextFloat() * ch;

            float phi = 0.61803398875f;
            float psi = 0.754877666f;
            float gx = fract(0.13f + (artSpawnIndex + spawnCounter * 0.37f) * phi + random.nextFloat() * 0.037f);
            float gy = fract(0.71f + (artSpawnIndex + spawnCounter * 0.41f) * psi + random.nextFloat() * 0.037f);
            float goldX = lerp(-width * 0.06f, width * 1.06f, gx);
            float goldY = lerp(-height * 0.06f, height * 1.06f, gy);

            float mix = 0.38f + random.nextFloat() * 0.28f;
            float x = lerp(heatX, goldX, mix);
            float y = lerp(heatY, goldY, mix);
            if (farPreference && random.nextFloat() < 0.40f) {
                x = width - x + (random.nextFloat() - 0.5f) * cw;
                y = height - y + (random.nextFloat() - 0.5f) * ch;
            }
            x = clamp(x, -width * 0.10f, width * 1.10f);
            y = clamp(y, -height * 0.10f, height * 1.10f);
            markSpawnHeat(x, y);
            return new float[]{x, y};
        }

        private void markSpawnHeat(float x, float y) {
            int col = clampInt((int)(clamp(x, 0f, Math.max(1, width - 1)) / Math.max(1f, width) * GRID_COLS), 0, GRID_COLS - 1);
            int row = clampInt((int)(clamp(y, 0f, Math.max(1, height - 1)) / Math.max(1f, height) * GRID_ROWS), 0, GRID_ROWS - 1);
            int idx = row * GRID_COLS + col;
            spawnHeat[idx] = Math.min(100000, spawnHeat[idx] + 4);
            spawnCounter++;
            if (spawnCounter % 36 == 0) {
                for (int i = 0; i < spawnHeat.length; i++) spawnHeat[i] = Math.max(0, spawnHeat[i] - 1);
            }
        }

        private void resetSpawnHeat() {
            for (int i = 0; i < spawnHeat.length; i++) spawnHeat[i] = 0;
            spawnCounter = 0;
        }

        private void updateStrokes(float sec, float dt, Phase phase, float intensity, float tension, float release) {
            Iterator<StrokeEvent> it = strokes.iterator();
            while (it.hasNext()) {
                StrokeEvent s = it.next();
                s.age += dt;
                if (s.age > s.life) {
                    it.remove();
                    continue;
                }
                updateStroke(s, sec, dt, phase, intensity, tension, release);
            }
        }

        private void updateStroke(StrokeEvent s, float sec, float dt, Phase phase, float intensity, float tension, float release) {
            float relationPull = s.relation * (0.00018f + 0.00036f * cfg.intimacy) * (0.5f + tension);
            if (phase.name.equals("分离")) relationPull = 0f;
            if (phase.name.equals("吸引")) relationPull *= 0.22f;
            if (phase.name.equals("临界")) relationPull *= 1.55f;

            updateStrokeAttractor(s, sec, dt, phase, tension, release);

            float journey = clamp(s.age / Math.max(0.001f, s.life), 0f, 1f);
            float journeyEnvelope = smooth(Math.min(1f, journey / 0.16f)) * (1f - smooth(Math.max(0f, (journey - 0.78f) / 0.22f)));
            float riseFall = (float)Math.sin(journey * (float)Math.PI * (2.6f + 1.4f * s.flowA) + s.seed * 1.73f);
            float lateralBreath = (float)Math.cos(journey * (float)Math.PI * (3.2f + s.flowB) + s.seed * 0.91f);
            // V45：同一 Scene DNA 内部也要经历“变形章节”，避免形体只是换位置。
            // explore -> encounter -> transform -> farewell 的能量包络会改变控制点之间的距离、旋入、呼吸与离别方向。
            float explore = smooth(clamp(journey / 0.24f, 0f, 1f));
            float encounter = smooth(clamp((journey - 0.22f) / 0.24f, 0f, 1f)) * (1f - smooth(clamp((journey - 0.58f) / 0.22f, 0f, 1f)));
            float transform = smooth(clamp((journey - 0.42f) / 0.22f, 0f, 1f)) * (1f - smooth(clamp((journey - 0.78f) / 0.18f, 0f, 1f)));
            float farewell = smooth(clamp((journey - 0.76f) / 0.24f, 0f, 1f));
            float sceneBeat = (float)Math.sin(journey * Math.PI * (1.6f + 0.8f * s.flowA) + s.seed * 0.73f);

            for (int i = 0; i < s.count; i++) {
                float wobble = (float)Math.sin(sec * (0.8f + s.turn * s.flowA) + s.seed + i * (1.05f + 0.18f * s.flowB));
                float wobble2 = (float)Math.cos(sec * (0.72f + s.turn * 0.76f * s.flowB) + s.seed * 1.37f + i * 1.67f);
                float eddy = (float)Math.sin(sec * (0.19f + 0.031f * s.flowA) + s.seed * 2.31f + i * 2.414f);
                // V29：非周期小流场。控制点仍保持整体势能，但每一类母型拥有不同“呼吸”，
                // 避免长期播放时所有线都像同一条曲线换皮。
                float motifFlow = isSculpturalMotif(s.motif) ? 0.56f : ((s.motif == 8 || s.motif == 9) ? 1.22f : (s.motif == 3 || s.motif == 10 ? 0.72f : 1.0f));
                s.vx[i] += (wobble + eddy * 0.42f * s.flowC) * s.speed * s.turn * motifFlow * (0.030f + cfg.randomness * 0.052f) * dt;
                s.vy[i] += (wobble2 - eddy * 0.36f * s.flowC) * s.speed * s.turn * motifFlow * (0.030f + cfg.randomness * 0.052f) * dt;

                // V46：curl-like 生命运动场。低频场决定主轨迹，高频场只扰动边缘。
                // 同步阶段两个主体共享相位；临界向共同中心卷入；释放外爆；余韵减速上浮。
                float curlX = curlFlowX(s, s.x[i], s.y[i], sec);
                float curlY = curlFlowY(s, s.x[i], s.y[i], sec);
                float curlGain = (0.018f + cfg.randomness * 0.020f) * s.speed * journeyEnvelope;
                if (phase.name.equals("分离")) curlGain *= 0.72f;
                else if (phase.name.equals("吸引")) curlGain *= 1.05f;
                else if (phase.name.equals("同步")) curlGain *= 1.18f;
                else if (phase.name.equals("临界")) curlGain *= 1.48f;
                else if (phase.name.equals("释放")) curlGain *= 1.82f;
                else curlGain *= 0.48f;
                s.vx[i] += curlX * curlGain * dt;
                s.vy[i] += curlY * curlGain * dt;

                s.vx[i] += (s.attractX - s.x[i]) * relationPull * 60f * dt;
                s.vy[i] += (s.attractY - s.y[i]) * relationPull * 60f * dt;
                if (release > 0f) {
                    s.vx[i] += (s.attractX - s.x[i]) * release * 0.016f;
                    s.vy[i] += (s.attractY - s.y[i]) * release * 0.016f;
                }
                // V40：为每个长生命形体增加可感知的跌宕起伏。
                // 它不是随机抖动，而是贯穿其生命周期的缓慢呼吸：上升、俯冲、侧身、再上升。
                float uLife = i / Math.max(1f, (s.count - 1f));
                float bodyPhase = (float)Math.sin((uLife * 2.0f - 1.0f) * (float)Math.PI + s.seed);
                s.vx[i] += lateralBreath * journeyEnvelope * s.asymmetry * width * 0.010f * dt * (0.35f + 0.65f * Math.abs(bodyPhase));
                s.vy[i] += riseFall * journeyEnvelope * height * 0.012f * dt * (0.46f + 0.54f * (float)Math.sin(uLife * Math.PI));

                float dxC = s.x[i] - s.attractX;
                float dyC = s.y[i] - s.attractY;
                float distC = (float)Math.sqrt(dxC * dxC + dyC * dyC) + 0.001f;
                float nxC = dxC / distC;
                float nyC = dyC / distC;
                float txC = -nyC;
                float tyC = nxC;
                float midWeight = (float)Math.sin(uLife * Math.PI);
                float edgeWeight = Math.abs(uLife - 0.5f) * 2f;
                float dnaForce = Math.min(width, height) * (0.010f + cfg.randomness * 0.012f) * journeyEnvelope;
                switch (s.sceneProgram) {
                    case 0: // 遥远双生：先保持距离，中段微靠近，离别时再次外放。
                        s.vx[i] += (s.actor == 1 ? -1f : 1f) * dnaForce * (0.45f * explore + 0.70f * farewell) * dt;
                        s.vy[i] += tyC * dnaForce * sceneBeat * 0.42f * midWeight * dt;
                        break;
                    case 1: // 对角追逐：沿切线滑行，像两条生命曲线在试探追逐。
                        s.vx[i] += txC * dnaForce * (0.82f * explore + 0.72f * encounter) * (s.actor == 1 ? 1f : -1f) * dt;
                        s.vy[i] += tyC * dnaForce * (0.82f * explore + 0.72f * encounter) * (s.actor == 1 ? 1f : -1f) * dt;
                        break;
                    case 2: // 纵向绽放：中段向外展开，后段像花瓣垂落。
                        s.vx[i] += nxC * dnaForce * transform * midWeight * 0.80f * dt;
                        s.vy[i] += (-height * 0.010f * transform * (0.25f + midWeight) + height * 0.012f * farewell * edgeWeight) * dt;
                        break;
                    case 3: // 水域漂移：慢速漩涡与上浮，偏向余韵水感。
                        s.vx[i] += (txC * 0.70f + nxC * 0.22f * sceneBeat) * dnaForce * (0.65f + transform) * dt;
                        s.vy[i] += (-height * 0.006f * journeyEnvelope + tyC * dnaForce * 0.30f * sceneBeat) * dt;
                        break;
                    case 4: // 螺旋互缠：临界前后增强旋入感，但不过度增加元素数量。
                        s.vx[i] += txC * dnaForce * (0.90f * encounter + 1.20f * transform) * dt;
                        s.vy[i] += tyC * dnaForce * (0.90f * encounter + 1.20f * transform) * dt;
                        s.vx[i] -= nxC * dnaForce * transform * 0.42f * dt;
                        s.vy[i] -= nyC * dnaForce * transform * 0.42f * dt;
                        break;
                    default: // 中央汇环：先收缩成共同体，离别时薄薄散开。
                        s.vx[i] += (-nxC * dnaForce * encounter * 0.76f + nxC * dnaForce * farewell * 0.62f) * dt;
                        s.vy[i] += (-nyC * dnaForce * encounter * 0.76f + nyC * dnaForce * farewell * 0.62f) * dt;
                        break;
                }
                s.x[i] += s.vx[i] * dt;
                s.y[i] += s.vy[i] * dt;
                s.vx[i] *= 0.998f;
                s.vy[i] *= 0.998f;
                bounce(s, i);
            }
            relaxStrokeMotion(s, phase, dt, journey, tension, release);
        }

        private void updateStrokeAttractor(StrokeEvent s, float sec, float dt, Phase phase, float tension, float release) {
            float smoothness = clamp(s.motionSmoothness, 0.35f, 0.96f);
            float wander = (1.0f - smoothness) * 0.50f + 0.18f;
            if (phase.name.equals("同步") || phase.name.equals("余韵")) wander *= 0.82f;
            if (phase.name.equals("释放")) wander *= 1.35f;
            s.attractVX += (float)Math.sin(sec * (0.021f + s.turn * 0.007f) + s.seed * 0.91f) * width * 0.0045f * wander * dt;
            s.attractVY += (float)Math.cos(sec * (0.019f + s.turn * 0.006f) + s.seed * 1.07f) * height * 0.0048f * wander * dt;
            float targetDamp = (float)Math.exp(-(2.8f + smoothness * 3.2f) * dt);
            s.attractVX *= targetDamp;
            s.attractVY *= targetDamp;
            s.attractTargetX += s.attractVX * dt * 60f;
            s.attractTargetY += s.attractVY * dt * 60f;
            s.attractTargetX = clamp(s.attractTargetX, -width * 0.12f, width * 1.12f);
            s.attractTargetY = clamp(s.attractTargetY, -height * 0.12f, height * 1.12f);
            float response = 1f - (float)Math.exp(-(3.0f + smoothness * 4.5f) * dt);
            if (phase.name.equals("释放")) response *= 0.88f;
            s.attractX = lerp(s.attractX, s.attractTargetX, response);
            s.attractY = lerp(s.attractY, s.attractTargetY, response);
        }

        private void relaxStrokeMotion(StrokeEvent s, Phase phase, float dt, float journey, float tension, float release) {
            if (s == null || s.count < 3) return;
            float[] ox = s.x.clone();
            float[] oy = s.y.clone();
            float[] ovx = s.vx.clone();
            float[] ovy = s.vy.clone();
            float smoothness = clamp(s.motionSmoothness, 0.35f, 0.96f);
            float shapeAlpha = (0.08f + smoothness * 0.18f) * (phase.name.equals("释放") ? 0.52f : 1f);
            float velAlpha = (0.10f + smoothness * 0.22f) * (phase.name.equals("释放") ? 0.60f : 1f);
            float closureAlpha = s.closureTendency * (0.05f + smoothness * 0.10f) * (phase.name.equals("释放") || phase.name.equals("余韵") ? 0.20f : 1f);
            for (int i = 1; i < s.count - 1; i++) {
                float u = i / Math.max(1f, (s.count - 1f));
                float body = (float)Math.sin(u * Math.PI);
                float avgX = (ox[i - 1] + ox[i + 1]) * 0.5f;
                float avgY = (oy[i - 1] + oy[i + 1]) * 0.5f;
                float localAlpha = shapeAlpha * (0.35f + 0.65f * body) * (0.92f + 0.08f * (1f - Math.abs(journey - 0.5f)));
                s.x[i] = lerp(ox[i], avgX, localAlpha);
                s.y[i] = lerp(oy[i], avgY, localAlpha);
                float avgVx = (ovx[i - 1] + ovx[i] + ovx[i + 1]) / 3f;
                float avgVy = (ovy[i - 1] + ovy[i] + ovy[i + 1]) / 3f;
                s.vx[i] = lerp(ovx[i], avgVx, velAlpha * (0.45f + 0.55f * body));
                s.vy[i] = lerp(ovy[i], avgVy, velAlpha * (0.45f + 0.55f * body));
            }
            if (closureAlpha > 0.001f && s.count > 4) {
                float hx = (ox[0] + ox[s.count - 1]) * 0.5f;
                float hy = (oy[0] + oy[s.count - 1]) * 0.5f;
                s.x[1] = lerp(s.x[1], (hx + ox[1]) * 0.5f, closureAlpha * 0.72f);
                s.y[1] = lerp(s.y[1], (hy + oy[1]) * 0.5f, closureAlpha * 0.72f);
                s.x[s.count - 2] = lerp(s.x[s.count - 2], (hx + ox[s.count - 2]) * 0.5f, closureAlpha * 0.72f);
                s.y[s.count - 2] = lerp(s.y[s.count - 2], (hy + oy[s.count - 2]) * 0.5f, closureAlpha * 0.72f);
            }
            float tailDamp = 1f - clamp(0.010f + smoothness * 0.024f, 0.01f, 0.05f);
            s.vx[0] *= tailDamp; s.vy[0] *= tailDamp;
            s.vx[s.count - 1] *= tailDamp; s.vy[s.count - 1] *= tailDamp;
        }

        private float curlFlowX(StrokeEvent s, float x, float y, float sec) {
            float px = x / Math.max(1f, width);
            float py = y / Math.max(1f, height);
            float phase = s.seed;
            if (s.dna != null && s.dna.flowField == FLOW_SHARED && s.partner != null) phase = Math.min(s.seed, s.partner.seed) * 0.72f;
            if (s.dna != null && s.dna.flowField == FLOW_CURL_B) phase += 1.731f;
            float t = sec * (0.052f + 0.018f * s.flowA) + phase;
            float low = (float)Math.sin(py * 7.1f + t) + 0.62f * (float)Math.cos((px + py) * 5.3f - t * 0.72f);
            float high = 0.36f * (float)Math.sin((py * 21.0f - px * 8.0f) + t * 2.2f);
            float out = low + high;
            if (s.dna != null && s.dna.flowField == FLOW_EXPAND) {
                float dx = px - pulseX;
                float dy = py - pulseY;
                float len = (float)Math.sqrt(dx * dx + dy * dy) + 0.001f;
                out += dx / len * 1.35f;
            }
            return out;
        }

        private float curlFlowY(StrokeEvent s, float x, float y, float sec) {
            float px = x / Math.max(1f, width);
            float py = y / Math.max(1f, height);
            float phase = s.seed;
            if (s.dna != null && s.dna.flowField == FLOW_SHARED && s.partner != null) phase = Math.min(s.seed, s.partner.seed) * 0.72f;
            if (s.dna != null && s.dna.flowField == FLOW_CURL_B) phase += 1.731f;
            float t = sec * (0.050f + 0.020f * s.flowB) + phase;
            float low = -(float)Math.cos(px * 6.7f - t) + 0.58f * (float)Math.sin((px - py) * 5.9f + t * 0.68f);
            float high = 0.34f * (float)Math.cos((px * 19.0f + py * 7.0f) - t * 2.0f);
            float out = low + high;
            if (s.dna != null && s.dna.flowField == FLOW_EXPAND) {
                float dx = px - pulseX;
                float dy = py - pulseY;
                float len = (float)Math.sqrt(dx * dx + dy * dy) + 0.001f;
                out += dy / len * 1.35f;
            }
            if (s.dna != null && s.dna.lifeScript == 5) out -= 0.42f; // afterglow upward drift
            return out;
        }

        private void bounce(StrokeEvent s, int i) {
            RectF b = s.bounds;
            if (s.x[i] < b.left) { s.x[i] = b.left; s.vx[i] = Math.abs(s.vx[i]) * (0.82f + random.nextFloat()*0.22f); }
            if (s.x[i] > b.right) { s.x[i] = b.right; s.vx[i] = -Math.abs(s.vx[i]) * (0.82f + random.nextFloat()*0.22f); }
            if (s.y[i] < b.top) { s.y[i] = b.top; s.vy[i] = Math.abs(s.vy[i]) * (0.82f + random.nextFloat()*0.22f); }
            if (s.y[i] > b.bottom) { s.y[i] = b.bottom; s.vy[i] = -Math.abs(s.vy[i]) * (0.82f + random.nextFloat()*0.22f); }
        }

        private void drawAllStrokes(Phase phase, float intensity, float tension, float release, float after) {
            for (int i = 0; i < strokes.size(); i++) {
                StrokeEvent s = strokes.get(i);
                drawStroke(s, phase, intensity, tension, release, after);
            }
        }

        private void drawStroke(StrokeEvent s, Phase phase, float intensity, float tension, float release, float after) {
            // V17：真正做“头部游走显现 + 尾部同步缓慢消失”。
            // 不再只画当前一段，也不让整条笔触整体衰老；而是把同一条光迹按时间切成多层。
            // 每层都是过去某个瞬间的可见窗口：越靠近头部越亮，越靠尾部越淡。
            // FBO 再继续保留更旧的尾迹，形成 Windows Mystify 那种“后会有期”的淡出背影。
            float progress = clamp(s.age / Math.max(0.001f, s.life), 0f, 1f);
            float born = smooth(Math.min(1f, s.age / Math.max(0.001f, s.life * 0.10f)));
            float depart = 1f - smooth(Math.max(0f, (progress - 0.78f) / 0.22f));
            float journeyPulse = 0.86f + 0.18f * (float)Math.sin(progress * (float)Math.PI * (3.4f + s.flowA) + s.seed * 1.31f);
            if (born <= 0.015f || depart <= 0.012f) return;

            ArrayList<float[]> all = sampleStroke(s);
            if (all.size() < 2) return;

            int ca = s.colorA;
            int cb = s.colorB;
            float baseWidth = lerp(0.78f, 3.75f, cfg.ribbonWidth) * s.widthScale * journeyPulse * (0.72f + intensity * 0.66f + release * 0.32f);
            float[] c1 = color4(ca, 1f);
            float[] c2 = color4(cb, 1f);
            float[] mix = new float[]{(c1[0]+c2[0])*0.5f, (c1[1]+c2[1])*0.5f, (c1[2]+c2[2])*0.5f, 1f};

            // 过去的窗口层数。trail 越长，尾巴越柔和、越慢退场。
            int layers = cfg.powerSave ? 7 : (10 + (int)(cfg.trail * 18f));
            float step = lerp(0.018f, 0.010f, cfg.trail);
            for (int layer = layers; layer >= 0; layer--) {
                float p = progress - layer * step;
                if (p <= -0.08f || p >= 1.18f) continue;
                ArrayList<float[]> pts = visibleSegmentAt(all, s, p);
                if (pts.size() < 2) continue;

                float depth = layer / Math.max(1f, (float)layers);
                float afterStroke = phase.name.equals("余韵") && cfg.bubbles
                        ? (0.12f * (1f - 0.42f * after))
                        : (1f - after * 0.55f);
                float layerAlpha = born * depart * journeyPulse * (float)Math.pow(1f - depth, 2.15f) * afterStroke;
                if (layer == 0) layerAlpha *= 1.14f;
                // V48：非释放/非余韵阶段不再让同一个主体的多个历史窗口反复叠加成白色宽影。
                // 只保留头层清晰主体，旧层降为极淡运动提示；释放和余韵保持原逻辑。
                if (!isReleaseOrAfterglowPhase(phase) && layer > 0) layerAlpha *= 0.18f;
                if (layerAlpha <= 0.006f) continue;

                drawStrokeLayer(s, pts, phase, baseWidth, mix, layerAlpha, intensity, tension, release, layer == 0);
            }
        }

        private void drawStrokeLayer(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                     float[] mix, float alpha, float intensity, float tension, float release, boolean headLayer) {
            if (pts.size() < 2 || alpha <= 0.004f) return;
            boolean sculptural = isSculpturalMotif(s.motif);
            float detailMul = 1f;
            float restraintMul = 1f;
            float roleAlpha = 1f;
            if (s.artist != null) {
                detailMul = s.artist.detailDensity == DETAIL_SPARSE ? 0.62f : (s.artist.detailDensity == DETAIL_MEDIUM ? 1.0f : 1.28f);
                restraintMul = s.artist.restraintLevel == RESTRAINT_HIGH ? 0.74f : (s.artist.restraintLevel == RESTRAINT_MEDIUM ? 1.0f : 1.18f);
                roleAlpha = s.artist.compositionRole == COMPOSITION_HERO ? 1.0f : (s.artist.compositionRole == COMPOSITION_SUPPORT ? 0.84f : 0.66f);
            }
            alpha *= roleAlpha;
            if (s.fan && headLayer && (s.motif == 2 || s.motif == 5) && detailMul > 0.72f) {
                float nx = (float)Math.cos(s.seed + Math.PI / 2f);
                float ny = (float)Math.sin(s.seed + Math.PI / 2f);
                for (int k = s.fanLines; k >= 1; k--) {
                    float off = (k - s.fanLines * 0.5f) * s.fanGapPx * (0.70f + intensity);
                    drawTaperedStrip(offsetPoints(pts, nx * off, ny * off), baseWidth * 0.16f, mix[0], mix[1], mix[2], alpha * (0.010f + intensity * 0.018f));
                }
            }

            // V30：雕塑形态优先以“面/体/片/环”出现；纤维与点线只保留给非雕塑轨迹。
            if (!sculptural) {
                drawFiberVeil(s, pts, baseWidth, mix[0], mix[1], mix[2], alpha * detailMul * restraintMul, intensity, tension, release, headLayer);
            }
            // 扇形光网降级为少数专属母型，不再每条线都展开网状肋纹。
            if ((s.motif == 2 && (headLayer || s.fan)) || (s.motif == 5 && headLayer && tension > 0.38f)) {
                drawMystifyFanLattice(s, pts, phase, baseWidth, mix[0], mix[1], mix[2], alpha * 0.82f * detailMul, intensity, tension, release);
            }
            drawArtMotifAccent(s, pts, phase, baseWidth, mix[0], mix[1], mix[2], alpha * detailMul, intensity, tension, release, headLayer);
            if (headLayer && s.dna != null) {
                drawShapeDnaBody(s, pts, phase, baseWidth, mix[0], mix[1], mix[2], alpha * restraintMul, intensity, tension, release);
            }

            float actorFace = s.actor == 1 ? 0.86f : (s.actor == 2 ? 1.14f : 1.0f);
            float actorLine = s.actor == 1 ? 0.92f : (s.actor == 2 ? 1.08f : 1.0f);
            float whiteBandMax = nonReleaseWhiteBandMaxPx(phase);
            float wideScale = nonReleaseWideAlphaScale(phase);
            float hiScale = nonReleaseHighlightAlphaScale(phase);
            boolean preferLinePoint = !isReleaseOrAfterglowPhase(phase);
            if (preferLinePoint) {
                float bundleSpan = baseWidth * actorFace * (sculptural ? 0.95f : 0.78f) * (1.0f + tension * 0.18f) * s.bundleSpread;
                float contourWidth = Math.min(Math.max(0.72f, baseWidth * actorLine * (0.34f + tension * 0.06f)), whiteBandMax * 0.38f);
                int contourCopies = Math.max(sculptural ? 4 : 3, s.bundleLineCount);
                drawMystifyRibbonBundle(s, pts, bundleSpan, contourWidth, mix[0], mix[1], mix[2], alpha * hiScale * restraintMul * (0.34f + intensity * 0.10f), contourCopies, true);
                drawCurvatureDensityLines(s, pts, baseWidth, mix[0], mix[1], mix[2], alpha * hiScale * restraintMul * (0.26f + intensity * 0.09f));
                if (headLayer) {
                    drawSpiralFanEnd(s, pts, phase, baseWidth, mix[0], mix[1], mix[2], alpha * hiScale * restraintMul * (0.34f + intensity * 0.12f));
                    drawPointLatticeAlongCurve(s, pts, phase, baseWidth, mix[0], mix[1], mix[2], alpha * detailMul * restraintMul * (0.22f + intensity * 0.09f));
                }
                drawLinePointContourBundle(s, pts, bundleSpan * 0.32f, Math.max(0.18f, contourWidth * 0.55f), 1f, 1f, 1f, alpha * hiScale * restraintMul * (0.11f + intensity * 0.05f), Math.max(2, contourCopies / 2), false);
            } else if (sculptural) {
                drawTaperedStrip(pts, capNonReleaseBand(phase, baseWidth * actorFace * (5.8f + tension * 1.15f)), mix[0], mix[1], mix[2], alpha * wideScale * restraintMul * (0.010f + intensity * 0.012f + release * 0.014f));
                drawTaperedStrip(pts, Math.min(baseWidth * actorLine * (0.86f + tension * 0.16f), whiteBandMax), mix[0], mix[1], mix[2], alpha * hiScale * restraintMul * (0.078f + intensity * 0.052f + release * 0.036f));
            } else {
                // 释放/余韵保留此前较完整的带状语言。
                drawTaperedStrip(pts, capNonReleaseBand(phase, baseWidth * actorFace * (6.2f + tension * 1.4f)), mix[0], mix[1], mix[2], alpha * wideScale * restraintMul * (0.008f + intensity * 0.015f + release * 0.024f));
                drawTaperedStrip(pts, Math.min(baseWidth * actorLine * (1.95f + tension * 0.42f), whiteBandMax), mix[0], mix[1], mix[2], alpha * hiScale * restraintMul * (0.040f + intensity * 0.048f + release * 0.034f));
                drawTaperedStrip(pts, Math.min(baseWidth * actorLine * (0.64f + tension * 0.12f), whiteBandMax * 0.55f), mix[0], mix[1], mix[2], alpha * hiScale * restraintMul * (0.17f + intensity * 0.12f + release * 0.060f));
            }
            if (headLayer && !sculptural && s.motif != 11) drawActorHeadCluster(s, pts, baseWidth, mix[0], mix[1], mix[2], alpha * detailMul, intensity, tension, release);

            // 点线喷洒只作为少量纹理；雕塑类、扇面和星座链不再继续喷点，避免“网状/散点”主导。
            if (!sculptural && s.motif != 2 && s.motif != 11 && (headLayer || alpha > 0.105f)) {
                drawPointLineSpray(s, pts, phase, baseWidth, mix[0], mix[1], mix[2], alpha * 0.58f * detailMul * restraintMul, intensity, tension, release);
            }
            // 核心亮线：极细，模拟 Windows 屏保里锋利的亮边。
            drawTaperedStrip(pts, Math.min(Math.max(0.72f, baseWidth * (sculptural ? 0.12f : 0.16f)), whiteBandMax * 0.46f), 1f, 1f, 1f, alpha * hiScale * restraintMul * (sculptural ? 0.52f : 0.68f + intensity * 0.22f));
        }

        private void drawMystifyFanLattice(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                        float r, float g, float b, float alpha, float intensity,
                                        float tension, float release) {
            if (pts.size() < 5 || alpha <= 0.004f) return;
            boolean motifFan = s.motif == 2 || s.motif == 5 || s.motif == 10;
            boolean phaseAllows = phase.name.equals("同步") || phase.name.equals("临界") || phase.name.equals("释放") || motifFan;
            float chance = (s.fan || motifFan ? 1.0f : 0.10f + cfg.randomness * 0.18f + tension * 0.18f);
            if (!phaseAllows && !s.fan) return;
            if (!s.fan && !motifFan && strokeHash(s, 0, 881) > chance) return;

            float[] first = pts.get(0);
            float[] last = pts.get(pts.size() - 1);
            float dx = last[0] - first[0];
            float dy = last[1] - first[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) return;
            float tx = dx / len;
            float ty = dy / len;
            float nx = -ty;
            float ny = tx;

            int ribs = s.fan ? Math.max(5, s.fanLines + 4) : 5 + (int)(cfg.randomness * 7f + tension * 4f);
            if (phase.name.equals("临界")) ribs += 3;
            if (phase.name.equals("释放")) ribs += 1;
            ribs = Math.min(18, Math.max(4, ribs));
            float spread = baseWidth * (5.8f + cfg.randomness * 4.8f + tension * 5.2f + release * 4.2f);
            float originBias = strokeHash(s, 1, 883) < 0.5f ? 0f : 1f;
            for (int j = 0; j < ribs; j++) {
                float jj = ribs == 1 ? 0f : (j / (float)(ribs - 1));
                float centered = (jj - 0.5f) * 2f;
                float hash = strokeHash(s, j, 887);
                float off = centered * spread * (0.55f + hash * 0.55f);
                float phaseShift = (strokeHash(s, j, 889) - 0.5f) * baseWidth * (1.2f + tension);
                ArrayList<float[]> rib = new ArrayList<>(pts.size());
                for (int i = 0; i < pts.size(); i++) {
                    float u = i / Math.max(1f, pts.size() - 1f);
                    float fanGrow = originBias < 0.5f ? smooth(u) : smooth(1f - u);
                    float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                    float shimmer = (float)Math.sin(u * Math.PI * 2.0f + s.seed * 1.7f + j * 0.41f)
                            * baseWidth * (0.35f + tension * 0.25f) * feather;
                    float[] p = pts.get(i);
                    rib.add(new float[]{
                            p[0] + nx * (off * fanGrow + shimmer) + tx * phaseShift * feather,
                            p[1] + ny * (off * fanGrow + shimmer) + ty * phaseShift * feather
                    });
                }
                float ribWidth = Math.max(0.22f, baseWidth * (0.040f + strokeHash(s, j, 891) * 0.060f));
                float ribAlpha = alpha * (0.020f + intensity * 0.026f + release * 0.030f) * (0.55f + hash * 0.70f);
                drawTaperedStrip(rib, ribWidth, r, g, b, ribAlpha);
            }

            // 扇面内增加极淡的横向折线，形成“电子纱/贝壳肋纹”的网感。
            int cross = Math.min(6, Math.max(2, ribs / 3));
            for (int k = 1; k <= cross; k++) {
                float u = k / (float)(cross + 1);
                int idx = clampInt((int)(u * (pts.size() - 1)), 1, pts.size() - 2);
                float[] p = pts.get(idx);
                float span = spread * (0.22f + 0.52f * (originBias < 0.5f ? smooth(u) : smooth(1f - u)));
                ArrayList<float[]> crossPts = new ArrayList<>(2);
                crossPts.add(new float[]{p[0] - nx * span, p[1] - ny * span});
                crossPts.add(new float[]{p[0] + nx * span, p[1] + ny * span});
                drawTaperedStrip(crossPts, Math.max(0.18f, baseWidth * 0.025f), r, g, b,
                        alpha * (0.008f + intensity * 0.014f + release * 0.012f));
            }
        }


        private void drawAsymmetricRibbon(ArrayList<float[]> pts, float leftMax, float rightMax,
                                           float r, float g, float b, float a, float power) {
            if (pts.size() < 2 || a <= 0.001f) return;
            int n = pts.size();
            float[] verts = new float[n * 2 * 2];
            int vi = 0;
            for (int i = 0; i < n; i++) {
                float u = i / Math.max(1f, n - 1f);
                float profile = (float)Math.pow(Math.max(0f, Math.sin(Math.PI * u)), power);
                float[] prev = pts.get(Math.max(0, i - 1));
                float[] next = pts.get(Math.min(n - 1, i + 1));
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float x = pts.get(i)[0];
                float y = pts.get(i)[1];
                putNdc(verts, vi, x + nx * leftMax * profile, y + ny * leftMax * profile); vi += 2;
                putNdc(verts, vi, x - nx * rightMax * profile, y - ny * rightMax * profile); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void drawEllipse(float cx, float cy, float rx, float ry, float rot, float r, float g, float b, float a, int segments) {
            if (a <= 0f || rx <= 0f || ry <= 0f) return;
            float[] verts = new float[(segments + 2) * 2];
            putNdc(verts, 0, cx, cy);
            float co = (float)Math.cos(rot);
            float si = (float)Math.sin(rot);
            int vi = 2;
            for (int i = 0; i <= segments; i++) {
                float ang = i / (float)segments * (float)Math.PI * 2f;
                float x = (float)Math.cos(ang) * rx;
                float y = (float)Math.sin(ang) * ry;
                putNdc(verts, vi, cx + x * co - y * si, cy + x * si + y * co);
                vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_FAN, r, g, b, a);
        }

        private void drawArcStrip(float cx, float cy, float radius, float widthPx, float startAng, float sweep,
                                  float r, float g, float b, float a, int segments) {
            if (a <= 0f || radius <= 0f || widthPx <= 0f || segments < 2) return;
            float[] verts = new float[(segments + 1) * 2 * 2];
            int vi = 0;
            for (int i = 0; i <= segments; i++) {
                float u = i / (float)segments;
                float ang = startAng + sweep * u;
                float co = (float)Math.cos(ang);
                float si = (float)Math.sin(ang);
                float fade = (float)Math.pow(Math.max(0f, Math.sin(Math.PI * u)), 0.35f);
                float outer = radius + widthPx * (0.35f + 0.65f * fade);
                float inner = Math.max(0f, radius - widthPx * (0.35f + 0.65f * fade));
                putNdc(verts, vi, cx + co * outer, cy + si * outer); vi += 2;
                putNdc(verts, vi, cx + co * inner, cy + si * inner); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void drawFilledPolygon(ArrayList<float[]> poly, float r, float g, float b, float a) {
            if (poly.size() < 3 || a <= 0.001f) return;
            float[] verts = new float[poly.size() * 2];
            int vi = 0;
            for (int i = 0; i < poly.size(); i++) {
                float[] p = poly.get(i);
                putNdc(verts, vi, p[0], p[1]);
                vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_FAN, r, g, b, a);
        }

        private ArrayList<float[]> buildEllipsePath(float cx, float cy, float rx, float ry, float rot, int segments, float startAng, float sweep) {
            ArrayList<float[]> pts = new ArrayList<>(segments + 1);
            float co = (float)Math.cos(rot);
            float si = (float)Math.sin(rot);
            for (int i = 0; i <= segments; i++) {
                float u = i / (float)Math.max(1, segments);
                float ang = startAng + sweep * u;
                float lx = (float)Math.cos(ang) * rx;
                float ly = (float)Math.sin(ang) * ry;
                pts.add(new float[]{cx + lx * co - ly * si, cy + lx * si + ly * co});
            }
            return pts;
        }

        private ArrayList<float[]> buildPolygonLoop(ArrayList<float[]> src, boolean close) {
            ArrayList<float[]> out = new ArrayList<>(src.size() + (close ? 1 : 0));
            out.addAll(src);
            if (close && src.size() > 2) {
                float[] p = src.get(0);
                out.add(new float[]{p[0], p[1]});
            }
            return out;
        }

        private void drawPointChain(ArrayList<float[]> pts, float radius, float r, float g, float b, float a, int step) {
            if (pts == null || pts.size() < 2 || a <= 0.002f) return;
            int stride = Math.max(1, step);
            for (int i = 0; i < pts.size(); i += stride) {
                float[] p = pts.get(i);
                float fade = (float)Math.pow(Math.max(0f, Math.sin(Math.PI * (i / Math.max(1f, pts.size() - 1f)))), 0.35f);
                drawCircle(p[0], p[1], radius, r, g, b, a * (0.55f + 0.45f * fade), 12);
            }
        }

        private void drawContourPath(ArrayList<float[]> pts, float width, float r, float g, float b, float a, boolean dotted) {
            if (pts == null || pts.size() < 2 || a <= 0.002f) return;
            drawTaperedStrip(pts, Math.max(0.18f, width), r, g, b, a);
            if (dotted) {
                drawPointChain(pts, Math.max(0.26f, width * 0.72f), r, g, b, a * 0.72f, Math.max(2, pts.size() / 14));
            }
        }

        private void drawLinePointContourBundle(StrokeEvent s, ArrayList<float[]> pts, float span, float width,
                                                float r, float g, float b, float a, int copies, boolean dotted) {
            if (pts == null || pts.size() < 2 || a <= 0.002f) return;
            float[] first = pts.get(0);
            float[] last = pts.get(pts.size() - 1);
            float dx = last[0] - first[0];
            float dy = last[1] - first[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) len = 1f;
            float nx = -dy / len;
            float ny = dx / len;
            int n = Math.max(1, copies);
            for (int i = 0; i < n; i++) {
                float u = n == 1 ? 0.5f : i / (float)(n - 1);
                float centered = (u - 0.5f) * 2f;
                float off = centered * span;
                ArrayList<float[]> chain = offsetPoints(pts, nx * off, ny * off);
                float alphaMul = 1.0f - Math.abs(centered) * 0.34f;
                drawContourPath(chain, width * (0.82f + 0.18f * (1f - Math.abs(centered))), r, g, b, a * alphaMul, dotted && (i % 2 == 0));
            }
        }

        private float curvatureAt(ArrayList<float[]> pts, int idx) {
            if (pts == null || pts.size() < 3) return 0f;
            int i0 = Math.max(0, idx - 2);
            int i1 = idx;
            int i2 = Math.min(pts.size() - 1, idx + 2);
            if (i0 == i1 || i1 == i2) return 0f;
            float[] p0 = pts.get(i0), p1 = pts.get(i1), p2 = pts.get(i2);
            float ax = p1[0] - p0[0], ay = p1[1] - p0[1];
            float bx = p2[0] - p1[0], by = p2[1] - p1[1];
            float al = (float)Math.sqrt(ax * ax + ay * ay) + 0.001f;
            float bl = (float)Math.sqrt(bx * bx + by * by) + 0.001f;
            ax /= al; ay /= al; bx /= bl; by /= bl;
            float dot = clamp(ax * bx + ay * by, -1f, 1f);
            float angle = (float)Math.acos(dot);
            return clamp(angle / (float)Math.PI, 0f, 1f);
        }

        private void tangentNormalAt(ArrayList<float[]> pts, int idx, float[] out) {
            int prev = Math.max(0, idx - 1);
            int next = Math.min(pts.size() - 1, idx + 1);
            float dx = pts.get(next)[0] - pts.get(prev)[0];
            float dy = pts.get(next)[1] - pts.get(prev)[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) { dx = 1f; dy = 0f; len = 1f; }
            float tx = dx / len;
            float ty = dy / len;
            out[0] = tx;
            out[1] = ty;
            out[2] = -ty;
            out[3] = tx;
        }

        private float[] tangentNormalAt(ArrayList<float[]> pts, int idx) {
            float[] out = new float[4];
            tangentNormalAt(pts, idx, out);
            return out;
        }

        private void drawMystifyRibbonBundle(StrokeEvent s, ArrayList<float[]> pts, float span, float width,
                                             float r, float g, float b, float alpha, int lineCount, boolean dotted) {
            if (pts == null || pts.size() < 3 || alpha <= 0.002f) return;
            int lines = clampInt(lineCount + 2, 5, cfg.powerSave ? 10 : 18);
            float[] basis = new float[4];
            for (int line = 0; line < lines; line++) {
                float q = lines == 1 ? 0.5f : line / (float)(lines - 1);
                float centered = (q - 0.5f) * 2f;
                ArrayList<float[]> curve = new ArrayList<>(pts.size());
                for (int i = 0; i < pts.size(); i++) {
                    float u = i / Math.max(1f, pts.size() - 1f);
                    float body = (float)Math.pow(Math.max(0f, Math.sin(Math.PI * u)), 0.72f);
                    float terminal = smooth(clamp((u - 0.58f) / 0.42f, 0f, 1f));
                    float c = curvatureAt(pts, i);
                    tangentNormalAt(pts, i, basis);
                    float topologyWave = (float)Math.sin(u * Math.PI * (1.3f + 0.34f * s.flowA) + s.seed + line * 0.71f)
                            * span * 0.045f * (0.25f + body);
                    float densityFan = 1f + terminal * s.terminalFan * (0.55f + c * 2.6f);
                    float off = centered * span * (0.18f + 0.82f * body) * densityFan + topologyWave;
                    float along = terminal * centered * span * 0.10f * s.flowC;
                    float[] p = pts.get(i);
                    curve.add(new float[]{p[0] + basis[2] * off + basis[0] * along, p[1] + basis[3] * off + basis[1] * along});
                }
                float edge = Math.abs(centered);
                float lineAlpha = alpha * (0.58f + 0.42f * (1f - edge)) * (0.92f + 0.08f * strokeHash(s, line, 1771));
                float lineWidth = Math.max(0.42f, width * (0.76f + 0.34f * (1f - edge)));
                drawContourPath(curve, lineWidth, r, g, b, lineAlpha, dotted && (line % 2 == 0));
            }
        }

        private void drawCurvatureDensityLines(StrokeEvent s, ArrayList<float[]> pts, float baseWidth,
                                               float r, float g, float b, float alpha) {
            if (pts == null || pts.size() < 8 || alpha <= 0.002f) return;
            float[] basis = new float[4];
            int maxMarks = cfg.powerSave ? 7 : 13;
            int made = 0;
            for (int i = 2; i < pts.size() - 2 && made < maxMarks; i += 3) {
                float u = i / Math.max(1f, pts.size() - 1f);
                float c = curvatureAt(pts, i);
                float terminal = smooth(clamp((u - 0.48f) / 0.52f, 0f, 1f));
                float chance = c * 1.85f + terminal * s.terminalFan * 0.70f;
                if (chance < 0.24f && strokeHash(s, i, 1783) > chance) continue;
                tangentNormalAt(pts, i, basis);
                float span = baseWidth * (2.2f + 4.8f * c + 3.2f * terminal * s.terminalFan);
                float side = strokeHash(s, i, 1787) < 0.5f ? -1f : 1f;
                float[] p = pts.get(i);
                ArrayList<float[]> mark = new ArrayList<>(3);
                mark.add(new float[]{p[0] - basis[2] * span * 0.55f * side - basis[0] * span * 0.16f,
                        p[1] - basis[3] * span * 0.55f * side - basis[1] * span * 0.16f});
                mark.add(new float[]{p[0] + basis[2] * span * 0.10f * side,
                        p[1] + basis[3] * span * 0.10f * side});
                mark.add(new float[]{p[0] + basis[2] * span * 0.68f * side + basis[0] * span * 0.22f,
                        p[1] + basis[3] * span * 0.68f * side + basis[1] * span * 0.22f});
                drawContourPath(mark, Math.max(0.34f, baseWidth * 0.090f), r, g, b, alpha * (0.18f + 0.22f * c + 0.14f * terminal), made % 2 == 0);
                made++;
            }
        }

        private void drawSpiralFanEnd(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                      float r, float g, float b, float alpha) {
            if (pts == null || pts.size() < 4 || alpha <= 0.002f || s.terminalFan <= 0.04f) return;
            if (phase.name.equals("释放") || phase.name.equals("余韵")) return;
            int endIdx = pts.size() - 1;
            float[] end = pts.get(endIdx);
            float[] prev = pts.get(Math.max(0, endIdx - Math.max(2, pts.size() / 8)));
            float dx = end[0] - prev[0];
            float dy = end[1] - prev[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) { dx = 1f; dy = 0f; len = 1f; }
            float baseAng = (float)Math.atan2(dy, dx) + s.flowC * 0.36f;
            int arcs = clampInt(Math.round(s.bundleLineCount * (0.72f + s.terminalFan)), 3, cfg.powerSave ? 7 : 12);
            float radiusBase = baseWidth * (2.8f + 2.6f * s.terminalFan);
            for (int k = 0; k < arcs; k++) {
                float u = k / Math.max(1f, arcs - 1f);
                float rad = radiusBase * (0.72f + u * 1.85f);
                float sweep = s.flowC * (float)Math.PI * (0.30f + 0.48f * s.terminalFan + 0.12f * u);
                float start = baseAng - sweep * 0.42f + (u - 0.5f) * 0.34f;
                float lineAlpha = alpha * (0.18f + 0.22f * (1f - u)) * (0.55f + s.terminalFan);
                drawArcContour(end[0], end[1], rad, rad * (0.42f + 0.30f * u), baseAng + s.flowC * u * 0.22f,
                        start, sweep, Math.max(0.16f, baseWidth * (0.045f + 0.020f * (1f - u))), r, g, b, lineAlpha, k % 2 == 0, 18 + k * 2);
            }
        }

        private void drawPointLatticeAlongCurve(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                                float r, float g, float b, float alpha) {
            if (pts == null || pts.size() < 4 || alpha <= 0.002f) return;
            if (phase.name.equals("释放")) return;
            int stride = cfg.powerSave ? 7 : 5;
            float[] basis = new float[4];
            for (int i = 0; i < pts.size(); i += stride) {
                float u = i / Math.max(1f, pts.size() - 1f);
                float c = curvatureAt(pts, i);
                float terminal = smooth(clamp((u - 0.45f) / 0.55f, 0f, 1f));
                float density = 0.28f + c * 1.35f + terminal * s.terminalFan * 1.20f;
                if (strokeHash(s, i, 1799) > density) continue;
                tangentNormalAt(pts, i, basis);
                float side = (strokeHash(s, i, 1801) - 0.5f) * 2f;
                float off = side * baseWidth * (1.2f + 4.2f * c + 3.0f * terminal * s.terminalFan);
                float[] p = pts.get(i);
                float rad = Math.max(0.20f, baseWidth * (0.070f + 0.055f * c + 0.040f * terminal));
                float a = alpha * (0.18f + 0.16f * c + 0.14f * terminal);
                drawCircle(p[0] + basis[2] * off, p[1] + basis[3] * off, rad, r, g, b, a, 10);
            }
        }

        private void drawEllipseContour(float cx, float cy, float rx, float ry, float rot, float width,
                                        float r, float g, float b, float a, boolean dotted, int segments) {
            ArrayList<float[]> loop = buildEllipsePath(cx, cy, rx, ry, rot, Math.max(10, segments), 0f, (float)Math.PI * 2f);
            drawContourPath(loop, width, r, g, b, a, dotted);
        }

        private void drawArcContour(float cx, float cy, float rx, float ry, float rot, float startAng, float sweep,
                                    float width, float r, float g, float b, float a, boolean dotted, int segments) {
            ArrayList<float[]> arc = buildEllipsePath(cx, cy, rx, ry, rot, Math.max(8, segments), startAng, sweep);
            drawContourPath(arc, width, r, g, b, a, dotted);
        }

        private ArrayList<float[]> buildClosureAccentPath(StrokeEvent s, ArrayList<float[]> pts, float bow) {
            ArrayList<float[]> out = new ArrayList<>();
            if (pts == null || pts.size() < 3) return out;
            float[] first = pts.get(0);
            float[] last = pts.get(pts.size() - 1);
            float dx = first[0] - last[0];
            float dy = first[1] - last[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) len = 1f;
            float nx = -dy / len;
            float ny = dx / len;
            float sign = (s.dna != null && (s.dna.masterTemplate == TEMPLATE_BLOSSOM_CROWN || s.dna.masterTemplate == TEMPLATE_TWIN_LEAF)) ? 1f : -1f;
            float x0 = last[0], y0 = last[1];
            float x1 = lerp(last[0], first[0], 0.28f) + nx * bow * 0.65f * sign;
            float y1 = lerp(last[1], first[1], 0.28f) + ny * bow * 0.65f * sign;
            float x2 = lerp(last[0], first[0], 0.72f) + nx * bow * 0.88f * sign;
            float y2 = lerp(last[1], first[1], 0.72f) + ny * bow * 0.88f * sign;
            float x3 = first[0], y3 = first[1];
            int segs = 18;
            for (int i = 0; i <= segs; i++) {
                float t = i / (float)segs;
                out.add(new float[]{catmull(x0, x0, x1, x2, t), catmull(y0, y0, y1, y2, t)});
            }
            for (int i = 1; i <= segs; i++) {
                float t = i / (float)segs;
                out.add(new float[]{catmull(x1, x2, x3, x3, t), catmull(y1, y2, y3, y3, t)});
            }
            return out;
        }

        private void drawClosureLoopAccent(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                           float r, float g, float b, float alpha) {
            if (pts == null || pts.size() < 3 || alpha <= 0.002f) return;
            if (phase.name.equals("释放") || phase.name.equals("余韵")) return;
            float closure = clamp(s.closureTendency, 0f, 1f);
            if (closure <= 0.04f) return;
            float[] first = pts.get(0);
            float[] last = pts.get(pts.size() - 1);
            float span = distance(first[0], first[1], last[0], last[1]);
            float bow = span * (0.22f + 0.20f * closure);
            ArrayList<float[]> bridge = buildClosureAccentPath(s, pts, bow);
            float w = Math.max(0.18f, baseWidth * (0.18f + 0.12f * closure));
            drawContourPath(bridge, w, r, g, b, alpha * (0.16f + 0.12f * closure), true);
            if (s.dna != null && (s.dna.masterTemplate == TEMPLATE_BLOSSOM_CROWN || s.dna.masterTemplate == TEMPLATE_TWIN_LEAF || s.dna.family == FAMILY_HALO)) {
                drawPointChain(bridge, Math.max(0.22f, w * 0.84f), 1f, 1f, 1f, alpha * 0.08f, Math.max(2, bridge.size() / 16));
            }
        }

        private void drawShapeDnaBody(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                      float r, float g, float b, float alpha, float intensity,
                                      float tension, float release) {
            if (s.dna == null || pts.size() < 3 || alpha <= 0.003f) return;
            float[] first = pts.get(0);
            float[] mid = pts.get(pts.size() / 2);
            float[] last = pts.get(pts.size() - 1);
            float dx = last[0] - first[0];
            float dy = last[1] - first[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) len = 1f;
            float rot = (float)Math.atan2(dy, dx);
            float tx = dx / len;
            float ty = dy / len;
            float nx = -ty;
            float ny = tx;
            float life = clamp(s.age / Math.max(0.001f, s.life), 0f, 1f);
            float born = smooth(clamp(life / 0.16f, 0f, 1f));
            float depart = 1f - smooth(clamp((life - 0.78f) / 0.22f, 0f, 1f));
            float pulse = 0.86f + 0.14f * (float)Math.sin(life * Math.PI * (2.0f + s.flowA) + s.dna.seed);
            float detailMul = 1f;
            float restraintMul = 1f;
            float roleMul = 1f;
            if (s.artist != null) {
                detailMul = s.artist.detailDensity == DETAIL_SPARSE ? 0.70f : (s.artist.detailDensity == DETAIL_MEDIUM ? 1.0f : 1.24f);
                restraintMul = s.artist.restraintLevel == RESTRAINT_HIGH ? 0.80f : (s.artist.restraintLevel == RESTRAINT_MEDIUM ? 1.0f : 1.16f);
                roleMul = s.artist.compositionRole == COMPOSITION_HERO ? 1.0f : (s.artist.compositionRole == COMPOSITION_SUPPORT ? 0.82f : 0.64f);
            }
            float bodyAlpha = alpha * born * depart * pulse * nonReleaseWideAlphaScale(phase) * roleMul;
            float rx = baseWidth * (6.2f + s.dna.aspect * 2.6f + tension * 2.2f + release * 1.4f) * s.dna.softness;
            float ry = baseWidth * (3.4f + s.dna.softness * 2.0f + intensity * 1.2f);
            if (s.artist != null) {
                if (s.artist.silhouetteLaw == SILHOUETTE_SIMPLE) { rx *= 0.92f; ry *= 0.90f; }
                if (s.artist.silhouetteLaw == SILHOUETTE_TAPERED) { rx *= 1.06f; ry *= 0.90f; }
                if (s.artist.silhouetteLaw == SILHOUETTE_ASYMMETRIC) { rx *= 1.08f; ry *= 0.96f; rot += 0.10f * s.asymmetry; }
                if (s.artist.silhouetteLaw == SILHOUETTE_TWIN_BALANCED) { rx *= 1.04f; }
            }
            if (phase.name.equals("临界")) { rx *= 0.86f; ry *= 0.92f; }
            if (phase.name.equals("释放")) { rx *= 1.20f; ry *= 1.08f; }

            switch (s.dna.family) {
                case FAMILY_MEMBRANE:
                    drawImplicitMembrane(s, mid[0], mid[1], rx, ry, rot, r, g, b, bodyAlpha * restraintMul, phase);
                    if (s.artist == null || s.artist.innerTexture == TEXTURE_MEMBRANE || s.artist.innerTexture == TEXTURE_RIPPLE) {
                        drawMembraneMicroTexture(s, mid[0], mid[1], rx, ry, rot, r, g, b, bodyAlpha * 0.76f * detailMul, phase);
                    }
                    break;
                case FAMILY_BLOSSOM:
                    drawBlossomSdf(s, mid[0], mid[1], rx, ry, rot, r, g, b, bodyAlpha * restraintMul, phase);
                    if (s.artist == null || s.artist.innerTexture == TEXTURE_VEIN) {
                        drawGrowthVeins(s, pts, baseWidth, r, g, b, bodyAlpha * detailMul, Math.max(3, 4 + (int)(4f * detailMul * s.dna.softness)));
                    }
                    break;
                case FAMILY_JELLYFISH:
                    drawJellyfishSdf(s, mid[0], mid[1], rx, ry, rot, r, g, b, bodyAlpha * restraintMul, phase);
                    drawJellyTendrils(s, mid[0], mid[1], tx, ty, nx, ny, baseWidth, r, g, b, bodyAlpha * detailMul, phase);
                    break;
                case FAMILY_CRYSTAL:
                    drawCrystalSdf(s, pts, rx, ry, rot, r, g, b, bodyAlpha * (1.0f + 0.10f * detailMul), phase);
                    break;
                case FAMILY_LIQUID:
                    drawLiquidMergeSdf(s, pts, rx, ry, rot, r, g, b, bodyAlpha * restraintMul, phase);
                    if (s.artist == null || s.artist.innerTexture == TEXTURE_MEMBRANE || s.artist.innerTexture == TEXTURE_RIPPLE) {
                        drawMembraneMicroTexture(s, mid[0], mid[1], rx * 0.86f, ry * 0.82f, rot, r, g, b, bodyAlpha * 0.42f * detailMul, phase);
                    }
                    break;
                case FAMILY_HALO:
                    drawHaloSdf(s, mid[0], mid[1], Math.max(rx, ry), rot, r, g, b, bodyAlpha * restraintMul, phase);
                    break;
                default:
                    drawTwinOrbitSdf(s, pts, rx, ry, rot, r, g, b, bodyAlpha * restraintMul, phase);
                    break;
            }
            drawClosureLoopAccent(s, pts, phase, baseWidth, r, g, b, bodyAlpha * restraintMul);
            if (s.artist != null) {
                if (s.artist.edgeTreatment == EDGE_IRIDESCENT) {
                    drawArcStrip(mid[0], mid[1], Math.max(rx, ry) * 0.92f, Math.max(0.24f, baseWidth * 0.10f), rot + s.seed, (float)Math.PI * 0.72f, 1f, 0.95f, 1f, bodyAlpha * 0.10f * detailMul, 24);
                } else if (s.artist.edgeTreatment == EDGE_WET_FILM) {
                    drawArcStrip(mid[0], mid[1], Math.max(rx, ry) * 0.86f, Math.max(0.20f, baseWidth * 0.08f), rot + s.seed * 0.7f, (float)Math.PI * 0.60f, 0.84f, 0.96f, 1f, bodyAlpha * 0.08f * detailMul, 20);
                } else if (s.artist.edgeTreatment == EDGE_REFRACT) {
                    drawArcStrip(mid[0], mid[1], Math.max(rx, ry) * 0.98f, Math.max(0.20f, baseWidth * 0.07f), rot + 0.4f, (float)Math.PI * 0.55f, 1f, 1f, 1f, bodyAlpha * 0.14f, 18);
                }
            }
        }

        private void drawImplicitMembrane(StrokeEvent s, float cx, float cy, float rx, float ry, float rot,
                                          float r, float g, float b, float alpha, Phase phase) {
            if (alpha <= 0.003f) return;
            float co = (float)Math.cos(rot), si = (float)Math.sin(rot);
            float split = s.dna != null && s.dna.bodySdf == SDF_IMPLICIT_MERGE ? 0.40f : 0.22f;
            float lineW = Math.max(0.22f, Math.min(rx, ry) * 0.016f);
            drawEllipseContour(cx, cy, rx, ry, rot, lineW, r, g, b, alpha * 0.40f, true, 46);
            drawEllipseContour(cx + co * rx * split, cy + si * rx * split, rx * 0.62f, ry * 0.72f, rot + 0.12f * s.flowC,
                    lineW * 0.92f, r, g, b, alpha * 0.28f, true, 34);
            drawEllipseContour(cx - co * rx * split * 0.92f, cy - si * rx * split * 0.92f, rx * 0.58f, ry * 0.68f, rot - 0.16f * s.flowC,
                    lineW * 0.82f, 0.60f + r * 0.38f, 0.78f + g * 0.20f, 1.0f, alpha * 0.18f, false, 34);
            drawArcContour(cx, cy, rx * 1.02f, ry * 1.02f, rot, s.dna.seed, (float)Math.PI * 0.86f,
                    Math.max(0.18f, lineW * 0.72f), 0.92f, 0.98f, 1f, alpha * 0.22f, true, 28);
            drawArcContour(cx, cy, rx * 0.86f, ry * 0.84f, rot, s.dna.seed + 2.2f, (float)Math.PI * 0.62f,
                    Math.max(0.16f, lineW * 0.58f), r, g, b, alpha * 0.12f, false, 24);
            if (!phase.name.equals("分离")) {
                drawPointChain(buildEllipsePath(cx + co * rx * 0.05f - si * ry * 0.20f, cy + si * rx * 0.05f + co * ry * 0.20f,
                        rx * 0.14f, Math.max(0.5f, ry * 0.040f), rot + 0.34f, 12, 0f, (float)Math.PI * 2f),
                        Math.max(0.22f, lineW * 0.82f), 1f, 1f, 1f, alpha * 0.12f, 2);
            }
        }

        private void drawBlossomSdf(StrokeEvent s, float cx, float cy, float rx, float ry, float rot,
                                    float r, float g, float b, float alpha, Phase phase) {
            int petals = phase.name.equals("临界") ? 7 : 6;
            float open = phase.name.equals("分离") ? 0.70f : phase.name.equals("吸引") ? 0.86f : phase.name.equals("同步") ? 1.0f : 0.82f;
            float lineW = Math.max(0.18f, Math.min(rx, ry) * 0.014f);
            for (int k = 0; k < petals; k++) {
                float u = k / (float)petals;
                float ang = rot + u * (float)Math.PI * 2f + s.dna.seed * 0.22f;
                float px = cx + (float)Math.cos(ang) * rx * 0.22f * open;
                float py = cy + (float)Math.sin(ang) * ry * 0.22f * open;
                float petalRx = rx * (0.34f + 0.05f * (float)Math.sin(k + s.seed));
                float petalRy = ry * (0.48f + 0.08f * (float)Math.cos(k * 1.7f + s.seed));
                drawEllipseContour(px, py, petalRx, petalRy, ang, lineW, r, g, b, alpha * (0.26f + 0.06f * open), true, 24);
                drawArcContour(px, py, petalRy * 0.82f, petalRy * 0.82f, ang, -0.65f, 1.20f,
                        Math.max(0.16f, lineW * 0.58f), 0.90f, 0.98f, 1f, alpha * 0.06f, false, 14);
            }
            drawPointChain(buildEllipsePath(cx, cy, Math.max(0.8f, Math.min(rx, ry) * 0.16f), Math.max(0.8f, Math.min(rx, ry) * 0.16f), 0f, 16, 0f, (float)Math.PI * 2f),
                    Math.max(0.24f, lineW * 0.90f), 1f, 0.88f, 0.40f, alpha * 0.18f, 2);
        }

        private void drawJellyfishSdf(StrokeEvent s, float cx, float cy, float rx, float ry, float rot,
                                      float r, float g, float b, float alpha, Phase phase) {
            float lineW = Math.max(0.18f, Math.min(rx, ry) * 0.013f);
            drawEllipseContour(cx, cy, rx * 0.92f, ry * 0.58f, rot, lineW, r, g, b, alpha * 0.30f, true, 40);
            drawArcContour(cx, cy, rx * 0.78f, ry * 0.58f, rot, 0.12f, (float)Math.PI * 0.94f,
                    Math.max(0.16f, lineW * 0.66f), 0.88f, 0.98f, 1f, alpha * 0.18f, true, 26);
            drawPointChain(buildEllipsePath(cx, cy + ry * 0.18f, rx * 0.72f, ry * 0.24f, rot, 20, 0f, (float)Math.PI * 2f),
                    Math.max(0.22f, lineW * 0.84f), 0.45f, 0.90f, 1f, alpha * 0.12f, 3);
        }

        private void drawJellyTendrils(StrokeEvent s, float cx, float cy, float tx, float ty, float nx, float ny, float baseWidth,
                                       float r, float g, float b, float alpha, Phase phase) {
            int tendrils = cfg.powerSave ? 4 : 7;
            float minDim = Math.min(width, height);
            for (int i = 0; i < tendrils; i++) {
                float h = strokeHash(s, i, 5451);
                float side = (i - (tendrils - 1) * 0.5f) / Math.max(1f, tendrils - 1f);
                ArrayList<float[]> line = new ArrayList<>(4);
                float rootX = cx + nx * side * baseWidth * (6.0f + h * 3.0f);
                float rootY = cy + ny * side * baseWidth * (6.0f + h * 3.0f);
                for (int k = 0; k < 4; k++) {
                    float u = k / 3f;
                    float wave = (float)Math.sin(u * Math.PI * 1.6f + s.seed + i * 0.7f) * baseWidth * (1.2f + h * 1.6f) * (0.4f + u);
                    line.add(new float[]{rootX - ty * minDim * 0.020f * u + nx * wave, rootY + tx * minDim * 0.020f * u + ny * wave});
                }
                drawTaperedStrip(line, Math.max(0.20f, baseWidth * (0.055f + h * 0.030f)), r, g, b, alpha * (0.052f + h * 0.026f));
            }
        }

        private void drawCrystalSdf(StrokeEvent s, ArrayList<float[]> pts, float rx, float ry, float rot,
                                    float r, float g, float b, float alpha, Phase phase) {
            float[] first = pts.get(0), mid = pts.get(pts.size() / 2), last = pts.get(pts.size() - 1);
            float dx = last[0] - first[0], dy = last[1] - first[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy); if (len < 1f) len = 1f;
            float nx = -dy / len, ny = dx / len;
            ArrayList<float[]> poly = new ArrayList<>(5);
            poly.add(new float[]{first[0], first[1]});
            poly.add(new float[]{mid[0] + nx * ry * 0.92f, mid[1] + ny * ry * 0.92f});
            poly.add(new float[]{last[0], last[1]});
            poly.add(new float[]{mid[0] - nx * ry * 0.54f, mid[1] - ny * ry * 0.54f});
            ArrayList<float[]> loop = buildPolygonLoop(poly, true);
            drawContourPath(loop, Math.max(0.22f, ry * 0.016f), r, g, b, alpha * 0.22f, true);
            for (int k = 0; k < poly.size(); k++) {
                ArrayList<float[]> e = new ArrayList<>(2);
                e.add(poly.get(k)); e.add(poly.get((k + 1) % poly.size()));
                drawTaperedStrip(e, Math.max(0.22f, ry * 0.012f), k == 0 ? 1f : r, k == 0 ? 1f : g, k == 0 ? 1f : b, alpha * (k == 0 ? 0.18f : 0.10f));
                drawPointChain(e, Math.max(0.22f, ry * 0.010f), 1f, 1f, 1f, alpha * 0.08f, 1);
            }
            ArrayList<float[]> facet = new ArrayList<>(2);
            facet.add(new float[]{mid[0] - nx * ry * 0.50f, mid[1] - ny * ry * 0.50f});
            facet.add(new float[]{mid[0] + nx * ry * 0.88f, mid[1] + ny * ry * 0.88f});
            drawTaperedStrip(facet, Math.max(0.20f, ry * 0.010f), 0.80f, 0.94f, 1f, alpha * 0.12f);
        }

        private void drawLiquidMergeSdf(StrokeEvent s, ArrayList<float[]> pts, float rx, float ry, float rot,
                                        float r, float g, float b, float alpha, Phase phase) {
            float[] mid = pts.get(pts.size() / 2);
            float co = (float)Math.cos(rot), si = (float)Math.sin(rot);
            float d = rx * (phase.name.equals("临界") ? 0.22f : 0.42f);
            float lineW = Math.max(0.18f, Math.min(rx, ry) * 0.014f);
            drawEllipseContour(mid[0] - co * d, mid[1] - si * d, rx * 0.64f, ry * 0.78f, rot + 0.18f, lineW, r, g, b, alpha * 0.28f, true, 36);
            drawEllipseContour(mid[0] + co * d, mid[1] + si * d, rx * 0.68f, ry * 0.74f, rot - 0.16f, lineW * 0.92f, 0.64f, 0.92f, 1f, alpha * 0.22f, true, 36);
            ArrayList<float[]> bridge = new ArrayList<>(4);
            bridge.add(new float[]{mid[0] - co * d, mid[1] - si * d});
            bridge.add(new float[]{mid[0] - co * d * 0.25f, mid[1] - si * d * 0.25f});
            bridge.add(new float[]{mid[0] + co * d * 0.25f, mid[1] + si * d * 0.25f});
            bridge.add(new float[]{mid[0] + co * d, mid[1] + si * d});
            drawLinePointContourBundle(s, bridge, ry * 0.22f, Math.max(0.18f, lineW * 0.82f), r, g, b, alpha * 0.16f, 3, true);
            drawArcContour(mid[0], mid[1], rx * 0.78f, ry * 0.68f, rot, s.dna.seed, (float)Math.PI * 1.15f,
                    Math.max(0.16f, lineW * 0.58f), 1f, 1f, 1f, alpha * 0.10f, false, 28);
        }

        private void drawHaloSdf(StrokeEvent s, float cx, float cy, float radius, float rot,
                                 float r, float g, float b, float alpha, Phase phase) {
            float shrink = phase.name.equals("临界") ? 0.84f : 1f;
            float rad = radius * shrink;
            float lineW = Math.max(0.18f, rad * 0.015f);
            drawEllipseContour(cx, cy, rad * 0.78f, rad * 0.78f, 0f, lineW * 0.86f, r, g, b, alpha * 0.18f, true, 56);
            drawArcContour(cx, cy, rad * 0.94f, rad * 0.94f, 0f, rot + s.dna.seed, (float)Math.PI * (1.18f + 0.22f * s.dna.softness),
                    lineW, r, g, b, alpha * 0.22f, true, 42);
            drawArcContour(cx, cy, rad * 0.54f, rad * 0.54f, 0f, rot + s.dna.seed + 2.44f, (float)Math.PI * 0.74f,
                    Math.max(0.16f, lineW * 0.58f), 0.90f, 0.98f, 1f, alpha * 0.13f, false, 28);
        }

        private void drawTwinOrbitSdf(StrokeEvent s, ArrayList<float[]> pts, float rx, float ry, float rot,
                                      float r, float g, float b, float alpha, Phase phase) {
            float[] mid = pts.get(pts.size() / 2);
            float co = (float)Math.cos(rot), si = (float)Math.sin(rot);
            float d = rx * (phase.name.equals("分离") ? 0.58f : phase.name.equals("同步") ? 0.34f : 0.24f);
            float ax = mid[0] - co * d, ay = mid[1] - si * d;
            float bx = mid[0] + co * d, by = mid[1] + si * d;
            float lineW = Math.max(0.18f, Math.min(rx, ry) * 0.014f);
            drawEllipseContour(ax, ay, rx * 0.42f, ry * 0.58f, rot + 0.26f, lineW, r, g, b, alpha * 0.24f, true, 30);
            drawEllipseContour(bx, by, rx * 0.44f, ry * 0.60f, rot - 0.22f, lineW * 0.92f, 0.72f, 0.92f, 1f, alpha * 0.22f, true, 30);
            drawArcContour(mid[0], mid[1], d * 1.20f, d * 1.20f, 0f, rot + s.dna.seed, (float)Math.PI * 1.40f * s.flowC,
                    Math.max(0.16f, lineW * 0.62f), r, g, b, alpha * 0.16f, false, 36);
            if (!phase.name.equals("分离")) {
                ArrayList<float[]> join = new ArrayList<>(3);
                join.add(new float[]{ax, ay}); join.add(new float[]{mid[0], mid[1]}); join.add(new float[]{bx, by});
                drawLinePointContourBundle(s, join, ry * 0.10f, Math.max(0.16f, lineW * 0.82f), r, g, b, alpha * 0.10f, 2, true);
            }
        }

        private void drawGrowthVeins(StrokeEvent s, ArrayList<float[]> pts, float baseWidth, float r, float g, float b, float alpha, int branches) {
            if (pts.size() < 3 || alpha <= 0.003f) return;
            float[] root = pts.get(pts.size() / 2);
            for (int i = 0; i < branches; i++) {
                float h0 = strokeHash(s, i, 5759);
                float h1 = strokeHash(s, i, 5767);
                float ang = s.dna.seed + i * 2.3999632f + (h0 - 0.5f) * 0.62f;
                float len = baseWidth * (4.0f + h1 * 5.8f);
                ArrayList<float[]> branch = new ArrayList<>(3);
                branch.add(new float[]{root[0], root[1]});
                branch.add(new float[]{root[0] + (float)Math.cos(ang) * len * 0.52f, root[1] + (float)Math.sin(ang) * len * 0.52f});
                branch.add(new float[]{root[0] + (float)Math.cos(ang + 0.24f * s.flowC) * len, root[1] + (float)Math.sin(ang + 0.24f * s.flowC) * len});
                drawTaperedStrip(branch, Math.max(0.18f, baseWidth * 0.050f), r, g, b, alpha * (0.045f + h0 * 0.028f));
            }
        }

        private void drawMembraneMicroTexture(StrokeEvent s, float cx, float cy, float rx, float ry, float rot,
                                              float r, float g, float b, float alpha, Phase phase) {
            if (alpha <= 0.002f) return;
            int cells = cfg.powerSave ? 4 : 7;
            float co = (float)Math.cos(rot), si = (float)Math.sin(rot);
            for (int i = 0; i < cells; i++) {
                float h0 = hash01(s.dna.textureSeed + i * 61, 6101);
                float h1 = hash01(s.dna.textureSeed + i * 67, 6107);
                float h2 = hash01(s.dna.textureSeed + i * 71, 6113);
                float rr = (float)Math.sqrt(h0) * 0.72f;
                float ang = h1 * (float)Math.PI * 2f + s.age * 0.018f;
                float lx = (float)Math.cos(ang) * rx * rr;
                float ly = (float)Math.sin(ang) * ry * rr;
                float x = cx + co * lx - si * ly;
                float y = cy + si * lx + co * ly;
                float rad = Math.max(0.45f, Math.min(rx, ry) * (0.055f + h2 * 0.070f));
                drawRing(x, y, rad, Math.max(0.22f, rad * 0.08f), r, g, b, alpha * (0.032f + h2 * 0.018f), 18);
                drawArcStrip(x, y, rad * 1.25f, Math.max(0.18f, rad * 0.052f), ang + 1.1f, (float)Math.PI * (0.45f + h1 * 0.42f), 0.80f, 0.98f, 1f, alpha * 0.036f, 12);
            }
        }

        private void drawArtMotifAccent(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                        float r, float g, float b, float alpha, float intensity,
                                        float tension, float release, boolean headLayer) {
            if (pts.size() < 3 || alpha <= 0.004f) return;
            float[] first = pts.get(0);
            float[] last = pts.get(pts.size() - 1);
            float dx = last[0] - first[0];
            float dy = last[1] - first[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) return;
            float tx = dx / len;
            float ty = dy / len;
            float nx = -ty;
            float ny = tx;
            float whiteBandMax = nonReleaseWhiteBandMaxPx(phase);
            float wideScale = nonReleaseWideAlphaScale(phase);
            float hiScale = nonReleaseHighlightAlphaScale(phase);

            if (s.motif == 12) {
                // Liquid pod: large soft oval body with inner glow and a few broad rings.
                float[] mid = pts.get(pts.size() / 2);
                float rot = (float)Math.atan2(dy, dx);
                float rx = baseWidth * (8.0f + tension * 3.5f + s.motifStrength * 2.2f);
                float ry = baseWidth * (4.5f + release * 2.4f + s.motifStrength * 1.6f);
                drawEllipse(mid[0], mid[1], rx, ry, rot, r, g, b, alpha * wideScale * (0.070f + intensity * 0.040f + release * 0.040f), 36);
                drawEllipse(mid[0] + nx * rx * 0.10f, mid[1] + ny * rx * 0.10f, rx * 0.38f, ry * 0.36f, rot + 0.22f * s.flowC, 0.74f, 0.90f, 1f, alpha * wideScale * 0.020f, 28);
                drawRing(mid[0], mid[1], Math.max(1f, rx * 0.86f), Math.min(Math.max(0.55f, baseWidth * 0.12f), whiteBandMax * 0.38f), r, g, b, alpha * hiScale * 0.065f, 48);
                return;
            } else if (s.motif == 13) {
                // Luminous wing: two translucent lobes, no mesh ribs.
                drawAsymmetricRibbon(pts, capNonReleaseBand(phase, baseWidth * (5.2f + tension * 1.4f)), capNonReleaseBand(phase, baseWidth * (2.1f + tension * 0.7f)), r, g, b, alpha * wideScale * (0.032f + intensity * 0.018f), 0.74f);
                drawAsymmetricRibbon(pts, capNonReleaseBand(phase, baseWidth * (2.0f + tension * 0.7f)), capNonReleaseBand(phase, baseWidth * (4.8f + tension * 1.2f)), r, g, b, alpha * wideScale * (0.026f + intensity * 0.014f), 0.88f);
                drawTaperedStrip(pts, Math.min(Math.max(0.30f, baseWidth * 0.10f), whiteBandMax * 0.42f), 0.86f, 0.96f, 1f, alpha * hiScale * 0.18f);
                return;
            } else if (s.motif == 14) {
                // Blossom crown: visible petals as soft ellipses gathered around a curved center.
                float[] mid = pts.get(pts.size() / 2);
                float rot = (float)Math.atan2(dy, dx);
                int petals = headLayer ? 5 : 3;
                for (int k = 0; k < petals; k++) {
                    float a = rot + (k - (petals - 1) * 0.5f) * 0.58f;
                    float px = mid[0] + (float)Math.cos(a) * baseWidth * (2.6f + k * 0.18f);
                    float py = mid[1] + (float)Math.sin(a) * baseWidth * (2.6f + k * 0.18f);
                    drawEllipse(px, py, baseWidth * (4.7f + tension * 1.9f), baseWidth * (1.75f + intensity), a, r, g, b,
                            alpha * wideScale * (0.045f + intensity * 0.030f) * (1f - k * 0.055f), 28);
                }
                drawCircle(mid[0], mid[1], Math.min(baseWidth * (1.4f + release * 1.3f), whiteBandMax * 0.45f), 1f, 1f, 1f, alpha * hiScale * 0.070f, 24);
                return;
            } else if (s.motif == 15) {
                // Silk banner: one continuous translucent cloth-like sheet plus a narrow gleaming fold.
                drawAsymmetricRibbon(pts, capNonReleaseBand(phase, baseWidth * (4.6f + tension * 1.1f)), capNonReleaseBand(phase, baseWidth * (3.8f + release * 0.9f)), r, g, b, alpha * wideScale * (0.022f + intensity * 0.012f + release * 0.012f), 0.66f);
                drawAsymmetricRibbon(pts, Math.min(baseWidth * (1.8f + tension * 0.6f), whiteBandMax), Math.min(baseWidth * (1.2f + tension * 0.5f), whiteBandMax * 0.75f), 0.90f, 0.96f, 1f, alpha * hiScale * 0.010f, 1.0f);
                return;
            } else if (s.motif == 16) {
                // Orbit halo: crescent arcs and one full diffuse ring.
                float[] mid = pts.get(pts.size() / 2);
                float radius = Math.max(baseWidth * 5.0f, Math.min(width, height) * (0.045f + 0.030f * s.motifStrength));
                float start = (float)Math.atan2(first[1] - mid[1], first[0] - mid[0]) + s.seed * 0.23f;
                drawArcStrip(mid[0], mid[1], radius, Math.min(Math.max(0.75f, baseWidth * 0.62f), whiteBandMax), start, (float)Math.PI * (1.15f + 0.55f * s.motifStrength) * s.flowC, r, g, b, alpha * hiScale * (0.15f + intensity * 0.06f), 44);
                drawRing(mid[0], mid[1], radius * 0.66f, Math.min(Math.max(0.48f, baseWidth * 0.10f), whiteBandMax * 0.38f), r, g, b, alpha * hiScale * 0.045f, 48);
                drawCircle(mid[0], mid[1], Math.min(baseWidth * (1.2f + release), whiteBandMax * 0.42f), 1f, 1f, 1f, alpha * hiScale * 0.055f, 18);
                return;
            } else if (s.motif == 17) {
                // Crystal shard: faceted polygon plate with a white edge, replacing net-like crosshatching.
                float[] mid = pts.get(pts.size() / 2);
                ArrayList<float[]> poly = new ArrayList<>(5);
                poly.add(new float[]{first[0], first[1]});
                poly.add(new float[]{mid[0] + nx * baseWidth * (5.2f + tension * 1.7f), mid[1] + ny * baseWidth * (5.2f + tension * 1.7f)});
                poly.add(new float[]{last[0], last[1]});
                poly.add(new float[]{mid[0] - nx * baseWidth * (2.4f + release * 1.4f), mid[1] - ny * baseWidth * (2.4f + release * 1.4f)});
                drawFilledPolygon(poly, r, g, b, alpha * (0.060f + release * 0.030f));
                ArrayList<float[]> edgeA = new ArrayList<>(2);
                edgeA.add(poly.get(0)); edgeA.add(poly.get(1));
                drawTaperedStrip(edgeA, Math.max(0.32f, baseWidth * 0.09f), 0.86f, 0.96f, 1f, alpha * 0.18f);
                ArrayList<float[]> edgeB = new ArrayList<>(2);
                edgeB.add(poly.get(1)); edgeB.add(poly.get(2));
                drawTaperedStrip(edgeB, Math.max(0.34f, baseWidth * 0.10f), r, g, b, alpha * 0.20f);
                return;
            }

            if (s.motif == 3 || phase.name.equals("释放")) {
                // Silver blade: a pale triangular face plus a very thin white cutting edge.
                float[] mid = pts.get(pts.size() / 2);
                ArrayList<float[]> blade = new ArrayList<>(3);
                blade.add(new float[]{first[0], first[1]});
                blade.add(new float[]{mid[0] + nx * baseWidth * (2.4f + tension * 1.8f), mid[1] + ny * baseWidth * (2.4f + tension * 1.8f)});
                blade.add(new float[]{last[0], last[1]});
                drawTaperedStrip(blade, Math.min(baseWidth * (1.6f + release * 0.9f), whiteBandMax), 0.90f, 0.96f, 1f,
                        alpha * hiScale * (0.012f + release * 0.020f));
                ArrayList<float[]> edge = new ArrayList<>(2);
                edge.add(new float[]{first[0], first[1]});
                edge.add(new float[]{last[0], last[1]});
                drawTaperedStrip(edge, Math.min(Math.max(0.28f, baseWidth * 0.08f), whiteBandMax * 0.35f), 0.92f, 0.98f, 1f,
                        alpha * hiScale * (0.22f + intensity * 0.12f));
            } else if (s.motif == 4 || s.motif == 6) {
                // Petal / vine: soft side curls so the body looks like a living leaf or flower edge.
                float side = strokeHash(s, 3, 930) < 0.5f ? -1f : 1f;
                int layers = headLayer ? 3 : 1;
                for (int layer = 0; layer < layers; layer++) {
                    ArrayList<float[]> petal = new ArrayList<>(pts.size());
                    for (int i = 0; i < pts.size(); i++) {
                        float u = i / Math.max(1f, pts.size() - 1f);
                        float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                        float curl = (float)Math.sin(u * Math.PI * 1.5f + layer * 0.52f + s.seed) * baseWidth * (0.9f + tension);
                        float off = side * baseWidth * (1.9f + layer * 0.86f) * feather;
                        float[] p = pts.get(i);
                        petal.add(new float[]{p[0] + nx * off + tx * curl * feather, p[1] + ny * off + ty * curl * feather});
                    }
                    float a = alpha * (0.022f + intensity * 0.042f + release * 0.028f) * (1f - layer * 0.18f);
                    drawTaperedStrip(petal, baseWidth * (0.24f + layer * 0.12f), r, g, b, a);
                }
            } else if (s.motif == 5) {
                // Prism polygon: a few offset echoes make the frame read as a tilted transparent sheet.
                for (int k = -2; k <= 2; k++) {
                    if (k == 0) continue;
                    float off = baseWidth * k * 1.15f;
                    ArrayList<float[]> copy = new ArrayList<>(pts.size());
                    for (int i = 0; i < pts.size(); i++) {
                        float[] p = pts.get(i);
                        copy.add(new float[]{p[0] + nx * off, p[1] + ny * off});
                    }
                    drawTaperedStrip(copy, Math.max(0.22f, baseWidth * 0.055f), r, g, b,
                            alpha * (0.016f + intensity * 0.028f));
                }
            } else if (s.motif == 7) {
                // Long bridge: a strong central bow plus faint parallel ghost line, like the magenta arc in the video.
                ArrayList<float[]> ghost = new ArrayList<>(pts.size());
                float side = strokeHash(s, 4, 941) < 0.5f ? -1f : 1f;
                for (int i = 0; i < pts.size(); i++) {
                    float u = i / Math.max(1f, pts.size() - 1f);
                    float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                    float[] p = pts.get(i);
                    ghost.add(new float[]{p[0] + nx * side * baseWidth * 3.1f * feather, p[1] + ny * side * baseWidth * 3.1f * feather});
                }
                drawTaperedStrip(ghost, Math.max(0.25f, baseWidth * 0.18f), r, g, b,
                        alpha * (0.018f + intensity * 0.022f));
            } else if (s.motif == 8) {
                // Jellyfish tendril: short hanging side filaments near the head, very dim and organic.
                int hairs = headLayer ? 5 : 2;
                for (int h = 0; h < hairs; h++) {
                    float u = 0.45f + strokeHash(s, h, 960) * 0.48f;
                    int idx = clampInt((int)(u * (pts.size() - 1)), 1, pts.size() - 2);
                    float[] p = pts.get(idx);
                    float side2 = strokeHash(s, h, 961) < 0.5f ? -1f : 1f;
                    ArrayList<float[]> hair = new ArrayList<>(3);
                    hair.add(new float[]{p[0], p[1]});
                    hair.add(new float[]{p[0] + nx * side2 * baseWidth * (2.0f + h), p[1] + ny * side2 * baseWidth * (2.0f + h)});
                    hair.add(new float[]{p[0] + nx * side2 * baseWidth * (2.7f + h) + tx * baseWidth * (1.2f + h * 0.2f), p[1] + ny * side2 * baseWidth * (2.7f + h) + ty * baseWidth * (1.2f + h * 0.2f)});
                    drawTaperedStrip(hair, Math.max(0.18f, baseWidth * 0.050f), r, g, b, alpha * (0.018f + intensity * 0.018f));
                }
            } else if (s.motif == 9) {
                // Nebula coil: offset echoes make the stroke read as a luminous smoke curl, not a simple arc.
                for (int k = 1; k <= 3; k++) {
                    ArrayList<float[]> echo = new ArrayList<>(pts.size());
                    float sign = k % 2 == 0 ? -1f : 1f;
                    for (int i = 0; i < pts.size(); i++) {
                        float u = i / Math.max(1f, pts.size() - 1f);
                        float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                        float swirl = (float)Math.sin(u * Math.PI * (1.0f + k * 0.35f) + s.seed) * baseWidth * (1.4f + k * 0.55f) * feather;
                        float[] p = pts.get(i);
                        echo.add(new float[]{p[0] + nx * sign * swirl, p[1] + ny * sign * swirl});
                    }
                    drawTaperedStrip(echo, Math.max(0.20f, baseWidth * (0.070f - k * 0.010f)), r, g, b,
                            alpha * (0.018f + intensity * 0.020f) * (1f - k * 0.18f));
                }
            } else if (s.motif == 10) {
                // Origami sheet: two fold lines and a faint translucent face.
                ArrayList<float[]> foldA = new ArrayList<>(pts.size());
                ArrayList<float[]> foldB = new ArrayList<>(pts.size());
                for (int i = 0; i < pts.size(); i++) {
                    float u = i / Math.max(1f, pts.size() - 1f);
                    float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                    float[] p = pts.get(i);
                    foldA.add(new float[]{p[0] + nx * baseWidth * 2.0f * feather, p[1] + ny * baseWidth * 2.0f * feather});
                    foldB.add(new float[]{p[0] - nx * baseWidth * 1.6f * feather, p[1] - ny * baseWidth * 1.6f * feather});
                }
                drawTaperedStrip(foldA, Math.max(0.22f, baseWidth * 0.060f), 1f, 1f, 1f, alpha * (0.090f + release * 0.045f));
                drawTaperedStrip(foldB, Math.max(0.20f, baseWidth * 0.045f), r, g, b, alpha * (0.030f + intensity * 0.020f));
            } else if (s.motif == 11) {
                // Constellation chain: sparse nodes welded into the moving line, avoiding random dust clutter.
                int nodes = Math.min(6, Math.max(3, pts.size() / 8));
                for (int k = 1; k <= nodes; k++) {
                    int idx = clampInt((int)(k / (float)(nodes + 1) * (pts.size() - 1)), 1, pts.size() - 2);
                    float[] p = pts.get(idx);
                    drawCircle(p[0], p[1], baseWidth * (0.42f + strokeHash(s, k, 980) * 0.44f), r, g, b,
                            alpha * (0.075f + intensity * 0.040f), 12);
                }
            } else if ((s.motif == 2 || s.motif == 10) && headLayer) {
                // Fan/sheet hinge glow, a dim focal phosphor dot that makes the structure appear intentional rather than random.
                float[] pivot = strokeHash(s, 5, 950) < 0.5f ? first : last;
                drawCircle(pivot[0], pivot[1], capNonReleaseBand(phase, baseWidth * (10.0f + tension * 7.0f)), r, g, b,
                        alpha * wideScale * 0.030f, 24);
            }
        }

        private void drawFiberVeil(StrokeEvent s, ArrayList<float[]> pts, float baseWidth,
                                   float r, float g, float b, float alpha, float intensity,
                                   float tension, float release, boolean headLayer) {
            if (pts.size() < 4 || alpha <= 0.004f) return;
            float[] first = pts.get(0);
            float[] last = pts.get(pts.size() - 1);
            float dx = last[0] - first[0];
            float dy = last[1] - first[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) return;
            float nx = -dy / len;
            float ny = dx / len;

            int strands = 5 + (int)(cfg.randomness * 5f + intensity * 4f);
            if (s.actor == 1) strands = Math.max(3, strands - 2);
            if (s.actor == 2) strands += 2;
            if (!headLayer) strands = Math.max(3, strands / 2);
            float spread = baseWidth * (1.2f + tension * 1.9f + release * 1.7f) * (s.actor == 2 ? 1.20f : 0.92f);
            for (int j = 0; j < strands; j++) {
                float h = strokeHash(s, j, 701);
                float h2 = strokeHash(s, j, 709);
                float side = (j - (strands - 1) * 0.5f) / Math.max(1f, (strands - 1f));
                float off = side * spread * (0.55f + h * 0.90f);
                float along = (h2 - 0.5f) * baseWidth * (1.0f + tension);
                ArrayList<float[]> strand = new ArrayList<>(pts.size());
                for (int i = 0; i < pts.size(); i++) {
                    float u = i / Math.max(1f, pts.size() - 1f);
                    float feather = (float)Math.sin(Math.PI * clamp(u, 0f, 1f));
                    float wave = (float)Math.sin(u * Math.PI * 2.0f + s.seed + j * 0.77f) * baseWidth * 0.28f * feather;
                    float[] p = pts.get(i);
                    strand.add(new float[]{p[0] + nx * (off + wave) + dx / len * along * feather,
                                           p[1] + ny * (off + wave) + dy / len * along * feather});
                }
                float strandWidth = Math.max(0.24f, baseWidth * (0.030f + strokeHash(s, j, 719) * 0.070f));
                float strandAlpha = alpha * (0.025f + intensity * 0.035f + release * 0.035f) * (0.45f + h * 0.80f);
                drawTaperedStrip(strand, strandWidth, r, g, b, strandAlpha);
            }
        }

        private ArrayList<float[]> offsetPoints(ArrayList<float[]> src, float dx, float dy) {
            ArrayList<float[]> out = new ArrayList<>(src.size());
            for (int i = 0; i < src.size(); i++) {
                float[] p = src.get(i);
                out.add(new float[]{p[0] + dx, p[1] + dy});
            }
            return out;
        }


        private void drawActorHeadCluster(StrokeEvent s, ArrayList<float[]> pts, float baseWidth,
                                          float r, float g, float b, float alpha,
                                          float intensity, float tension, float release) {
            if (pts.size() < 3 || alpha <= 0.004f) return;
            float[] head = pts.get(pts.size() - 1);
            float[] prev = pts.get(Math.max(0, pts.size() - 4));
            float dx = head[0] - prev[0];
            float dy = head[1] - prev[1];
            float len = (float)Math.sqrt(dx * dx + dy * dy);
            if (len < 0.001f) len = 1f;
            float tx = dx / len;
            float ty = dy / len;
            float nx = -ty;
            float ny = tx;
            int dots = s.actor == 2 ? 5 : 3;
            float cluster = baseWidth * (s.actor == 2 ? 2.6f : 1.7f) * (0.80f + tension * 0.40f + release * 0.50f);
            for (int i = 0; i < dots; i++) {
                float h1 = strokeHash(s, i, 901);
                float h2 = strokeHash(s, i, 907);
                float along = (-0.18f + h1 * 0.36f) * cluster;
                float side = (h2 - 0.5f) * 2f * cluster * (s.actor == 2 ? 0.95f : 0.45f);
                float x = head[0] + tx * along + nx * side;
                float y = head[1] + ty * along + ny * side;
                float rr = Math.max(0.40f, baseWidth * (s.actor == 2 ? 0.20f : 0.13f) * (0.55f + h1));
                drawCircle(x, y, rr, r, g, b, alpha * (s.actor == 2 ? 0.050f : 0.034f) * (0.7f + intensity), 10);
            }
            if (s.actor == 2) {
                for (int k = -1; k <= 1; k += 2) {
                    ArrayList<float[]> ray = new ArrayList<>(2);
                    float side = k * cluster * 0.72f;
                    ray.add(new float[]{head[0] - tx * cluster * 0.20f, head[1] - ty * cluster * 0.20f});
                    ray.add(new float[]{head[0] + tx * cluster * 0.55f + nx * side, head[1] + ty * cluster * 0.55f + ny * side});
                    drawTaperedStrip(ray, Math.max(0.24f, baseWidth * 0.045f), r, g, b, alpha * 0.035f);
                }
            }
        }

        private void drawPointLineSpray(StrokeEvent s, ArrayList<float[]> pts, Phase phase, float baseWidth,
                                        float r, float g, float b, float alpha, float intensity, float tension, float release) {
            if (pts.size() < 3 || alpha <= 0.004f) return;
            int n = pts.size();
            float minDim = Math.min(width, height);
            float lifeProgress = clamp(s.age / Math.max(0.001f, s.life), 0f, 1f);
            float headBias = lifeProgress < 0.55f ? smooth(lifeProgress / 0.55f) : 1f;
            float grainBase = phase.name.equals("分离") ? 3f : phase.name.equals("吸引") ? 5f : phase.name.equals("同步") ? 6f : phase.name.equals("临界") ? 8f : 5f;
            if (s.actor == 1) grainBase *= 0.58f;
            if (s.actor == 2) grainBase *= 0.82f;
            int grains = (int)(grainBase + cfg.randomness * (s.actor == 2 ? 4f : 3f) + release * 4f);
            float spray = baseWidth * (1.35f + tension * 1.55f) * (s.actor == 2 ? 1.18f : 0.88f) + minDim * (0.0010f + cfg.randomness * 0.0035f);

            for (int i = 0; i < grains; i++) {
                float h1 = strokeHash(s, i, 11);
                float h2 = strokeHash(s, i, 17);
                float h3 = strokeHash(s, i, 23);
                // 大部分颗粒落在当前光迹前部，少部分散落在尾部，形成“喷洒”而非等宽线条。
                float u = h1 < 0.68f ? lerp(0.58f, 1.0f, h2) : h2;
                u = clamp(lerp(u, headBias, 0.18f * intensity), 0f, 1f);
                int idx = clampInt((int)(u * (n - 1)), 1, n - 2);
                float[] p = pts.get(idx);
                float[] prev = pts.get(idx - 1);
                float[] next = pts.get(idx + 1);
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float tx = dx / len;
                float ty = dy / len;
                float nx = -ty;
                float ny = tx;
                float side = (h2 - 0.5f) * 2f;
                float along = (strokeHash(s, i, 31) - 0.5f) * spray * 0.72f;
                float normal = side * spray * (0.35f + strokeHash(s, i, 37) * 1.25f);
                // 临界/释放更像飞溅；分离更淡、更远。
                float phaseBoost = phase.name.equals("临界") ? 1.30f : phase.name.equals("释放") ? 1.55f : phase.name.equals("分离") ? 0.72f : 1.0f;
                float x = p[0] + tx * along + nx * normal * phaseBoost;
                float y = p[1] + ty * along + ny * normal * phaseBoost;
                float radius = Math.max(0.32f, baseWidth * (0.018f + strokeHash(s, i, 41) * 0.070f) + minDim * 0.00028f);
                float dotAlpha = alpha * (0.014f + 0.060f * intensity + release * 0.055f) * (0.35f + h3 * 0.60f);
                if (phase.name.equals("分离")) dotAlpha *= 0.55f;
                if (s.actor == 1) dotAlpha *= 0.78f;
                if (s.actor == 2) dotAlpha *= 1.18f;
                drawCircle(x, y, radius, r, g, b, dotAlpha, 10);

                // 少量短促微线，形成“点线组成”的笔触纹理，而不是一根孤立线。
                if (strokeHash(s, i, 53) < 0.46f + intensity * 0.20f) {
                    float seg = radius * (5.0f + strokeHash(s, i, 59) * 9.0f);
                    ArrayList<float[]> mini = new ArrayList<>(2);
                    mini.add(new float[]{x - tx * seg * 0.45f, y - ty * seg * 0.45f});
                    mini.add(new float[]{x + tx * seg * 0.55f, y + ty * seg * 0.55f});
                    drawTaperedStrip(mini, Math.max(0.22f, radius * 0.50f), r, g, b, dotAlpha * 0.38f);
                }
            }
        }

        private float strokeHash(StrokeEvent s, int i, int salt) {
            double v = Math.sin(s.seed * 12.9898 + s.variant * 0.013579 + i * 78.233 + salt * 37.719) * 43758.5453;
            return (float)(v - Math.floor(v));
        }

        private ArrayList<float[]> sampleStroke(StrokeEvent s) {
            ArrayList<float[]> pts = new ArrayList<>();
            if (s.count == 2) {
                for (int i = 0; i <= 18; i++) {
                    float t = i / 18f;
                    pts.add(new float[]{lerp(s.x[0], s.x[1], t), lerp(s.y[0], s.y[1], t)});
                }
                return pts;
            }
            int samplesPerSegment = 12 + Math.max(0, Math.round(6f * clamp(s.motionSmoothness, 0f, 1f)));
            for (int i = 0; i < s.count - 1; i++) {
                float x0 = s.x[Math.max(0, i - 1)], y0 = s.y[Math.max(0, i - 1)];
                float x1 = s.x[i], y1 = s.y[i];
                float x2 = s.x[i + 1], y2 = s.y[i + 1];
                float x3 = s.x[Math.min(s.count - 1, i + 2)], y3 = s.y[Math.min(s.count - 1, i + 2)];
                for (int k = 0; k < samplesPerSegment; k++) {
                    float t = k / (float)samplesPerSegment;
                    pts.add(new float[]{catmull(x0, x1, x2, x3, t), catmull(y0, y1, y2, y3, t)});
                }
            }
            pts.add(new float[]{s.x[s.count - 1], s.y[s.count - 1]});
            return pts;
        }

        private ArrayList<float[]> visibleSegment(ArrayList<float[]> all, StrokeEvent s) {
            return visibleSegmentAt(all, s, clamp(s.age / Math.max(0.001f, s.life), 0f, 1f));
        }

        private ArrayList<float[]> visibleSegmentAt(ArrayList<float[]> all, StrokeEvent s, float progress) {
            ArrayList<float[]> out = new ArrayList<>();
            if (all.size() < 2) return out;

            // V17：移动窗口。head 继续向前“写出”，tail 同步跟进；
            // 不再把整条线画出来再整体淡死。
            float eased = smooth(clamp(progress, 0f, 1f));
            float window = clamp(s.visibleWindow, 0.22f, 0.62f);
            float head = lerp(-s.headLead, 1.0f + window + s.headLead, eased);
            float tail = head - window;
            if (tail >= 1.0f || head <= 0.0f) return out;
            float startF = clamp(tail, 0f, 1f);
            float endF = clamp(head, 0f, 1f);
            int start = clampInt((int)(startF * (all.size() - 1)), 0, all.size() - 2);
            int end = clampInt((int)(endF * (all.size() - 1)), start + 1, all.size() - 1);
            for (int i = start; i <= end; i++) out.add(all.get(i));
            // V18：过滤过短可见片段。Mystify/Ribbons 的观感不是“短点线残片”，
            // 而是一笔有势能、有长度、有消失背影的光迹。
            // 开头和结尾如果窗口太短，直接不画，让旧 FBO 残影自然承担退场。
            float minLen = Math.min(width, height) * 0.18f;
            if (polylineLength(out) < minLen) out.clear();
            return out;
        }

        private float polylineLength(ArrayList<float[]> pts) {
            float len = 0f;
            for (int i = 1; i < pts.size(); i++) {
                float[] a = pts.get(i - 1);
                float[] b = pts.get(i);
                float dx = b[0] - a[0];
                float dy = b[1] - a[1];
                len += (float)Math.sqrt(dx * dx + dy * dy);
            }
            return len;
        }

        private void drawTaperedStrip(ArrayList<float[]> pts, float widthPx, float r, float g, float b, float a) {
            if (pts.size() < 2 || a <= 0.001f || widthPx <= 0.05f) return;
            int n = pts.size();
            float[] verts = new float[n * 2 * 2];
            int vi = 0;
            for (int i = 0; i < n; i++) {
                float u = i / Math.max(1f, (n - 1f));
                float profile = (float)Math.pow(Math.max(0.0, Math.sin(Math.PI * u)), 1.22);
                float half = widthPx * 0.5f * (0.004f + 0.996f * profile);
                float[] prev = pts.get(Math.max(0, i - 1));
                float[] next = pts.get(Math.min(n - 1, i + 1));
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float x = pts.get(i)[0];
                float y = pts.get(i)[1];
                putNdc(verts, vi, x + nx * half, y + ny * half); vi += 2;
                putNdc(verts, vi, x - nx * half, y - ny * half); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void drawStrip(ArrayList<float[]> pts, float widthPx, float r, float g, float b, float a) {
            if (pts.size() < 2 || a <= 0.001f || widthPx <= 0.05f) return;
            int n = pts.size();
            float[] verts = new float[n * 2 * 2];
            int vi = 0;
            float half = widthPx * 0.5f;
            for (int i = 0; i < n; i++) {
                float[] prev = pts.get(Math.max(0, i - 1));
                float[] next = pts.get(Math.min(n - 1, i + 1));
                float dx = next[0] - prev[0];
                float dy = next[1] - prev[1];
                float len = (float)Math.sqrt(dx * dx + dy * dy);
                if (len < 0.001f) len = 1f;
                float nx = -dy / len;
                float ny = dx / len;
                float x = pts.get(i)[0];
                float y = pts.get(i)[1];
                putNdc(verts, vi, x + nx * half, y + ny * half); vi += 2;
                putNdc(verts, vi, x - nx * half, y - ny * half); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }


        private void drawAfterglowReturnBridge(float sec, float after, Phase phase) {
            if (!phase.name.equals("余韵") || after <= 0.001f) return;
            float minDim = Math.min(width, height);
            float cx = pulseX * width;
            float cy = pulseY * height;
            float appear = 1f - smooth(clamp((after - 0.54f) / 0.28f, 0f, 1f));
            if (appear <= 0.002f) return;
            // V45：释放不是硬切到气泡，而是有一个“热光退潮 -> 冷蓝回落”的过渡桥。
            // 用金橙细环、冷蓝水纹和少量余烬光滴，把高潮后的能量转成余韵气泡。
            float heat = (1f - smooth(clamp(after / 0.36f, 0f, 1f))) * appear;
            float cool = smooth(clamp(after / 0.42f, 0f, 1f)) * appear;
            for (int i = 0; i < 5; i++) {
                float u = i / 4f;
                float r = minDim * (0.12f + u * 0.28f + after * 0.18f);
                float w = minDim * (0.0035f + 0.0020f * (1f - u));
                float spin = sec * (0.10f + i * 0.017f) + releaseSeed * 0.00013f + i * 0.91f;
                drawArcStrip(cx, cy, r, w * 2.4f, spin, (float)Math.PI * (0.74f + 0.22f * u), 1.00f, 0.48f, 0.06f, 0.055f * heat * (1f - u * 0.12f), 26);
                drawArcStrip(cx, cy, r * (1.02f + u * 0.018f), w, spin + 1.72f, (float)Math.PI * (0.58f + 0.18f * u), 0.36f, 0.88f, 1.00f, 0.060f * cool * (1f - u * 0.10f), 24);
            }
            for (int i = 0; i < 42; i++) {
                int key = releaseSeed + i * 977 + 13007;
                float h0 = hash01(key, 11);
                float h1 = hash01(key, 13);
                float h2 = hash01(key, 17);
                float born = h0 * 0.22f;
                float u = clamp((after - born) / (0.72f + h1 * 0.30f), 0f, 1f);
                float live = smooth(clamp(u / 0.12f, 0f, 1f)) * (1f - smooth(clamp((u - 0.76f) / 0.24f, 0f, 1f))) * appear;
                if (live <= 0.002f) continue;
                float ang = h2 * (float)Math.PI * 2f + sec * 0.05f;
                float dist = minDim * (0.05f + 0.58f * (float)Math.pow(u, 0.62f));
                float x = cx + (float)Math.cos(ang) * dist + (h0 - 0.5f) * minDim * 0.06f * u;
                float y = cy + (float)Math.sin(ang) * dist - minDim * (0.045f + h1 * 0.10f) * u;
                float sz = minDim * (0.0025f + h1 * 0.0055f) * (1f - 0.35f * u);
                drawEllipse(x, y, sz * (1.7f + h2), Math.max(0.5f, sz * 0.32f), ang, 1.0f, 0.74f, 0.22f, live * heat * 0.20f, 10);
                drawCircle(x, y, sz * 0.40f, 0.55f, 0.92f, 1.00f, live * cool * 0.16f, 10);
            }
        }

        private void drawAfterglowBubbleAquarium(float sec, float after, Phase phase) {
            if (!cfg.bubbles || !phase.name.equals("余韵") || after <= 0.006f) return;
            float appear = smooth(Math.min(1f, after / 0.070f));
            float fadeOut = 1f - smooth(Math.max(0f, (after - 0.90f) / 0.10f));
            float aBase = clamp(appear * fadeOut, 0f, 1f);
            if (aBase <= 0.002f) return;
            float minDim = Math.max(1f, Math.min(width, height));
            float cx = pulseX * width;
            float cy = pulseY * height;

            // V36：余韵气泡逐帧清绘；这里给一层干净、稳定的深蓝玻璃水域，
            // 不依靠历史残影叠亮，因此透明泡移动时不会拖成长筒。
            drawSolidRect(0.004f, 0.030f, 0.105f, aBase * 0.155f);
            drawSolidRect(0.000f, 0.110f, 0.220f, aBase * 0.055f);

            // 左下到右上的青绿水光：较亮但很细，模拟参考视频里的斜向光束，不再形成大面积白色斜面。
            for (int k = 0; k < 5; k++) {
                float off = minDim * (-0.16f + k * 0.055f + 0.024f * (float)Math.sin(sec * 0.045f + k * 1.9f));
                float y0 = height * (1.02f + 0.010f * k) + off;
                float y1 = height * (0.36f + 0.036f * k) + off * 0.14f;
                ArrayList<float[]> beam = new ArrayList<>(4);
                beam.add(new float[]{-width * 0.22f, y0});
                beam.add(new float[]{width * 0.18f, lerp(y0, y1, 0.33f)});
                beam.add(new float[]{width * 0.64f, lerp(y0, y1, 0.72f)});
                beam.add(new float[]{width * 1.14f, y1});
                drawTaperedStrip(beam, minDim * (0.014f + k * 0.0022f), 0.07f, 0.74f, 1.00f, aBase * (0.010f - k * 0.0009f));
                drawTaperedStrip(beam, Math.max(0.55f, minDim * (0.0017f + k * 0.00045f)), 0.72f, 1.00f, 0.90f, aBase * (0.040f - k * 0.0040f));
            }

            // 透明肥皂泡爆散：每轮释放使用 afterglowSeed，确保每次出现的数量、方向、大小、薄膜色都不同。
            int count = cfg.powerSave ? 18 : 30;
            for (int i = 0; i < count; i++) {
                int key = afterglowSeed + i * 131;
                float h0 = hash01(key, 3301);
                float h1 = hash01(key, 3303);
                float h2 = hash01(key, 3307);
                float h3 = hash01(key, 3313);
                float h4 = hash01(key, 3319);
                float born = h0 * 0.11f;
                float life = 0.92f + h1 * 0.46f;
                float u = clamp((after - born) / Math.max(0.001f, life), 0f, 1f);
                float live = smooth(Math.min(1f, u / 0.060f)) * (1f - smooth(Math.max(0f, (u - 0.86f) / 0.14f)));
                if (live <= 0.002f) continue;

                float burst = smooth(Math.min(1f, u / 0.18f));
                float[] pDisk = poissonBubblePoint(i, count, cx, cy, minDim, key);
                float ang = (float)(h2 * Math.PI * 2.0 + 0.16f * Math.sin(sec * 0.10f + i * 0.7f));
                float drift = minDim * (0.040f + h1 * 0.120f) * u;
                float swirl = minDim * (0.010f + h0 * 0.030f) * (float)Math.sin(u * Math.PI * 1.9f + i * 1.3f);
                float nx = (float)Math.cos(ang);
                float ny = (float)Math.sin(ang);
                float tx = -ny;
                float ty = nx;
                // V46：余韵气泡采用 Poisson / golden-angle 出生骨架，避免随机局部扎堆；
                // 再叠加水流漂移和上浮，保留生命感而不形成固定小点串。
                float bx = lerp(cx, pDisk[0], burst) + nx * drift + tx * swirl;
                float by = lerp(cy, pDisk[1], burst) + ny * drift + ty * swirl;
                bx += minDim * (0.018f + h4 * 0.080f) * u;
                by -= minDim * (0.060f + h1 * 0.150f) * u;

                float radius = minDim * (0.024f + h4 * 0.050f) * (0.90f + 0.18f * (float)Math.sin(Math.PI * u));
                if (i % 9 == 0) radius *= 1.18f;
                radius = Math.min(radius, minDim * 0.088f);
                drawIridescentBubble(bx, by, radius, key, aBase * live, sec);
            }
        }

        private float[] poissonBubblePoint(int i, int count, float cx, float cy, float minDim, int key) {
            float golden = 2.399963229728653f;
            float t = (i + 0.5f) / Math.max(1f, count);
            float radial = (float)Math.sqrt(t);
            float ang = i * golden + hash01(key, 5003) * 0.52f;
            float jitterR = (hash01(key, 5009) - 0.5f) * minDim * 0.030f;
            float jitterA = (hash01(key, 5011) - 0.5f) * 0.22f;
            float radius = minDim * (0.23f + radial * 0.82f) + jitterR;
            float x = cx + (float)Math.cos(ang + jitterA) * radius;
            float y = cy + (float)Math.sin(ang + jitterA) * radius;
            x = clamp(x, minDim * -0.10f, width + minDim * 0.10f);
            y = clamp(y, minDim * -0.10f, height + minDim * 0.10f);
            return new float[]{x, y};
        }

        private void drawIridescentBubble(float cx, float cy, float radius, int index, float alpha, float sec) {
            if (alpha <= 0.002f || radius <= 0.5f) return;
            // V33：水晶泡泡 = 极淡蓝色内部 + 双层薄膜边缘 + 局部彩虹弧 + 白色椭圆高光。
            // 中心保持透明，不再画成黑珠或实心彩圈。
            drawCircle(cx, cy, radius * 0.98f, 0.020f, 0.210f, 0.410f, alpha * 0.018f, 44);
            drawCircle(cx - radius * 0.13f, cy - radius * 0.18f, radius * 0.62f, 0.32f, 0.86f, 1.00f, alpha * 0.008f, 36);

            float spin = sec * (0.10f + 0.003f * (index & 15)) + index * 0.0137f;
            float w = Math.max(0.55f, radius * 0.030f);
            drawRing(cx, cy, radius * 1.010f, Math.max(0.38f, radius * 0.015f), 0.92f, 0.99f, 1.00f, alpha * 0.24f, 72);
            drawRing(cx, cy, radius * 0.930f, Math.max(0.28f, radius * 0.007f), 0.22f, 0.76f, 1.00f, alpha * 0.045f, 64);
            drawArcStrip(cx, cy, radius * 1.015f, w * 1.36f, spin, (float)Math.PI * 0.50f, 0.96f, 0.30f, 0.78f, alpha * 0.22f, 18);
            drawArcStrip(cx, cy, radius * 1.020f, w * 1.22f, spin + 1.54f, (float)Math.PI * 0.54f, 0.26f, 0.94f, 1.00f, alpha * 0.24f, 20);
            drawArcStrip(cx, cy, radius * 1.015f, w * 1.12f, spin + 2.76f, (float)Math.PI * 0.46f, 0.60f, 1.00f, 0.36f, alpha * 0.18f, 18);
            drawArcStrip(cx, cy, radius * 1.005f, w * 0.96f, spin + 3.86f, (float)Math.PI * 0.38f, 1.00f, 0.86f, 0.34f, alpha * 0.12f, 16);

            float hiAng = -0.98f + 0.16f * (float)Math.sin(spin * 0.8f);
            float hx = cx + (float)Math.cos(hiAng) * radius * 0.44f;
            float hy = cy + (float)Math.sin(hiAng) * radius * 0.44f;
            drawEllipse(hx, hy, radius * 0.155f, radius * 0.052f, hiAng + 0.54f, 1f, 1f, 1f, alpha * 0.50f, 16);
            drawEllipse(cx - radius * 0.26f, cy - radius * 0.18f, radius * 0.40f, radius * 0.014f, hiAng + 0.16f, 0.72f, 0.96f, 1f, alpha * 0.105f, 16);
            drawEllipse(cx + radius * 0.30f, cy + radius * 0.23f, radius * 0.34f, radius * 0.010f, hiAng + 0.12f, 1.0f, 0.55f, 0.94f, alpha * 0.050f, 14);
        }

        private void drawSolidRect(float r, float g, float b, float a) {
            if (a <= 0f) return;
            float[] verts = new float[]{-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f};
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private float hash01(int i, int salt) {
            double v = Math.sin((i + 1) * 12.9898 + salt * 78.233 + cfg.style * 37.719) * 43758.5453;
            return (float)(v - Math.floor(v));
        }

        private void drawReleaseEruption(float local, float release, Phase phase) {
            float baseX = pulseX * width;
            float baseY = pulseY * height;
            float minDim = Math.max(1f, Math.min(width, height));
            float t = clamp(local, 0f, 1f);
            float releaseDurSec = Math.max(0.30f, phase.end - phase.start);
            float elapsed = t * releaseDurSec;

            // V39：震动必须肉眼可见，所以不再使用过高频的微颤。
            // 震动以“大圆冲击环扩张到最大”为唯一停止条件：ringProgressRaw < 1 时强震；到达 1 后立即归零。
            // 每个硬切帧维持约 70ms，手机屏幕上能明确看到整组释放光效横纵跳位，而不是被平均成模糊。
            float ringGrowSec = Math.max(0.58f, Math.min(0.92f, releaseDurSec * 0.22f));
            float ringProgressRaw = clamp(elapsed / ringGrowSec, 0f, 1f);
            float ringProgress = smooth(ringProgressRaw);
            float ringHoldFade = 1f - smooth(Math.max(0f, (elapsed - ringGrowSec) / 0.24f));
            float quakeStopGate = ringProgressRaw < 0.999f ? 1f : 0f;
            float quakeRise = Math.min(1f, elapsed / 0.030f);
            float preQuake = quakeRise * quakeStopGate;
            int quakeFrame = (int)Math.floor(elapsed * 14.0f + (releaseSeed & 15));
            float quakePhase = (float)(quakeFrame * 2.399963229728653 + ((releaseSeed & 1023) / 1023.0f) * Math.PI * 2.0);
            float quakeStrobe = ((quakeFrame & 1) == 0) ? 1.0f : 0.18f;
            float quakeSnap = ((quakeFrame & 1) == 0) ? 1.0f : -1.0f;
            float quakeSnapY = (((quakeFrame + 1) & 2) == 0) ? 1.0f : -1.0f;

            float impactFlash = smooth(Math.min(1f, elapsed / 0.050f)) * (1f - smooth(Math.max(0f, (elapsed - ringGrowSec * 0.74f) / 0.22f)));
            float beamSurgeTime = smooth(Math.min(1f, (elapsed - 0.12f) / 0.22f)) * (1f - smooth(Math.max(0f, (elapsed - 1.50f) / 0.62f)));
            float beamSurgeNorm = smooth(Math.min(1f, (t - 0.055f) / 0.145f)) * (1f - smooth(Math.max(0f, (t - 0.72f) / 0.28f)));
            float beamSurge = Math.max(beamSurgeTime, beamSurgeNorm * 0.82f);
            float floodSurge = smooth(Math.min(1f, (t - 0.15f) / 0.18f)) * (1f - smooth(Math.max(0f, (t - 0.88f) / 0.12f)));
            float finalClean = 1f - smooth(Math.max(0f, (t - 0.84f) / 0.16f));
            float visibleRelease = Math.max(release, Math.min(1f, preQuake * 0.62f + impactFlash * 0.86f));
            float a = clamp((visibleRelease * 0.82f + impactFlash * 0.55f + preQuake * 0.26f) * (0.90f + 0.38f * cfg.intimacy), 0f, 1.60f);

            // V39：大位移硬切。早期幅度最大，随着冲击环接近最大略收敛；到最大半径时 preQuake=0，震动停止。
            float tremor = preQuake;
            float snap = preQuake * (0.82f + 0.18f * quakeStrobe);
            float hardStepX = (float)Math.signum(Math.cos(quakePhase));
            float hardStepY = (float)Math.signum(Math.sin(quakePhase * 1.37f + 0.8f));
            if (hardStepX == 0f) hardStepX = 1f;
            if (hardStepY == 0f) hardStepY = -1f;
            float quakeAmp = minDim * (0.185f - 0.060f * ringProgressRaw) * preQuake;
            float jx = quakeAmp * (0.76f * (float)Math.cos(quakePhase) + 0.40f * hardStepX + 0.18f * quakeSnap);
            float jy = quakeAmp * (0.70f * (float)Math.sin(quakePhase * 1.21f) + 0.36f * hardStepY - 0.16f * quakeSnapY);
            float x = baseX + jx;
            float y = baseY + jy;

            // 明确的“颤抖可见层”：短促白闪 + 橙红热闪 + 撕裂光带。
            drawSolidRect(1.00f, 0.96f, 0.78f, a * preQuake * (0.055f + 0.038f * quakeStrobe));
            drawSolidRect(1.00f, 0.22f, 0.00f, a * preQuake * (0.050f + 0.032f * (1f - quakeStrobe)) * finalClean);
            drawQuakeTearBands(baseX, baseY, minDim, preQuake, quakeStrobe, elapsed, a);

            // 0.00-0.20：突然白化/热红升温，短促、刺激，但不长期烙屏。
            drawSolidRect(1.00f, 0.92f, 0.54f, a * (impactFlash * 0.052f + snap * 0.036f));
            drawSolidRect(1.00f, 0.39f, 0.02f, a * (beamSurge * 0.036f + snap * 0.030f) * finalClean);
            drawSolidRect(0.62f, 0.02f, 0.10f, a * (0.058f * preQuake + 0.020f * floodSurge) * finalClean);

            float coreR = minDim * (0.055f + 0.210f * beamSurge + 0.185f * impactFlash + 0.060f * visibleRelease);

            // V39 可见大圆冲击环：它的最大半径就是震动停止点。
            // ringProgressRaw < 1 时整个释放组硬震；到达 1 后震动归零，冲击环只短暂停留并淡出。
            float shockRingR = minDim * (0.085f + 0.585f * ringProgress);
            float shockRingWidth = Math.max(1.2f, minDim * (0.010f + 0.014f * preQuake));
            float shockRingAlpha = a * ringHoldFade * (0.070f + 0.145f * preQuake + 0.060f * impactFlash);
            drawArcStrip(x, y, shockRingR, shockRingWidth * 2.7f, 0f, (float)(Math.PI * 2.0),
                    1.00f, 0.44f, 0.00f, shockRingAlpha * 0.38f, 108);
            drawArcStrip(x, y, shockRingR * 0.992f, shockRingWidth * 1.15f, 0.04f, (float)(Math.PI * 2.0),
                    1.00f, 0.92f, 0.32f, shockRingAlpha * 0.84f, 108);
            drawArcStrip(x, y, shockRingR * 1.008f, Math.max(0.8f, shockRingWidth * 0.22f), 0.08f, (float)(Math.PI * 2.0),
                    1.00f, 1.00f, 0.94f, shockRingAlpha * 1.18f, 108);

            // V39：错位冲击环是“震动可见化”的关键。主环跳位的同时，上一/下一硬切位置以低透明度短暂出现，
            // 肉眼会看到大圆在扩张期间左右/上下猛跳；ringProgressRaw 到 1 后这些层完全不绘制。
            if (preQuake > 0.01f) {
                for (int q = 0; q < 4; q++) {
                    float ghostAng = quakePhase + (float)(q * Math.PI * 0.5 + 0.37f * q);
                    float ghostAmp = minDim * preQuake * (0.095f + 0.030f * q);
                    float gxRing = baseX + (float)Math.cos(ghostAng) * ghostAmp;
                    float gyRing = baseY + (float)Math.sin(ghostAng * 1.13f) * ghostAmp * 0.86f;
                    float ga = shockRingAlpha * (0.46f - q * 0.070f) * (0.62f + 0.38f * quakeStrobe);
                    drawArcStrip(gxRing, gyRing, shockRingR * (0.984f + q * 0.010f), shockRingWidth * (1.30f - q * 0.16f), 0.02f * q, (float)(Math.PI * 2.0),
                            1.00f, 0.86f, 0.30f, ga, 96);
                    drawArcStrip(gxRing, gyRing, shockRingR * (1.006f + q * 0.004f), Math.max(0.75f, shockRingWidth * 0.28f), 0.05f * q, (float)(Math.PI * 2.0),
                            1.00f, 1.00f, 0.96f, ga * 0.92f, 96);
                    drawCircle(gxRing, gyRing, coreR * (0.72f + q * 0.12f), 1.00f, 1.00f, 0.96f, a * preQuake * (0.075f - q * 0.010f), 34);
                }
            }

            // V39：多重错帧核心。冲击环扩张期间用明显分离的白金光心告诉眼睛“它在大幅震动”。
            if (preQuake > 0.01f) {
                for (int q = 0; q < 7; q++) {
                    int key = releaseSeed + q * 761;
                    float angQ = (float)(hash01(key, 3901) * Math.PI * 2.0 + elapsed * (38.0f + q * 6.5f));
                    float ampQ = minDim * (0.040f + 0.092f * hash01(key, 3903)) * preQuake * (0.55f + 0.45f * quakeStrobe);
                    float qx = baseX + (float)Math.cos(angQ) * ampQ + (q % 2 == 0 ? jx * 0.45f : -jx * 0.36f);
                    float qy = baseY + (float)Math.sin(angQ) * ampQ + (q % 2 == 0 ? jy * 0.45f : -jy * 0.36f);
                    drawCircle(qx, qy, coreR * (0.58f + 0.20f * q), 1.00f, 1.00f, 0.96f, a * preQuake * (0.085f - q * 0.007f), 34);
                    drawCircle(qx, qy, coreR * (1.45f + 0.16f * q), 1.00f, 0.55f, 0.02f, a * preQuake * (0.040f - q * 0.0038f), 42);
                }
            }

            // 颤抖重影核心：白、金、橙、玫红多层错位，形成参考视频那种“强光把细节吞掉”的瞬间。
            for (int g = 0; g < 5; g++) {
                float gh = hash01(releaseSeed + g * 97, 3951);
                float gx = x + (gh - 0.5f) * minDim * 0.130f * preQuake;
                float gy = y + (hash01(releaseSeed + g * 101, 3957) - 0.5f) * minDim * 0.130f * preQuake;
                drawCircle(gx, gy, coreR * (2.65f + g * 0.34f), 1.00f, 0.48f, 0.03f, a * Math.max(0.004f, (0.040f - g * 0.0050f)) * finalClean, 64);
                drawCircle(gx, gy, coreR * (1.55f + g * 0.16f), 1.00f, 0.82f, 0.10f, a * Math.max(0.006f, (0.100f - g * 0.012f)) * finalClean, 64);
            }
            drawCircle(x, y, coreR * 0.74f, 1.00f, 0.96f, 0.82f, a * 0.165f * finalClean, 56);
            drawCircle(x + jx * 0.55f, y - jy * 0.55f, coreR * 0.36f, 1.00f, 0.96f, 0.82f, a * 0.130f * impactFlash, 40);

            // 宽幅冲击楔面：从中心突然推开，模拟视频里的大面积金白爆光与舞台追光，而非单个机械大圆盘。
            int wedges = cfg.powerSave ? 7 : 13;
            for (int w = 0; w < wedges; w++) {
                int key = releaseSeed + w * 137;
                float h0 = hash01(key, 4001);
                float h1 = hash01(key, 4003);
                float ang = (float)(h0 * Math.PI * 2.0 + 0.18f * Math.sin(t * 28.0f + h1 * 6.28f) + preQuake * quakeSnap * 0.20f);
                float sweep = 0.20f + h1 * 0.30f;
                float len = minDim * (0.52f + h1 * 0.90f) * (0.52f + beamSurge * 0.80f + preQuake * 0.22f);
                float inner = minDim * (0.018f + h1 * 0.020f);
                ArrayList<float[]> poly = new ArrayList<>(4);
                poly.add(new float[]{x + (float)Math.cos(ang - sweep) * inner, y + (float)Math.sin(ang - sweep) * inner});
                poly.add(new float[]{x + (float)Math.cos(ang - sweep * 0.72f) * len, y + (float)Math.sin(ang - sweep * 0.72f) * len});
                poly.add(new float[]{x + (float)Math.cos(ang + sweep * 0.72f) * len * (0.92f + h0 * 0.18f), y + (float)Math.sin(ang + sweep * 0.72f) * len * (0.92f + h0 * 0.18f)});
                poly.add(new float[]{x + (float)Math.cos(ang + sweep) * inner, y + (float)Math.sin(ang + sweep) * inner});
                float wa = a * Math.max(beamSurge, preQuake * 0.72f) * (0.035f + h0 * 0.030f) * finalClean;
                drawFilledPolygon(poly, 1.00f, 0.54f + h1 * 0.22f, 0.03f, wa * 0.58f);
                drawFilledPolygon(poly, 1.00f, 0.96f, 0.54f, wa * 0.22f);
            }

            // 粗大放射光柱：数量更密、宽窄交替、中心白芯更亮；加上横向/斜向扫光增强“冲屏”感。
            int beams = cfg.powerSave ? 16 : 32;
            for (int i = 0; i < beams; i++) {
                int key = releaseSeed + i * 193;
                float h0 = hash01(key, 4101);
                float h1 = hash01(key, 4103);
                float h2 = hash01(key, 4107);
                float h3 = hash01(key, 4111);
                float trem = preQuake * (h2 - 0.5f) * 1.10f;
                float ang = (float)(h0 * Math.PI * 2.0 + trem + 0.28f * Math.sin(t * 10.0f + h1 * 6.28f));
                float len = minDim * (0.70f + h1 * 1.18f) * (0.34f + beamSurge * 0.98f + preQuake * 0.20f);
                float sx = x + (float)Math.cos(ang) * minDim * (0.012f + h2 * 0.030f);
                float sy = y + (float)Math.sin(ang) * minDim * (0.012f + h2 * 0.030f);
                float ex = x + (float)Math.cos(ang) * len;
                float ey = y + (float)Math.sin(ang) * len;
                float tx = (float)Math.cos(ang + Math.PI * 0.5f);
                float ty = (float)Math.sin(ang + Math.PI * 0.5f);
                float bend = minDim * (h2 - 0.5f) * 0.24f * (0.35f + beamSurge + preQuake * 0.30f);
                ArrayList<float[]> beam = new ArrayList<>(4);
                beam.add(new float[]{sx, sy});
                beam.add(new float[]{lerp(sx, ex, 0.25f) + tx * bend * 0.22f, lerp(sy, ey, 0.25f) + ty * bend * 0.22f});
                beam.add(new float[]{lerp(sx, ex, 0.67f) + tx * bend, lerp(sy, ey, 0.67f) + ty * bend});
                beam.add(new float[]{ex, ey});
                float beamAlpha = a * (0.046f + h2 * 0.048f) * Math.max(beamSurge, preQuake * 0.52f) * finalClean;
                float beamWidth = minDim * (0.024f + h3 * 0.070f) * (0.72f + 1.12f * visibleRelease + 0.86f * impactFlash + 0.75f * snap);
                drawTaperedStrip(beam, beamWidth * 5.40f, 1.00f, 0.24f + h1 * 0.18f, 0.00f, beamAlpha * 0.36f);
                drawTaperedStrip(beam, beamWidth * 2.45f, 1.00f, 0.70f + h1 * 0.20f, 0.10f, beamAlpha * 0.78f);
                drawTaperedStrip(beam, Math.max(1.10f, beamWidth * 0.25f), 1.00f, 1.00f, 0.92f, beamAlpha * 1.45f);
            }

            // 扫屏光带：参考视频中粗黄光柱横穿画面，加入少量斜切光带，避免只有中心圆爆。
            int sweeps = cfg.powerSave ? 4 : 7;
            for (int sIdx = 0; sIdx < sweeps; sIdx++) {
                int key = releaseSeed + sIdx * 313;
                float h0 = hash01(key, 4161);
                float angle = (float)(-0.54f + h0 * 1.08f + 0.24f * Math.sin(t * 9.0f + sIdx) + preQuake * quakeSnap * 0.16f);
                float dx = (float)Math.cos(angle);
                float dy = (float)Math.sin(angle);
                float nx = -dy;
                float ny = dx;
                float off = minDim * (-0.40f + sIdx * 0.14f + (hash01(key, 4167) - 0.5f) * 0.30f + quakeSnap * preQuake * 0.18f);
                ArrayList<float[]> sweep = new ArrayList<>(4);
                sweep.add(new float[]{x - dx * width * 1.35f + nx * off, y - dy * width * 1.35f + ny * off});
                sweep.add(new float[]{x - dx * width * 0.45f + nx * (off + minDim * 0.03f), y - dy * width * 0.45f + ny * (off + minDim * 0.03f)});
                sweep.add(new float[]{x + dx * width * 0.45f + nx * (off - minDim * 0.02f), y + dy * width * 0.45f + ny * (off - minDim * 0.02f)});
                sweep.add(new float[]{x + dx * width * 1.35f + nx * off, y + dy * width * 1.35f + ny * off});
                float sw = minDim * (0.032f + 0.022f * hash01(key, 4171)) * (0.8f + 1.2f * beamSurge + 0.44f * preQuake);
                drawTaperedStrip(sweep, sw * 3.3f, 1.00f, 0.33f, 0.00f, a * Math.max(beamSurge, preQuake * 0.65f) * 0.028f * finalClean);
                drawTaperedStrip(sweep, sw * 1.05f, 1.00f, 0.95f, 0.42f, a * Math.max(beamSurge, preQuake * 0.65f) * 0.090f * finalClean);
                drawTaperedStrip(sweep, Math.max(0.8f, sw * 0.15f), 1.00f, 1.00f, 0.93f, a * Math.max(beamSurge, preQuake * 0.65f) * 0.140f * finalClean);
            }

            // 热浪/冲击环：只保留断续弧线与外推空气波，避免形成单调大圆盘。
            for (int j = 0; j < 8; j++) {
                float h = hash01(releaseSeed + j * 271, 4201);
                float r = minDim * (0.08f + 0.105f * j + beamSurge * (0.18f + h * 0.20f));
                float start = (float)(h * Math.PI * 2.0 + t * 2.5f + tremor * 0.3f);
                float sweep = (float)Math.PI * (0.26f + hash01(releaseSeed + j, 4207) * 0.74f);
                float alpha = a * (0.078f - j * 0.006f) * beamSurge * finalClean;
                drawArcStrip(x, y, r, Math.max(1.0f, minDim * (0.0060f + j * 0.0009f)), start, sweep,
                        1.00f, 0.64f + h * 0.20f, 0.05f, alpha, 44);
                drawArcStrip(x, y, r * 1.018f, Math.max(0.65f, minDim * 0.0016f), start + 0.07f, sweep * 0.58f,
                        1.00f, 1.00f, 0.80f, alpha * 0.78f, 34);
            }

            drawReleaseParticleFlood(x, y, t, visibleRelease, a, minDim, preQuake, floodSurge);
        }

        private void drawQuakeTearBands(float cx, float cy, float minDim, float quake, float strobe, float elapsed, float alpha) {
            if (quake <= 0.005f || alpha <= 0f) return;
            int bands = cfg.powerSave ? 5 : 9;
            for (int i = 0; i < bands; i++) {
                int key = releaseSeed + i * 881;
                float h0 = hash01(key, 3841);
                float h1 = hash01(key, 3847);
                float angle = (float)(-0.42f + h0 * 0.84f + quake * (((i & 1) == 0) ? 0.16f : -0.16f));
                float dx = (float)Math.cos(angle);
                float dy = (float)Math.sin(angle);
                float nx = -dy;
                float ny = dx;
                float gate = (((int)Math.floor(elapsed * (14f + i * 0.9f) + h1 * 9f)) & 1) == 0 ? 1f : -1f;
                float off = minDim * (-0.46f + i * 0.12f + (h1 - 0.5f) * 0.16f + gate * quake * 0.34f);
                float widthPx = minDim * (0.014f + h0 * 0.034f) * (1.0f + quake * 2.4f);
                ArrayList<float[]> band = new ArrayList<>(4);
                band.add(new float[]{cx - dx * width * 1.35f + nx * off, cy - dy * width * 1.35f + ny * off});
                band.add(new float[]{cx - dx * width * 0.40f + nx * (off + gate * minDim * 0.045f), cy - dy * width * 0.40f + ny * (off + gate * minDim * 0.045f)});
                band.add(new float[]{cx + dx * width * 0.52f + nx * (off - gate * minDim * 0.035f), cy + dy * width * 0.52f + ny * (off - gate * minDim * 0.035f)});
                band.add(new float[]{cx + dx * width * 1.35f + nx * off, cy + dy * width * 1.35f + ny * off});
                float a = alpha * quake * (0.072f + h1 * 0.070f) * (0.55f + 0.45f * strobe);
                drawTaperedStrip(band, widthPx * 6.4f, 1.00f, 0.16f, 0.00f, a * 0.36f);
                drawTaperedStrip(band, widthPx * 2.25f, 1.00f, 0.88f, 0.32f, a * 0.78f);
                drawTaperedStrip(band, Math.max(1.1f, widthPx * 0.34f), 1.00f, 1.00f, 0.96f, a * 1.25f);
            }
        }

        private void drawReleaseParticleFlood(float cx, float cy, float local, float release, float alpha, float minDim, float quake, float floodSurge) {
            int count = cfg.powerSave ? 110 : 230;
            for (int i = 0; i < count; i++) {
                int key = releaseSeed + i * 307;
                float h0 = hash01(key, 4301);
                float h1 = hash01(key, 4303);
                float h2 = hash01(key, 4307);
                float h3 = hash01(key, 4311);
                float h4 = hash01(key, 4319);
                float born = h0 * 0.22f;
                float life = 0.46f + h1 * 0.46f;
                float u = clamp((local - born) / Math.max(0.001f, life), 0f, 1f);
                float live = smooth(Math.min(1f, u / 0.045f)) * (1f - smooth(Math.max(0f, (u - 0.78f) / 0.22f))) * release * (0.55f + 0.85f * floodSurge);
                if (live <= 0.002f) continue;
                // V46：释放碎光不是独立随机飞散，而是 9 个微群体的 Boids-like 爆散：
                // cohesion 给每组一个共同方向，alignment 让速度同频，separation 避免粒子重叠成噪点。
                int flock = i % 9;
                float flockBase = (float)(flock / 9.0f * Math.PI * 2.0 + hash01(releaseSeed + flock * 733, 4327) * 0.58f);
                float alignment = (float)Math.sin(local * (4.0f + h1 * 2.8f) + flock * 0.83f) * 0.22f;
                float separation = (h4 - 0.5f) * (0.42f + quake * 0.62f);
                float ang = flockBase * 0.48f + h2 * (float)Math.PI * 2.0f * 0.52f + alignment + separation
                        + 0.14f * (float)Math.sin(u * 9.0f + h3 * 6.28f);
                float dist = minDim * (0.030f + (0.35f + h3 * 1.30f) * (float)Math.pow(u, 0.50f));
                float groupPull = minDim * (0.035f + 0.075f * h1) * smooth(u);
                float drift = minDim * (h4 - 0.5f) * 0.18f * u * u;
                float nx = (float)Math.cos(ang);
                float ny = (float)Math.sin(ang);
                float tx = -ny;
                float ty = nx;
                float gx = (float)Math.cos(flockBase) * groupPull;
                float gy = (float)Math.sin(flockBase) * groupPull;
                float x = cx + nx * dist + tx * drift + gx;
                float y = cy + ny * dist + ty * drift + gy;
                float sz = minDim * (0.0030f + h4 * 0.0125f) * (1.12f - u * 0.46f) * (0.90f + floodSurge * 0.32f);
                float rot = ang + h0 * 2.8f + local * (1.2f + h1 * 2.0f);
                float a = alpha * live * (0.22f + h1 * 0.34f);
                if ((i & 3) == 0) {
                    ArrayList<float[]> poly = new ArrayList<>(4);
                    float co = (float)Math.cos(rot), si = (float)Math.sin(rot);
                    float rx = sz * (1.6f + h3 * 2.4f);
                    float ry = sz * (0.38f + h2 * 0.60f);
                    poly.add(new float[]{x + co * rx, y + si * rx});
                    poly.add(new float[]{x - si * ry, y + co * ry});
                    poly.add(new float[]{x - co * rx * 0.68f, y - si * rx * 0.68f});
                    poly.add(new float[]{x + si * ry, y - co * ry});
                    drawFilledPolygon(poly, 1.00f, 0.65f + h1 * 0.28f, 0.04f, a * 0.72f);
                    drawCircle(x, y, Math.max(0.6f, sz * 0.30f), 1f, 1f, 0.90f, a * 0.78f, 10);
                } else if ((i & 3) == 1) {
                    drawEllipse(x, y, sz * (1.8f + h2 * 1.8f), sz * (0.28f + h1 * 0.34f), rot,
                            1.00f, 0.42f + h1 * 0.30f, 0.00f, a * 0.98f, 10);
                    drawEllipse(x, y, sz * 0.80f, Math.max(0.35f, sz * 0.11f), rot, 1f, 1f, 0.86f, a * 0.76f, 8);
                } else if ((i & 3) == 2) {
                    ArrayList<float[]> comet = new ArrayList<>(3);
                    float tail = sz * (3.6f + h1 * 5.0f);
                    comet.add(new float[]{x - nx * tail, y - ny * tail});
                    comet.add(new float[]{x - nx * tail * 0.42f + tx * sz * 0.35f, y - ny * tail * 0.42f + ty * sz * 0.35f});
                    comet.add(new float[]{x, y});
                    drawTaperedStrip(comet, Math.max(0.55f, sz * (0.65f + h2)), 1.00f, 0.92f, 0.26f, a * 0.54f);
                    drawCircle(x, y, Math.max(0.5f, sz * 0.34f), 1f, 1f, 1f, a * 0.56f, 8);
                } else {
                    drawCircle(x, y, sz * (0.40f + h2 * 0.55f), 1.00f, 0.88f, 0.20f, a * 0.42f, 10);
                    drawEllipse(x + tx * sz * 0.20f, y + ty * sz * 0.20f, sz * (0.72f + h1), sz * 0.16f, rot, 1f, 1f, 0.94f, a * 0.66f, 8);
                }
            }
        }

        private void drawCircle(float cx, float cy, float radius, float r, float g, float b, float a, int segments) {
            if (a <= 0f || radius <= 0f) return;
            float[] verts = new float[(segments + 2) * 2];
            putNdc(verts, 0, cx, cy);
            int vi = 2;
            for (int i = 0; i <= segments; i++) {
                float ang = i / (float)segments * (float)Math.PI * 2f;
                putNdc(verts, vi, cx + (float)Math.cos(ang) * radius, cy + (float)Math.sin(ang) * radius);
                vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_FAN, r, g, b, a);
        }

        private void drawRing(float cx, float cy, float radius, float widthPx, float r, float g, float b, float a, int segments) {
            if (a <= 0f || radius <= 0f || widthPx <= 0f) return;
            float[] verts = new float[(segments + 1) * 2 * 2];
            int vi = 0;
            for (int i = 0; i <= segments; i++) {
                float ang = i / (float)segments * (float)Math.PI * 2f;
                float co = (float)Math.cos(ang);
                float si = (float)Math.sin(ang);
                putNdc(verts, vi, cx + co * (radius + widthPx), cy + si * (radius + widthPx)); vi += 2;
                putNdc(verts, vi, cx + co * Math.max(0f, radius - widthPx), cy + si * Math.max(0f, radius - widthPx)); vi += 2;
            }
            drawColorVertices(verts, GLES20.GL_TRIANGLE_STRIP, r, g, b, a);
        }

        private void putNdc(float[] verts, int idx, float x, float y) {
            verts[idx] = x / Math.max(1f, width) * 2f - 1f;
            verts[idx + 1] = 1f - y / Math.max(1f, height) * 2f;
        }

        private void drawColorVertices(float[] verts, int mode, float r, float g, float b, float a) {
            GLES20.glUseProgram(colorProgram);
            int aPos = GLES20.glGetAttribLocation(colorProgram, "aPosition");
            int uColor = GLES20.glGetUniformLocation(colorProgram, "uColor");
            FloatBuffer buf = makeFloatBuffer(verts);
            GLES20.glEnableVertexAttribArray(aPos);
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, buf);
            // V46：全局白化保险。白色仍可做短闪和窄边，但不允许长期以大面片覆盖桌面。
            if (r > 0.94f && g > 0.94f && b > 0.94f && mode == GLES20.GL_TRIANGLE_FAN) {
                a = Math.min(a, 0.55f);
            }
            GLES20.glUniform4f(uColor, r, g, b, clamp(a, 0f, 1f));
            GLES20.glDrawArrays(mode, 0, verts.length / 2);
            GLES20.glDisableVertexAttribArray(aPos);
        }

        private void drawTexture(int textureId, float fade) {
            float[] verts = new float[]{
                    -1f, -1f, 0f, 0f,
                     1f, -1f, 1f, 0f,
                    -1f,  1f, 0f, 1f,
                     1f,  1f, 1f, 1f
            };
            GLES20.glUseProgram(textureProgram);
            int aPos = GLES20.glGetAttribLocation(textureProgram, "aPosition");
            int aTex = GLES20.glGetAttribLocation(textureProgram, "aTexCoord");
            int uTex = GLES20.glGetUniformLocation(textureProgram, "uTexture");
            int uFade = GLES20.glGetUniformLocation(textureProgram, "uFade");
            FloatBuffer buf = makeFloatBuffer(verts);
            buf.position(0);
            GLES20.glEnableVertexAttribArray(aPos);
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, buf);
            buf.position(2);
            GLES20.glEnableVertexAttribArray(aTex);
            GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, buf);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
            GLES20.glUniform1i(uTex, 0);
            GLES20.glUniform1f(uFade, fade);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            GLES20.glDisableVertexAttribArray(aPos);
            GLES20.glDisableVertexAttribArray(aTex);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
        }

        private int createProgram(String vs, String fs) {
            int v = compileShader(GLES20.GL_VERTEX_SHADER, vs);
            int f = compileShader(GLES20.GL_FRAGMENT_SHADER, fs);
            int p = GLES20.glCreateProgram();
            GLES20.glAttachShader(p, v);
            GLES20.glAttachShader(p, f);
            GLES20.glLinkProgram(p);
            int[] ok = new int[1];
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
            GLES20.glDeleteShader(v);
            GLES20.glDeleteShader(f);
            if (ok[0] == 0) {
                GLES20.glDeleteProgram(p);
                return 0;
            }
            return p;
        }

        private int compileShader(int type, String source) {
            int s = GLES20.glCreateShader(type);
            GLES20.glShaderSource(s, source);
            GLES20.glCompileShader(s);
            int[] ok = new int[1];
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
            if (ok[0] == 0) {
                GLES20.glDeleteShader(s);
                return 0;
            }
            return s;
        }

        private FloatBuffer makeFloatBuffer(float[] data) {
            ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 4);
            bb.order(ByteOrder.nativeOrder());
            FloatBuffer fb = bb.asFloatBuffer();
            fb.put(data);
            fb.position(0);
            return fb;
        }

        private void deleteFbos() {
            if (fbo[0] != 0 || fbo[1] != 0) GLES20.glDeleteFramebuffers(2, fbo, 0);
            if (tex[0] != 0 || tex[1] != 0) GLES20.glDeleteTextures(2, tex, 0);
            fbo[0] = fbo[1] = tex[0] = tex[1] = 0;
            fboReady = false;
        }

        private void releaseGl() {
            try {
                deleteFbos();
                if (textureProgram != 0) GLES20.glDeleteProgram(textureProgram);
                if (colorProgram != 0) GLES20.glDeleteProgram(colorProgram);
                if (egl != null && eglDisplay != null) {
                    egl.eglMakeCurrent(eglDisplay, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                    if (eglSurface != null && eglSurface != EGL10.EGL_NO_SURFACE) egl.eglDestroySurface(eglDisplay, eglSurface);
                    if (eglContext != null && eglContext != EGL10.EGL_NO_CONTEXT) egl.eglDestroyContext(eglDisplay, eglContext);
                    egl.eglTerminate(eglDisplay);
                }
            } catch (Throwable ignored) {}
        }

        private void ensureCycleState(boolean force) {
            long wallNow = System.currentTimeMillis();
            String sig = cycleConfigSignature();
            long savedStart = prefs.getLong("cycleStartWallMs", 0L);
            float savedDuration = prefs.getFloat("cycleDurationSec", 0f);
            String savedSig = prefs.getString("cycleConfigSignature", "");
            boolean missing = savedStart <= 0L || savedDuration <= 0f;
            boolean configChanged = !sig.equals(savedSig);
            boolean completed = !missing && wallNow - savedStart >= (long)(savedDuration * 1000f);
            if (force || missing || configChanged || completed) {
                beginNewCycle(wallNow);
            } else {
                cycleStartWallMs = savedStart;
                cycleDurationSec = savedDuration;
                cycleCriticalStartSec = prefs.getFloat("cycleCriticalStartSec", 0f);
                cycleReleaseStartSec = prefs.getFloat("cycleReleaseStartSec", Math.max(0f, savedDuration - 60f));
                cycleReleaseDurationSec = prefs.getFloat("cycleReleaseDurationSec", 12f);
                cycleAfterglowDurationSec = prefs.getFloat("cycleAfterglowDurationSec", 24f);
                cycleCriticalDurationSec = prefs.getFloat("cycleCriticalDurationSec", 60f);
                cycleSignature = savedSig;
            }
        }

        private void beginNewCycle(long wallNow) {
            cycleStartWallMs = wallNow;
            cycleDurationSec = chooseCycleDurationSec();
            cycleSignature = cycleConfigSignature();
            CyclePlan plan = randomPlanForDuration(cycleDurationSec);
            cycleCriticalStartSec = plan.criticalStartSec;
            cycleReleaseStartSec = plan.releaseStartSec;
            cycleReleaseDurationSec = plan.releaseDurationSec;
            cycleAfterglowDurationSec = plan.afterglowDurationSec;
            cycleCriticalDurationSec = plan.criticalDurationSec;
            prefs.edit()
                    .putLong("cycleStartWallMs", cycleStartWallMs)
                    .putFloat("cycleDurationSec", cycleDurationSec)
                    .putFloat("cycleCriticalStartSec", cycleCriticalStartSec)
                    .putFloat("cycleReleaseStartSec", cycleReleaseStartSec)
                    .putFloat("cycleReleaseDurationSec", cycleReleaseDurationSec)
                    .putFloat("cycleAfterglowDurationSec", cycleAfterglowDurationSec)
                    .putFloat("cycleCriticalDurationSec", cycleCriticalDurationSec)
                    .putString("cycleConfigSignature", cycleSignature)
                    .apply();
            startMs = SystemClock.elapsedRealtime();
            nextSpawnSec = 0f;
            nextHardClearSec = 6f + random.nextFloat() * 12f;
            lastVisualSec = -1f;
            releasePulseArmed = true;
            releaseSeed = random.nextInt();
            strokes.clear();
            resetSpawnHeat();
            classicReady = false;
            classicFilled = 0;
            classicHead = 0;
            classicShapeAge = 0f;
            clearFbos();
        }

        private void clearFbos() {
            if (!fboReady) return;
            for (int i = 0; i < 2; i++) {
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[i]);
                GLES20.glClearColor(0f, 0f, 0f, 1f);
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            }
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
        }

        private float currentCycleElapsedSec() {
            if (cycleStartWallMs <= 0L) return (SystemClock.elapsedRealtime() - startMs) / 1000f;
            return Math.max(0f, (System.currentTimeMillis() - cycleStartWallMs) / 1000f);
        }

        private CyclePlan storedCyclePlan(float durationSec) {
            CyclePlan p = new CyclePlan();
            p.durationSec = durationSec;
            p.criticalStartSec = cycleCriticalStartSec;
            p.releaseStartSec = cycleReleaseStartSec;
            p.releaseDurationSec = cycleReleaseDurationSec;
            p.afterglowDurationSec = cycleAfterglowDurationSec;
            p.criticalDurationSec = cycleCriticalDurationSec;
            return p.sanitized();
        }

        private CyclePlan previewPlan(float durationSec) {
            // 预览模式仍遵守“只出现一次释放/余韵”，但把真实天级周期压缩到几分钟。
            CyclePlan p = new CyclePlan();
            p.durationSec = durationSec;
            float seedLike = stable01("preview-release");
            p.releaseDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioRelease, cfg.releaseMinSec, cfg.releaseMaxSec, false);
            p.afterglowDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioAfterglow, cfg.afterglowMinSec, cfg.afterglowMaxSec, false);
            p.criticalDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioCritical, cfg.criticalMinSec, cfg.criticalMaxSec, false);
            float latest = Math.max(1f, durationSec - p.releaseDurationSec - p.afterglowDurationSec - 1f);
            float earliest = Math.min(latest, Math.max(1f, durationSec * 0.34f));
            p.releaseStartSec = earliest + (latest - earliest) * seedLike;
            p.criticalStartSec = Math.max(0f, p.releaseStartSec - p.criticalDurationSec);
            return p.sanitized();
        }

        private CyclePlan randomPlanForDuration(float durationSec) {
            CyclePlan p = new CyclePlan();
            p.durationSec = durationSec;
            p.releaseDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioRelease, cfg.releaseMinSec, cfg.releaseMaxSec, true);
            p.afterglowDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioAfterglow, cfg.afterglowMinSec, cfg.afterglowMaxSec, true);
            p.criticalDurationSec = durationFromRatioAndRange(durationSec, cfg.ratioCritical, cfg.criticalMinSec, cfg.criticalMaxSec, true);
            float minPre = Math.max(60f, Math.min(3600f, durationSec * 0.035f));
            float latest = Math.max(minPre, durationSec - p.releaseDurationSec - p.afterglowDurationSec - 60f);
            p.releaseStartSec = minPre + random.nextFloat() * Math.max(0f, latest - minPre);
            p.criticalStartSec = Math.max(0f, p.releaseStartSec - p.criticalDurationSec);
            return p.sanitized();
        }

        private float durationFromRatioAndRange(float totalSec, float ratio, float minSec, float maxSec, boolean randomize) {
            float min = Math.min(minSec, maxSec);
            float max = Math.max(minSec, maxSec);
            // 阶段比例给出该阶段在本轮周期中的目标长度；用户设置的秒级范围是硬边界。
            // 如果目标超出范围，就被钳制到范围内，因此“短阶段持续时间范围”一定真实生效。
            // 若目标位于范围内，随机项只做轻微扰动，避免每轮完全机械一致。
            float target = clamp(totalSec * Math.max(0.0001f, ratio), min, max);
            float jitter = randomize ? randRange(min, max) : stableRange(min, max, "dur-" + Math.round(totalSec) + ":" + Math.round(ratio * 10000f));
            return clamp(lerp(target, jitter, 0.22f), min, max);
        }

        private float stableRange(float a, float b, String salt) {
            float min = Math.min(a, b);
            float max = Math.max(a, b);
            return min + stable01(salt) * Math.max(0f, max - min);
        }

        private float stable01(String salt) {
            int h = (cycleSignature + ":" + salt).hashCode();
            long v = h & 0x7fffffffL;
            return (v % 1000000L) / 1000000f;
        }

        private float randRange(float a, float b) {
            float min = Math.min(a, b);
            float max = Math.max(a, b);
            return min + random.nextFloat() * Math.max(0f, max - min);
        }

        private float chooseCycleDurationSec() {
            float minDays = clamp(cfg.cycleMinDays, 1f, 365f);
            float maxDays = clamp(cfg.cycleMaxDays, minDays, 365f);
            float days;
            if (cfg.randomCycle) days = minDays + random.nextFloat() * Math.max(0f, maxDays - minDays);
            else days = clamp(cfg.fixedCycleDays, minDays, maxDays);
            return Math.max(86400f, days * 86400f);
        }

        private String cycleConfigSignature() {
            return cfg.randomCycle + ":" + Math.round(cfg.cycleMinDays * 10f) + ":" + Math.round(cfg.cycleMaxDays * 10f)
                    + ":" + Math.round(cfg.fixedCycleDays * 10f) + ":" + Math.round(cfg.ratioSeparation * 1000f)
                    + ":" + Math.round(cfg.ratioAttraction * 1000f) + ":" + Math.round(cfg.ratioSync * 1000f)
                    + ":" + Math.round(cfg.ratioCritical * 1000f) + ":" + Math.round(cfg.ratioRelease * 1000f)
                    + ":" + Math.round(cfg.ratioAfterglow * 1000f) + ":" + Math.round(cfg.criticalMinSec) + ":" + Math.round(cfg.criticalMaxSec)
                    + ":" + Math.round(cfg.releaseMinSec) + ":" + Math.round(cfg.releaseMaxSec)
                    + ":" + Math.round(cfg.afterglowMinSec) + ":" + Math.round(cfg.afterglowMaxSec);
        }

        private void readConfig(boolean force) {
            long now = SystemClock.elapsedRealtime();
            if (!force && !configDirty && now - lastConfigRead < 500L) return;
            lastConfigRead = now;
            configDirty = false;
            String oldVisualSignature = visualConfigSignature;
            cfg.style = prefs.getInt("style", 0);
            cfg.intimacy = prefs.getFloat("intimacy", 0.72f);
            cfg.randomness = prefs.getFloat("randomness", 0.66f);
            cfg.ribbonWidth = prefs.getFloat("ribbonWidth", 0.62f);
            cfg.trail = prefs.getFloat("trail", 0.90f);
            cfg.fullScreenCoverage = prefs.getFloat("fullScreenCoverage", 0.96f);
            cfg.strokeDensity = prefs.getFloat("strokeDensity", 0.24f);
            cfg.journeyMinSec = clamp(prefs.getFloat("journeyMinSec", 6f), 6f, 60f);
            cfg.journeyMaxSec = clamp(prefs.getFloat("journeyMaxSec", 60f), cfg.journeyMinSec, 60f);
            cfg.previewAccelerated = prefs.getBoolean("previewAccelerated", false);
            cfg.previewCycleMinutes = clamp(prefs.getFloat("previewCycleMinutes", 3f), 0.5f, 60f);
            cfg.debugLoopEnabled = prefs.getBoolean("debugLoopEnabled", false);
            cfg.debugCycleMinutes = clamp(prefs.getFloat("debugCycleMinutes", 3f), 1f, 60f);
            cfg.bubbles = prefs.getBoolean("bubbles", true);
            cfg.powerSave = prefs.getBoolean("powerSave", false);
            cfg.cycleMinDays = clamp(prefs.getFloat("cycleMinDays", 1f), 1f, 365f);
            cfg.cycleMaxDays = clamp(prefs.getFloat("cycleMaxDays", 365f), cfg.cycleMinDays, 365f);
            cfg.fixedCycleDays = clamp(prefs.getFloat("fixedCycleDays", 30f), cfg.cycleMinDays, cfg.cycleMaxDays);
            cfg.randomCycle = prefs.getBoolean("randomCycle", true);
            cfg.ratioSeparation = prefs.getFloat("ratioSeparation", 0.46f);
            cfg.ratioAttraction = prefs.getFloat("ratioAttraction", 0.22f);
            cfg.ratioSync = prefs.getFloat("ratioSync", 0.22f);
            cfg.ratioCritical = prefs.getFloat("ratioCritical", 0.06f);
            cfg.ratioRelease = prefs.getFloat("ratioRelease", 0.02f);
            cfg.ratioAfterglow = prefs.getFloat("ratioAfterglow", 0.02f);
            cfg.criticalMinSec = clamp(prefs.getFloat("criticalMinSec", 30f), 5f, 3600f);
            cfg.criticalMaxSec = clamp(prefs.getFloat("criticalMaxSec", 180f), cfg.criticalMinSec, 7200f);
            cfg.releaseMinSec = clamp(prefs.getFloat("releaseMinSec", 8f), 2f, 600f);
            cfg.releaseMaxSec = clamp(prefs.getFloat("releaseMaxSec", 24f), cfg.releaseMinSec, 1200f);
            cfg.afterglowMinSec = clamp(prefs.getFloat("afterglowMinSec", 20f), 3f, 1800f);
            cfg.afterglowMaxSec = clamp(prefs.getFloat("afterglowMaxSec", 90f), cfg.afterglowMinSec, 3600f);
            normalizeRatios(cfg);
            visualConfigSignature = buildVisualConfigSignature();
            if (force || !visualConfigSignature.equals(oldVisualSignature)) {
                strokes.clear();
                resetSpawnHeat();
                nextSpawnSec = 0f;
                nextHardClearSec = 6f + random.nextFloat() * 12f;
                startMs = SystemClock.elapsedRealtime();
                lastVisualSec = -1f;
                releasePulseArmed = true;
                if (fboReady) clearFbos();
            }
            ensureCycleState(force);
        }

        private String buildVisualConfigSignature() {
            return cfg.style + ":" + Math.round(cfg.intimacy * 1000f)
                    + ":" + Math.round(cfg.randomness * 1000f)
                    + ":" + Math.round(cfg.ribbonWidth * 1000f)
                    + ":" + Math.round(cfg.trail * 1000f)
                    + ":" + Math.round(cfg.fullScreenCoverage * 1000f)
                    + ":" + Math.round(cfg.strokeDensity * 1000f)
                    + ":" + Math.round(cfg.journeyMinSec) + ":" + Math.round(cfg.journeyMaxSec)
                    + ":" + cfg.debugLoopEnabled + ":" + Math.round(cfg.debugCycleMinutes * 1000f)
                    + ":" + cfg.bubbles + ":" + cfg.powerSave;
        }

        private void normalizeRatios(Config c) {
            c.ratioSeparation = Math.max(0.01f, c.ratioSeparation);
            c.ratioAttraction = Math.max(0.01f, c.ratioAttraction);
            c.ratioSync = Math.max(0.01f, c.ratioSync);
            c.ratioCritical = Math.max(0.005f, c.ratioCritical);
            c.ratioRelease = Math.max(0.002f, c.ratioRelease);
            c.ratioAfterglow = Math.max(0.002f, c.ratioAfterglow);
            float sum = c.ratioSeparation + c.ratioAttraction + c.ratioSync + c.ratioCritical + c.ratioRelease + c.ratioAfterglow;
            if (sum <= 0f) {
                c.ratioSeparation = 0.46f; c.ratioAttraction = 0.22f; c.ratioSync = 0.22f;
                c.ratioCritical = 0.06f; c.ratioRelease = 0.02f; c.ratioAfterglow = 0.02f;
                return;
            }
            c.ratioSeparation /= sum;
            c.ratioAttraction /= sum;
            c.ratioSync /= sum;
            c.ratioCritical /= sum;
            c.ratioRelease /= sum;
            c.ratioAfterglow /= sum;
        }

        private boolean isReleaseOrAfterglowPhase(Phase phase) {
            return phase != null && (phase.name.equals("释放") || phase.name.equals("余韵"));
        }

        private float pxPerMm() {
            try {
                android.util.DisplayMetrics dm = context.getResources().getDisplayMetrics();
                float dpi = Math.max(dm.xdpi, dm.ydpi);
                if (dpi <= 1f || Float.isNaN(dpi) || Float.isInfinite(dpi)) dpi = dm.densityDpi;
                if (dpi <= 1f) dpi = 420f;
                return dpi / 25.4f;
            } catch (Throwable ignored) {
                return Math.max(1f, Math.min(width, height) / 68f);
            }
        }

        private float nonReleaseWhiteBandMaxPx(Phase phase) {
            if (isReleaseOrAfterglowPhase(phase)) return Math.max(4f, Math.min(width, height) * 0.25f);
            float minDim = Math.max(1f, Math.min(width, height));
            // 2.6mm 是中值；再加屏幕比例保险，避免某些机型 xdpi 异常导致过宽。
            return clamp(pxPerMm() * 2.6f, minDim * 0.008f, minDim * 0.048f);
        }

        private float capNonReleaseBand(Phase phase, float widthPx) {
            if (isReleaseOrAfterglowPhase(phase)) return widthPx;
            return Math.min(widthPx, nonReleaseWhiteBandMaxPx(phase));
        }

        private float nonReleaseWideAlphaScale(Phase phase) {
            return isReleaseOrAfterglowPhase(phase) ? 1f : 0.52f;
        }

        private float nonReleaseHighlightAlphaScale(Phase phase) {
            return isReleaseOrAfterglowPhase(phase) ? 1f : 1.05f;
        }

        private int[] palette(int style) {
            switch (Math.floorMod(style, 5)) {
                case 1: return new int[]{0xFF34D399, 0xFF67E8F9, 0xFF93C5FD, 0xFFFDE68A, 0xFF020617};
                case 2: return new int[]{0xFFA78BFA, 0xFFD8B4FE, 0xFFF472B6, 0xFF93C5FD, 0xFF050316};
                case 3: return new int[]{0xFFBFDBFE, 0xFFE0F2FE, 0xFF93C5FD, 0xFFCBD5E1, 0xFF000000};
                case 4: return new int[]{0xFFFDE68A, 0xFFFDBA74, 0xFFFB7185, 0xFFF97316, 0xFF06030A};
                default: return new int[]{0xFF7DD3FC, 0xFFC4B5FD, 0xFFF472B6, 0xFFFDE68A, 0xFF030712};
            }
        }

        private int pickColor(int[] colors) { return colors[random.nextInt(4)]; }
        private static float catmull(float p0, float p1, float p2, float p3, float t) {
            float t2 = t * t;
            float t3 = t2 * t;
            return 0.5f * ((2f * p1) + (-p0 + p2) * t + (2f*p0 - 5f*p1 + 4f*p2 - p3) * t2 + (-p0 + 3f*p1 - 3f*p2 + p3) * t3);
        }
        private float distance(float x0, float y0, float x1, float y1) {
            float dx = x1 - x0, dy = y1 - y0;
            return (float)Math.sqrt(dx * dx + dy * dy);
        }
        private float[] color4(int color, float alpha) {
            return new float[]{Color.red(color)/255f, Color.green(color)/255f, Color.blue(color)/255f, clamp(alpha, 0f, 1f)};
        }
        private static int clampInt(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }
        private static float clamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }
        private static float fract(float v) { return v - (float)Math.floor(v); }
        private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
        private static float smooth(float x) { x = clamp(x, 0f, 1f); return x * x * (3f - 2f * x); }
        private static void sleepQuiet(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }

        private static final String TEXTURE_VERTEX =
                "attribute vec2 aPosition;\n" +
                "attribute vec2 aTexCoord;\n" +
                "varying vec2 vTexCoord;\n" +
                "void main(){ gl_Position = vec4(aPosition, 0.0, 1.0); vTexCoord = aTexCoord; }";
        private static final String TEXTURE_FRAGMENT =
                "precision mediump float;\n" +
                "uniform sampler2D uTexture;\n" +
                "uniform float uFade;\n" +
                "varying vec2 vTexCoord;\n" +
                // V29 phosphor decay：不是简单乘 fade，而是每帧轻微扣黑，
                // 让尾迹像参考视频那样先失彩、再变细、最后被黑场吞没。
                "void main(){ vec4 c = texture2D(uTexture, vTexCoord); vec3 rgb = max(c.rgb * uFade - vec3(0.00105), vec3(0.0)); rgb = pow(rgb, vec3(1.010)); gl_FragColor = vec4(rgb, 1.0); }";
        private static final String COLOR_VERTEX =
                "attribute vec2 aPosition;\n" +
                "void main(){ gl_Position = vec4(aPosition, 0.0, 1.0); }";
        private static final String COLOR_FRAGMENT =
                "precision mediump float;\n" +
                "uniform vec4 uColor;\n" +
                "void main(){ gl_FragColor = uColor; }";
    }

    static final class StrokeEvent {
        final int count;
        final float[] x, y, vx, vy;
        RectF bounds = new RectF();
        StrokeEvent partner;
        float age = 0f;
        float life = 3f;
        float seed = 0f;
        float widthScale = 1f;
        float speed = 80f;
        float turn = 0.4f;
        float relation = 0f;
        float visibleWindow = 0.26f;
        float headLead = 0.10f;
        float attractX = 0f;
        float attractY = 0f;
        float attractTargetX = 0f;
        float attractTargetY = 0f;
        float attractVX = 0f;
        float attractVY = 0f;
        float motionSmoothness = 0.72f;
        float closureTendency = 0.22f;
        int bundleLineCount = 5;
        float bundleSpread = 1f;
        float terminalFan = 0.5f;
        int colorA = Color.WHITE;
        int colorB = Color.WHITE;
        int actor = 0;
        // V29 art motif: 0 comet arc, 1 veil ribbon, 2 electronic fan, 3 silver blade,
        // 4 petal hook, 5 prism polygon, 6 falling leaf, 7 long bridge,
        // 8 jellyfish tendril, 9 nebula coil, 10 origami sheet, 11 constellation chain,
        // 12 liquid pod, 13 wing, 14 blossom, 15 silk banner, 16 orbit halo, 17 crystal shard.
        int motif = 0;
        int sceneProgram = 0;
        int colorMood = 0;
        int variant = 0;
        float motifStrength = 1f;
        float flowA = 1f;
        float flowB = 1f;
        float flowC = 1f;
        float asymmetry = 0f;
        boolean fan = false;
        int fanLines = 0;
        float fanGapPx = 3f;
        ShapeDNA dna;
        ArtistDNA artist;

        StrokeEvent(int count) {
            this.count = Math.max(2, count);
            x = new float[this.count]; y = new float[this.count];
            vx = new float[this.count]; vy = new float[this.count];
        }
    }

    static final class ShapeDNA {
        int family = 0;
        int bodySdf = 0;
        int pathType = 0;
        int flowField = 0;
        int colorMood = 0;
        int relationRole = 0;
        int lifeScript = 0;
        int masterTemplate = 0;
        int templateVariant = 0;
        int textureSeed = 0;
        float seed = 0f;
        float aspect = 1f;
        float softness = 1f;
    }

    static final class ArtistDNA {
        int styleFamily = 0;
        int silhouetteLaw = 0;
        int detailDensity = 0;
        int edgeTreatment = 0;
        int innerTexture = 0;
        int rhythmStyle = 0;
        int compositionRole = 0;
        int restraintLevel = 0;
        float beautyScore = 0.72f;
    }

    static final class Config {
        int style = 0;
        float intimacy = 0.72f;
        float randomness = 0.66f;
        float ribbonWidth = 0.62f;
        float trail = 0.90f;
        float fullScreenCoverage = 0.96f;
        float strokeDensity = 0.24f;
        // V41：单个生命形体连续表演时间，默认 6～60 秒；足够表达，但不长时间遮挡桌面。
        float journeyMinSec = 6f;
        float journeyMaxSec = 60f;
        boolean previewAccelerated = false;
        float previewCycleMinutes = 3f;
        boolean debugLoopEnabled = false;
        float debugCycleMinutes = 3f;
        boolean bubbles = false;
        boolean powerSave = false;
        boolean randomCycle = true;
        float cycleMinDays = 1f;
        float cycleMaxDays = 365f;
        float fixedCycleDays = 30f;
        float ratioSeparation = 0.46f;
        float ratioAttraction = 0.22f;
        float ratioSync = 0.22f;
        float ratioCritical = 0.06f;
        float ratioRelease = 0.02f;
        float ratioAfterglow = 0.02f;
        float criticalMinSec = 30f;
        float criticalMaxSec = 180f;
        float releaseMinSec = 8f;
        float releaseMaxSec = 24f;
        float afterglowMinSec = 20f;
        float afterglowMaxSec = 90f;
    }

    static final class CyclePlan {
        float durationSec = 86400f;
        float criticalStartSec = 0f;
        float releaseStartSec = 3600f;
        float releaseDurationSec = 12f;
        float afterglowDurationSec = 24f;
        float criticalDurationSec = 60f;
        private static float cpClamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }
        CyclePlan sanitized() {
            durationSec = Math.max(30f, durationSec);
            releaseDurationSec = cpClamp(releaseDurationSec, 1f, Math.max(1f, durationSec * 0.20f));
            afterglowDurationSec = cpClamp(afterglowDurationSec, 1f, Math.max(1f, durationSec * 0.20f));
            criticalDurationSec = cpClamp(criticalDurationSec, 1f, Math.max(1f, durationSec * 0.35f));
            releaseStartSec = cpClamp(releaseStartSec, 1f, Math.max(1f, durationSec - releaseDurationSec - afterglowDurationSec));
            criticalStartSec = cpClamp(releaseStartSec - criticalDurationSec, 0f, releaseStartSec);
            return this;
        }
    }

    static final class Phase {
        final String name;
        final float start, end, intensity, closeness, tension, relation, pairChance, fanChance;
        Phase(String name, float start, float end, float intensity, float closeness, float tension, float relation, float pairChance, float fanChance) {
            this.name = name;
            this.start = start;
            this.end = end;
            this.intensity = intensity;
            this.closeness = closeness;
            this.tension = tension;
            this.relation = relation;
            this.pairChance = pairChance;
            this.fanChance = fanChance;
        }
        static Phase of(float sec, float durationSec, Config cfg, CyclePlan plan) {
            float releaseStart = plan.releaseStartSec;
            float releaseEnd = releaseStart + plan.releaseDurationSec;
            float afterEnd = releaseEnd + plan.afterglowDurationSec;
            float criticalStart = plan.criticalStartSec;

            if (sec >= releaseStart && sec < releaseEnd) {
                return new Phase("释放", releaseStart, releaseEnd, 1.00f, 1.00f, 0.46f, 1.00f, 0.04f, 0.006f);
            }
            if (sec >= releaseEnd && sec < afterEnd) {
                return new Phase("余韵", releaseEnd, afterEnd, 0.22f, 0.54f, 0.08f, 0.12f, 0.02f, 0.004f);
            }
            if (sec >= criticalStart && sec < releaseStart) {
                return new Phase("临界", criticalStart, releaseStart, 0.96f, 0.92f, 1.00f, 0.92f, 0.16f, 0.025f);
            }
            if (sec >= afterEnd) {
                return new Phase("分离", afterEnd, durationSec, 0.08f, 0.00f, 0.04f, 0.00f, 0.00f, 0.004f);
            }

            float pre = Math.max(1f, criticalStart);
            float sum = Math.max(0.001f, cfg.ratioSeparation + cfg.ratioAttraction + cfg.ratioSync);
            float sepDur = pre * (cfg.ratioSeparation / sum);
            float attrDur = pre * (cfg.ratioAttraction / sum);
            float syncDur = Math.max(0f, pre - sepDur - attrDur);
            float sepEnd = sepDur;
            float attrEnd = sepEnd + attrDur;
            float syncEnd = attrEnd + syncDur;
            if (sec < sepEnd) return new Phase("分离", 0f, sepEnd, 0.08f, 0.00f, 0.04f, 0.00f, 0.00f, 0.004f);
            if (sec < attrEnd) return new Phase("吸引", sepEnd, attrEnd, 0.24f, 0.16f, 0.16f, 0.06f, 0.010f, 0.004f);
            return new Phase("同步", attrEnd, Math.max(attrEnd + 0.001f, syncEnd), 0.56f, 0.58f, 0.52f, 0.58f, 0.11f, 0.010f);
        }
    }
}
