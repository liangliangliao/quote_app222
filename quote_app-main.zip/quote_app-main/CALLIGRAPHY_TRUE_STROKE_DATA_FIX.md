# 书法动态壁纸：真实逐笔书写修复说明

本次修复不再把完整字体当作遮罩做“刮奖式露出”，而是改为按每个汉字的真实笔顺中线（median）逐笔绘制。

## 核心变化

1. Android 动态壁纸 `IntimacyMystifyWallpaperService.java`：
   - 新增 Hanzi Writer / Make Me a Hanzi 字符数据加载逻辑。
   - 首次遇到汉字时从 `hanzi-writer-data` 读取 JSON，解析 `medians`。
   - 每一笔使用 `PathMeasure` 截取当前路径长度，实现真正“一笔正在写出、前一笔保留”。
   - 数据成功后缓存到应用内部目录：`files/calligraphy_hanzi_writer_data/`。
   - 完全移除主书法文字的 `drawText` / `SRC_IN` / `DST_IN` / 完整字形遮罩 reveal。

2. Flutter 预览 `touch_mystify_wallpaper_page.dart`：
   - 保留逐笔路径预览，不再使用完整字形遮罩。
   - 预览侧仍是轻量骨架，最终动态壁纸侧优先使用真实 `medians` 数据。

## 重要说明

- 第一次显示某个新汉字时需要联网下载该字 JSON；下载成功后会缓存，以后离线也可使用该字。
- 若设备无法访问 CDN/GitHub，暂时会使用内置骨架兜底，但不会回退到完整字体刮奖遮罩。
- 若要做到生产级完全离线和所有字立即准确，应把 `hanzi-writer-data` 中需要的 JSON 打包到 `assets` 或 Android `raw/assets` 中，再改为优先从本地读取。
