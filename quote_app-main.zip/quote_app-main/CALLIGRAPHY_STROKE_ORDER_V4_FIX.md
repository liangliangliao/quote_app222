# 书法书写 V4：真笔顺落笔修复

本次修复的目标不是“让完整字体显现”，而是让每个汉字按笔顺逐笔写出。

核心变化：

1. 主书法文字彻底禁止 `drawText`、遮罩 reveal、刮奖式显示和通用随机骨架。
2. 优先使用本地确定性的笔顺数据，不再让网络 medians 异步覆盖已有本地笔顺，避免半途跳变。
3. “大”明确按三笔：横 → 撇 → 捺；每笔由 `PathMeasure` / `PathMetric` 按长度逐步截取显示。
4. 写字节奏放慢为默认约 2 秒一笔，用户能看见“一横写完、停住，再写一撇，再写一捺”。
5. 动态壁纸使用 `configUpdatedAtMs` 作为书写起点；保存、重新落墨或版本升级后都会从空白重新开始写，避免打开时直接处于完成态，看起来像打印。
6. 行书/草书不再随机扭曲笔画或自动连线，避免乱写乱画、重影、刮奖感。
7. `versionCode` 已提升，减少安装时旧 APK/旧动态壁纸服务未更新导致“没有任何效果”的概率。

重点文件：

- `lib/pages/touch_mystify_wallpaper_page.dart`
- `android/app/src/main/java/com/example/quote_app/wallpaper/IntimacyMystifyWallpaperService.java`
- `android/app/src/main/kotlin/com/example/quote_app/IntimacyWallpaperChannel.kt`
