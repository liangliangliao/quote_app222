# 书法书写 V5：真笔顺数据离线化 + 变宽笔痕 + 行书/草书牵丝

本次修复针对两个问题：

1. 书法书写效果不像“书法家用钢笔/毛笔在纸上写字”，笔画是固定宽度的双层线条，
   没有起笔、行笔提按、收笔出锋的粗细变化；自定义/AI 生成的诗词名句里，绝大多数
   汉字不在内置的 28 字笔顺表里，依赖联网下载 hanzi-writer-data，国内网络大概率
   失败，导致这些字根本写不出来或形状不对，看起来“乱写乱画”。
2. 行书、草书风格和楷书几乎一样（V2 之后只剩下笔画粗细、圆角的差别），没有牵丝
   连笔、整体倾斜等行书/草书的标志性特征，因此“不标准”。

## 参考方案

笔顺数据来自 [Make Me a Hanzi](https://github.com/skishore/makemeahanzi)（即
`hanzi-writer-data` 的数据源），这是该领域的事实标准开源数据集，此前 V4 已经在
用它做“联网兜底”，本次把它离线化、扩大到几乎全部常用汉字。

行书/草书的“牵丝连笔、整体倾斜、出锋更明显、几乎一笔带过”等处理方式，是中文
书法中行书/草书相对楷书的公认基本特征（笔断意连、字势欹侧、用笔提按变化），
本次以这些特征为依据对同一套笔顺骨架做有依据的、确定性的变换，而不是随机扭曲
坐标——既区别于楷书，又不会变成“乱写乱画”。

## 核心变化

### 1. 离线真笔顺数据集（双端共用）

- 新增 `assets/calligraphy/hanzi_medians.txt`（同时拷贝到
  `android/app/src/main/assets/calligraphy/hanzi_medians.txt`），约 5MB，
  收录 **9565 个汉字**的标准笔顺中线坐标（medians，1024 见方，y 轴向上），
  自定义文本格式：`字\t笔画1|笔画2|...`，每个笔画为 `x1,y1;x2,y2;...`。
- Flutter 预览（`touch_mystify_wallpaper_page.dart`）新增 `_HanziMedianStore`，
  在 `initState` 中后台 isolate 解析并缓存；解析完成后刷新一次预览。
- Android 动态壁纸（`IntimacyMystifyWallpaperService.java`）新增
  `loadBundledHanziMedians()`，在渲染线程启动时一次性读取并并入
  `hanziMediansCache`，之后逐字查表，**绝大多数汉字不再依赖联网下载**。
- `drawAnimatedCalligraphyGlyph` / `_paintGlyphStrokeByStroke` 现在优先使用这份
  离线 medians；内置的 28 字手工笔顺与联网下载仅作为资产缺失时的兜底，
  不再影响正常路径。
- `strokeCountForCodePoint` / `_calligraphyStrokeUnitCount` 同步改为优先读取
  medians 的笔画数，书写节奏（“一笔一画停顿”）从一开始就按真实笔画数计算，
  不会因为数据来源变化而中途跳变。

### 2. 变宽“笔痕”渲染（双端新增 `drawBrushStroke` / `_drawBrushStroke`）

不再用固定宽度的 `Paint.Style.STROKE` 画线，改为：

- 沿笔画中线采样若干点，按“起笔藏锋（偏细）→ 行笔提按（接近满宽，带轻微自然
  起伏）→ 收笔出锋”的包络函数计算每个采样点的宽度；
- 楷书收笔偏顿（接近满宽），行书/草书出锋更明显（收笔变细，几乎收尖）；
- 左右各按半宽偏移中线，拼成一个填充多边形，即“笔痕”本体；额外叠一层放大
  1.35 倍、低透明度的轮廓做“湿墨边缘”；
- 正在书写中的这一笔，末端再额外收细，表现“墨迹刚落下”的笔锋感，
  替代了原来单独叠加的发光笔尖（`drawCalligraphyBrushTip`，已移除）。

### 3. 行书 / 草书：牵丝连笔 + 整体倾斜（双端新增 `drawGlyphFromStrokePaths` /
   `_drawGlyphFromStrokePaths`）

- **整体倾斜**：`pathFromHanziMedian` / `_pathFromMedianPoints` 对行书
  （错切系数 0.06）、草书（0.115）施加以字格中线为轴的统一横向错切，
  楷书不变。只改变整字的“姿态”，不改变笔顺骨架。
- **牵丝连笔**：楷书笔笔独立；行书在相邻两笔之间，当收笔点到下一笔起笔点的
  距离不太远时（< 字宽 42%），补一条很细（笔宽 20%）、两端尖细的弧线连笔，
  在当前笔写到 72%~100% 时逐渐显现；草书的连笔更明显（笔宽 50%，距离阈值放宽
  到字宽 95%），从 55% 进度起就开始连笔，几乎一笔带过。

### 4. 清理

- 移除已不再使用的旧版固定宽度笔画绘制（`drawOneCalligraphyStroke`）、
  发光笔尖（`drawCalligraphyBrushTip`）、`partialPath`，以及更早版本遗留、
  从未被调用的字间连线函数（`drawCalligraphyLigature`、`quadratic`）。
- Dart 侧对应移除 `_paintOneVisibleStroke`、`_paintBrushTip`、
  `_extractPartialPath`、未使用的 `_paintLigature`。
- `CALLIGRAPHY_ENGINE_VERSION` 4 → 5，`versionCode` 16 → 17 / `versionName`
  1.0.4 → 1.0.5，确保旧版本动态壁纸服务被升级覆盖。

## 重点文件

- `assets/calligraphy/hanzi_medians.txt`（新增，Flutter 资产）
- `android/app/src/main/assets/calligraphy/hanzi_medians.txt`（新增，Android 资产）
- `lib/pages/touch_mystify_wallpaper_page.dart`
- `android/app/src/main/java/com/example/quote_app/wallpaper/IntimacyMystifyWallpaperService.java`
- `pubspec.yaml`（注册新资产，version 0.1.0+5）
- `android/app/build.gradle`（versionCode/versionName）

## 已知取舍

- 草书的“连笔合一”是基于楷书 medians 骨架做牵丝处理，不是逐字的草书专用字形
  数据（公开、可商用的草书字形数据集非常少见）；但牵丝、倾斜、出锋这些处理
  是行书/草书相对楷书的真实区别特征，整体观感应明显区别于楷书，且不会出现
  “乱写乱画”。
- 离线数据集覆盖 9565 个汉字（GB 常用字 + 一部分生僻字），极少数超出范围的字
  仍会触发原有的联网兜底逻辑。
