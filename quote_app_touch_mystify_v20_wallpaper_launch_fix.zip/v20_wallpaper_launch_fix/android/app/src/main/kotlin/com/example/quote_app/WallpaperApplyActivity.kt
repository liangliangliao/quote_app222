package com.example.quote_app

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import com.example.quote_app.wallpaper.IntimacyMystifyWallpaperService

/**
 * Native launcher for Android live-wallpaper system UI.
 *
 * Several OEM systems do not visibly open the system preview when
 * ACTION_CHANGE_LIVE_WALLPAPER is launched directly from FlutterActivity,
 * even though startActivity() returns normally. This tiny native activity
 * makes the transition explicit and tries multiple system entry points.
 */
class WallpaperApplyActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        launchWallpaperUi()
    }

    private fun launchWallpaperUi() {
        val component = ComponentName(this, IntimacyMystifyWallpaperService::class.java)
        val attempts = listOf(
            Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
            },
            Intent("android.service.wallpaper.CHANGE_LIVE_WALLPAPER").apply {
                putExtra("android.service.wallpaper.extra.LIVE_WALLPAPER_COMPONENT", component)
            },
            Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER),
            Intent(Settings.ACTION_WALLPAPER_SETTINGS),
            Intent(Intent.ACTION_SET_WALLPAPER)
        )

        var lastError: Throwable? = null
        for (intent in attempts) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                // Do not use resolveActivity as a hard gate: Android 11+ package visibility
                // and some OEM launchers can return null even when startActivity succeeds.
                startActivity(intent)
                finish()
                overridePendingTransition(0, 0)
                return
            } catch (t: Throwable) {
                lastError = t
            }
        }

        Toast.makeText(
            this,
            "无法打开系统壁纸页面：${lastError?.message ?: "设备不支持动态壁纸入口"}",
            Toast.LENGTH_LONG
        ).show()
        finish()
        overridePendingTransition(0, 0)
    }
}
